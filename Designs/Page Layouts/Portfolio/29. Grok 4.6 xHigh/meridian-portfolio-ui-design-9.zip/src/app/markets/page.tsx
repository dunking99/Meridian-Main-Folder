import { Plate } from "@/components/plate";
import { Spark } from "@/components/spark";
import { getBook } from "@/lib/queries";
import { formatPct } from "@/lib/format";

export default async function MarketsPage() {
  const book = await getBook();
  return (
    <div className="px-4 py-6 md:px-10 md:py-8">
      <p className="kicker">The field</p>
      <h2 className="font-display text-5xl tracking-tight">A quiet board</h2>
      <p className="mt-3 max-w-xl text-mist">
        The indices the book is measured against, plus the dollar, the ten-year, and fear.
      </p>
      <div className="mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {book.markets.map((m) => (
          <Plate key={m.symbol}>
            <p className="kicker">{m.symbol}</p>
            <p className="font-display mt-2 text-2xl">{m.name}</p>
            <p className="font-display mt-4 text-3xl">{m.last.toLocaleString()}</p>
            <p className={`font-mono text-sm ${m.changePct >= 0 ? "num-up" : "num-down"}`}>{formatPct(m.changePct)}</p>
            <div className="mt-4">
              <Spark data={m.history} color="auto" width={200} height={48} />
            </div>
          </Plate>
        ))}
      </div>
    </div>
  );
}
