import Link from "next/link";

export default function NotFound() {
  return (
    <div className="grid min-h-[70vh] place-items-center px-6">
      <div className="text-center">
        <p className="kicker text-meridian">Off the map</p>
        <h1 className="font-display mt-3 text-6xl">This meridian is empty</h1>
        <p className="mt-3 text-mist">The name is not in the book.</p>
        <Link href="/portfolio" className="mt-6 inline-block font-mono text-[12px] tracking-[0.16em] text-meridian">
          ← RETURN TO THE BOOK
        </Link>
      </div>
    </div>
  );
}
