import { Plate } from "@/components/plate";
import { getBook } from "@/lib/queries";

export default async function JournalPage() {
  const book = await getBook();
  return (
    <div className="px-4 py-6 md:px-10 md:py-8">
      <p className="kicker">The notes</p>
      <h2 className="font-display text-5xl tracking-tight">Investment journal</h2>
      <p className="mt-3 max-w-xl text-mist">
        Why a line was added, trimmed, or left alone. The book without the diary is just a tape.
      </p>
      <div className="mt-8 space-y-4">
        {book.journal.map((j) => (
          <Plate key={j.date + j.title}>
            <p className="kicker">
              {j.date} · {j.mood}
            </p>
            <h3 className="font-display mt-2 text-3xl">{j.title}</h3>
            <p className="mt-3 max-w-2xl text-[15px] leading-relaxed text-moon/85">{j.body}</p>
          </Plate>
        ))}
      </div>
    </div>
  );
}
