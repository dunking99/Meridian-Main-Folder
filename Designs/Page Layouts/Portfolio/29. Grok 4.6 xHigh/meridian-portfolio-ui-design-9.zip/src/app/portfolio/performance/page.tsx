import type { ReactNode } from "react";
import { Plate } from "@/components/plate";
import { Money } from "@/components/currency";
import { DrawdownTrench, MountainChart } from "@/components/viz-mountain";
import { ArcMeter, Scorecard } from "@/components/viz-instruments";
import {
  CaptureTubes,
  MercuryCalendar,
  Ridgeline,
  TrailingLadders,
} from "@/components/viz-analysis";
import { getBook } from "@/lib/queries";
import { performanceBundle, trailing } from "@/lib/metrics";
import { formatPct } from "@/lib/format";

export default async function PerformancePage() {
  const book = await getBook();
  const m = performanceBundle(book.months, book.nav);
  const ladders = [
    { label: "1 month", ...trailing(book.months, 1) },
    { label: "3 month", ...trailing(book.months, 3) },
    { label: "YTD", ...trailing(book.months.filter((x) => x.year === 2026), 12) },
    { label: "1 year", ...trailing(book.months, 12) },
    { label: "3 year", ...trailing(book.months, 36) },
    { label: "Since inception", ...trailing(book.months, 999) },
  ];
  const years = [...new Set(book.months.map((x) => x.year))];
  const yearCards = years.map((y) => {
    const row = book.months.filter((x) => x.year === y);
    const p = row.reduce((s, x) => s * (1 + x.portfolioRet / 100), 1) - 1;
    const b = row.reduce((s, x) => s * (1 + x.benchmarkRet / 100), 1) - 1;
    return { y, p: p * 100, b: b * 100 };
  });

  return (
    <div className="space-y-6">
      <Plate index="21" title="Cumulative wealth" kicker="The mountain is the book. The dashed violet is ACWI, rebased as a ghost.">
        <MountainChart nav={book.nav} />
      </Plate>

      <div className="grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
        <Plate index="22" title="Trailing returns" kicker="Ladders from the meridian. Lime is the book, violet the world.">
          <TrailingLadders rows={ladders} />
        </Plate>
        <Plate index="23" title="Capture tubes" kicker="Mercury of participation. Above 100 means we take more than the market’s move.">
          <CaptureTubes up={m.upCap} down={m.dnCap} />
        </Plate>
      </div>

      <Plate index="24" title="Monthly mercury" kicker="Each cell is a thermometer, not a heatmap tile. Year column compounds the row.">
        <MercuryCalendar months={book.months} />
      </Plate>

      <div className="grid gap-6 lg:grid-cols-2">
        <Plate index="25" title="Drawdown trench" kicker="Looking down from peak. The surface is the meridian — underwater is violet.">
          <DrawdownTrench nav={book.nav} />
        </Plate>
        <Plate index="26" title="Return weather" kicker="Ridgeline of monthly returns. The meridian is zero.">
          <Ridgeline months={book.months} />
          <dl className="mt-6 grid grid-cols-3 gap-4">
            <Mini label="Best month" value={formatPct(m.best)} up />
            <Mini label="Worst month" value={formatPct(m.worst)} />
            <Mini label="Hit rate" value={`${m.hit.toFixed(0)}%`} up />
            <Mini label="Skew" value={m.skew.toFixed(2)} />
            <Mini label="Kurtosis" value={m.kurt.toFixed(2)} />
            <Mini label="95% month" value={formatPct(m.var95)} />
          </dl>
        </Plate>
      </div>

      <Plate index="27" title="Instrument cluster" kicker="Risk-adjusted numbers as subdials. Not a spreadsheet with rounded corners.">
        <Scorecard
          items={[
            { label: "Sharpe", value: m.sharpe, max: 2.2, color: "#7DF0E8", note: "excess / vol" },
            { label: "Sortino", value: m.sortino, max: 3, color: "#C6F26D", note: "downside only" },
            { label: "Calmar", value: m.calmar, max: 2.5, color: "#B4A5FF", note: "CAGR / max DD" },
            { label: "Info ratio", value: m.info, max: 1.5, color: "#E7C9A0", note: "alpha / TE" },
          ]}
        />
      </Plate>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Plate>
          <ArcMeter label="CAGR" value={m.cg} max={20} suffix="%" color="#7DF0E8" hint={`${m.years.toFixed(1)} years`} />
        </Plate>
        <Plate>
          <ArcMeter label="Vol" value={m.vol} max={25} suffix="%" color="#E7C9A0" hint={`ACWI ${m.bmVol.toFixed(1)}%`} />
        </Plate>
        <Plate>
          <ArcMeter label="Max DD" value={Math.abs(m.maxDd)} max={40} suffix="%" color="#FF6A4A" hint="peak to trough" />
        </Plate>
        <Plate>
          <ArcMeter label="Tracking" value={m.te} max={12} suffix="%" color="#B4A5FF" hint="annualised TE" />
        </Plate>
      </div>

      <Plate index="28" title="Calendar years" kicker="Each year is a plate. Excess versus ACWI sits in the kicker.">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {yearCards.map((y) => (
            <div key={y.y} className="hairline bg-ink/60 px-4 py-4">
              <p className="kicker">{y.y}</p>
              <p className={`font-display text-3xl ${y.p >= 0 ? "num-up" : "num-down"}`}>{formatPct(y.p)}</p>
              <p className="mt-1 font-mono text-[11px] text-mist">
                ACWI {formatPct(y.b)} · excess {formatPct(y.p - y.b)}
              </p>
            </div>
          ))}
        </div>
      </Plate>

      <Plate index="29" title="More of the engine room" kicker="The unglamorous ratios that still change how you sit in the chair.">
        <div className="grid grid-cols-2 gap-6 md:grid-cols-4">
          <Mini label="Alpha (ann.)" value={formatPct(m.alpha)} up={m.alpha >= 0} />
          <Mini label="Gain/loss" value={m.gainLoss.toFixed(2)} up />
          <Mini label="Ulcer index" value={m.ulcer.toFixed(1)} />
          <Mini label="Beta (book)" value={book.totals.beta.toFixed(2)} />
          <Mini label="NAV start" value={<Money usd={book.nav[0]?.nav ?? 0} compact />} />
          <Mini label="NAV now" value={<Money usd={book.totals.nav} compact />} />
          <Mini label="Unrealised" value={formatPct(book.totals.unrealizedPct)} up={book.totals.unrealizedPct >= 0} />
          <Mini label="Yield" value={`${book.totals.yield.toFixed(2)}%`} />
        </div>
      </Plate>
    </div>
  );
}

function Mini({
  label,
  value,
  up,
}: {
  label: string;
  value: ReactNode;
  up?: boolean;
}) {
  return (
    <div>
      <p className="kicker">{label}</p>
      <p className={`font-display mt-1 text-2xl ${up ? "num-up" : up === false ? "num-down" : ""}`}>{value}</p>
    </div>
  );
}
