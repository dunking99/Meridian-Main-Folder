import { Plate } from "@/components/plate";
import { Scorecard } from "@/components/viz-instruments";
import {
  CorrelationQuilt,
  CurrencyWheel,
  FactorCompass,
  FundOverlap,
  HomeBias,
  OrbitScatter,
  ScenarioBars,
  SectorButterfly,
} from "@/components/viz-analysis";
import { WeightRibbon } from "@/components/viz-mosaic";
import { getBook } from "@/lib/queries";

export default async function AnalysisPage() {
  const book = await getBook();
  const corrSymbols = [...new Set(book.correlations.flatMap((c) => [c.symbolA, c.symbolB]))];
  const herfindahl = book.holdings.reduce((s, h) => s + (h.weight / 100) ** 2, 0);
  const effectiveN = herfindahl ? 1 / herfindahl : 0;
  const top5 = book.holdings.slice(0, 5).reduce((s, h) => s + h.weight, 0);
  const singleName = book.holdings[0]?.weight ?? 0;
  const us = book.holdings.filter((h) => h.countryCode === "US").reduce((s, h) => s + h.weight, 0);

  return (
    <div className="space-y-6">
      <Plate index="31" title="Scorecard" kicker="Four subdials. Health of the construction, not the tape.">
        <Scorecard
          items={[
            { label: "Balance", value: 68, color: "#7DF0E8", note: "vs a 60/40 world" },
            { label: "Crowd", value: 41, color: "#E7C9A0", note: "lower is more unique" },
            { label: "Resilience", value: 74, color: "#C6F26D", note: "liquidity + ballast" },
            { label: "Discipline", value: 81, color: "#B4A5FF", note: "drift vs policy weights" },
          ]}
        />
      </Plate>

      <div className="grid gap-6 lg:grid-cols-2">
        <Plate index="32" title="Sector butterfly" kicker="The book on the left, ACWI on the right. Asymmetry is the tell.">
          <SectorButterfly holdings={book.holdings} />
        </Plate>
        <Plate index="33" title="Risk versus return" kicker="Orbits, not a default bubble chart. X is beta, Y is ninety-day path, radius is weight. Dashed arc is a sketch of the frontier.">
          <OrbitScatter holdings={book.holdings} />
        </Plate>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
        <Plate index="34" title="Correlation quilt" kicker="Upper triangle only. Hover a ticker — the rest of the sky goes dark.">
          <CorrelationQuilt symbols={corrSymbols} values={book.correlations} />
        </Plate>
        <Plate index="35" title="Home bias" kicker="Two rings. How much of the sky is your own country.">
          <HomeBias holdings={book.holdings} />
        </Plate>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Plate index="36" title="Currency exposure" kicker="Listing currency, not revenue. Look-through would light Europe more.">
          <CurrencyWheel holdings={book.holdings} />
        </Plate>
        <Plate index="37" title="Factor compass" kicker="Loadings versus ACWI (violet). The book is a growth-quality kite.">
          <FactorCompass factors={book.factors} />
        </Plate>
      </div>

      <Plate index="38" title="Fund overlap" kicker="QQQ, VTI, VXUS versus names we already own. Lit cells are double-counted economic exposure.">
        <FundOverlap overlaps={book.overlaps} holdings={book.holdings} />
      </Plate>

      <div className="grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
        <Plate index="39" title="Concentration spine" kicker="Effective bets, not a Herfindahl footnote.">
          <div className="space-y-6">
            <Big n={effectiveN.toFixed(1)} label="effective names" hint="1 / HHI" />
            <Big n={`${top5.toFixed(0)}%`} label="top five" hint="weight in five names" />
            <Big n={`${singleName.toFixed(1)}%`} label="largest line" hint={book.holdings[0]?.symbol} />
            <Big n={`${us.toFixed(0)}%`} label="United States" hint="direct listing" />
            <div className="h-3 overflow-hidden bg-white/5">
              {book.holdings.slice(0, 12).map((h) => (
                <span
                  key={h.symbol}
                  className="inline-block h-full"
                  style={{ width: `${h.weight}%`, background: h.color, opacity: 0.85 }}
                />
              ))}
            </div>
          </div>
        </Plate>
        <Plate index="40" title="Scenarios" kicker="Not forecasts. Shocks, with a signed scar on NAV.">
          <ScenarioBars rows={book.scenarios} />
        </Plate>
      </div>

      <Plate index="41" title="Exposure by kind" kicker="One more core sample, because the mix is the policy.">
        <WeightRibbon holdings={book.holdings} groupBy="assetClass" />
      </Plate>
    </div>
  );
}

function Big({ n, label, hint }: { n: string; label: string; hint?: string }) {
  return (
    <div>
      <p className="font-display text-4xl leading-none">{n}</p>
      <p className="kicker mt-1">
        {label}
        {hint ? ` · ${hint}` : ""}
      </p>
    </div>
  );
}
