import type { ReactNode } from "react";
import Link from "next/link";
import { notFound } from "next/navigation";
import type { Holding } from "@/lib/types";
import { Plate } from "@/components/plate";
import { Money } from "@/components/currency";
import { EventsRail, NewsRail } from "@/components/tape";
import { Spark } from "@/components/spark";
import { ArcMeter } from "@/components/viz-instruments";
import { getBook, getHolding } from "@/lib/queries";
import { formatPct } from "@/lib/format";

export default async function HoldingPage({ params }: { params: Promise<{ symbol: string }> }) {
  const { symbol } = await params;
  const row = await getHolding(symbol);
  if (!row) notFound();
  const book = await getBook();
  const news = book.news.filter((n) => n.symbol === row.symbol);
  const events = book.events.filter((e) => e.symbol === row.symbol);
  const peers = book.holdings.filter((h) => h.sector === row.sector && h.symbol !== row.symbol).slice(0, 5);
  const hist = row.priceHistory;
  const pathRet = hist.length > 1 ? ((hist[hist.length - 1] - hist[0]) / hist[0]) * 100 : 0;

  return (
    <div className="space-y-6">
      <div className="relative overflow-hidden pb-4">
        <div className="pointer-events-none absolute inset-y-0 left-[22%] w-px meridian-rule" />
        <Link href="/portfolio/holdings" className="kicker text-meridian">
          ← The ledger
        </Link>
        <p className="mt-3 font-mono text-sm tracking-[0.2em] text-mist">{row.symbol}</p>
        <h2 className="font-display text-[clamp(3rem,8vw,5.5rem)] leading-[0.9] tracking-[-0.04em]">{row.name}</h2>
        <div className="mt-4 flex flex-wrap items-end gap-8">
          <div>
            <p className="kicker">Last</p>
            <p className="font-display text-4xl">{row.lastPrice.toFixed(2)}</p>
            <p className={`font-mono text-sm ${row.dayChangePct >= 0 ? "num-up" : "num-down"}`}>
              {formatPct(row.dayChangePct)} session
            </p>
          </div>
          <div>
            <p className="kicker">Line in the book</p>
            <p className="font-display text-4xl">
              <Money usd={row.marketValue} />
            </p>
            <p className="font-mono text-[12px] text-mist">{row.weight.toFixed(2)}% of NAV</p>
          </div>
          <Spark data={hist} color="auto" width={220} height={72} />
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.2fr_0.8fr]">
        <Plate index="H1" title="The thesis" kicker={`${row.industry} · ${row.country} · ${row.currency}`}>
          <p className="max-w-2xl text-lg leading-relaxed text-moon/90">{row.thesis}</p>
          <dl className="mt-8 grid grid-cols-2 gap-6 md:grid-cols-4">
            <Cell label="Quantity" value={row.quantity.toFixed(row.kind === "cash" ? 0 : 2)} />
            <Cell label="Avg cost" value={row.avgCost.toFixed(2)} />
            <Cell label="Unrealised" value={formatPct(row.unrealizedPct)} tone={row.unrealizedPct >= 0 ? "up" : "down"} />
            <Cell label="Day P&L" value={<Money usd={row.dayPnl} />} tone={row.dayPnl >= 0 ? "up" : "down"} />
          </dl>
        </Plate>
        <Plate index="H2" title="Ninety sessions" kicker={`${formatPct(pathRet)} along the filament`}>
          <Spark data={hist} color="#7DF0E8" width={420} height={140} />
          <p className="mt-3 font-mono text-[11px] text-mist">Not a trading chart. A memory of how we sat with it.</p>
        </Plate>
      </div>

      <Plate index="H3" title="Engraved fundamentals" kicker="Needles, not a factset dump.">
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          <ArcMeter label="Beta" value={row.beta} max={2} color="#7DF0E8" hint="vs the world" />
          <ArcMeter
            label="P/E"
            value={row.peRatio ?? 0}
            max={60}
            color="#B4A5FF"
            hint={row.peRatio ? "trailing" : "not meaningful"}
          />
          <ArcMeter label="Yield" value={row.dividendYield} max={5} suffix="%" color="#E7C9A0" hint="gross" />
          <ArcMeter
            label="Weight"
            value={row.weight}
            max={20}
            suffix="%"
            color="#C6F26D"
            hint={row.sector}
          />
        </div>
      </Plate>

      <div className="grid gap-6 lg:grid-cols-2">
        <Plate index="H4" title="Place in the book" kicker="How much of the sector and of the country this line is carrying.">
          <Place row={row} bookW={book.holdings} />
        </Plate>
        <Plate index="H5" title="Sector companions" kicker="Other names in the same mineral.">
          <ul className="divide-y divide-white/5">
            {peers.map((p) => (
              <li key={p.symbol} className="flex items-center justify-between py-3">
                <Link href={`/portfolio/holdings/${p.symbol}`} className="font-mono text-sm text-meridian">
                  {p.symbol}
                  <span className="ml-2 text-moon">{p.name}</span>
                </Link>
                <span className="font-mono text-[12px] text-mist">{p.weight.toFixed(1)}%</span>
              </li>
            ))}
            {peers.length === 0 ? <li className="text-mist">A lone name in its sector.</li> : null}
          </ul>
        </Plate>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Plate index="H6" title="Tape for this name">
          {news.length ? <NewsRail news={news} /> : <p className="text-mist">Quiet tape.</p>}
        </Plate>
        <Plate index="H7" title="Calendar">
          {events.length ? <EventsRail events={events} /> : <p className="text-mist">No near events booked.</p>}
        </Plate>
      </div>
    </div>
  );
}

function Cell({
  label,
  value,
  tone,
}: {
  label: string;
  value: React.ReactNode;
  tone?: "up" | "down";
}) {
  return (
    <div>
      <p className="kicker">{label}</p>
      <p className={`font-display mt-1 text-2xl ${tone === "up" ? "num-up" : tone === "down" ? "num-down" : ""}`}>
        {value}
      </p>
    </div>
  );
}

function Place({
  row,
  bookW,
}: {
  row: Holding;
  bookW: Holding[];
}) {
  if (!row) return null;
  const sector = bookW.filter((h) => h.sector === row.sector).reduce((s, h) => s + h.weight, 0);
  const country = bookW.filter((h) => h.country === row.country).reduce((s, h) => s + h.weight, 0);
  const shareS = sector ? (row.weight / sector) * 100 : 0;
  const shareC = country ? (row.weight / country) * 100 : 0;
  return (
    <div className="space-y-5">
      <Bar label={`of ${row.sector}`} value={shareS} />
      <Bar label={`of ${row.country}`} value={shareC} />
      <Bar label="of the whole book" value={row.weight} />
      {row.marketCapBn ? (
        <p className="font-mono text-[12px] text-mist">Market cap {row.marketCapBn.toFixed(0)}bn · {row.kind}</p>
      ) : (
        <p className="font-mono text-[12px] text-mist">{row.kind}</p>
      )}
    </div>
  );
}

function Bar({ label, value }: { label: string; value: number }) {
  return (
    <div>
      <div className="mb-1 flex justify-between font-mono text-[11px]">
        <span className="text-mist">{label}</span>
        <span>{value.toFixed(1)}%</span>
      </div>
      <div className="h-2 bg-white/5">
        <div className="h-full bg-meridian" style={{ width: `${Math.min(100, value)}%` }} />
      </div>
    </div>
  );
}
