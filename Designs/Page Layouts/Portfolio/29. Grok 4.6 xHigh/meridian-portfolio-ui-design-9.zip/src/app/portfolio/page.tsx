import type { ReactNode } from "react";
import { Plate } from "@/components/plate";
import { Money } from "@/components/currency";
import { EventsRail, NewsRail } from "@/components/tape";
import {
  CompassRose,
  HealthRings,
  HeroNav,
  PulseVitals,
} from "@/components/viz-instruments";
import { MountainChart } from "@/components/viz-mountain";
import {
  AttributionCascade,
  BookShape,
  LeadersLaggards,
  WeightRibbon,
} from "@/components/viz-mosaic";
import { HoldingsTable } from "@/components/holdings-table";
import { Spark } from "@/components/spark";
import { getBook } from "@/lib/queries";
import { formatPct } from "@/lib/format";

export default async function OverviewPage() {
  const book = await getBook();
  const { holdings, totals, portfolio } = book;
  const top10 = holdings.slice(0, 10).reduce((s, h) => s + h.weight, 0);
  const eq = holdings.filter((h) => h.assetClass === "Equity").reduce((s, h) => s + h.weight, 0);
  const tech = holdings.filter((h) => h.sector === "Technology").reduce((s, h) => s + h.weight, 0);
  const income = holdings.reduce((s, h) => s + (h.marketValue * h.dividendYield) / 100, 0);

  return (
    <div className="space-y-6">
      <HeroNav
        nav={totals.nav}
        dayPct={totals.dayPct}
        dayPnl={totals.dayPnl}
        inception={portfolio.inceptionDate}
      />

      <PulseVitals
        items={[
          { label: "Breadth", value: `${holdings.filter((h) => h.dayChangePct > 0).length}/${holdings.length}`, hint: "names green today", tone: "up" },
          { label: "Vol regime", value: "Calm", hint: "realised 11.4% vs 14.8 VIX", tone: "flat" },
          { label: "Concentration", value: `${top10.toFixed(0)}%`, hint: "top ten of the book", tone: "warn" },
          { label: "Beta", value: totals.beta.toFixed(2), hint: "vs ACWI, weighted", tone: "flat" },
          { label: "Liquidity", value: "1.8d", hint: "days to exit 95% of book", tone: "up" },
          { label: "Drift", value: formatPct(totals.dayPct), hint: "session P&L on NAV", tone: totals.dayPct >= 0 ? "up" : "down" },
        ]}
      />

      <div className="grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
        <Plate index="01" title="Twin instruments" kicker="Risk as a compass. Health as nested chapter rings. Neither is a traffic light.">
          <div className="grid gap-4 md:grid-cols-2">
            <CompassRose score={portfolio.riskScore} grade={portfolio.riskGrade} />
            <HealthRings
              score={portfolio.healthScore}
              parts={[
                { label: "Diversification", value: 62, color: "#7DF0E8" },
                { label: "Liquidity", value: 84, color: "#C6F26D" },
                { label: "Drawdown", value: 71, color: "#B4A5FF" },
                { label: "Income", value: 48, color: "#E7C9A0" },
              ]}
            />
          </div>
        </Plate>
        <Plate index="02" title="Shape of the book" kicker="Asset class, then sector, then names — a skeleton movement, not a pie.">
          <BookShape holdings={holdings} />
        </Plate>
      </div>

      <Plate index="03" title="The path" kicker="Topography of wealth versus a ghost of ACWI. Scrub the ridge.">
        <MountainChart nav={book.nav} />
      </Plate>

      <Plate index="04" title="Allocation at a glance" kicker="A core sample of the book. Mineral strata, not a legend-first pie.">
        <WeightRibbon holdings={holdings} groupBy="assetClass" />
        <div className="mt-6">
          <WeightRibbon holdings={holdings} groupBy="sector" />
        </div>
      </Plate>

      <div className="grid gap-6 lg:grid-cols-2">
        <Plate index="05" title="Leaders & laggards" kicker="Today’s tide. Click through to the name.">
          <LeadersLaggards holdings={holdings} />
        </Plate>
        <Plate index="06" title="What moved the book" kicker="Session P&L cascading from the meridian.">
          <AttributionCascade holdings={holdings} />
        </Plate>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.35fr_0.65fr]">
        <Plate index="07" title="Top of the book" kicker="Weight, path, and carry. The full tessera lives under Holdings.">
          <HoldingsTable holdings={holdings.slice(0, 12)} />
        </Plate>
        <div className="space-y-6">
          <Plate index="08" title="Upcoming passes" kicker="Earnings, coupons, and the Fed — a satellite schedule.">
            <EventsRail events={book.events.slice(0, 7)} />
          </Plate>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.2fr_0.8fr]">
        <Plate index="09" title="Relevant tape" kicker="News that actually touches the names we own.">
          <NewsRail news={book.news.slice(0, 7)} />
        </Plate>
        <Plate index="10" title="Quiet numbers" kicker="The ones that don’t need a chart.">
          <dl className="grid grid-cols-2 gap-y-6">
            <Stat label="Equity sleeve" value={`${eq.toFixed(1)}%`} />
            <Stat label="Technology" value={`${tech.toFixed(1)}%`} />
            <Stat label="Unrealised" value={<Money usd={totals.unrealized} />} tone={totals.unrealized >= 0 ? "up" : "down"} />
            <Stat label="Unrealised %" value={formatPct(totals.unrealizedPct)} tone={totals.unrealizedPct >= 0 ? "up" : "down"} />
            <Stat label="Gross yield" value={`${totals.yield.toFixed(2)}%`} />
            <Stat label="Income run-rate" value={<Money usd={income} compact />} />
            <Stat label="Positions" value={String(totals.positions)} />
            <Stat label="Benchmark" value={portfolio.benchmark} />
          </dl>
          <div className="mt-8">
            <p className="kicker mb-2">ACWI ghost, last ninety</p>
            <Spark data={book.nav.slice(-90).map((n) => n.benchmark)} color="#B4A5FF" width={280} height={64} />
          </div>
        </Plate>
      </div>
    </div>
  );
}

function Stat({
  label,
  value,
  tone,
}: {
  label: string;
  value: ReactNode;
  tone?: "up" | "down";
}) {
  return (
    <div>
      <dt className="kicker">{label}</dt>
      <dd
        className={`font-display mt-1 text-2xl ${
          tone === "up" ? "num-up" : tone === "down" ? "num-down" : "text-moon"
        }`}
      >
        {value}
      </dd>
    </div>
  );
}
