import type { ReactNode } from "react";
import { CurrencySwitch } from "@/components/currency";
import { PortfolioSubnav } from "@/components/shell";
import { getBook } from "@/lib/queries";

export default async function PortfolioLayout({ children }: { children: ReactNode }) {
  const book = await getBook();
  return (
    <div className="px-4 py-6 md:px-10 md:py-8">
      <div className="mb-8 flex flex-wrap items-end justify-between gap-4 border-b border-white/8 pb-4">
        <div>
          <p className="kicker">Observatory</p>
          <h2 className="font-display text-3xl tracking-tight">{book.portfolio.name}</h2>
        </div>
        <div className="flex flex-col items-end gap-3">
          <CurrencySwitch />
          <PortfolioSubnav />
        </div>
      </div>
      {children}
    </div>
  );
}
