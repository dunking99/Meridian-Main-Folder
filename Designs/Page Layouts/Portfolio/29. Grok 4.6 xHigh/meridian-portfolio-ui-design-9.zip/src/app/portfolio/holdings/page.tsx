import { Plate } from "@/components/plate";
import { HoldingsTable } from "@/components/holdings-table";
import { ExposureGlobe } from "@/components/viz-globe";
import { HoldingTreemap, WeightRibbon } from "@/components/viz-mosaic";
import { getBook } from "@/lib/queries";
import { regionWeights } from "@/lib/metrics";

export default async function HoldingsPage() {
  const book = await getBook();
  const regions = regionWeights(book.holdings);
  const maxR = Math.max(...regions.map((r) => r.value), 1);

  return (
    <div className="space-y-6">
      <Plate index="11" title="Weight ribbon" kicker="Every name as a stratum. Geography in the second core.">
        <WeightRibbon holdings={book.holdings} groupBy="sector" />
        <div className="mt-6">
          <WeightRibbon holdings={book.holdings} groupBy="region" />
        </div>
      </Plate>

      <Plate index="12" title="Tessera" kicker="Toggle heat for winners and losers, or mineral colour for sector. Click a tile.">
        <HoldingTreemap holdings={book.holdings} />
      </Plate>

      <div className="grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
        <Plate index="13" title="Where the book lives" kicker="A spinning instrument, not a choropleth. Prime meridian lit. Drag it.">
          <ExposureGlobe holdings={book.holdings} />
        </Plate>
        <Plate index="14" title="Region weights" kicker="Bars as meridians of exposure.">
          <ul className="space-y-4">
            {regions.map((r) => (
              <li key={r.label}>
                <div className="mb-1 flex justify-between font-mono text-[11px]">
                  <span>{r.label}</span>
                  <span className="text-meridian">{r.value.toFixed(1)}%</span>
                </div>
                <div className="h-2 bg-white/5">
                  <div
                    className="h-full"
                    style={{
                      width: `${(r.value / maxR) * 100}%`,
                      background: "linear-gradient(90deg, transparent, #7DF0E8)",
                    }}
                  />
                </div>
              </li>
            ))}
          </ul>
          <p className="mt-6 text-[13px] leading-relaxed text-mist">
            Direct listings sit on the globe. VXUS is booked as international — look-through lives on Analysis.
          </p>
        </Plate>
      </div>

      <Plate index="15" title="The ledger" kicker="Sort, filter, open a name. Paths are ninety sessions of price.">
        <HoldingsTable holdings={book.holdings} />
      </Plate>
    </div>
  );
}
