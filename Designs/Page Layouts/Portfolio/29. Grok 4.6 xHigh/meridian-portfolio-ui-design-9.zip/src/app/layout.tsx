import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Fraunces, Outfit, IBM_Plex_Mono } from "next/font/google";
import { AppShell } from "@/components/shell";
import { CurrencyProvider } from "@/components/currency";
import { getBook } from "@/lib/queries";
import "./globals.css";

const fraunces = Fraunces({
  subsets: ["latin"],
  variable: "--font-display-face",
});

const outfit = Outfit({
  subsets: ["latin"],
  variable: "--font-ui-face",
});

const plex = IBM_Plex_Mono({
  subsets: ["latin"],
  weight: ["400", "500"],
  variable: "--font-mono-face",
});

export const metadata: Metadata = {
  title: "Meridian — The Book",
  description: "A private observatory for a single book of capital.",
};

export const dynamic = "force-dynamic";

export default async function RootLayout({ children }: { children: ReactNode }) {
  const book = await getBook();
  return (
    <html lang="en" className={`${fraunces.variable} ${outfit.variable} ${plex.variable}`}>
      <body className="antialiased">
        <CurrencyProvider fx={book.fx}>
          <AppShell>{children}</AppShell>
        </CurrencyProvider>
      </body>
    </html>
  );
}
