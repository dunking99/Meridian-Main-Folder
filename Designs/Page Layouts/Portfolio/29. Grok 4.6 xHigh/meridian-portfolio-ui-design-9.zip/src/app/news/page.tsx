import { Plate } from "@/components/plate";
import { NewsRail } from "@/components/tape";
import { getBook } from "@/lib/queries";

export default async function NewsPage() {
  const book = await getBook();
  const tags = [...new Set(book.news.map((n) => n.tag))];
  return (
    <div className="px-4 py-6 md:px-10 md:py-8">
      <p className="kicker">The tape</p>
      <h2 className="font-display text-5xl tracking-tight">News that touches the book</h2>
      <p className="mt-3 max-w-xl text-mist">
        Not a firehose. Only items that map onto names, rates, or the dollar we actually sit in.
      </p>
      <div className="mt-6 flex flex-wrap gap-2">
        {tags.map((t) => (
          <span key={t} className="hairline px-3 py-1 font-mono text-[10px] tracking-[0.16em] uppercase text-mist">
            {t}
          </span>
        ))}
      </div>
      <div className="mt-8">
        <Plate>
          <NewsRail news={book.news} />
        </Plate>
      </div>
    </div>
  );
}
