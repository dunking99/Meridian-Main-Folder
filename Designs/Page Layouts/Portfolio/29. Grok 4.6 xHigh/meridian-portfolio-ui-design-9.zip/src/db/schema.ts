import {
  date,
  doublePrecision,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

export const portfolios = pgTable("portfolios", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  baseCurrency: text("base_currency").notNull().default("USD"),
  inceptionDate: date("inception_date").notNull(),
  benchmark: text("benchmark").notNull(),
  riskGrade: text("risk_grade").notNull(),
  riskScore: doublePrecision("risk_score").notNull(),
  healthScore: doublePrecision("health_score").notNull(),
  cashUsd: doublePrecision("cash_usd").notNull(),
});

export const holdings = pgTable("holdings", {
  id: serial("id").primaryKey(),
  portfolioId: integer("portfolio_id").notNull(),
  symbol: text("symbol").notNull(),
  name: text("name").notNull(),
  kind: text("kind").notNull(),
  assetClass: text("asset_class").notNull(),
  sector: text("sector").notNull(),
  industry: text("industry").notNull(),
  country: text("country").notNull(),
  countryCode: text("country_code").notNull(),
  region: text("region").notNull(),
  lat: doublePrecision("lat").notNull(),
  lng: doublePrecision("lng").notNull(),
  currency: text("currency").notNull(),
  quantity: doublePrecision("quantity").notNull(),
  avgCost: doublePrecision("avg_cost").notNull(),
  lastPrice: doublePrecision("last_price").notNull(),
  dayChangePct: doublePrecision("day_change_pct").notNull(),
  beta: doublePrecision("beta").notNull(),
  peRatio: doublePrecision("pe_ratio"),
  dividendYield: doublePrecision("dividend_yield").notNull(),
  marketCapBn: doublePrecision("market_cap_bn"),
  color: text("color").notNull(),
  priceHistory: jsonb("price_history").$type<number[]>().notNull(),
  thesis: text("thesis"),
});

export const navSnapshots = pgTable("nav_snapshots", {
  id: serial("id").primaryKey(),
  portfolioId: integer("portfolio_id").notNull(),
  date: date("date").notNull(),
  nav: doublePrecision("nav").notNull(),
  benchmark: doublePrecision("benchmark").notNull(),
  drawdown: doublePrecision("drawdown").notNull(),
});

export const monthlyReturns = pgTable("monthly_returns", {
  id: serial("id").primaryKey(),
  portfolioId: integer("portfolio_id").notNull(),
  year: integer("year").notNull(),
  month: integer("month").notNull(),
  portfolioRet: doublePrecision("portfolio_ret").notNull(),
  benchmarkRet: doublePrecision("benchmark_ret").notNull(),
});

export const newsItems = pgTable("news_items", {
  id: serial("id").primaryKey(),
  symbol: text("symbol"),
  headline: text("headline").notNull(),
  source: text("source").notNull(),
  summary: text("summary").notNull(),
  publishedAt: timestamp("published_at", { withTimezone: true }).notNull(),
  sentiment: text("sentiment").notNull(),
  tag: text("tag").notNull(),
});

export const calendarEvents = pgTable("calendar_events", {
  id: serial("id").primaryKey(),
  symbol: text("symbol"),
  type: text("type").notNull(),
  date: date("date").notNull(),
  title: text("title").notNull(),
  detail: text("detail").notNull(),
});

export const fxRates = pgTable("fx_rates", {
  id: serial("id").primaryKey(),
  code: text("code").notNull(),
  usdPerUnit: doublePrecision("usd_per_unit").notNull(),
  label: text("label").notNull(),
});

export const correlations = pgTable("correlations", {
  id: serial("id").primaryKey(),
  symbolA: text("symbol_a").notNull(),
  symbolB: text("symbol_b").notNull(),
  value: doublePrecision("value").notNull(),
});

export const fundOverlaps = pgTable("fund_overlaps", {
  id: serial("id").primaryKey(),
  fundSymbol: text("fund_symbol").notNull(),
  holdingSymbol: text("holding_symbol").notNull(),
  weight: doublePrecision("weight").notNull(),
});

export const factorExposures = pgTable("factor_exposures", {
  id: serial("id").primaryKey(),
  portfolioId: integer("portfolio_id").notNull(),
  factor: text("factor").notNull(),
  loading: doublePrecision("loading").notNull(),
  benchmark: doublePrecision("benchmark").notNull(),
});

export const scenarios = pgTable("scenarios", {
  id: serial("id").primaryKey(),
  portfolioId: integer("portfolio_id").notNull(),
  name: text("name").notNull(),
  shock: text("shock").notNull(),
  impactPct: doublePrecision("impact_pct").notNull(),
});

export const journalEntries = pgTable("journal_entries", {
  id: serial("id").primaryKey(),
  date: date("date").notNull(),
  title: text("title").notNull(),
  body: text("body").notNull(),
  mood: text("mood").notNull(),
});

export const marketSnapshots = pgTable("market_snapshots", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull(),
  name: text("name").notNull(),
  last: doublePrecision("last").notNull(),
  changePct: doublePrecision("change_pct").notNull(),
  history: jsonb("history").$type<number[]>().notNull(),
});
