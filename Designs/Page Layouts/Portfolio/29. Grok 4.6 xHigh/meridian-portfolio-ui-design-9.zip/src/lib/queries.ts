import { cache } from "react";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { ensureSeeded } from "@/db/seed";
import {
  calendarEvents,
  correlations,
  factorExposures,
  fundOverlaps,
  fxRates,
  holdings,
  journalEntries,
  marketSnapshots,
  monthlyReturns,
  navSnapshots,
  newsItems,
  portfolios,
  scenarios,
} from "@/db/schema";
import type { Book, Holding, Totals } from "@/lib/types";

export const getBook = cache(async (): Promise<Book> => {
  await ensureSeeded();

  const [portfolio] = await db.select().from(portfolios).limit(1);
  const holdingRows = await db.select().from(holdings).where(eq(holdings.portfolioId, portfolio.id));
  const navRows = await db
    .select()
    .from(navSnapshots)
    .where(eq(navSnapshots.portfolioId, portfolio.id))
    .orderBy(navSnapshots.date);
  const monthRows = await db
    .select()
    .from(monthlyReturns)
    .where(eq(monthlyReturns.portfolioId, portfolio.id));
  const newsRows = await db.select().from(newsItems).orderBy(desc(newsItems.publishedAt));
  const eventRows = await db.select().from(calendarEvents).orderBy(calendarEvents.date);
  const fxRows = await db.select().from(fxRates);
  const corrRows = await db.select().from(correlations);
  const overlapRows = await db.select().from(fundOverlaps);
  const factorRows = await db.select().from(factorExposures).where(eq(factorExposures.portfolioId, portfolio.id));
  const scenarioRows = await db.select().from(scenarios).where(eq(scenarios.portfolioId, portfolio.id));
  const journalRows = await db.select().from(journalEntries).orderBy(desc(journalEntries.date));
  const marketRows = await db.select().from(marketSnapshots);

  const enriched: Holding[] = holdingRows.map((h) => {
    const marketValue = h.quantity * h.lastPrice;
    const costBasis = h.quantity * h.avgCost;
    const unrealized = marketValue - costBasis;
    const dayPnl = marketValue - marketValue / (1 + h.dayChangePct / 100);
    return {
      ...h,
      priceHistory: h.priceHistory ?? [],
      marketValue,
      weight: 0,
      costBasis,
      unrealized,
      unrealizedPct: costBasis === 0 ? 0 : (unrealized / costBasis) * 100,
      dayPnl,
    };
  });

  const nav = enriched.reduce((s, h) => s + h.marketValue, 0);
  for (const h of enriched) {
    h.weight = (h.marketValue / nav) * 100;
  }
  enriched.sort((a, b) => b.marketValue - a.marketValue);

  const dayPnl = enriched.reduce((s, h) => s + h.dayPnl, 0);
  const unrealized = enriched.reduce((s, h) => s + h.unrealized, 0);
  const yieldW = enriched.reduce((s, h) => s + h.dividendYield * h.weight, 0) / 100;
  const beta = enriched.reduce((s, h) => s + h.beta * h.weight, 0) / 100;

  const totals: Totals = {
    nav,
    dayPnl,
    dayPct: (dayPnl / (nav - dayPnl)) * 100,
    unrealized,
    unrealizedPct: (unrealized / (nav - unrealized)) * 100,
    yield: yieldW,
    beta,
    positions: enriched.filter((h) => h.kind !== "cash").length,
  };

  return {
    portfolio: {
      ...portfolio,
      inceptionDate: String(portfolio.inceptionDate),
    },
    holdings: enriched,
    nav: navRows.map((r) => ({
      date: String(r.date),
      nav: r.nav,
      benchmark: r.benchmark,
      drawdown: r.drawdown,
    })),
    months: monthRows
      .map((r) => ({
        year: r.year,
        month: r.month,
        portfolioRet: r.portfolioRet,
        benchmarkRet: r.benchmarkRet,
      }))
      .sort((a, b) => a.year - b.year || a.month - b.month),
    news: newsRows.map((n) => ({
      ...n,
      publishedAt:
        n.publishedAt instanceof Date ? n.publishedAt.toISOString() : String(n.publishedAt),
    })),
    events: eventRows.map((e) => ({
      ...e,
      date: String(e.date),
    })),
    fx: fxRows,
    correlations: corrRows,
    overlaps: overlapRows,
    factors: factorRows,
    scenarios: scenarioRows,
    journal: journalRows.map((j) => ({ ...j, date: String(j.date) })),
    markets: marketRows.map((m) => ({ ...m, history: m.history ?? [] })),
    totals,
  };
});

export async function getHolding(symbol: string) {
  const book = await getBook();
  return book.holdings.find((h) => h.symbol.toLowerCase() === symbol.toLowerCase()) ?? null;
}
