export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return function next() {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function gaussian(rand: () => number) {
  const u = Math.max(rand(), 1e-9);
  const v = rand();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

export function series(
  seed: number,
  n: number,
  start: number,
  drift: number,
  vol: number,
) {
  const rand = mulberry32(seed);
  const out: number[] = [start];
  for (let i = 1; i < n; i += 1) {
    out.push(out[i - 1] * (1 + drift + vol * gaussian(rand)));
  }
  return out;
}
