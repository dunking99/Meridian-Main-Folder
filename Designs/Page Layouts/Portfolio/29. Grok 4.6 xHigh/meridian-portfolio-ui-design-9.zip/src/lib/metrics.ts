import type { Holding, MonthRet, NavPoint } from "@/lib/types";

export function cagr(start: number, end: number, years: number) {
  if (start <= 0 || years <= 0) return 0;
  return (Math.pow(end / start, 1 / years) - 1) * 100;
}

export function stdev(xs: number[]) {
  if (xs.length < 2) return 0;
  const m = xs.reduce((s, x) => s + x, 0) / xs.length;
  const v = xs.reduce((s, x) => s + (x - m) ** 2, 0) / (xs.length - 1);
  return Math.sqrt(v);
}

export function trailing(months: MonthRet[], n: number) {
  const slice = months.slice(-n);
  const prod = slice.reduce((s, m) => s * (1 + m.portfolioRet / 100), 1);
  const bprod = slice.reduce((s, m) => s * (1 + m.benchmarkRet / 100), 1);
  return { p: (prod - 1) * 100, b: (bprod - 1) * 100 };
}

export function performanceBundle(months: MonthRet[], nav: NavPoint[]) {
  const rets = months.map((m) => m.portfolioRet);
  const bm = months.map((m) => m.benchmarkRet);
  const vol = stdev(rets) * Math.sqrt(12);
  const bmVol = stdev(bm) * Math.sqrt(12);
  const avg = rets.reduce((s, x) => s + x, 0) / (rets.length || 1);
  const ann = avg * 12;
  const rf = 4.2;
  const sharpe = vol ? (ann - rf) / vol : 0;
  const down = rets.filter((x) => x < 0);
  const dvol = stdev(down.length ? down : [0]) * Math.sqrt(12);
  const sortino = dvol ? (ann - rf) / dvol : 0;
  const maxDd = Math.min(...nav.map((n) => n.drawdown), 0);
  const calmar = maxDd ? ann / Math.abs(maxDd) : 0;
  const excess = rets.map((r, i) => r - bm[i]);
  const te = stdev(excess) * Math.sqrt(12);
  const alpha = excess.reduce((s, x) => s + x, 0) / (excess.length || 1) * 12;
  const info = te ? alpha / te : 0;
  const upM = rets.filter((r, i) => bm[i] > 0);
  const upB = bm.filter((b) => b > 0);
  const dnM = rets.filter((r, i) => bm[i] < 0);
  const dnB = bm.filter((b) => b < 0);
  const upCap =
    upB.reduce((s, x) => s + x, 0) === 0 ? 0 : (upM.reduce((s, x) => s + x, 0) / upB.reduce((s, x) => s + x, 0)) * 100;
  const dnCap =
    dnB.reduce((s, x) => s + x, 0) === 0 ? 0 : (dnM.reduce((s, x) => s + x, 0) / dnB.reduce((s, x) => s + x, 0)) * 100;
  const hit = (rets.filter((r) => r > 0).length / (rets.length || 1)) * 100;
  const wins = rets.filter((r) => r > 0);
  const losses = rets.filter((r) => r < 0);
  const gainLoss =
    Math.abs(losses.reduce((s, x) => s + x, 0) / (losses.length || 1)) === 0
      ? 0
      : Math.abs((wins.reduce((s, x) => s + x, 0) / (wins.length || 1)) / (losses.reduce((s, x) => s + x, 0) / (losses.length || 1)));
  const best = Math.max(...rets);
  const worst = Math.min(...rets);
  const years = months.length / 12;
  const start = nav[0]?.nav ?? 1;
  const end = nav[nav.length - 1]?.nav ?? start;
  const cg = cagr(start, end, years);
  const var95 = [...rets].sort((a, b) => a - b)[Math.max(0, Math.floor(rets.length * 0.05))] ?? 0;
  const skew = (() => {
    const m = avg;
    const sd = stdev(rets) || 1;
    return rets.reduce((s, x) => s + ((x - m) / sd) ** 3, 0) / rets.length;
  })();
  const kurt = (() => {
    const m = avg;
    const sd = stdev(rets) || 1;
    return rets.reduce((s, x) => s + ((x - m) / sd) ** 4, 0) / rets.length - 3;
  })();
  const ulcer =
    Math.sqrt(nav.reduce((s, n) => s + n.drawdown * n.drawdown, 0) / (nav.length || 1));
  return {
    vol,
    bmVol,
    ann,
    sharpe,
    sortino,
    maxDd,
    calmar,
    te,
    alpha,
    info,
    upCap,
    dnCap,
    hit,
    gainLoss,
    best,
    worst,
    cg,
    var95,
    skew,
    kurt,
    ulcer,
    years,
  };
}

export function sectorWeights(holdings: Holding[]) {
  const map = new Map<string, number>();
  for (const h of holdings) {
    map.set(h.sector, (map.get(h.sector) ?? 0) + h.weight);
  }
  return [...map.entries()].map(([label, value]) => ({ label, value })).sort((a, b) => b.value - a.value);
}

export function currencyWeights(holdings: Holding[]) {
  const map = new Map<string, number>();
  for (const h of holdings) {
    map.set(h.currency, (map.get(h.currency) ?? 0) + h.weight);
  }
  return [...map.entries()].map(([label, value]) => ({ label, value })).sort((a, b) => b.value - a.value);
}

export function regionWeights(holdings: Holding[]) {
  const map = new Map<string, number>();
  for (const h of holdings) {
    map.set(h.region, (map.get(h.region) ?? 0) + h.weight);
  }
  return [...map.entries()].map(([label, value]) => ({ label, value })).sort((a, b) => b.value - a.value);
}

export const ACWI_SECTOR: Record<string, number> = {
  Technology: 24.2,
  "Health Care": 11.1,
  Financials: 16.4,
  "Consumer Discretionary": 10.6,
  Communication: 7.8,
  Energy: 4.2,
  "Consumer Staples": 6.5,
  Blend: 0,
  Bonds: 0,
  Commodities: 0,
  "Real Estate": 2.4,
  Cash: 0,
};

export const WORLD_REGION = {
  "North America": 64,
  Europe: 16,
  Asia: 18,
  International: 1,
  Global: 1,
};
