export type Holding = {
  id: number;
  portfolioId: number;
  symbol: string;
  name: string;
  kind: string;
  assetClass: string;
  sector: string;
  industry: string;
  country: string;
  countryCode: string;
  region: string;
  lat: number;
  lng: number;
  currency: string;
  quantity: number;
  avgCost: number;
  lastPrice: number;
  dayChangePct: number;
  beta: number;
  peRatio: number | null;
  dividendYield: number;
  marketCapBn: number | null;
  color: string;
  priceHistory: number[];
  thesis: string | null;
  marketValue: number;
  weight: number;
  costBasis: number;
  unrealized: number;
  unrealizedPct: number;
  dayPnl: number;
};

export type Portfolio = {
  id: number;
  name: string;
  baseCurrency: string;
  inceptionDate: string;
  benchmark: string;
  riskGrade: string;
  riskScore: number;
  healthScore: number;
  cashUsd: number;
};

export type NavPoint = {
  date: string;
  nav: number;
  benchmark: number;
  drawdown: number;
};

export type MonthRet = {
  year: number;
  month: number;
  portfolioRet: number;
  benchmarkRet: number;
};

export type NewsItem = {
  id: number;
  symbol: string | null;
  headline: string;
  source: string;
  summary: string;
  publishedAt: string;
  sentiment: string;
  tag: string;
};

export type CalEvent = {
  id: number;
  symbol: string | null;
  type: string;
  date: string;
  title: string;
  detail: string;
};

export type FxRate = { code: string; usdPerUnit: number; label: string };

export type Book = {
  portfolio: Portfolio;
  holdings: Holding[];
  nav: NavPoint[];
  months: MonthRet[];
  news: NewsItem[];
  events: CalEvent[];
  fx: FxRate[];
  correlations: Array<{ symbolA: string; symbolB: string; value: number }>;
  overlaps: Array<{ fundSymbol: string; holdingSymbol: string; weight: number }>;
  factors: Array<{ factor: string; loading: number; benchmark: number }>;
  scenarios: Array<{ name: string; shock: string; impactPct: number }>;
  journal: Array<{ date: string; title: string; body: string; mood: string }>;
  markets: Array<{ symbol: string; name: string; last: number; changePct: number; history: number[] }>;
  totals: Totals;
};

export type Totals = {
  nav: number;
  dayPnl: number;
  dayPct: number;
  unrealized: number;
  unrealizedPct: number;
  yield: number;
  beta: number;
  positions: number;
};
