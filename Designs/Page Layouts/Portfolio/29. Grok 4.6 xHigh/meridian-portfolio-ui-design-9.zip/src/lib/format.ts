export function formatMoney(
  usd: number,
  ccy: string,
  rate: number,
  compact = false,
) {
  const value = usd * rate;
  const abs = Math.abs(value);
  if (compact && abs >= 1_000_000_000) {
    return `${ccySymbol(ccy)}${(value / 1_000_000_000).toFixed(2)}B`;
  }
  if (compact && abs >= 1_000_000) {
    return `${ccySymbol(ccy)}${(value / 1_000_000).toFixed(2)}M`;
  }
  if (compact && abs >= 10_000) {
    return `${ccySymbol(ccy)}${(value / 1_000).toFixed(1)}k`;
  }
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: ccy,
    maximumFractionDigits: abs >= 1000 ? 0 : 2,
  }).format(value);
}

export function ccySymbol(ccy: string) {
  switch (ccy) {
    case "EUR":
      return "€";
    case "GBP":
      return "£";
    case "JPY":
      return "¥";
    case "CHF":
      return "CHF ";
    default:
      return "$";
  }
}

export function formatPct(n: number, digits = 1, signed = true) {
  const sign = signed && n > 0 ? "+" : "";
  return `${sign}${n.toFixed(digits)}%`;
}

export function formatPctPoints(n: number, digits = 2) {
  const sign = n > 0 ? "+" : "";
  return `${sign}${n.toFixed(digits)}%`;
}

export function formatNum(n: number, digits = 2) {
  return n.toLocaleString("en-US", {
    maximumFractionDigits: digits,
    minimumFractionDigits: digits,
  });
}

export function formatCompact(n: number) {
  if (Math.abs(n) >= 1_000_000_000) return `${(n / 1_000_000_000).toFixed(1)}B`;
  if (Math.abs(n) >= 1_000_000) return `${(n / 1_000_000).toFixed(2)}M`;
  if (Math.abs(n) >= 1_000) return `${(n / 1_000).toFixed(1)}k`;
  return n.toFixed(0);
}

export function clsx(...parts: Array<string | false | null | undefined>) {
  return parts.filter(Boolean).join(" ");
}

export function signedClass(n: number) {
  if (n > 0.0001) return "num-up";
  if (n < -0.0001) return "num-down";
  return "num-flat";
}
