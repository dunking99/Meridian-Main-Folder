"use client";

import { createContext, useContext, useMemo, useState, type ReactNode } from "react";
import type { FxRate } from "@/lib/types";
import { formatMoney } from "@/lib/format";

type Ctx = {
  code: string;
  rate: number;
  setCode: (c: string) => void;
  fx: FxRate[];
};

const CurrencyContext = createContext<Ctx | null>(null);

export function CurrencyProvider({ fx, children }: { fx: FxRate[]; children: ReactNode }) {
  const [code, setCode] = useState("USD");
  const rate = fx.find((f) => f.code === code)?.usdPerUnit ?? 1;
  const value = useMemo(() => ({ code, rate, setCode, fx }), [code, rate, fx]);
  return <CurrencyContext.Provider value={value}>{children}</CurrencyContext.Provider>;
}

export function useCurrency() {
  const ctx = useContext(CurrencyContext);
  if (!ctx) throw new Error("CurrencyProvider missing");
  return ctx;
}

export function Money({
  usd,
  compact,
  className,
}: {
  usd: number;
  compact?: boolean;
  className?: string;
}) {
  const { code, rate } = useCurrency();
  return <span className={className}>{formatMoney(usd, code, rate, compact)}</span>;
}

export function CurrencySwitch() {
  const { code, setCode, fx } = useCurrency();
  return (
    <div className="flex items-center gap-0.5 rounded-full bg-ink p-[3px] hairline">
      {fx.map((f) => (
        <button
          key={f.code}
          type="button"
          onClick={() => setCode(f.code)}
          className={`px-2.5 py-1 text-[10px] tracking-[0.16em] font-mono rounded-full transition ${
            code === f.code ? "bg-meridian/15 text-meridian" : "text-mist hover:text-moon"
          }`}
        >
          {f.code}
        </button>
      ))}
    </div>
  );
}
