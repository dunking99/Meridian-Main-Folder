"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import type { ReactNode } from "react";
import { BookOpen, Globe2, LineChart, Newspaper, Orbit } from "lucide-react";
import { clsx } from "@/lib/format";

const NAV = [
  { href: "/portfolio", label: "Portfolio", hint: "The book", icon: Orbit },
  { href: "/news", label: "News", hint: "The tape", icon: Newspaper },
  { href: "/markets", label: "Markets", hint: "The field", icon: Globe2 },
  { href: "/journal", label: "Journal", hint: "The notes", icon: BookOpen },
];

export function AppShell({ children }: { children: ReactNode }) {
  const path = usePathname();
  return (
    <div className="min-h-screen">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-[220px] flex-col border-r border-white/5 bg-ink/80 px-5 py-6 backdrop-blur-md md:flex">
        <Link href="/portfolio" className="block">
          <p className="kicker text-meridian">Private book</p>
          <h1 className="font-display mt-1 text-[2rem] leading-none tracking-tight">Meridian</h1>
        </Link>
        <p className="mt-3 text-[11px] leading-relaxed text-mist">
          A single-user observatory for the shape of capital.
        </p>
        <nav className="mt-10 flex flex-col gap-1">
          {NAV.map((item) => {
            const active = item.href === "/portfolio" ? path.startsWith("/portfolio") : path.startsWith(item.href);
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={clsx("nav-link group flex items-center gap-3 rounded-lg px-3 py-2.5", active && "active")}
              >
                <Icon size={16} className={active ? "text-meridian" : "text-mist"} />
                <span className="flex flex-col">
                  <span className="text-sm">{item.label}</span>
                  <span className="text-[10px] tracking-wide text-mist/80">{item.hint}</span>
                </span>
              </Link>
            );
          })}
        </nav>
        <div className="mt-auto">
          <div className="h-px w-full bg-white/5" />
          <div className="mt-4 flex items-center gap-2">
            <span className="pulse-dot" />
            <span className="kicker">Live book</span>
          </div>
          <p className="mt-2 font-mono text-[11px] text-mist">MSCI ACWI · quiet tape</p>
        </div>
      </aside>

      <div className="md:pl-[220px]">
        <header className="sticky top-0 z-20 flex items-center justify-between border-b border-white/5 bg-void/75 px-4 py-3 backdrop-blur-md md:hidden">
          <span className="font-display text-xl">Meridian</span>
          <div className="flex gap-3">
            {NAV.map((item) => (
              <Link key={item.href} href={item.href} className="text-[11px] uppercase tracking-widest text-mist">
                {item.label}
              </Link>
            ))}
          </div>
        </header>
        <div className="min-h-screen">{children}</div>
      </div>
    </div>
  );
}

export function PortfolioSubnav() {
  const path = usePathname();
  const tabs = [
    { href: "/portfolio", label: "Overview", exact: true },
    { href: "/portfolio/holdings", label: "Holdings" },
    { href: "/portfolio/performance", label: "Performance" },
    { href: "/portfolio/analysis", label: "Analysis" },
  ];
  return (
    <div className="flex items-end gap-6 overflow-x-auto">
      {tabs.map((t) => {
        const active = t.exact ? path === t.href : path.startsWith(t.href);
        return (
          <Link key={t.href} href={t.href} className={clsx("subtab pb-2", active && "active")}>
            {t.label}
          </Link>
        );
      })}
    </div>
  );
}

export function SectionRule() {
  return (
    <div className="flex items-center gap-3">
      <span className="h-px flex-1 bg-white/8" />
      <LineChart size={12} className="text-meridian/70" />
      <span className="h-px flex-1 bg-white/8" />
    </div>
  );
}
