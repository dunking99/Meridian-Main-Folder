import Link from "next/link";
import type { CalEvent, NewsItem } from "@/lib/types";

export function NewsRail({ news }: { news: NewsItem[] }) {
  return (
    <div className="space-y-5">
      {news.map((n) => (
        <article key={n.id} className="relative pl-4">
          <span className="absolute left-0 top-1 h-full w-px bg-white/8" />
          <span
            className={`absolute left-[-3px] top-1.5 h-2 w-2 rounded-full ${
              n.sentiment === "up" ? "bg-lime" : n.sentiment === "down" ? "bg-coral" : "bg-meridian"
            }`}
          />
          <p className="kicker">
            {n.tag}
            {n.symbol ? ` · ${n.symbol}` : ""} · {n.source}
          </p>
          {n.symbol ? (
            <Link href={`/portfolio/holdings/${n.symbol}`} className="font-display mt-1 block text-xl leading-tight hover:text-meridian">
              {n.headline}
            </Link>
          ) : (
            <h4 className="font-display mt-1 text-xl leading-tight">{n.headline}</h4>
          )}
          <p className="mt-1 text-[13px] leading-relaxed text-mist">{n.summary}</p>
        </article>
      ))}
    </div>
  );
}

export function EventsRail({ events }: { events: CalEvent[] }) {
  return (
    <ol className="relative space-y-4 pl-4">
      <span className="absolute bottom-2 left-[7px] top-2 w-px bg-gradient-to-b from-meridian/70 to-transparent" />
      {events.map((e) => (
        <li key={e.id} className="relative">
          <span className="absolute -left-[13px] top-1.5 h-2.5 w-2.5 rounded-full bg-void ring-1 ring-meridian" />
          <p className="kicker">
            {e.date} · {e.type}
          </p>
          {e.symbol ? (
            <Link href={`/portfolio/holdings/${e.symbol}`} className="mt-1 block font-display text-lg leading-tight hover:text-meridian">
              {e.title}
            </Link>
          ) : (
            <p className="mt-1 font-display text-lg leading-tight">{e.title}</p>
          )}
          <p className="text-[12px] text-mist">{e.detail}</p>
        </li>
      ))}
    </ol>
  );
}
