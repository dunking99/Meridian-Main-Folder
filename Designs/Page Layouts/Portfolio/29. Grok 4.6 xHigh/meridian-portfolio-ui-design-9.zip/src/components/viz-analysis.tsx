"use client";

import { useMemo, useState } from "react";
import type { Holding, MonthRet } from "@/lib/types";
import { formatPct } from "@/lib/format";
import { ACWI_SECTOR, WORLD_REGION } from "@/lib/metrics";

export function MercuryCalendar({ months }: { months: MonthRet[] }) {
  const years = [...new Set(months.map((m) => m.year))];
  const max = Math.max(...months.map((m) => Math.abs(m.portfolioRet)), 1);
  const names = ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"];
  return (
    <div className="overflow-x-auto">
      <div className="grid grid-cols-[48px_repeat(12,1fr)_56px] gap-1.5 min-w-[720px]">
        <span />
        {names.map((n, i) => (
          <span key={n + i} className="text-center font-mono text-[10px] text-mist">
            {n}
          </span>
        ))}
        <span className="text-center font-mono text-[10px] text-mist">YR</span>
        {years.map((y) => {
          const row = months.filter((m) => m.year === y);
          const yr = row.reduce((s, m) => s * (1 + m.portfolioRet / 100), 1) - 1;
          return (
            <div key={y} className="contents">
              <span className="font-mono text-[11px] text-mist self-center">{y}</span>
              {Array.from({ length: 12 }, (_, i) => {
                const cell = row.find((m) => m.month === i + 1);
                if (!cell) return <div key={i} className="h-12 bg-white/3" />;
                const h = (Math.abs(cell.portfolioRet) / max) * 100;
                const up = cell.portfolioRet >= 0;
                return (
                  <div key={i} className="relative h-12 bg-ink hairline flex items-end justify-center">
                    <div
                      className="w-3/5 mb-1"
                      style={{
                        height: `${Math.max(8, h)}%`,
                        background: up
                          ? "linear-gradient(180deg, #C6F26D, #4d7a22)"
                          : "linear-gradient(180deg, #FF6A4A, #7a2418)",
                        boxShadow: up ? "0 0 10px rgba(198,242,109,0.35)" : "0 0 10px rgba(255,106,74,0.35)",
                      }}
                      title={`${cell.portfolioRet.toFixed(1)}%`}
                    />
                  </div>
                );
              })}
              <div className={`self-center text-center font-mono text-[11px] ${yr >= 0 ? "num-up" : "num-down"}`}>
                {(yr * 100).toFixed(1)}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export function TrailingLadders({
  rows,
}: {
  rows: Array<{ label: string; p: number; b: number }>;
}) {
  const max = Math.max(...rows.flatMap((r) => [Math.abs(r.p), Math.abs(r.b)]), 1);
  return (
    <div className="space-y-4">
      {rows.map((r) => (
        <div key={r.label}>
          <div className="mb-1 flex justify-between font-mono text-[10px] tracking-widest text-mist">
            <span>{r.label}</span>
            <span>
              <span className={r.p >= 0 ? "num-up" : "num-down"}>{formatPct(r.p)}</span>
              <span className="text-mist"> · ACWI {formatPct(r.b)}</span>
            </span>
          </div>
          <div className="relative h-3 bg-white/5">
            <div className="absolute left-1/2 top-0 h-full w-px bg-meridian/50" />
            <div
              className="absolute top-0 h-full"
              style={{
                left: r.p >= 0 ? "50%" : `${50 - (Math.abs(r.p) / max) * 50}%`,
                width: `${(Math.abs(r.p) / max) * 50}%`,
                background: r.p >= 0 ? "#C6F26D" : "#FF6A4A",
              }}
            />
            <div
              className="absolute top-1 h-1"
              style={{
                left: r.b >= 0 ? "50%" : `${50 - (Math.abs(r.b) / max) * 50}%`,
                width: `${(Math.abs(r.b) / max) * 50}%`,
                background: "#B4A5FF",
              }}
            />
          </div>
        </div>
      ))}
    </div>
  );
}

export function CaptureTubes({ up, down }: { up: number; down: number }) {
  return (
    <div className="grid grid-cols-2 gap-8">
      <Tube label="Upside capture" value={up} color="#C6F26D" />
      <Tube label="Downside capture" value={down} color="#FF6A4A" />
    </div>
  );
}

function Tube({ label, value, color }: { label: string; value: number; color: string }) {
  const h = Math.min(100, Math.max(6, value / 1.6));
  return (
    <div className="flex flex-col items-center">
      <div className="relative h-40 w-16 rounded-full hairline bg-ink overflow-hidden">
        <div
          className="absolute bottom-0 left-0 right-0"
          style={{
            height: `${h}%`,
            background: `linear-gradient(180deg, ${color}, ${color}55)`,
            boxShadow: `0 0 18px ${color}`,
          }}
        />
        <div className="absolute inset-x-2 top-3 h-px bg-white/10" />
        <div className="absolute inset-x-2 top-1/2 h-px bg-white/10" />
      </div>
      <p className="font-display mt-3 text-2xl">{value.toFixed(0)}%</p>
      <p className="kicker mt-1">{label}</p>
    </div>
  );
}

export function Ridgeline({ months }: { months: MonthRet[] }) {
  const buckets = Array.from({ length: 17 }, (_, i) => -8 + i);
  const counts = buckets.map((b) => months.filter((m) => Math.round(m.portfolioRet) === b).length);
  const max = Math.max(...counts, 1);
  const w = 340;
  const h = 120;
  const d = counts
    .map((c, i) => {
      const x = (i / (counts.length - 1)) * w;
      const y = h - (c / max) * (h - 20) - 8;
      return `${i === 0 ? "M" : "L"}${x},${y}`;
    })
    .join(" ");
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full">
      <defs>
        <linearGradient id="ridge" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#7DF0E8" stopOpacity="0.5" />
          <stop offset="100%" stopColor="#7DF0E8" stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={`${d} L${w},${h} L0,${h} Z`} fill="url(#ridge)" />
      <path d={d} fill="none" stroke="#7DF0E8" strokeWidth="1.6" />
      <line x1={w / 2} x2={w / 2} y1="0" y2={h} stroke="rgba(125,240,232,0.35)" />
      <text x="4" y={h - 2} fill="#8B97AB" fontSize="9" fontFamily="IBM Plex Mono, monospace">
        −8%
      </text>
      <text x={w - 24} y={h - 2} fill="#8B97AB" fontSize="9" fontFamily="IBM Plex Mono, monospace">
        +8%
      </text>
    </svg>
  );
}

export function CorrelationQuilt({
  symbols,
  values,
}: {
  symbols: string[];
  values: Array<{ symbolA: string; symbolB: string; value: number }>;
}) {
  const [hover, setHover] = useState<string | null>(null);
  const lookup = (a: string, b: string) => {
    if (a === b) return 1;
    return (
      values.find((v) => (v.symbolA === a && v.symbolB === b) || (v.symbolA === b && v.symbolB === a))?.value ?? 0
    );
  };
  const size = 28;
  const pad = 52;
  return (
    <svg
      viewBox={`0 0 ${pad + symbols.length * size + 8} ${pad + symbols.length * size + 8}`}
      className="w-full max-w-[560px]"
    >
      {symbols.map((s, i) => (
        <text
          key={`x${s}`}
          x={pad + i * size + size / 2}
          y={pad - 10}
          textAnchor="middle"
          fill={hover === s ? "#7DF0E8" : "#8B97AB"}
          fontSize="8"
          fontFamily="IBM Plex Mono, monospace"
        >
          {s}
        </text>
      ))}
      {symbols.map((s, i) => (
        <text
          key={`y${s}`}
          x={pad - 8}
          y={pad + i * size + size / 2 + 3}
          textAnchor="end"
          fill={hover === s ? "#7DF0E8" : "#8B97AB"}
          fontSize="8"
          fontFamily="IBM Plex Mono, monospace"
        >
          {s}
        </text>
      ))}
      {symbols.map((a, i) =>
        symbols.map((b, j) => {
          if (j < i) return null;
          const v = lookup(a, b);
          const col =
            v >= 0
              ? `rgba(125,240,232,${0.12 + v * 0.75})`
              : `rgba(255,106,74,${0.12 + Math.abs(v) * 0.75})`;
          const dim = hover && hover !== a && hover !== b;
          return (
            <rect
              key={`${a}${b}`}
              x={pad + j * size + 2}
              y={pad + i * size + 2}
              width={size - 4}
              height={size - 4}
              rx="2"
              fill={col}
              opacity={dim ? 0.2 : 1}
              stroke="rgba(243,239,228,0.06)"
              onMouseEnter={() => setHover(a)}
              onMouseLeave={() => setHover(null)}
            >
              <title>
                {a} / {b} {v.toFixed(2)}
              </title>
            </rect>
          );
        }),
      )}
    </svg>
  );
}

export function SectorButterfly({ holdings }: { holdings: Holding[] }) {
  const rows = useMemo(() => {
    const map = new Map<string, number>();
    for (const h of holdings) map.set(h.sector, (map.get(h.sector) ?? 0) + h.weight);
    const labels = Object.keys(ACWI_SECTOR).filter((k) => (map.get(k) ?? 0) > 0.4 || ACWI_SECTOR[k] > 0.4);
    return labels
      .map((label) => ({
        label,
        p: map.get(label) ?? 0,
        b: ACWI_SECTOR[label] ?? 0,
      }))
      .sort((a, b) => b.p - a.p);
  }, [holdings]);
  const max = Math.max(...rows.flatMap((r) => [r.p, r.b]), 1);
  return (
    <div className="space-y-2">
      {rows.map((r) => (
        <div key={r.label} className="grid grid-cols-[1fr_110px_1fr] items-center gap-2">
          <div className="flex justify-end">
            <div
              className="h-4"
              style={{
                width: `${(r.p / max) * 100}%`,
                background: "linear-gradient(270deg, #7DF0E8, rgba(125,240,232,0.15))",
              }}
            />
          </div>
          <div className="text-center">
            <p className="font-mono text-[10px] text-moon">{r.label}</p>
            <p className="font-mono text-[9px] text-mist">
              {r.p.toFixed(1)} · {r.b.toFixed(1)}
            </p>
          </div>
          <div>
            <div
              className="h-4"
              style={{
                width: `${(r.b / max) * 100}%`,
                background: "linear-gradient(90deg, #B4A5FF, rgba(180,165,255,0.15))",
              }}
            />
          </div>
        </div>
      ))}
      <div className="flex justify-between font-mono text-[10px] text-mist">
        <span>The book →</span>
        <span>← ACWI</span>
      </div>
    </div>
  );
}

export function OrbitScatter({ holdings }: { holdings: Holding[] }) {
  const pts = holdings.filter((h) => h.kind !== "cash");
  const w = 520;
  const h = 360;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full">
      <defs>
        <radialGradient id="well">
          <stop offset="0%" stopColor="rgba(125,240,232,0.08)" />
          <stop offset="100%" stopColor="rgba(125,240,232,0)" />
        </radialGradient>
      </defs>
      <rect x="48" y="16" width={w - 64} height={h - 48} fill="url(#well)" />
      {[0, 0.25, 0.5, 0.75, 1].map((t) => (
        <g key={t}>
          <line x1="48" x2={w - 16} y1={16 + t * (h - 48)} y2={16 + t * (h - 48)} stroke="rgba(210,224,236,0.06)" />
          <line x1={48 + t * (w - 64)} x2={48 + t * (w - 64)} y1="16" y2={h - 32} stroke="rgba(210,224,236,0.06)" />
        </g>
      ))}
      <path
        d={`M 70 ${h - 70} Q 240 40, 470 90`}
        fill="none"
        stroke="rgba(198,242,109,0.45)"
        strokeDasharray="4 6"
      />
      <text x="54" y="28" fill="#8B97AB" fontSize="9" fontFamily="IBM Plex Mono, monospace">
        RETURN
      </text>
      <text x={w - 90} y={h - 12} fill="#8B97AB" fontSize="9" fontFamily="IBM Plex Mono, monospace">
        RISK →
      </text>
      {pts.map((p) => {
        const x = 48 + (Math.min(p.beta, 2) / 2) * (w - 80);
        const hist = p.priceHistory;
        const ret = hist.length > 1 ? ((hist[hist.length - 1] - hist[0]) / hist[0]) * 100 : p.dayChangePct;
        const y = h - 32 - ((ret + 20) / 55) * (h - 56);
        const r = 6 + p.weight / 3.2;
        return (
          <g key={p.symbol}>
            <circle cx={x} cy={y} r={r} fill={p.color} fillOpacity="0.28" stroke={p.color} />
            <text x={x} y={y + r + 10} textAnchor="middle" fill="#F3EFE4" fontSize="8" fontFamily="IBM Plex Mono, monospace">
              {p.symbol}
            </text>
          </g>
        );
      })}
    </svg>
  );
}

export function CurrencyWheel({ holdings }: { holdings: Holding[] }) {
  const groups = useMemo(() => {
    const map = new Map<string, number>();
    for (const h of holdings) map.set(h.currency, (map.get(h.currency) ?? 0) + h.weight);
    return [...map.entries()].sort((a, b) => b[1] - a[1]);
  }, [holdings]);
  const total = groups.reduce((s, g) => s + g[1], 0);
  const colors = ["#7DF0E8", "#C6F26D", "#B4A5FF", "#E7C9A0", "#FF6A4A"];
  let a0 = -Math.PI / 2;
  const c = 120;
  const r0 = 48;
  const r1 = 96;
  return (
    <div className="flex items-center gap-6">
      <svg viewBox="0 0 240 240" className="w-48">
        {groups.map((g, i) => {
          const sweep = (g[1] / total) * Math.PI * 2 * 0.98;
          const large = sweep > Math.PI ? 1 : 0;
          const a1 = a0 + sweep;
          const p = (r: number, a: number) => [c + Math.cos(a) * r, c + Math.sin(a) * r];
          const p0 = p(r1, a0);
          const p1 = p(r1, a1);
          const p2 = p(r0, a1);
          const p3 = p(r0, a0);
          const d = `M${p0[0]},${p0[1]} A${r1},${r1} 0 ${large} 1 ${p1[0]},${p1[1]} L${p2[0]},${p2[1]} A${r0},${r0} 0 ${large} 0 ${p3[0]},${p3[1]} Z`;
          const el = <path key={g[0]} d={d} fill={colors[i % colors.length]} fillOpacity="0.8" />;
          a0 = a1 + 0.02;
          return el;
        })}
        <text x={c} y={c + 4} textAnchor="middle" fill="#F3EFE4" fontSize="12" fontFamily="IBM Plex Mono, monospace">
          FX
        </text>
      </svg>
      <ul className="space-y-2">
        {groups.map((g, i) => (
          <li key={g[0]} className="flex items-center gap-2 font-mono text-[12px]">
            <i className="h-2 w-2 rounded-full" style={{ background: colors[i % colors.length] }} />
            <span className="text-moon w-10">{g[0]}</span>
            <span className="text-mist">{g[1].toFixed(1)}%</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function HomeBias({ holdings }: { holdings: Holding[] }) {
  const home = holdings.filter((h) => h.countryCode === "US").reduce((s, h) => s + h.weight, 0);
  const worldHome = WORLD_REGION["North America"];
  return (
    <div>
      <div className="flex items-end gap-8">
        <CircleStack label="The book" home={home} color="#7DF0E8" />
        <CircleStack label="World market" home={worldHome} color="#B4A5FF" />
      </div>
      <p className="mt-4 font-mono text-[11px] leading-relaxed text-mist">
        Home weight {home.toFixed(1)}% versus a ~{worldHome}% North America share of global equity. Bias of{" "}
        <span className="text-sand">{(home - worldHome).toFixed(1)}pp</span>.
      </p>
    </div>
  );
}

function CircleStack({ label, home, color }: { label: string; home: number; color: string }) {
  const size = 140;
  const r = 58;
  const circ = 2 * Math.PI * r;
  return (
    <div className="flex flex-col items-center">
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <circle cx={70} cy={70} r={r} fill="none" stroke="rgba(210,224,236,0.08)" strokeWidth="14" />
        <circle
          cx={70}
          cy={70}
          r={r}
          fill="none"
          stroke={color}
          strokeWidth="14"
          strokeDasharray={`${(home / 100) * circ} ${circ}`}
          transform="rotate(-90 70 70)"
          strokeLinecap="round"
        />
        <text x="70" y="66" textAnchor="middle" fill="#F3EFE4" fontSize="22" fontFamily="Fraunces, serif">
          {home.toFixed(0)}%
        </text>
        <text x="70" y="84" textAnchor="middle" fill="#8B97AB" fontSize="8" fontFamily="IBM Plex Mono, monospace">
          HOME
        </text>
      </svg>
      <p className="kicker">{label}</p>
    </div>
  );
}

export function FundOverlap({
  overlaps,
  holdings,
}: {
  overlaps: Array<{ fundSymbol: string; holdingSymbol: string; weight: number }>;
  holdings: Holding[];
}) {
  const funds = [...new Set(overlaps.map((o) => o.fundSymbol))];
  return (
    <div className="space-y-5">
      {funds.map((f) => {
        const rows = overlaps.filter((o) => o.fundSymbol === f);
        const owned = rows.filter((r) => holdings.some((h) => h.symbol === r.holdingSymbol && h.kind === "equity"));
        const overlap = owned.reduce((s, r) => s + r.weight, 0);
        return (
          <div key={f}>
            <div className="mb-2 flex items-baseline justify-between">
              <span className="font-display text-xl">{f}</span>
              <span className="font-mono text-[11px] text-meridian">{overlap.toFixed(1)}% look-through already owned</span>
            </div>
            <div className="flex h-6 overflow-hidden">
              {rows.map((r) => {
                const also = holdings.some((h) => h.symbol === r.holdingSymbol && h.kind === "equity");
                return (
                  <div
                    key={r.holdingSymbol}
                    style={{ width: `${r.weight * 3}%` }}
                    className={`h-full ${also ? "bg-meridian/80" : "bg-white/10"}`}
                    title={`${r.holdingSymbol} ${r.weight}%`}
                  />
                );
              })}
            </div>
            <p className="mt-1 font-mono text-[10px] text-mist">
              lit cells sit in the book as single names · dark cells are fund-only
            </p>
          </div>
        );
      })}
    </div>
  );
}

export function FactorCompass({
  factors,
}: {
  factors: Array<{ factor: string; loading: number; benchmark: number }>;
}) {
  const n = factors.length;
  const c = 130;
  const r = 96;
  const pt = (i: number, v: number) => {
    const a = -Math.PI / 2 + (i / n) * Math.PI * 2;
    const rr = r * ((v + 1) / 2);
    return [c + Math.cos(a) * rr, c + Math.sin(a) * rr] as const;
  };
  const poly = (key: "loading" | "benchmark") =>
    factors.map((f, i) => pt(i, f[key])).map((p, i) => `${i === 0 ? "M" : "L"}${p[0]},${p[1]}`).join(" ") + " Z";
  return (
    <svg viewBox="0 0 260 260" className="mx-auto w-full max-w-[300px]">
      {[0.25, 0.5, 0.75, 1].map((t) => (
        <circle key={t} cx={c} cy={c} r={r * t} fill="none" stroke="rgba(210,224,236,0.08)" />
      ))}
      {factors.map((f, i) => {
        const [x, y] = pt(i, 1);
        return (
          <g key={f.factor}>
            <line x1={c} y1={c} x2={x} y2={y} stroke="rgba(210,224,236,0.08)" />
            <text x={x} y={y} fill="#8B97AB" fontSize="9" fontFamily="IBM Plex Mono, monospace" textAnchor="middle">
              {f.factor}
            </text>
          </g>
        );
      })}
      <path d={poly("benchmark")} fill="rgba(180,165,255,0.15)" stroke="#B4A5FF" />
      <path d={poly("loading")} fill="rgba(125,240,232,0.18)" stroke="#7DF0E8" />
    </svg>
  );
}

export function ScenarioBars({
  rows,
}: {
  rows: Array<{ name: string; shock: string; impactPct: number }>;
}) {
  const max = Math.max(...rows.map((r) => Math.abs(r.impactPct)), 1);
  return (
    <div className="space-y-3">
      {rows.map((r) => (
        <div key={r.name}>
          <div className="flex justify-between">
            <span className="font-display text-lg">{r.name}</span>
            <span className={r.impactPct >= 0 ? "num-up font-mono" : "num-down font-mono"}>
              {formatPct(r.impactPct)}
            </span>
          </div>
          <p className="font-mono text-[10px] text-mist">{r.shock}</p>
          <div className="relative mt-1 h-2 bg-white/5">
            <div className="absolute left-1/2 top-0 h-full w-px bg-meridian/50" />
            <div
              className="absolute top-0 h-full"
              style={{
                left: r.impactPct >= 0 ? "50%" : `${50 - (Math.abs(r.impactPct) / max) * 50}%`,
                width: `${(Math.abs(r.impactPct) / max) * 50}%`,
                background: r.impactPct >= 0 ? "#C6F26D" : "#FF6A4A",
              }}
            />
          </div>
        </div>
      ))}
    </div>
  );
}
