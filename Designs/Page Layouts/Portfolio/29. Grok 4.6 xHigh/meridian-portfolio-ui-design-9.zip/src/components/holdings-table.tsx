"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import type { Holding } from "@/lib/types";
import { formatPct, clsx } from "@/lib/format";
import { Money } from "@/components/currency";
import { Filament } from "@/components/spark";

type SortKey = "weight" | "day" | "unrealized" | "yield" | "name";

export function HoldingsTable({ holdings }: { holdings: Holding[] }) {
  const [q, setQ] = useState("");
  const [sort, setSort] = useState<SortKey>("weight");
  const rows = useMemo(() => {
    const f = holdings.filter(
      (h) =>
        h.symbol.toLowerCase().includes(q.toLowerCase()) ||
        h.name.toLowerCase().includes(q.toLowerCase()) ||
        h.sector.toLowerCase().includes(q.toLowerCase()),
    );
    const s = [...f];
    s.sort((a, b) => {
      if (sort === "name") return a.name.localeCompare(b.name);
      if (sort === "day") return b.dayChangePct - a.dayChangePct;
      if (sort === "unrealized") return b.unrealizedPct - a.unrealizedPct;
      if (sort === "yield") return b.dividendYield - a.dividendYield;
      return b.weight - a.weight;
    });
    return s;
  }, [holdings, q, sort]);

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Filter symbol, name, sector"
          className="w-64 bg-transparent hairline px-3 py-2 font-mono text-[12px] text-moon outline-none placeholder:text-mist"
        />
        <div className="flex gap-1">
          {(["weight", "day", "unrealized", "yield", "name"] as SortKey[]).map((k) => (
            <button
              key={k}
              type="button"
              onClick={() => setSort(k)}
              className={clsx(
                "px-2 py-1 font-mono text-[10px] tracking-[0.14em] uppercase",
                sort === k ? "text-meridian" : "text-mist",
              )}
            >
              {k}
            </button>
          ))}
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[760px] text-left">
          <thead>
            <tr className="kicker border-b border-white/8">
              <th className="py-2 font-medium">Name</th>
              <th className="py-2 font-medium">Path</th>
              <th className="py-2 font-medium text-right">Value</th>
              <th className="py-2 font-medium text-right">Wt</th>
              <th className="py-2 font-medium text-right">Day</th>
              <th className="py-2 font-medium text-right">P&L</th>
              <th className="py-2 font-medium text-right">Yield</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((h) => (
              <tr key={h.symbol} className="border-b border-white/5 hover:bg-white/3">
                <td className="py-3">
                  <Link href={`/portfolio/holdings/${h.symbol}`} className="block">
                    <p className="font-mono text-[12px] text-meridian">{h.symbol}</p>
                    <p className="text-[12px] text-moon">{h.name}</p>
                    <p className="font-mono text-[10px] text-mist">
                      {h.sector} · {h.country}
                    </p>
                  </Link>
                </td>
                <td className="py-3">
                  <Filament data={h.priceHistory} />
                </td>
                <td className="py-3 text-right font-mono text-[12px]">
                  <Money usd={h.marketValue} />
                </td>
                <td className="py-3 text-right">
                  <div className="flex flex-col items-end gap-1">
                    <span className="font-mono text-[12px]">{h.weight.toFixed(1)}%</span>
                    <span className="block h-[3px] bg-meridian/70" style={{ width: `${Math.min(72, h.weight * 6)}px` }} />
                  </div>
                </td>
                <td className={clsx("py-3 text-right font-mono text-[12px]", h.dayChangePct >= 0 ? "num-up" : "num-down")}>
                  {formatPct(h.dayChangePct)}
                </td>
                <td className={clsx("py-3 text-right font-mono text-[12px]", h.unrealized >= 0 ? "num-up" : "num-down")}>
                  {formatPct(h.unrealizedPct)}
                </td>
                <td className="py-3 text-right font-mono text-[12px] text-sand">{h.dividendYield.toFixed(2)}%</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
