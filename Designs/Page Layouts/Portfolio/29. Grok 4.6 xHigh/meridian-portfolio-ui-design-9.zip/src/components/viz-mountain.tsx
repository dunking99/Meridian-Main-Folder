"use client";

import { useMemo, useState } from "react";
import type { NavPoint } from "@/lib/types";
import { formatCompact, formatPct } from "@/lib/format";
import { useCurrency, Money } from "@/components/currency";

const RANGES = [
  { id: "1Y", days: 252 },
  { id: "3Y", days: 756 },
  { id: "5Y", days: 1260 },
  { id: "MAX", days: 99999 },
];

export function MountainChart({ nav }: { nav: NavPoint[] }) {
  const { rate } = useCurrency();
  const [range, setRange] = useState("5Y");
  const [hover, setHover] = useState<number | null>(null);
  const slice = useMemo(() => {
    const days = RANGES.find((r) => r.id === range)?.days ?? 99999;
    return nav.slice(Math.max(0, nav.length - days));
  }, [nav, range]);

  const w = 920;
  const h = 320;
  const pad = { l: 16, r: 16, t: 28, b: 28 };

  const path = useMemo(() => {
    if (!slice.length) return null;
    const nmin = Math.min(...slice.map((d) => d.nav));
    const nmax = Math.max(...slice.map((d) => d.nav));
    const bmin = Math.min(...slice.map((d) => d.benchmark));
    const bmax = Math.max(...slice.map((d) => d.benchmark));
    const nx = (i: number) => pad.l + (i / (slice.length - 1)) * (w - pad.l - pad.r);
    const ny = (v: number) => pad.t + (1 - (v - nmin) / (nmax - nmin || 1)) * (h - pad.t - pad.b);
    const by = (v: number) => pad.t + (1 - (v - bmin) / (bmax - bmin || 1)) * (h - pad.t - pad.b);
    const line = slice
      .map((d, i) => `${i === 0 ? "M" : "L"}${nx(i).toFixed(1)},${ny(d.nav).toFixed(1)}`)
      .join(" ");
    const area = `${line} L${nx(slice.length - 1)},${h - pad.b} L${pad.l},${h - pad.b} Z`;
    const bench = slice
      .map((d, i) => `${i === 0 ? "M" : "L"}${nx(i).toFixed(1)},${by(d.benchmark).toFixed(1)}`)
      .join(" ");
    const last = slice[slice.length - 1];
    const first = slice[0];
    const ret = ((last.nav - first.nav) / first.nav) * 100;
    return { line, area, bench, nx, ny, ret, first, last, nmin, nmax };
  }, [slice]);

  if (!path) return null;
  const hi = hover ?? slice.length - 1;
  const point = slice[hi];
  const x = path.nx(hi);
  const y = path.ny(point.nav);

  return (
    <div>
      <div className="mb-3 flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="kicker">Wealth path</p>
          <p className="font-display text-3xl text-moon">
            <Money usd={point.nav} />
          </p>
          <p className="mt-1 font-mono text-[11px] text-mist">
            {point.date} · vs ACWI ghost · window {formatPct(path.ret)}
          </p>
        </div>
        <div className="flex gap-1">
          {RANGES.map((r) => (
            <button
              key={r.id}
              type="button"
              onClick={() => setRange(r.id)}
              className={`font-mono text-[10px] tracking-[0.16em] px-2 py-1 rounded-full ${
                range === r.id ? "bg-meridian/15 text-meridian" : "text-mist hover:text-moon"
              }`}
            >
              {r.id}
            </button>
          ))}
        </div>
      </div>
      <svg
        viewBox={`0 0 ${w} ${h}`}
        className="h-[280px] w-full overflow-visible"
        onMouseLeave={() => setHover(null)}
        onMouseMove={(e) => {
          const rect = e.currentTarget.getBoundingClientRect();
          const t = (e.clientX - rect.left) / rect.width;
          const i = Math.round(t * (slice.length - 1));
          setHover(Math.max(0, Math.min(slice.length - 1, i)));
        }}
      >
        <defs>
          <linearGradient id="mnt" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#7DF0E8" stopOpacity="0.32" />
            <stop offset="55%" stopColor="#7DF0E8" stopOpacity="0.05" />
            <stop offset="100%" stopColor="#7DF0E8" stopOpacity="0" />
          </linearGradient>
          <filter id="glow">
            <feGaussianBlur stdDeviation="3.5" result="b" />
            <feMerge>
              <feMergeNode in="b" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>
        {[0, 0.25, 0.5, 0.75, 1].map((t) => {
          const gy = pad.t + t * (h - pad.t - pad.b);
          return (
            <g key={t}>
              <line x1={pad.l} x2={w - pad.r} y1={gy} y2={gy} stroke="rgba(210,224,236,0.06)" />
              <text x={w - pad.r} y={gy - 4} textAnchor="end" fill="#8B97AB" fontSize="10" fontFamily="IBM Plex Mono, monospace">
                {formatCompact(path.nmax - t * (path.nmax - path.nmin) * rate)}
              </text>
            </g>
          );
        })}
        <path d={path.bench} fill="none" stroke="rgba(180,165,255,0.55)" strokeWidth="1.2" strokeDasharray="3 5" />
        <path d={path.area} fill="url(#mnt)" />
        <path d={path.line} fill="none" stroke="#7DF0E8" strokeWidth="1.8" filter="url(#glow)" />
        <line x1={x} x2={x} y1={pad.t} y2={h - pad.b} stroke="rgba(125,240,232,0.35)" strokeWidth="1" />
        <circle cx={x} cy={y} r="5" fill="#0C1018" stroke="#7DF0E8" strokeWidth="2" />
        <circle cx={x} cy={y} r="10" fill="none" stroke="rgba(125,240,232,0.25)" />
      </svg>
      <div className="mt-1 flex justify-between font-mono text-[10px] tracking-widest text-mist">
        <span>{slice[0]?.date}</span>
        <span className="text-violet/80">dashed · ACWI</span>
        <span>{slice[slice.length - 1]?.date}</span>
      </div>
    </div>
  );
}

export function DrawdownTrench({ nav }: { nav: NavPoint[] }) {
  const slice = nav.slice(-756);
  const w = 900;
  const h = 180;
  const min = Math.min(...slice.map((d) => d.drawdown), -1);
  const d = slice
    .map((p, i) => {
      const x = (i / (slice.length - 1)) * w;
      const y = ((p.drawdown - 0) / (min - 0 || -1)) * (h - 16) + 8;
      return `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");
  const area = `${d} L${w},8 L0,8 Z`;
  const maxDd = Math.min(...slice.map((p) => p.drawdown));
  return (
    <div>
      <div className="mb-2 flex items-baseline justify-between">
        <p className="kicker">Underwater trench</p>
        <p className="font-display text-2xl text-coral">{maxDd.toFixed(1)}%</p>
      </div>
      <svg viewBox={`0 0 ${w} ${h}`} className="h-[160px] w-full">
        <defs>
          <linearGradient id="trench" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#FF6A4A" stopOpacity="0" />
            <stop offset="100%" stopColor="#B4A5FF" stopOpacity="0.45" />
          </linearGradient>
        </defs>
        <line x1="0" x2={w} y1="8" y2="8" stroke="rgba(125,240,232,0.4)" strokeWidth="1" />
        <path d={area} fill="url(#trench)" />
        <path d={d} fill="none" stroke="#B4A5FF" strokeWidth="1.4" />
      </svg>
      <p className="mt-1 font-mono text-[10px] text-mist">Depth from peak · 3 year window · surface is the meridian</p>
    </div>
  );
}
