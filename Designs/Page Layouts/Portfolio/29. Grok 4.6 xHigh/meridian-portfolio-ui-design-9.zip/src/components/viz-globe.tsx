"use client";

import { useEffect, useRef } from "react";
import type { Holding } from "@/lib/types";

type City = { lat: number; lng: number; name: string; weight: number; color: string };

export function ExposureGlobe({ holdings }: { holdings: Holding[] }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);

  const cities: City[] = [];
  const map = new Map<string, City>();
  for (const h of holdings) {
    if (h.countryCode === "XX") continue;
    const key = h.country;
    const cur = map.get(key) ?? {
      lat: h.lat,
      lng: h.lng,
      name: h.country,
      weight: 0,
      color: h.color,
    };
    cur.weight += h.weight;
    map.set(key, cur);
  }
  cities.push(...map.values());

  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let rotY = 20;
    let rotX = -8;
    let dragging = false;
    let lastX = 0;
    let lastY = 0;
    let raf = 0;
    let running = true;

    const resize = () => {
      const size = Math.min(wrap.clientWidth, 460);
      const dpr = window.devicePixelRatio || 1;
      canvas.style.width = `${size}px`;
      canvas.style.height = `${size}px`;
      canvas.width = size * dpr;
      canvas.height = size * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(wrap);

    const project = (lat: number, lng: number, r: number) => {
      const λ = ((lng + rotY) * Math.PI) / 180;
      const φ = (lat * Math.PI) / 180;
      let x = Math.cos(φ) * Math.sin(λ);
      let y = Math.sin(φ);
      let z = Math.cos(φ) * Math.cos(λ);
      const rx = (rotX * Math.PI) / 180;
      const y2 = y * Math.cos(rx) - z * Math.sin(rx);
      const z2 = y * Math.sin(rx) + z * Math.cos(rx);
      return { x: x * r, y: y2 * r, z: z2, visible: z2 > 0 };
    };

    const draw = () => {
      if (!running) return;
      const size = canvas.clientWidth;
      const c = size / 2;
      const r = size * 0.38;
      ctx.clearRect(0, 0, size, size);

      const grd = ctx.createRadialGradient(c - r * 0.3, c - r * 0.4, r * 0.2, c, c, r * 1.15);
      grd.addColorStop(0, "rgba(125,240,232,0.08)");
      grd.addColorStop(0.45, "rgba(18,24,38,0.9)");
      grd.addColorStop(1, "rgba(7,9,14,0)");
      ctx.beginPath();
      ctx.arc(c, c, r * 1.18, 0, Math.PI * 2);
      ctx.fillStyle = grd;
      ctx.fill();

      const sphere = ctx.createRadialGradient(c - r * 0.35, c - r * 0.45, r * 0.1, c, c, r);
      sphere.addColorStop(0, "#1a2740");
      sphere.addColorStop(0.7, "#0c1320");
      sphere.addColorStop(1, "#07090e");
      ctx.beginPath();
      ctx.arc(c, c, r, 0, Math.PI * 2);
      ctx.fillStyle = sphere;
      ctx.fill();
      ctx.strokeStyle = "rgba(125,240,232,0.35)";
      ctx.lineWidth = 1;
      ctx.stroke();

      ctx.save();
      ctx.beginPath();
      ctx.arc(c, c, r, 0, Math.PI * 2);
      ctx.clip();

      ctx.strokeStyle = "rgba(125,240,232,0.12)";
      ctx.lineWidth = 0.7;
      for (let lat = -75; lat <= 75; lat += 15) {
        ctx.beginPath();
        let started = false;
        for (let lng = -180; lng <= 180; lng += 6) {
          const p = project(lat, lng, r);
          if (!p.visible) {
            started = false;
            continue;
          }
          if (!started) {
            ctx.moveTo(c + p.x, c - p.y);
            started = true;
          } else ctx.lineTo(c + p.x, c - p.y);
        }
        ctx.stroke();
      }
      for (let lng = -180; lng < 180; lng += 15) {
        const meridian = lng === 0;
        ctx.strokeStyle = meridian ? "rgba(125,240,232,0.7)" : "rgba(125,240,232,0.12)";
        ctx.lineWidth = meridian ? 1.4 : 0.7;
        ctx.beginPath();
        let started = false;
        for (let lat = -90; lat <= 90; lat += 4) {
          const p = project(lat, lng, r);
          if (!p.visible) {
            started = false;
            continue;
          }
          if (!started) {
            ctx.moveTo(c + p.x, c - p.y);
            started = true;
          } else ctx.lineTo(c + p.x, c - p.y);
        }
        ctx.stroke();
      }

      const ranked = [...cities].sort((a, b) => a.weight - b.weight);
      for (const city of ranked) {
        const p = project(city.lat, city.lng, r);
        if (!p.visible) continue;
        const px = c + p.x;
        const py = c - p.y;
        const rad = 3 + city.weight / 6;
        const g = ctx.createRadialGradient(px, py, 0, px, py, rad * 4);
        g.addColorStop(0, city.color);
        g.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(px, py, rad * 4, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(px, py, rad, 0, Math.PI * 2);
        ctx.fillStyle = "#F3EFE4";
        ctx.fill();
        ctx.strokeStyle = city.color;
        ctx.lineWidth = 1.2;
        ctx.stroke();
        ctx.fillStyle = "rgba(243,239,228,0.85)";
        ctx.font = "10px IBM Plex Mono, monospace";
        ctx.fillText(`${city.name} ${city.weight.toFixed(0)}%`, px + 8, py - 8);
      }
      ctx.restore();

      if (!dragging) rotY += 0.12;
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);

    const down = (e: PointerEvent) => {
      dragging = true;
      lastX = e.clientX;
      lastY = e.clientY;
      canvas.setPointerCapture(e.pointerId);
    };
    const move = (e: PointerEvent) => {
      if (!dragging) return;
      rotY += (e.clientX - lastX) * 0.35;
      rotX = Math.max(-40, Math.min(40, rotX + (e.clientY - lastY) * 0.2));
      lastX = e.clientX;
      lastY = e.clientY;
    };
    const up = () => {
      dragging = false;
    };
    canvas.addEventListener("pointerdown", down);
    canvas.addEventListener("pointermove", move);
    canvas.addEventListener("pointerup", up);

    return () => {
      running = false;
      cancelAnimationFrame(raf);
      ro.disconnect();
      canvas.removeEventListener("pointerdown", down);
      canvas.removeEventListener("pointermove", move);
      canvas.removeEventListener("pointerup", up);
    };
  }, [holdings]);

  return (
    <div ref={wrapRef} className="flex flex-col items-center">
      <canvas ref={canvasRef} className="cursor-grab active:cursor-grabbing" />
      <p className="mt-1 font-mono text-[10px] tracking-widest text-mist">DRAG TO ROTATE · PRIME MERIDIAN LIT</p>
    </div>
  );
}
