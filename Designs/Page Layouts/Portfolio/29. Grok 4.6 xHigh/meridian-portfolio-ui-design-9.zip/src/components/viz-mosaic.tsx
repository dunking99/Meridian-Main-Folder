"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import type { Holding } from "@/lib/types";
import { formatPct, clsx } from "@/lib/format";
import { Money } from "@/components/currency";

export function WeightRibbon({
  holdings,
  groupBy = "assetClass",
}: {
  holdings: Holding[];
  groupBy?: "assetClass" | "sector" | "region" | "currency";
}) {
  const groups = useMemo(() => {
    const map = new Map<string, { label: string; value: number; color: string }>();
    for (const h of holdings) {
      const label = h[groupBy];
      const cur = map.get(label) ?? { label, value: 0, color: h.color };
      cur.value += h.weight;
      map.set(label, cur);
    }
    return [...map.values()].sort((a, b) => b.value - a.value);
  }, [holdings, groupBy]);
  const [hover, setHover] = useState<string | null>(null);

  return (
    <div>
      <div className="flex h-9 w-full overflow-hidden rounded-sm">
        {groups.map((g) => (
          <div
            key={g.label}
            onMouseEnter={() => setHover(g.label)}
            onMouseLeave={() => setHover(null)}
            className="relative h-full transition-all"
            style={{
              width: `${g.value}%`,
              background: `linear-gradient(180deg, ${g.color}, ${g.color}99)`,
              opacity: hover && hover !== g.label ? 0.35 : 1,
              boxShadow: "inset -1px 0 0 rgba(7,9,14,0.6)",
            }}
            title={`${g.label} ${g.value.toFixed(1)}%`}
          />
        ))}
      </div>
      <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1">
        {groups.map((g) => (
          <span
            key={g.label}
            className={clsx("font-mono text-[10px] tracking-wide", hover === g.label ? "text-moon" : "text-mist")}
          >
            <i className="mr-1.5 inline-block h-1.5 w-1.5 rounded-full" style={{ background: g.color }} />
            {g.label} {g.value.toFixed(1)}%
          </span>
        ))}
      </div>
    </div>
  );
}

export function BookShape({ holdings }: { holdings: Holding[] }) {
  const rings = useMemo(() => {
    const asset = roll(holdings, "assetClass");
    const sector = roll(holdings, "sector");
    const names = holdings.slice(0, 14).map((h) => ({ label: h.symbol, value: h.weight, color: h.color }));
    return [asset, sector, names];
  }, [holdings]);
  const size = 320;
  const c = size / 2;
  return (
    <svg viewBox={`0 0 ${size} ${size}`} className="mx-auto w-full max-w-[340px]">
      <circle cx={c} cy={c} r="18" fill="#0C1018" stroke="#7DF0E8" />
      <text x={c} y={c + 3} textAnchor="middle" fill="#7DF0E8" fontSize="8" fontFamily="IBM Plex Mono, monospace">
        BOOK
      </text>
      {rings.map((ring, ri) => {
        const r0 = 28 + ri * 38;
        const r1 = r0 + 32;
        let a0 = -Math.PI / 2;
        const total = ring.reduce((s, x) => s + x.value, 0) || 1;
        return (
          <g key={ri}>
            {ring.map((seg) => {
              const sweep = (seg.value / total) * Math.PI * 2 * 0.97;
              const gap = (seg.value / total) * Math.PI * 2 * 0.03;
              const path = annular(c, c, r0, r1, a0, a0 + sweep);
              const mid = a0 + sweep / 2;
              const lx = c + Math.cos(mid) * ((r0 + r1) / 2);
              const ly = c + Math.sin(mid) * ((r0 + r1) / 2);
              const el = (
                <g key={seg.label}>
                  <path d={path} fill={seg.color} fillOpacity={0.22 + ri * 0.12} stroke={seg.color} strokeWidth="0.6" />
                  {seg.value > 7 ? (
                    <text
                      x={lx}
                      y={ly + 3}
                      textAnchor="middle"
                      fill="#F3EFE4"
                      fontSize={ri === 2 ? 7 : 8}
                      fontFamily="IBM Plex Mono, monospace"
                    >
                      {seg.label}
                    </text>
                  ) : null}
                </g>
              );
              a0 += sweep + gap;
              return el;
            })}
          </g>
        );
      })}
    </svg>
  );
}

function roll(holdings: Holding[], key: "assetClass" | "sector") {
  const map = new Map<string, { label: string; value: number; color: string }>();
  for (const h of holdings) {
    const label = h[key];
    const cur = map.get(label) ?? { label, value: 0, color: h.color };
    cur.value += h.weight;
    map.set(label, cur);
  }
  return [...map.values()].sort((a, b) => b.value - a.value);
}

function annular(cx: number, cy: number, r0: number, r1: number, a0: number, a1: number) {
  const large = a1 - a0 > Math.PI ? 1 : 0;
  const p = (r: number, a: number) => [cx + Math.cos(a) * r, cy + Math.sin(a) * r] as const;
  const p0 = p(r1, a0);
  const p1 = p(r1, a1);
  const p2 = p(r0, a1);
  const p3 = p(r0, a0);
  return `M${p0[0]},${p0[1]} A${r1},${r1} 0 ${large} 1 ${p1[0]},${p1[1]} L${p2[0]},${p2[1]} A${r0},${r0} 0 ${large} 0 ${p3[0]},${p3[1]} Z`;
}

export function LeadersLaggards({ holdings }: { holdings: Holding[] }) {
  const eq = holdings.filter((h) => h.kind !== "cash");
  const leaders = [...eq].sort((a, b) => b.dayChangePct - a.dayChangePct).slice(0, 5);
  const laggards = [...eq].sort((a, b) => a.dayChangePct - b.dayChangePct).slice(0, 5);
  const max = Math.max(...leaders.concat(laggards).map((h) => Math.abs(h.dayChangePct)), 1);
  return (
    <div className="grid grid-cols-2 gap-6">
      <Lane title="Leaders" items={leaders} max={max} up />
      <Lane title="Laggards" items={laggards} max={max} up={false} />
    </div>
  );
}

function Lane({
  title,
  items,
  max,
  up,
}: {
  title: string;
  items: Holding[];
  max: number;
  up: boolean;
}) {
  return (
    <div>
      <p className="kicker mb-3">{title}</p>
      <ul className="space-y-3">
        {items.map((h) => (
          <li key={h.symbol}>
            <Link href={`/portfolio/holdings/${h.symbol}`} className="block">
              <div className="flex items-baseline justify-between">
                <span className="font-mono text-[12px] text-moon">{h.symbol}</span>
                <span className={up ? "num-up font-mono text-[12px]" : "num-down font-mono text-[12px]"}>
                  {formatPct(h.dayChangePct)}
                </span>
              </div>
              <div className="mt-1 h-[6px] bg-white/5">
                <div
                  className="h-full"
                  style={{
                    width: `${(Math.abs(h.dayChangePct) / max) * 100}%`,
                    background: up
                      ? "linear-gradient(90deg, transparent, #C6F26D)"
                      : "linear-gradient(90deg, transparent, #FF6A4A)",
                  }}
                />
              </div>
              <p className="mt-0.5 text-[11px] text-mist">{h.name}</p>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function AttributionCascade({ holdings }: { holdings: Holding[] }) {
  const rows = [...holdings]
    .filter((h) => h.kind !== "cash")
    .sort((a, b) => Math.abs(b.dayPnl) - Math.abs(a.dayPnl))
    .slice(0, 8);
  const max = Math.max(...rows.map((r) => Math.abs(r.dayPnl)), 1);
  return (
    <div className="space-y-2">
      {rows.map((h) => {
        const pos = h.dayPnl >= 0;
        const w = (Math.abs(h.dayPnl) / max) * 48;
        return (
          <Link
            key={h.symbol}
            href={`/portfolio/holdings/${h.symbol}`}
            className="grid grid-cols-[72px_1fr_72px] items-center gap-2"
          >
            <span className="font-mono text-[11px] text-right text-mist">{h.symbol}</span>
            <div className="relative h-7">
              <div className="absolute inset-y-0 left-1/2 w-px bg-meridian/50" />
              <div
                className="absolute top-1 h-5"
                style={{
                  width: `${w}%`,
                  left: pos ? "50%" : `${50 - w}%`,
                  background: pos
                    ? "linear-gradient(90deg, rgba(198,242,109,0.15), #C6F26D)"
                    : "linear-gradient(90deg, #FF6A4A, rgba(255,106,74,0.15))",
                }}
              />
            </div>
            <span className={clsx("font-mono text-[11px]", pos ? "num-up" : "num-down")}>
              <Money usd={h.dayPnl} compact />
            </span>
          </Link>
        );
      })}
    </div>
  );
}

export function layoutTreemap<T extends { value: number }>(
  items: T[],
  x: number,
  y: number,
  w: number,
  h: number,
): Array<T & { x: number; y: number; w: number; h: number }> {
  const acc: Array<T & { x: number; y: number; w: number; h: number }> = [];
  const sorted = [...items].filter((d) => d.value > 0).sort((a, b) => b.value - a.value);
  split(sorted, x, y, w, h, acc);
  return acc;
}

function split<T extends { value: number }>(
  items: T[],
  x: number,
  y: number,
  w: number,
  h: number,
  acc: Array<T & { x: number; y: number; w: number; h: number }>,
) {
  if (!items.length) return;
  if (items.length === 1) {
    acc.push({ ...items[0], x, y, w, h });
    return;
  }
  const total = items.reduce((s, i) => s + i.value, 0);
  let run = 0;
  let cut = 1;
  for (let i = 0; i < items.length; i += 1) {
    run += items[i].value;
    cut = i + 1;
    if (run >= total * 0.45) break;
  }
  const a = items.slice(0, cut);
  const b = items.slice(cut);
  const aSum = a.reduce((s, i) => s + i.value, 0);
  if (w >= h) {
    const w1 = (aSum / total) * w;
    split(a, x, y, w1, h, acc);
    split(b, x + w1, y, w - w1, h, acc);
  } else {
    const h1 = (aSum / total) * h;
    split(a, x, y, w, h1, acc);
    split(b, x, y + h1, w, h - h1, acc);
  }
}

export function HoldingTreemap({ holdings }: { holdings: Holding[] }) {
  const router = useRouter();
  const [mode, setMode] = useState<"heat" | "sector">("heat");
  const [hover, setHover] = useState<string | null>(null);
  const cells = useMemo(() => {
    const src = holdings.filter((h) => h.kind !== "cash").map((h) => ({ ...h, value: h.marketValue }));
    return layoutTreemap(src, 0, 0, 1000, 560);
  }, [holdings]);

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <p className="kicker">Tessera of the book</p>
        <div className="flex gap-1 rounded-full bg-ink p-1 hairline">
          {(["heat", "sector"] as const).map((m) => (
            <button
              key={m}
              type="button"
              onClick={() => setMode(m)}
              className={`px-3 py-1 font-mono text-[10px] tracking-[0.14em] rounded-full ${
                mode === m ? "bg-meridian/15 text-meridian" : "text-mist"
              }`}
            >
              {m === "heat" ? "WINNERS / LOSERS" : "SECTOR MINERAL"}
            </button>
          ))}
        </div>
      </div>
      <svg viewBox="0 0 1000 560" className="h-auto w-full">
        {cells.map((c) => {
          const heat = c.dayChangePct;
          const fill =
            mode === "sector"
              ? c.color
              : heat >= 0
                ? `rgba(198,242,109,${0.18 + Math.min(Math.abs(heat) / 8, 0.7)})`
                : `rgba(255,106,74,${0.18 + Math.min(Math.abs(heat) / 8, 0.7)})`;
          const dim = hover && hover !== c.symbol;
          return (
            <g
              key={c.symbol}
              onMouseEnter={() => setHover(c.symbol)}
              onMouseLeave={() => setHover(null)}
              onClick={() => router.push(`/portfolio/holdings/${c.symbol}`)}
              opacity={dim ? 0.28 : 1}
              className="cursor-pointer"
            >
              <rect
                x={c.x + 2}
                y={c.y + 2}
                width={Math.max(0, c.w - 4)}
                height={Math.max(0, c.h - 4)}
                fill={fill}
                stroke="rgba(243,239,228,0.08)"
              />
              <line
                x1={c.x + 2}
                y1={c.y + 2}
                x2={c.x + Math.min(28, c.w)}
                y2={c.y + 2}
                stroke="#7DF0E8"
                strokeWidth="1.4"
              />
              {c.w > 70 && c.h > 40 ? (
                <>
                  <text x={c.x + 12} y={c.y + 28} fill="#F3EFE4" fontSize={c.w > 140 ? 22 : 13} fontFamily="var(--font-display-face), serif">
                    {c.symbol}
                  </text>
                  <text x={c.x + 12} y={c.y + 46} fill="#8B97AB" fontSize="10" fontFamily="var(--font-mono-face), monospace">
                    {c.weight.toFixed(1)}% · {formatPct(c.dayChangePct)}
                  </text>
                </>
              ) : c.w > 44 && c.h > 28 ? (
                <text x={c.x + 8} y={c.y + 20} fill="#F3EFE4" fontSize="10" fontFamily="var(--font-mono-face), monospace">
                  {c.symbol}
                </text>
              ) : null}
            </g>
          );
        })}
      </svg>
    </div>
  );
}
