import type { ReactNode } from "react";
import { clsx } from "@/lib/format";

export function Plate({
  index,
  title,
  kicker,
  action,
  children,
  className,
  bodyClass,
}: {
  index?: string;
  title?: string;
  kicker?: string;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
  bodyClass?: string;
}) {
  return (
    <section className={clsx("plate tick-corners p-5 md:p-6", className)}>
      {(title || index || action) && (
        <header className="relative z-[1] mb-5 flex items-start justify-between gap-3">
          <div>
            <div className="flex items-center gap-3">
              {index ? <span className="kicker text-meridian">{index}</span> : null}
              {title ? (
                <h3 className="font-display text-[1.35rem] leading-none text-moon">{title}</h3>
              ) : null}
            </div>
            {kicker ? <p className="mt-1.5 max-w-xl text-[12px] leading-relaxed text-mist">{kicker}</p> : null}
          </div>
          {action ? <div className="shrink-0">{action}</div> : null}
        </header>
      )}
      <div className={clsx("relative z-[1]", bodyClass)}>{children}</div>
    </section>
  );
}
