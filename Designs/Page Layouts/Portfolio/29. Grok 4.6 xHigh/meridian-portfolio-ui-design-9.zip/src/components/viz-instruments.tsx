"use client";

import { useEffect, useMemo, useState } from "react";
import { formatPct } from "@/lib/format";
import { Money } from "@/components/currency";

export function CountUp({
  value,
  className,
}: {
  value: number;
  className?: string;
}) {
  const [shown, setShown] = useState(value * 0.92);
  useEffect(() => {
    const start = performance.now();
    const from = value * 0.92;
    let raf = 0;
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / 900);
      const e = 1 - Math.pow(1 - p, 3);
      setShown(from + (value - from) * e);
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [value]);
  return (
    <span className={className}>
      <Money usd={shown} />
    </span>
  );
}

export function CompassRose({ score, grade }: { score: number; grade: string }) {
  const size = 260;
  const c = size / 2;
  const needle = -90 + (score / 100) * 180;
  const ticks = Array.from({ length: 36 }, (_, i) => i);
  const labels = [
    { a: -90, t: "Calm" },
    { a: -45, t: "Measured" },
    { a: 0, t: "Balanced" },
    { a: 45, t: "Assertive" },
    { a: 90, t: "Hot" },
  ];
  return (
    <div className="flex flex-col items-center">
      <svg viewBox={`0 0 ${size} ${size}`} className="w-full max-w-[280px]">
        <defs>
          <radialGradient id="compg" cx="50%" cy="45%">
            <stop offset="0%" stopColor="#1a2438" />
            <stop offset="100%" stopColor="#0c1018" />
          </radialGradient>
        </defs>
        <circle cx={c} cy={c} r={118} fill="url(#compg)" stroke="rgba(125,240,232,0.25)" />
        <circle cx={c} cy={c} r={102} fill="none" stroke="rgba(210,224,236,0.08)" />
        <circle cx={c} cy={c} r={86} fill="none" stroke="rgba(210,224,236,0.05)" />
        {ticks.map((i) => {
          const a = ((i / 36) * 360 - 90) * (Math.PI / 180);
          const inner = i % 3 === 0 ? 92 : 96;
          return (
            <line
              key={i}
              x1={c + Math.cos(a) * inner}
              y1={c + Math.sin(a) * inner}
              x2={c + Math.cos(a) * 112}
              y2={c + Math.sin(a) * 112}
              stroke={i % 9 === 0 ? "#7DF0E8" : "rgba(210,224,236,0.28)"}
              strokeWidth={i % 9 === 0 ? 1.6 : 0.7}
            />
          );
        })}
        {labels.map((l) => {
          const a = (l.a - 90) * (Math.PI / 180);
          return (
            <text
              key={l.t}
              x={c + Math.cos(a) * 72}
              y={c + Math.sin(a) * 72 + 3}
              textAnchor="middle"
              fill="#8B97AB"
              fontSize="8"
              fontFamily="IBM Plex Mono, monospace"
              letterSpacing="1.5"
            >
              {l.t.toUpperCase()}
            </text>
          );
        })}
        <polygon
          points={`${c},${c - 78} ${c - 7},${c + 18} ${c + 7},${c + 18}`}
          fill="#FF6A4A"
          transform={`rotate(${needle} ${c} ${c})`}
        />
        <circle cx={c} cy={c} r="18" fill="#0C1018" stroke="#7DF0E8" strokeWidth="1.4" />
        <text x={c} y={c + 5} textAnchor="middle" fill="#F3EFE4" fontSize="16" fontFamily="Fraunces, serif">
          {grade}
        </text>
        <text x={c} y={c + 46} textAnchor="middle" fill="#7DF0E8" fontSize="10" fontFamily="IBM Plex Mono, monospace">
          RISK {score}
        </text>
      </svg>
    </div>
  );
}

export function HealthRings({
  score,
  parts,
}: {
  score: number;
  parts: Array<{ label: string; value: number; color: string }>;
}) {
  const size = 260;
  const c = size / 2;
  return (
    <div className="flex flex-col items-center">
      <svg viewBox={`0 0 ${size} ${size}`} className="w-full max-w-[280px]">
        {parts.map((p, i) => {
          const r = 108 - i * 16;
          const circ = 2 * Math.PI * r;
          const dash = (p.value / 100) * circ;
          return (
            <g key={p.label}>
              <circle cx={c} cy={c} r={r} fill="none" stroke="rgba(210,224,236,0.06)" strokeWidth="8" />
              <circle
                cx={c}
                cy={c}
                r={r}
                fill="none"
                stroke={p.color}
                strokeWidth="8"
                strokeDasharray={`${dash} ${circ}`}
                strokeLinecap="round"
                transform={`rotate(-90 ${c} ${c})`}
              />
            </g>
          );
        })}
        <text x={c} y={c - 4} textAnchor="middle" fill="#F3EFE4" fontSize="36" fontFamily="Fraunces, serif">
          {score}
        </text>
        <text x={c} y={c + 16} textAnchor="middle" fill="#8B97AB" fontSize="9" fontFamily="IBM Plex Mono, monospace" letterSpacing="2">
          HEALTH
        </text>
      </svg>
      <div className="mt-2 grid w-full grid-cols-2 gap-x-4 gap-y-1">
        {parts.map((p) => (
          <div key={p.label} className="flex items-center justify-between gap-2">
            <span className="flex items-center gap-1.5 font-mono text-[10px] text-mist">
              <i className="inline-block h-1.5 w-1.5 rounded-full" style={{ background: p.color }} />
              {p.label}
            </span>
            <span className="font-mono text-[10px] text-moon">{p.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export function ArcMeter({
  label,
  value,
  max = 100,
  suffix = "",
  color = "#7DF0E8",
  hint,
}: {
  label: string;
  value: number;
  max?: number;
  suffix?: string;
  color?: string;
  hint?: string;
}) {
  const r = 52;
  const c = 70;
  const circ = Math.PI * r;
  const pct = Math.max(0, Math.min(1, value / max));
  const ticks = Array.from({ length: 21 }, (_, i) => i);
  return (
    <div className="flex flex-col items-center">
      <svg viewBox="0 0 140 92" className="w-full">
        <path
          d={`M ${c - r} ${c} A ${r} ${r} 0 0 1 ${c + r} ${c}`}
          fill="none"
          stroke="rgba(210,224,236,0.08)"
          strokeWidth="8"
          strokeLinecap="round"
        />
        <path
          d={`M ${c - r} ${c} A ${r} ${r} 0 0 1 ${c + r} ${c}`}
          fill="none"
          stroke={color}
          strokeWidth="8"
          strokeLinecap="round"
          strokeDasharray={`${pct * circ} ${circ}`}
        />
        {ticks.map((i) => {
          const a = Math.PI + (i / 20) * Math.PI;
          const inner = i % 5 === 0 ? 38 : 42;
          return (
            <line
              key={i}
              x1={c + Math.cos(a) * inner}
              y1={c + Math.sin(a) * inner}
              x2={c + Math.cos(a) * 46}
              y2={c + Math.sin(a) * 46}
              stroke="rgba(210,224,236,0.35)"
              strokeWidth={i % 5 === 0 ? 1.2 : 0.6}
            />
          );
        })}
        <text x={c} y={c - 4} textAnchor="middle" fill="#F3EFE4" fontSize="20" fontFamily="Fraunces, serif">
          {value.toFixed(value < 10 ? 2 : 0)}
          {suffix}
        </text>
        <text x={c} y={c + 14} textAnchor="middle" fill="#8B97AB" fontSize="8" fontFamily="IBM Plex Mono, monospace" letterSpacing="1.6">
          {label.toUpperCase()}
        </text>
      </svg>
      {hint ? <p className="mt-[-8px] text-center font-mono text-[10px] text-mist">{hint}</p> : null}
    </div>
  );
}

export function PulseVitals({
  items,
}: {
  items: Array<{ label: string; value: string; hint: string; tone: "up" | "down" | "flat" | "warn" }>;
}) {
  const tone = {
    up: "text-lime",
    down: "text-coral",
    flat: "text-meridian",
    warn: "text-sand",
  };
  return (
    <div className="grid grid-cols-2 gap-px overflow-hidden rounded-sm bg-white/5 md:grid-cols-6">
      {items.map((it) => (
        <div key={it.label} className="bg-plate px-4 py-4">
          <p className="kicker">{it.label}</p>
          <p className={`font-display mt-2 text-2xl leading-none ${tone[it.tone]}`}>{it.value}</p>
          <p className="mt-2 font-mono text-[10px] leading-relaxed text-mist">{it.hint}</p>
        </div>
      ))}
    </div>
  );
}

export function Scorecard({
  items,
}: {
  items: Array<{ label: string; value: number; max?: number; color: string; note: string }>;
}) {
  return (
    <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
      {items.map((it) => (
        <ArcMeter
          key={it.label}
          label={it.label}
          value={it.value}
          max={it.max ?? 100}
          color={it.color}
          hint={it.note}
        />
      ))}
    </div>
  );
}

export function useNowLabel() {
  return useMemo(() => {
    return new Intl.DateTimeFormat("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    }).format(new Date());
  }, []);
}

export function HeroNav({
  nav,
  dayPct,
  dayPnl,
  inception,
}: {
  nav: number;
  dayPct: number;
  dayPnl: number;
  inception: string;
}) {
  const date = useNowLabel();
  return (
    <div className="relative overflow-hidden px-1 py-4">
      <div className="pointer-events-none absolute inset-y-0 left-[34%] w-px meridian-rule" />
      <p className="kicker">The book · marked {date}</p>
      <div className="mt-3 flex flex-wrap items-end gap-6">
        <h2 className="font-display glow-cyan text-[clamp(3.4rem,8vw,6.4rem)] leading-[0.9] tracking-[-0.04em] text-moon">
          <CountUp value={nav} />
        </h2>
        <div className="mb-2">
          <p className={`font-display text-3xl ${dayPct >= 0 ? "num-up" : "num-down"}`}>{formatPct(dayPct)}</p>
          <p className="font-mono text-[11px] text-mist">
            <Money usd={dayPnl} /> today · incept {inception}
          </p>
        </div>
      </div>
    </div>
  );
}
