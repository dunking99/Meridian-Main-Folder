/* ══════════════════════════════════════════════════════════════════
   MERIDIAN · market engine
   A deterministic simulation so every view on every page derives
   from one consistent set of numbers.
   ══════════════════════════════════════════════════════════════════ */

export const N = 378; // trading days of history
const DAY = 86400000;
export const END = new Date(Date.UTC(2026, 1, 13));

/* ── seeded noise ─────────────────────────────────────────────── */
function mulberry32(a: number) {
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const rnd = mulberry32(20260213);
function gauss() {
  let u = 0;
  let v = 0;
  while (u === 0) u = rnd();
  while (v === 0) v = rnd();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

/* ── dates (weekdays only) ────────────────────────────────────── */
export const dates: Date[] = (() => {
  const out: Date[] = [];
  let t = END.getTime();
  while (out.length < N) {
    const d = new Date(t);
    const wd = d.getUTCDay();
    if (wd !== 0 && wd !== 6) out.push(d);
    t -= DAY;
  }
  return out.reverse();
})();

export const iso = (d: Date) => d.toISOString().slice(0, 10);
export const dayIndexFromNow = (daysAgo: number) => Math.max(0, N - 1 - daysAgo);

/* ── FX ───────────────────────────────────────────────────────── */
export const FX: Record<string, number> = {
  USD: 1,
  EUR: 1.0864,
  GBP: 1.2718,
  DKK: 0.1456,
  CHF: 1.1325,
  JPY: 0.00662,
  TWD: 0.03055,
  SGD: 0.7418,
};

export const CURRENCIES = [
  { code: "USD", symbol: "$", rate: 1 },
  { code: "EUR", symbol: "€", rate: 1 / FX.EUR },
  { code: "GBP", symbol: "£", rate: 1 / FX.GBP },
  { code: "JPY", symbol: "¥", rate: 1 / FX.JPY },
] as const;

/* ── holding specification ────────────────────────────────────── */
export type Spec = {
  ticker: string;
  name: string;
  short: string;
  exchange: string;
  sector: string;
  industry: string;
  country: string;
  flag: string;
  lat: number;
  lon: number;
  currency: string;
  price: number; // current native price
  weight: number; // target % of portfolio
  pl: number; // target unrealised P/L %
  beta: number;
  idio: number; // annualised idiosyncratic vol
  drift: number; // annual drift
  divYield: number;
  pe: number;
  mcap: string;
  assetClass: string;
  color: string;
  thesis?: string;
};

export const SECTOR_COLORS: Record<string, string> = {
  Technology: "#7db8ff",
  Semiconductors: "#a08bff",
  "Consumer Discretionary": "#ff9e6b",
  "Consumer Staples": "#e6d5a8",
  Healthcare: "#5ee3d0",
  Energy: "#ff6b5e",
  Financials: "#9fb3d9",
  Industrials: "#c0a2ff",
  Materials: "#b7c4d4",
  "Real Assets": "#ffd479",
  Bonds: "#7ea6b8",
  Cash: "#5c6a80",
};

export const SPECS: Spec[] = [
  { ticker: "NVDA", name: "NVIDIA Corporation", short: "NVIDIA", exchange: "NASDAQ", sector: "Semiconductors", industry: "AI accelerators", country: "United States", flag: "🇺🇸", lat: 37.4, lon: -122.1, currency: "USD", price: 1284.4, weight: 12.4, pl: 71.2, beta: 1.62, idio: 0.44, drift: 0.62, divYield: 0.02, pe: 41.2, mcap: "3.14T", assetClass: "Equity", color: SECTOR_COLORS.Semiconductors },
  { ticker: "VWRD", name: "Vanguard FTSE All-World", short: "All-World", exchange: "LSE", sector: "Real Assets", industry: "Global equity fund", country: "Ireland", flag: "🇮🇪", lat: 53.3, lon: -8, currency: "USD", price: 141.86, weight: 13.6, pl: 12.4, beta: 0.96, idio: 0.03, drift: 0.13, divYield: 1.92, pe: 18.4, mcap: "—", assetClass: "Fund", color: "#8fd0c2" },
  { ticker: "MSFT", name: "Microsoft Corporation", short: "Microsoft", exchange: "NASDAQ", sector: "Technology", industry: "Cloud & software", country: "United States", flag: "🇺🇸", lat: 47.7, lon: -122.1, currency: "USD", price: 498.2, weight: 9.1, pl: 23.8, beta: 1.08, idio: 0.21, drift: 0.16, divYield: 0.72, pe: 34.6, mcap: "3.70T", assetClass: "Equity", color: SECTOR_COLORS.Technology },
  { ticker: "ASML", name: "ASML Holding N.V.", short: "ASML", exchange: "Euronext", sector: "Semiconductors", industry: "Lithography", country: "Netherlands", flag: "🇳🇱", lat: 51.4, lon: 5.5, currency: "EUR", price: 742.9, weight: 6.0, pl: 15.1, beta: 1.34, idio: 0.33, drift: 0.14, divYield: 1.05, pe: 33.1, mcap: "291B", assetClass: "Equity", color: SECTOR_COLORS.Semiconductors },
  { ticker: "TSM", name: "Taiwan Semiconductor", short: "TSMC", exchange: "NYSE", sector: "Semiconductors", industry: "Foundry", country: "Taiwan", flag: "🇹🇼", lat: 24.8, lon: 121.0, currency: "TWD", price: 1184.0, weight: 5.3, pl: 38.4, beta: 1.28, idio: 0.29, drift: 0.29, divYield: 1.35, pe: 24.8, mcap: "580B", assetClass: "Equity", color: SECTOR_COLORS.Semiconductors },
  { ticker: "LVMH", name: "LVMH Moët Hennessy", short: "LVMH", exchange: "Euronext", sector: "Consumer Discretionary", industry: "Luxury goods", country: "France", flag: "🇫🇷", lat: 48.9, lon: 2.35, currency: "EUR", price: 612.4, weight: 5.7, pl: -13.8, beta: 1.12, idio: 0.24, drift: -0.09, divYield: 1.9, pe: 22.4, mcap: "306B", assetClass: "Equity", color: SECTOR_COLORS["Consumer Discretionary"] },
  { ticker: "7203", name: "Toyota Motor Corp.", short: "Toyota", exchange: "TSE", sector: "Consumer Discretionary", industry: "Autos", country: "Japan", flag: "🇯🇵", lat: 35.6, lon: 139.7, currency: "JPY", price: 3128.0, weight: 4.4, pl: 29.6, beta: 0.84, idio: 0.2, drift: 0.22, divYield: 2.6, pe: 9.8, mcap: "234B", assetClass: "Equity", color: "#ffb27a" },
  { ticker: "AAPL", name: "Apple Inc.", short: "Apple", exchange: "NASDAQ", sector: "Technology", industry: "Hardware & services", country: "United States", flag: "🇺🇸", lat: 37.3, lon: -122.0, currency: "USD", price: 264.8, weight: 4.6, pl: 8.9, beta: 1.02, idio: 0.19, drift: 0.07, divYield: 0.44, pe: 31.9, mcap: "3.96T", assetClass: "Equity", color: SECTOR_COLORS.Technology },
  { ticker: "IEAC", name: "iShares Core € Corp Bond", short: "€ Corp Bond", exchange: "Xetra", sector: "Bonds", industry: "Investment grade", country: "Ireland", flag: "🇮🇪", lat: 53.3, lon: -8, currency: "EUR", price: 128.44, weight: 7.0, pl: 2.6, beta: 0.18, idio: 0.035, drift: 0.045, divYield: 3.58, pe: 0, mcap: "—", assetClass: "Bond", color: SECTOR_COLORS.Bonds },
  { ticker: "NVO", name: "Novo Nordisk A/S", short: "Novo Nordisk", exchange: "Nasdaq Cph", sector: "Healthcare", industry: "GLP-1 therapies", country: "Denmark", flag: "🇩🇰", lat: 55.7, lon: 12.6, currency: "DKK", price: 412.6, weight: 4.0, pl: -21.4, beta: 0.72, idio: 0.36, drift: -0.18, divYield: 1.4, pe: 19.2, mcap: "368B", assetClass: "Equity", color: SECTOR_COLORS.Healthcare },
  { ticker: "SGLN", name: "iShares Physical Gold", short: "Gold", exchange: "LSE", sector: "Real Assets", industry: "Precious metal", country: "Ireland", flag: "🇮🇪", lat: 53.3, lon: -8, currency: "USD", price: 34.82, weight: 4.5, pl: 26.2, beta: 0.09, idio: 0.13, drift: 0.19, divYield: 0, pe: 0, mcap: "—", assetClass: "Commodity", color: "#ffd479" },
  { ticker: "SHEL", name: "Shell plc", short: "Shell", exchange: "LSE", sector: "Energy", industry: "Integrated oil", country: "United Kingdom", flag: "🇬🇧", lat: 51.5, lon: -0.1, currency: "GBP", price: 29.42, weight: 3.6, pl: 7.3, beta: 0.71, idio: 0.22, drift: 0.03, divYield: 4.05, pe: 12.1, mcap: "198B", assetClass: "Equity", color: SECTOR_COLORS.Energy },
  { ticker: "NESN", name: "Nestlé S.A.", short: "Nestlé", exchange: "SIX", sector: "Consumer Staples", industry: "Packaged food", country: "Switzerland", flag: "🇨🇭", lat: 46.8, lon: 8.2, currency: "CHF", price: 76.9, weight: 3.2, pl: -6.1, beta: 0.44, idio: 0.13, drift: -0.03, divYield: 3.42, pe: 17.6, mcap: "203B", assetClass: "Equity", color: SECTOR_COLORS["Consumer Staples"] },
  { ticker: "SAN", name: "Sanofi S.A.", short: "Sanofi", exchange: "Euronext", sector: "Healthcare", industry: "Pharmaceuticals", country: "France", flag: "🇫🇷", lat: 48.9, lon: 2.35, currency: "EUR", price: 96.14, weight: 2.9, pl: 10.4, beta: 0.58, idio: 0.18, drift: 0.08, divYield: 4.12, pe: 13.4, mcap: "122B", assetClass: "Equity", color: SECTOR_COLORS.Healthcare },
  { ticker: "REL", name: "RELX PLC", short: "RELX", exchange: "LSE", sector: "Industrials", industry: "Information services", country: "United Kingdom", flag: "🇬🇧", lat: 51.5, lon: -0.1, currency: "GBP", price: 42.18, weight: 3.1, pl: 44.2, beta: 0.79, idio: 0.16, drift: 0.31, divYield: 1.62, pe: 29.8, mcap: "78B", assetClass: "Equity", color: SECTOR_COLORS.Industrials },
  { ticker: "BAM", name: "Brookfield Corp.", short: "Brookfield", exchange: "NYSE", sector: "Financials", industry: "Alternative assets", country: "United States", flag: "🇺🇸", lat: 40.7, lon: -74.0, currency: "USD", price: 62.74, weight: 2.5, pl: 18.7, beta: 1.21, idio: 0.24, drift: 0.15, divYield: 0.58, pe: 27.2, mcap: "102B", assetClass: "Equity", color: SECTOR_COLORS.Financials },
  { ticker: "SE", name: "Sea Limited", short: "Sea Ltd", exchange: "NYSE", sector: "Consumer Discretionary", industry: "Digital commerce", country: "Singapore", flag: "🇸🇬", lat: 1.35, lon: 103.8, currency: "USD", price: 108.6, weight: 1.7, pl: -24.6, beta: 1.55, idio: 0.52, drift: -0.2, divYield: 0, pe: 0, mcap: "62B", assetClass: "Equity", color: "#ff8f6b" },
  { ticker: "RIO", name: "Rio Tinto Group", short: "Rio Tinto", exchange: "LSE", sector: "Materials", industry: "Diversified mining", country: "United Kingdom", flag: "🇬🇧", lat: 51.5, lon: -0.1, currency: "GBP", price: 62.94, weight: 2.0, pl: -4.4, beta: 0.88, idio: 0.19, drift: 0.02, divYield: 5.4, pe: 10.4, mcap: "102B", assetClass: "Equity", color: SECTOR_COLORS.Materials },
];

/* ── benchmark (global equity, net total return) ──────────────── */
const marketRet: number[] = [];
const bench: number[] = [];
(() => {
  let b = 100;
  for (let i = 0; i < N; i++) {
    const shock = i === N - 96 ? 0.011 : 0;
    const r = 0.00046 + 0.0071 * gauss() + shock;
    marketRet.push(r);
    b *= 1 + r;
    bench.push(b);
  }
})();
export const benchmark = bench;
export const benchmarkStart = bench[0];

/* ── one-off company events (days ago, % impact) ──────────────── */
const EVENTS: { t: string; ago: number; pct: number }[] = [
  { t: "NVDA", ago: 92, pct: 15.5 },
  { t: "NVDA", ago: 21, pct: 7.2 },
  { t: "NVO", ago: 138, pct: -19.8 },
  { t: "NVO", ago: 34, pct: -8.4 },
  { t: "LVMH", ago: 203, pct: -8.6 },
  { t: "SE", ago: 61, pct: -16.2 },
  { t: "REL", ago: 150, pct: 9.4 },
  { t: "TSM", ago: 175, pct: 11.2 },
  { t: "SHEL", ago: 240, pct: -7.1 },
  { t: "7203", ago: 118, pct: 8.8 },
  { t: "SGLN", ago: 260, pct: 6.4 },
  { t: "BAM", ago: 84, pct: -6.8 },
  { t: "MSFT", ago: 30, pct: 4.9 },
  { t: "ASML", ago: 47, pct: -5.2 },
];

/* ── cash flows & trades ──────────────────────────────────────── */
export type Trade = { ago: number; ticker: string; qty: number; type: "buy" | "sell"; note?: string };
export const TRADES: Trade[] = [
  { ago: 290, ticker: "NVDA", qty: 6, type: "buy", note: "Pre-earnings add" },
  { ago: 300, ticker: "LVMH", qty: 8, type: "buy", note: "Luxury de-rating entry" },
  { ago: 288, ticker: "VWRD", qty: 60, type: "buy" },
  { ago: 264, ticker: "SGLN", qty: 320, type: "buy", note: "Hedge top-up" },
  { ago: 240, ticker: "SE", qty: 22, type: "buy" },
  { ago: 214, ticker: "TSM", qty: 6, type: "buy" },
  { ago: 190, ticker: "NVO", qty: 26, type: "buy", note: "Averaging down" },
  { ago: 166, ticker: "REL", qty: 42, type: "buy" },
  { ago: 141, ticker: "SE", qty: 14, type: "sell", note: "Thesis trimmed" },
  { ago: 122, ticker: "7203", qty: 30, type: "buy" },
  { ago: 96, ticker: "NVDA", qty: 5, type: "buy" },
  { ago: 74, ticker: "SAN", qty: 18, type: "buy" },
  { ago: 52, ticker: "LVMH", qty: 6, type: "sell", note: "Stopped out of half" },
  { ago: 31, ticker: "BAM", qty: 24, type: "buy" },
  { ago: 12, ticker: "IEAC", qty: 205, type: "buy", note: "Duration add" },
  { ago: 4, ticker: "RIO", qty: 30, type: "buy" },
];

export const DEPOSITS: { ago: number; amount: number; note: string }[] = [
  { ago: 377, amount: 0, note: "Account opened · transfer in" },
  { ago: 310, amount: 14000, note: "Monthly saving" },
  { ago: 270, amount: 14000, note: "Monthly saving" },
  { ago: 170, amount: 14000, note: "Annual bonus" },
  { ago: 80, amount: 10000, note: "Monthly saving" },
  { ago: 25, amount: 6000, note: "Monthly saving" },
];

export const TARGET_VALUE = 516_400;

/* ── price series ─────────────────────────────────────────────── */
function seriesFor(s: Spec) {
  const raw: number[] = [];
  let p = 100;
  for (let i = 0; i < N; i++) {
    const idio = (s.idio / Math.sqrt(252)) * gauss();
    const r = s.beta * marketRet[i] + idio + s.drift / 252;
    p *= 1 + r;
    raw.push(p);
  }
  for (const e of EVENTS) {
    if (e.t !== s.ticker) continue;
    const idx = dayIndexFromNow(e.ago);
    for (let i = idx; i < N; i++) raw[i] *= 1 + e.pct / 100;
  }
  const k = s.price / raw[N - 1];
  return raw.map((v) => v * k);
}

export type Holding = Spec & {
  prices: number[];
  qty: number;
  avgCost: number;
  qtySeries: number[];
  isCash?: boolean;
};

function buildQuantities() {
  const qtySeries: Record<string, number[]> = {};
  const finalQty: Record<string, number> = {};
  const tradesByTicker: Record<string, { day: number; qty: number; type: string }[]> = {};
  for (const tr of TRADES) {
    (tradesByTicker[tr.ticker] ||= []).push({ day: dayIndexFromNow(tr.ago), qty: tr.qty, type: tr.type });
  }
  for (const s of SPECS) {
    const totalBuy = (tradesByTicker[s.ticker] || []).reduce(
      (a, t) => a + (t.type === "buy" ? t.qty : -t.qty),
      0,
    );
    // final target quantity, then back out the initial position
    const usd = s.price * FX[s.currency];
    const target = (TARGET_VALUE * s.weight) / 100 / usd;
    const base = Math.max(1, Math.round(target - totalBuy));
    const arr: number[] = [];
    let q = base;
    const list = tradesByTicker[s.ticker] || [];
    for (let i = 0; i < N; i++) {
      for (const t of list) if (t.day === i) q += t.type === "buy" ? t.qty : -t.qty;
      arr.push(q);
    }
    qtySeries[s.ticker] = arr;
    finalQty[s.ticker] = q;
  }
  return { qtySeries, finalQty, tradesByTicker };
}

/* ── cash account ─────────────────────────────────────────────── */
function buildCash(qtySeries: Record<string, number[]>, prices: Record<string, number[]>) {
  const bal: number[] = [];
  let cash = 8000;
  let interest = 0;
  const depositMap = new Map<number, number>();
  for (const d of DEPOSITS) depositMap.set(dayIndexFromNow(d.ago), d.amount);
  const tradeMap = new Map<number, { ticker: string; qty: number; type: string }[]>();
  for (const tr of TRADES) {
    const day = dayIndexFromNow(tr.ago);
    (tradeMap.get(day) || tradeMap.set(day, []).get(day)!).push(tr);
  }
  const divDays = [dayIndexFromNow(300), dayIndexFromNow(215), dayIndexFromNow(130), dayIndexFromNow(45)];
  for (let i = 0; i < N; i++) {
    const dep = depositMap.get(i) || 0;
    cash += dep;
    for (const t of tradeMap.get(i) || []) {
      const pr = prices[t.ticker][i];
      cash += t.type === "sell" ? t.qty * pr * FX[SPECS.find((s) => s.ticker === t.ticker)!.currency] : -t.qty * pr * FX[SPECS.find((s) => s.ticker === t.ticker)!.currency];
    }
    if (divDays.includes(i)) {
      for (const s of SPECS) {
        if (s.divYield <= 0) continue;
        cash += qtySeries[s.ticker][i] * prices[s.ticker][i] * FX[s.currency] * (s.divYield / 100 / 4);
      }
    }
    const int = cash * (0.042 / 252);
    cash += int;
    interest += int;
    bal.push(cash);
  }
  return { bal, interest };
}

const { qtySeries, finalQty } = buildQuantities();
const priceMap: Record<string, number[]> = {};
for (const s of SPECS) priceMap[s.ticker] = seriesFor(s);

// the opening book is bought on day zero with the opening transfer
const OPENING_COST = SPECS.reduce(
  (a, s) => a + qtySeries[s.ticker][0] * priceMap[s.ticker][0] * FX[s.currency],
  0,
);
DEPOSITS[0].amount = Math.round(OPENING_COST + 12000);

const { bal: cashBal, interest: cashInterest } = buildCash(qtySeries, priceMap);

export const HOLDINGS: Holding[] = SPECS.map((s) => {
  const prices = priceMap[s.ticker];
  const qty = finalQty[s.ticker];
  const avgCost = s.price / (1 + s.pl / 100);
  return { ...s, prices, qty, avgCost, qtySeries: qtySeries[s.ticker] };
});

export const CASH: Holding = {
  ticker: "USD",
  name: "Cash & money market",
  short: "Cash",
  exchange: "—",
  sector: "Cash",
  industry: "USD money market",
  country: "—",
  flag: "💵",
  lat: 0,
  lon: 0,
  currency: "USD",
  price: 1,
  weight: 5,
  pl: 0,
  beta: 0,
  idio: 0,
  drift: 0.042,
  divYield: 4.2,
  pe: 0,
  mcap: "—",
  assetClass: "Cash",
  color: SECTOR_COLORS.Cash,
  prices: cashBal,
  qty: 1,
  avgCost: 1,
  qtySeries: cashBal.map(() => 1),
  isCash: true,
};

export const POSITIONS = [...HOLDINGS, CASH];
export const cashInterestEarned = cashInterest;
export const cashBalance = cashBal[N - 1];
export const byTicker = (t: string) => POSITIONS.find((p) => p.ticker === t);
