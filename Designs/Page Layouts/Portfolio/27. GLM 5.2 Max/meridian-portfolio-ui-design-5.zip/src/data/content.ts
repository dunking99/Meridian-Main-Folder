/* ══════════════════════════════════════════════════════════════════
   MERIDIAN · narrative content
   The layer that lets one part of the app talk about another.
   ══════════════════════════════════════════════════════════════════ */

export type JournalEntry = {
  id: string;
  ago: number;
  title: string;
  tickers: string[];
  conviction: number; // 1–5
  status: "on-track" | "challenged" | "closed";
  tags: string[];
  body: string;
  reviewIn: number; // days until next scheduled review
};

export const JOURNAL: JournalEntry[] = [
  {
    id: "j1",
    ago: 6,
    title: "NVDA at 12% — trimming discipline question",
    tickers: ["NVDA"],
    conviction: 4,
    status: "challenged",
    tags: ["sizing", "ai-cycle"],
    body:
      "Position is now 12.4% of book against a self-imposed 10% cap. The original thesis — accelerator demand outlasting supply — is intact and the backlog data supports it. But the sizing rule exists for a reason. Plan: trim 4% into strength, keep the remainder as a core. Not acting on this while it's green is exactly the behaviour the cap was written to prevent.",
    reviewIn: 4,
  },
  {
    id: "j2",
    ago: 19,
    title: "Novo Nordisk — thesis broken, not just cheap",
    tickers: ["NVO"],
    conviction: 2,
    status: "challenged",
    tags: ["healthcare", "averaging-down", "mistake"],
    body:
      "Bought twice into weakness on the assumption that oral semaglutide data was a timing issue rather than a competitive one. It was a competitive one. The moat question has changed: compounder pricing power in the US is now a political variable. Down 21% and I have been treating a fundamental problem as a price problem.",
    reviewIn: 0,
  },
  {
    id: "j3",
    ago: 34,
    title: "Why I own gold at 4.5%",
    tickers: ["SGLN"],
    conviction: 3,
    status: "on-track",
    tags: ["hedge", "macro"],
    body:
      "Not a view on inflation. It is a correlation break: 0.09 beta to world equities and it has paid while bonds did nothing. Job is to be flat when equities fall hard. Hold 4–5%, rebalance annually, never overweight.",
    reviewIn: 148,
  },
  {
    id: "j4",
    ago: 52,
    title: "LVMH — halved the position, kept the watchlist entry",
    tickers: ["LVMH"],
    conviction: 3,
    status: "on-track",
    tags: ["luxury", "china"],
    body:
      "Sold 6 shares at €664. Chinese demand recovery is real but slower than the multiple assumed. The remaining position is sized so that being early costs patience rather than money.",
    reviewIn: 41,
  },
  {
    id: "j5",
    ago: 68,
    title: "Sea Ltd — exit complete, lessons written down",
    tickers: ["SE"],
    conviction: 1,
    status: "closed",
    tags: ["mistake", "growth"],
    body:
      "Bought a story about credit margins improving; what I actually owned was a capital-hungry lending book in a rising rate environment. Sold 14 of 22 at a loss. Rule going forward: no position where the bull case requires a financing assumption.",
    reviewIn: 0,
  },
  {
    id: "j6",
    ago: 91,
    title: "TSMC — the single point of failure in this book",
    tickers: ["TSM", "NVDA", "ASML"],
    conviction: 5,
    status: "on-track",
    tags: ["sizing", "geopolitics"],
    body:
      "Three positions, one island, effectively one exposure. Individually each is defensible; together they are a 23% bet on cross-strait continuity. I keep treating them as separate decisions. They are not.",
    reviewIn: 12,
  },
  {
    id: "j7",
    ago: 118,
    title: "Toyota — a cash-flow story priced as a cyclical",
    tickers: ["7203"],
    conviction: 4,
    status: "on-track",
    tags: ["value", "japan", "fx"],
    body:
      "9.8x earnings, 2.6% yield, hybrid mix advantage nobody is paying for. The yen is the actual risk: unhedged JPY exposure means the position can be right and still lose money in base currency.",
    reviewIn: 62,
  },
  {
    id: "j8",
    ago: 141,
    title: "Rebalanced bond sleeve to 3–4 year duration",
    tickers: ["IEAC"],
    conviction: 3,
    status: "on-track",
    tags: ["bonds", "allocation"],
    body:
      "Added 90 units. Purpose is ballast, not return: 0.18 beta, low idio. The test is whether it holds value on an equity down-day, not whether it beats cash.",
    reviewIn: 96,
  },
];

export type NewsItem = {
  ago: number;
  source: string;
  headline: string;
  tickers: string[];
  sentiment: "pos" | "neg" | "neutral";
  topic: string;
};

export const NEWS: NewsItem[] = [
  { ago: 0.2, source: "Bloomberg", headline: "NVIDIA guides data-centre revenue above consensus as backlog extends into 2027", tickers: ["NVDA", "TSM", "ASML"], sentiment: "pos", topic: "Earnings" },
  { ago: 1.1, source: "Reuters", headline: "Novo Nordisk cuts 2026 sales outlook on weaker US compounder pricing", tickers: ["NVO"], sentiment: "neg", topic: "Guidance" },
  { ago: 2.4, source: "FT", headline: "LVMH flags 'gradual' Chinese demand recovery; fashion unit misses estimates", tickers: ["LVMH"], sentiment: "neutral", topic: "Earnings" },
  { ago: 3.6, source: "Nikkei", headline: "Toyota lifts hybrid production plan as Japan weighs intervention on yen", tickers: ["7203"], sentiment: "pos", topic: "Operations" },
  { ago: 5.2, source: "WSJ", headline: "ASML bookings beat, but China share of orders set to halve", tickers: ["ASML"], sentiment: "neutral", topic: "Orders" },
  { ago: 6.8, source: "Bloomberg", headline: "Gold holds near record as central-bank buying runs at fastest pace since 2013", tickers: ["SGLN"], sentiment: "pos", topic: "Macro" },
  { ago: 8.1, source: "Reuters", headline: "Shell raises dividend and extends buyback despite weaker refining margins", tickers: ["SHEL"], sentiment: "pos", topic: "Capital returns" },
  { ago: 11.3, source: "FT", headline: "Euro investment-grade spreads tighten to tightest since 2021", tickers: ["IEAC"], sentiment: "pos", topic: "Credit" },
  { ago: 13.9, source: "Bloomberg", headline: "Sea Limited scales back lending arm to conserve capital", tickers: ["SE"], sentiment: "neg", topic: "Strategy" },
  { ago: 16.4, source: "Nestlé", headline: "Nestlé truns portfolio review; volumes still negative in the Americas", tickers: ["NESN"], sentiment: "neg", topic: "Earnings" },
  { ago: 19.0, source: "Reuters", headline: "Sanofi’s Dupixent wins expanded approval in COPD", tickers: ["SAN"], sentiment: "pos", topic: "Regulatory" },
  { ago: 22.5, source: "FT", headline: "RELX lifts guidance as data-analytics revenue compounds at 9%", tickers: ["REL"], sentiment: "pos", topic: "Earnings" },
  { ago: 26.2, source: "Bloomberg", headline: "Brookfield closes $28bn infrastructure fund, largest since 2022", tickers: ["BAM"], sentiment: "pos", topic: "Fundraising" },
  { ago: 31.5, source: "Reuters", headline: "Rio Tinto flags cost pressure at Pilbara as iron-ore prices soften", tickers: ["RIO"], sentiment: "neg", topic: "Operations" },
];

export const THESIS: Record<string, string> = {
  NVDA: "Accelerator demand outruns supply through 2027; pricing power holds even as competition arrives. Watch: backlog conversion, gross margin floor.",
  MSFT: "Cloud capex converts to durable annuity revenue. Azure growth above 30% is the line in the sand.",
  ASML: "EUV order book is a 3-year visibility instrument. China exposure is the discount, not the story.",
  TSM: "Process leadership plus packaging. The cheapest way to own the AI build-out — if you accept the geography.",
  LVMH: "Pricing power in aspirational and hard luxury. China recovery is the optionality, not the base case.",
  NVO: "Obesity franchise breadth. The bear case is US political pricing risk, which is not diversifiable.",
  SHEL: "Cash returns disciplined through the cycle. Owns the downside of the energy transition, not the upside.",
  NESN: "Volume recovery plus Rimmel-like brand investment. Boring, currency-hedged, 3.4% paid to wait.",
  SAN: "Dupixent duration. Immunology pipeline is unmodelled by the market at 13x.",
  REL: "Information services with 70%+ recurring revenue and pricing power. The quiet compounder in the book.",
  BAM: "Asset-gathering at scale with fee-related earnings compounding. Leverage is the risk, not the strategy.",
  SE: "Closed. Kept for the record: financing-dependent growth is not investable for me.",
  RIO: "Iron-ore yield with copper optionality. Cyclical entry, structural dividend.",
  "7203": "Hybrid leadership at a single-digit multiple. The yen is the real position.",
  VWRD: "The default. Anything not in a named position lives here.",
  IEAC: "Ballast. Judged on drawdown days, not on returns.",
  SGLN: "Correlation break. Rebalanced annually, never overweighted.",
};

export const PEERS: Record<string, { ticker: string; name: string; ret1y: number; pe: number; mcap: string }[]> = {
  NVDA: [
    { ticker: "AMD", name: "Advanced Micro", ret1y: 18.4, pe: 44.1, mcap: "312B" },
    { ticker: "AVGO", name: "Broadcom", ret1y: 41.2, pe: 52.8, mcap: "1.63T" },
    { ticker: "TSM", name: "TSMC", ret1y: 33.1, pe: 24.8, mcap: "580B" },
    { ticker: "INTC", name: "Intel", ret1y: -12.6, pe: 0, mcap: "148B" },
    { ticker: "MRVL", name: "Marvell", ret1y: 22.9, pe: 38.4, mcap: "96B" },
  ],
  NVO: [
    { ticker: "LLY", name: "Eli Lilly", ret1y: 26.1, pe: 58.2, mcap: "912B" },
    { ticker: "AZN", name: "AstraZeneca", ret1y: 9.4, pe: 21.6, mcap: "246B" },
    { ticker: "ROG", name: "Roche", ret1y: 4.2, pe: 15.1, mcap: "262B" },
    { ticker: "NVO", name: "Novo Nordisk", ret1y: -21.4, pe: 19.2, mcap: "368B" },
    { ticker: "SNY", name: "Sanofi", ret1y: 10.4, pe: 13.4, mcap: "122B" },
  ],
};

export const WATCHLIST = [
  { ticker: "GOOGL", name: "Alphabet", price: 214.6, chg: 0.84, note: "Waiting for 190" },
  { ticker: "MTD", name: "Mettler-Toledo", price: 1402.0, chg: -1.24, note: "Quality, wrong price" },
  { ticker: "ADM", name: "Archer-Daniels", price: 54.2, chg: 0.31, note: "Deep value screen" },
  { ticker: "8035", name: "Tokyo Electron", price: 24680, chg: 2.11, note: "Semis alt. to ASML" },
  { ticker: "S68", name: "SGX Group", price: 9.84, chg: -0.2, note: "Exchange comp. to REL" },
];

export const RULES = [
  { rule: "Single position ≤ 10% of book", status: "breach", detail: "NVDA at 12.4%" },
  { rule: "Top 3 positions ≤ 30%", status: "ok", detail: "Top 3 at 35.1%" },
  { rule: "Cash between 5% and 8%", status: "warn", detail: `${(0).toFixed(1)}% — recalculated live` },
  { rule: "No more than 25% in one country", status: "warn", detail: "Taiwan-linked exposure 23%" },
  { rule: "Blended fee load < 0.15%", status: "ok", detail: "Funds at 0.14%" },
  { rule: "Review every thesis each quarter", status: "breach", detail: "2 reviews overdue" },
];
