import {
  N,
  dates,
  FX,
  POSITIONS,
  HOLDINGS,
  CASH,
  benchmark,
  DEPOSITS,
  TRADES,
  dayIndexFromNow,
  type Holding,
} from "../data/market";
import { createContext, useContext } from "react";

/* ══════════════ formatting ══════════════ */
export type Cur = "USD" | "EUR" | "GBP" | "JPY";
export const CUR_SYM: Record<Cur, string> = { USD: "$", EUR: "€", GBP: "£", JPY: "¥" };
const RATE: Record<Cur, number> = { USD: 1, EUR: 1 / 1.0864, GBP: 1 / 1.2718, JPY: 1 / 0.00662 };

export const money = (usd: number, cur: Cur = "USD", dp?: number) => {
  const v = usd * RATE[cur];
  const d = dp ?? (Math.abs(v) >= 10000 ? 0 : 2);
  const neg = v < 0;
  const s = Math.abs(v).toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d });
  return `${neg ? "−" : ""}${CUR_SYM[cur]}${s}`;
};
export const compact = (usd: number, cur: Cur = "USD") => {
  const v = usd * RATE[cur];
  const a = Math.abs(v);
  const sign = v < 0 ? "−" : "";
  if (a >= 1e12) return `${sign}${CUR_SYM[cur]}${(a / 1e12).toFixed(2)}T`;
  if (a >= 1e9) return `${sign}${CUR_SYM[cur]}${(a / 1e9).toFixed(2)}B`;
  if (a >= 1e6) return `${sign}${CUR_SYM[cur]}${(a / 1e6).toFixed(2)}M`;
  if (a >= 1e3) return `${sign}${CUR_SYM[cur]}${(a / 1e3).toFixed(1)}k`;
  return `${sign}${CUR_SYM[cur]}${a.toFixed(0)}`;
};
export const pct = (v: number, dp = 2) => `${v > 0 ? "+" : ""}${v.toFixed(dp)}%`;
export const sign = (v: number) => (v > 0 ? 1 : v < 0 ? -1 : 0);
export const num = (v: number, dp = 2) => v.toLocaleString("en-US", { minimumFractionDigits: dp, maximumFractionDigits: dp });
export const dateShort = (d: Date) =>
  d.toLocaleDateString("en-GB", { day: "2-digit", month: "short", timeZone: "UTC" });
export const dateLong = (d: Date) =>
  d.toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric", timeZone: "UTC" });
export const monthName = (m: number) => ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"][m];

export const CurCtx = createContext<Cur>("USD");
export const useCur = () => useContext(CurCtx);
export const useM = () => {
  const c = useCur();
  return (v: number, dp?: number) => money(v, c, dp);
};
export const useK = () => {
  const c = useCur();
  return (v: number) => compact(v, c);
};

/* ══════════════ math ══════════════ */
const mean = (x: number[]) => x.reduce((a, b) => a + b, 0) / (x.length || 1);
const sd = (x: number[]) => {
  const m = mean(x);
  return Math.sqrt(x.reduce((a, b) => a + (b - m) ** 2, 0) / (x.length - 1 || 1));
};
export const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));

/* ══════════════ series ══════════════ */
const valueSeries: number[] = [];
for (let i = 0; i < N; i++) {
  let v = CASH.prices[i];
  for (const h of HOLDINGS) v += h.qtySeries[i] * h.prices[i] * FX[h.currency];
  valueSeries.push(v);
}
const flowAt = new Map<number, number>();
for (const d of DEPOSITS) flowAt.set(dayIndexFromNow(d.ago), (flowAt.get(dayIndexFromNow(d.ago)) || 0) + d.amount);
const flows = Array.from({ length: N }, (_, i) => flowAt.get(i) || 0);

const rets: number[] = [0];
const nav: number[] = [1];
for (let i = 1; i < N; i++) {
  const r = (valueSeries[i] - flows[i]) / valueSeries[i - 1] - 1;
  rets.push(r);
  nav.push(nav[i - 1] * (1 + r));
}
const benchNav = benchmark.map((b) => b / benchmark[0]);
const benchRets: number[] = [0];
for (let i = 1; i < N; i++) benchRets.push(benchNav[i] / benchNav[i - 1] - 1);

const ytdIdx = (() => {
  const y = dates[N - 1].getUTCFullYear();
  let i = N - 1;
  while (i > 0 && dates[i].getUTCFullYear() === y) i--;
  return i;
})();

export const portfolioValue = valueSeries[N - 1];
export const prevValue = valueSeries[N - 2];
export const dayChange = portfolioValue - prevValue; // no flows yesterday/today
export const dayChangePct = dayChange / prevValue;
export const startValue = valueSeries[0];
export const totalDeposited = DEPOSITS.reduce((a, d) => a + d.amount, 0);
export const valueHistory = valueSeries;
export const dailyRets = rets;
export const navHistory = nav;
export const benchHistory = benchNav;
export const benchName = "MSCI All-World (net)";

/* ══════════════ per-position ══════════════ */
export type Pos = Holding & {
  value: number;
  cost: number;
  pl: number;
  plPct: number;
  weight: number;
  dayPl: number;
  dayPct: number;
  rets: { w1: number; m1: number; m3: number; m6: number; ytd: number; y1: number };
  vol: number;
  spark: number[];
  divIncome: number;
  maxDD: number;
};

const retOf = (p: number[], back: number) => p[N - 1] / p[N - 1 - Math.min(back, N - 1)] - 1;
const maxDrawdown = (p: number[]) => {
  let peak = p[0];
  let mdd = 0;
  for (const v of p) {
    peak = Math.max(peak, v);
    mdd = Math.min(mdd, v / peak - 1);
  }
  return mdd;
};

/* helpers needed before positions are built */
const OPENING_INVESTED = HOLDINGS.reduce((a, h) => a + h.qtySeries[0] * h.prices[0] * FX[h.currency], 0);
function TRADES_NET() {
  let net = 0;
  for (let i = 0; i < N; i++) {
    for (const t of TRADES) {
      if (dayIndexFromNow(t.ago) !== i) continue;
      const h = HOLDINGS.find((x) => x.ticker === t.ticker)!;
      const px = h.prices[i] * FX[h.currency];
      net += t.type === "buy" ? -t.qty * px : t.qty * px;
    }
  }
  return net;
}
const LATER_DEPOSITS = totalDeposited - DEPOSITS[0].amount;
const CASH_INTEREST = CASH.prices[N - 1] - CASH.prices[0] - LATER_DEPOSITS - TRADES_NET();
const CASH_COST = CASH.prices[N - 1] - CASH_INTEREST;

export const positions: Pos[] = POSITIONS.map((h) => {
  const fx = FX[h.currency];
  const value = h.isCash ? CASH.prices[N - 1] : h.qty * h.prices[N - 1] * fx;
  const cost = h.isCash ? CASH_COST : h.qty * h.avgCost * fx;
  const pl = h.isCash ? CASH_INTEREST : value - cost;
  const daily: number[] = [];
  for (let i = 1; i < N; i++) daily.push(h.prices[i] / h.prices[i - 1] - 1);
  return {
    ...h,
    value,
    cost,
    pl,
    plPct: h.isCash ? (pl / Math.max(1, value - pl)) * 100 : (pl / cost) * 100,
    weight: (value / portfolioValue) * 100,
    dayPl: h.isCash ? CASH.prices[N - 1] - CASH.prices[N - 2] : h.qty * (h.prices[N - 1] - h.prices[N - 2]) * fx,
    dayPct: h.isCash ? 0 : h.prices[N - 1] / h.prices[N - 2] - 1,
    rets: {
      w1: retOf(h.prices, 5),
      m1: retOf(h.prices, 21),
      m3: retOf(h.prices, 63),
      m6: retOf(h.prices, 126),
      ytd: h.prices[N - 1] / h.prices[ytdIdx] - 1,
      y1: retOf(h.prices, 252),
    },
    vol: sd(daily) * Math.sqrt(252) * 100,
    spark: h.prices.slice(-64),
    divIncome: h.isCash ? 0 : h.qty * h.prices[N - 1] * fx * (h.divYield / 100),
    maxDD: maxDrawdown(h.prices.slice(-252)),
  };
});

export const cashInterestEarned = CASH_INTEREST;
export const openingInvested = OPENING_INVESTED;

export const invested = positions.filter((p) => !p.isCash).reduce((a, p) => a + p.cost, 0);
export const totalPl = portfolioValue - invested - CASH.prices[0];
export const totalPlPct = (totalPl / (invested + CASH.prices[0])) * 100;
export const equity = positions.filter((p) => !p.isCash);
export const cash = CASH.prices[N - 1];
export const cashWeight = (cash / portfolioValue) * 100;

export const best = [...equity].sort((a, b) => b.plPct - a.plPct)[0];
export const worst = [...equity].sort((a, b) => a.plPct - b.plPct)[0];
export const topDay = [...positions].sort((a, b) => b.dayPl - a.dayPl)[0];
export const bottomDay = [...positions].sort((a, b) => a.dayPl - b.dayPl)[0];
export const byWeight = [...positions].sort((a, b) => b.value - a.value);
export const movers = [...positions].sort((a, b) => Math.abs(b.dayPl) - Math.abs(a.dayPl));

/* ══════════════ returns ══════════════ */
export const periods: { key: string; label: string; days: number | "ytd" | "si" }[] = [
  { key: "w1", label: "1 week", days: 5 },
  { key: "m1", label: "1 month", days: 21 },
  { key: "m3", label: "3 months", days: 63 },
  { key: "m6", label: "6 months", days: 126 },
  { key: "ytd", label: "YTD", days: "ytd" },
  { key: "y1", label: "1 year", days: 252 },
  { key: "si", label: "Since inception", days: "si" },
];
export const trailingReturns = periods.map((p) => {
  const idx = p.days === "si" ? 0 : p.days === "ytd" ? ytdIdx : N - 1 - p.days;
  return {
    ...p,
    port: (nav[N - 1] / nav[idx] - 1) * 100,
    bench: (benchNav[N - 1] / benchNav[idx] - 1) * 100,
  };
});

export const monthly: { year: number; month: number; ret: number; bench: number; value: number }[] = (() => {
  const out: { year: number; month: number; ret: number; bench: number; value: number }[] = [];
  let cur = "";
  let start = 0;
  for (let i = 1; i < N; i++) {
    const k = `${dates[i].getUTCFullYear()}-${dates[i].getUTCMonth()}`;
    if (k !== cur) {
      if (cur) {
        out.push({
          year: dates[i - 1].getUTCFullYear(),
          month: dates[i - 1].getUTCMonth(),
          ret: (nav[i - 1] / nav[start - 1 < 0 ? 1 : nav[start - 1]] - 1) * 100,
          bench: (benchNav[i - 1] / benchNav[start - 1 < 0 ? 1 : benchNav[start - 1]] - 1) * 100,
          value: valueSeries[i - 1],
        });
      }
      cur = k;
      start = i;
    }
    if (i === N - 1) {
      out.push({
        year: dates[i].getUTCFullYear(),
        month: dates[i].getUTCMonth(),
        ret: (nav[i] / nav[start - 1 < 0 ? 1 : nav[start - 1]] - 1) * 100,
        bench: (benchNav[i] / benchNav[start - 1 < 0 ? 1 : benchNav[start - 1]] - 1) * 100,
        value: valueSeries[i],
      });
    }
  }
  return out;
})();
export const years = [...new Set(monthly.map((m) => m.year))].sort();
export const monthlyByYear = years.map((y) => ({
  year: y,
  months: Array.from({ length: 12 }, (_, m) => monthly.find((x) => x.year === y && x.month === m)?.ret ?? null),
  total: (() => {
    const ms = monthly.filter((x) => x.year === y);
    return (ms.reduce((a, x) => a * (1 + x.ret / 100), 1) - 1) * 100;
  })(),
}));
export const positiveMonths = monthly.filter((m) => m.ret > 0).length;
export const bestMonth = [...monthly].sort((a, b) => b.ret - a.ret)[0];
export const worstMonth = [...monthly].sort((a, b) => a.ret - b.ret)[0];

/* ══════════════ risk ══════════════ */
export const vol = sd(rets.slice(1)) * Math.sqrt(252) * 100;
export const benchVol = sd(benchRets.slice(1)) * Math.sqrt(252) * 100;
const rf = 0.041;
export const sharpe = ((mean(rets.slice(1)) * 252 - rf) / (sd(rets.slice(1)) * Math.sqrt(252)));
export const sortino = (() => {
  const dn = rets.slice(1).filter((r) => r < 0);
  return (mean(rets.slice(1)) * 252 - rf) / (sd(dn) * Math.sqrt(252));
})();
export const maxDD = maxDrawdown(nav) * 100;
export const drawdown = nav.map((v, i) => {
  let peak = -Infinity;
  for (let j = 0; j <= i; j++) peak = Math.max(peak, nav[j]);
  return (v / peak - 1) * 100;
});
export const var95 = (() => {
  const s = [...rets.slice(1)].sort((a, b) => a - b);
  return s[Math.floor(s.length * 0.05)] * 100;
})();
export const cvar95 = (() => {
  const s = [...rets.slice(1)].sort((a, b) => a - b);
  const k = Math.floor(s.length * 0.05);
  return mean(s.slice(0, Math.max(1, k))) * 100;
})();
export const hitRate = (rets.slice(1).filter((r) => r > 0).length / (rets.length - 1)) * 100;
export const beta = (() => {
  const a = rets.slice(1);
  const b = benchRets.slice(1);
  const cov = mean(a.map((v, i) => (v - mean(a)) * (b[i] - mean(b))));
  return cov / (sd(b) ** 2);
})();
export const alpha = (mean(rets.slice(1)) - beta * mean(benchRets.slice(1))) * 252 * 100;
export const upCapture = (mean(rets.slice(1).filter((_, i) => benchRets.slice(1)[i] > 0)) /
  mean(benchRets.slice(1).filter((r) => r > 0))) * 100;
export const downCapture = (mean(rets.slice(1).filter((_, i) => benchRets.slice(1)[i] < 0)) /
  mean(benchRets.slice(1).filter((r) => r < 0))) * 100;
export const retDist = (() => {
  const bins = 27;
  const lo = -0.045;
  const hi = 0.045;
  const h = (hi - lo) / bins;
  const counts = new Array(bins).fill(0);
  for (const r of rets.slice(1)) counts[clamp(Math.floor((r - lo) / h), 0, bins - 1)]++;
  return counts.map((c, i) => ({ x: lo + (i + 0.5) * h, c }));
})();

/* ══════════════ exposure ══════════════ */
export type Group = { key: string; value: number; weight: number; pl: number; color: string; count: number };
function groupBy(fn: (p: Pos) => string, colorFn?: (k: string) => string): Group[] {
  const map = new Map<string, Group>();
  for (const p of positions) {
    const k = fn(p);
    const g = map.get(k) || { key: k, value: 0, weight: 0, pl: 0, color: colorFn?.(k) || p.color, count: 0 };
    g.value += p.value;
    g.pl += p.pl;
    g.count++;
    map.set(k, g);
  }
  return [...map.values()]
    .map((g) => ({ ...g, weight: (g.value / portfolioValue) * 100 }))
    .sort((a, b) => b.value - a.value);
}
export const sectorExposure = groupBy((p) => p.sector);
export const regionExposure = groupBy((p) => p.country);
export const currencyExposure = groupBy((p) => p.currency);
export const assetExposure = groupBy((p) => p.assetClass);
export const hhi = positions.reduce((a, p) => a + (p.weight / 100) ** 2, 0) * 100;
export const top3 = byWeight.slice(0, 3).reduce((a, p) => a + p.weight, 0);
export const cumulativeWeights = byWeight.map((_, i) => byWeight.slice(0, i + 1).reduce((a, p) => a + p.weight, 0));

/* ══════════════ correlation ══════════════ */
export const corrUniverse = [...equity].sort((a, b) => b.value - a.value).slice(0, 9);
const dailyRetsOf = (p: Holding) => {
  const out: number[] = [];
  for (let i = N - 252; i < N; i++) out.push(p.prices[i] / p.prices[i - 1] - 1);
  return out;
};
export const corr = (() => {
  const series = corrUniverse.map(dailyRetsOf);
  const bm = benchRets.slice(-252);
  const all = [...series, bm];
  const labels = [...corrUniverse.map((p) => p.ticker), "WORLD"];
  const m: number[][] = [];
  for (let i = 0; i < all.length; i++) {
    m[i] = [];
    for (let j = 0; j < all.length; j++) {
      const a = all[i];
      const b = all[j];
      const c = mean(a.map((v, k) => (v - mean(a)) * (b[k] - mean(b))));
      m[i][j] = c / (sd(a) * sd(b));
    }
  }
  return { labels, m };
})();

/* ══════════════ attribution ══════════════ */
export const attribution = (() => {
  const groups = new Map<string, number>();
  for (const h of HOLDINGS) {
    const fx = FX[h.currency];
    let g = 0;
    for (let i = 1; i < N; i++) g += h.qtySeries[i] * (h.prices[i] - h.prices[i - 1]) * fx;
    const k = h.sector;
    groups.set(k, (groups.get(k) || 0) + g);
  }
  const capGains = [...groups.values()].reduce((a, b) => a + b, 0);
  const income = CASH.prices[N - 1] - CASH.prices[0] - TRADES_NET() - (totalDeposited - DEPOSITS[0].amount);
  const items = [
    { key: "Opening value", value: valueSeries[0], type: "base" as const },
    { key: "Net deposits", value: totalDeposited, type: "flow" as const },
    ...[...groups.entries()]
      .sort((a, b) => b[1] - a[1])
      .map(([key, value]) => ({ key, value, type: "gain" as const })),
    { key: "Income received", value: income, type: "flow" as const },
    { key: "Closing value", value: valueSeries[N - 1], type: "total" as const },
  ];
  return { items, capGains, income };
})();

/* ══════════════ income & cost ══════════════ */
export const dividendRun = positions.reduce((a, p) => a + p.divIncome, 0);
export const portfolioYield = (dividendRun / portfolioValue) * 100;
export const feesPaid = TRADES.reduce((a, t) => {
  const h = HOLDINGS.find((x) => x.ticker === t.ticker)!;
  return a + t.qty * h.prices[dayIndexFromNow(t.ago)] * FX[h.currency] * 0.0008;
}, 0);
export const fundTer =
  (positions.find((p) => p.ticker === "VWRD")!.value * 0.0022 +
    positions.find((p) => p.ticker === "IEAC")!.value * 0.002 +
    positions.find((p) => p.ticker === "SGLN")!.value * 0.0012) /
  portfolioValue *
  100;

/* ══════════════ health score ══════════════ */
const hhiScore = clamp(100 - (hhi - 6) * 2.2, 0, 100);
const top3Score = clamp(100 - (top3 - 24) * 3.1, 0, 100);
const cashScore = clamp(100 - Math.abs(cashWeight - 6) * 11, 0, 100);
const costScore = clamp(100 - fundTer * 26, 0, 100);
const riskScore = clamp(100 - Math.abs(vol - benchVol) * 12 - (maxDD + 14) * 1.1, 0, 100);
const incomeScore = clamp(portfolioYield * 18, 0, 100);
export const health = {
  score: Math.round(
    hhiScore * 0.2 + top3Score * 0.18 + cashScore * 0.14 + costScore * 0.1 + riskScore * 0.24 + incomeScore * 0.14,
  ),
  grade: (s: number) => (s >= 85 ? "A" : s >= 72 ? "B+" : s >= 60 ? "B" : s >= 48 ? "C" : "D"),
  pillars: [
    { name: "Diversification", score: hhiScore, note: `${positions.length} positions · HHI ${hhi.toFixed(0)}`, target: "HHI < 20" },
    { name: "Concentration", score: top3Score, note: `Top 3 = ${top3.toFixed(1)}% of book`, target: "Top 3 < 30%" },
    { name: "Risk calibration", score: riskScore, note: `${vol.toFixed(1)}% vol vs ${benchVol.toFixed(1)}% world`, target: "±20% of world vol" },
    { name: "Liquidity", score: cashScore, note: `${cashWeight.toFixed(1)}% cash available`, target: "5–8% dry powder" },
    { name: "Cost", score: costScore, note: `${fundTer.toFixed(2)}% blended fee load`, target: "< 0.15% TER" },
    { name: "Income", score: incomeScore, note: `${portfolioYield.toFixed(2)}% running yield`, target: "2.5%+ natural income" },
  ],
};

/* ══════════════ trade ledger ══════════════ */
export type LedgerRow = {
  date: Date;
  type: "Buy" | "Sell" | "Dividend" | "Deposit" | "Interest";
  ticker: string;
  qty: number;
  native: number;
  usd: number;
  note?: string;
};
export const ledger: LedgerRow[] = (() => {
  const rows: LedgerRow[] = [];
  for (const t of TRADES) {
    const h = HOLDINGS.find((x) => x.ticker === t.ticker)!;
    const i = dayIndexFromNow(t.ago);
    rows.push({
      date: dates[i],
      type: t.type === "buy" ? "Buy" : "Sell",
      ticker: h.ticker,
      qty: t.qty,
      native: h.prices[i],
      usd: t.qty * h.prices[i] * FX[h.currency],
      note: t.note,
    });
  }
  for (const d of DEPOSITS) rows.push({ date: dates[dayIndexFromNow(d.ago)], type: "Deposit", ticker: "USD", qty: 0, native: 1, usd: d.amount, note: d.note });
  for (const i of [dayIndexFromNow(300), dayIndexFromNow(215), dayIndexFromNow(130), dayIndexFromNow(45)]) {
    for (const h of HOLDINGS) {
      if (h.divYield <= 0) continue;
      rows.push({
        date: dates[i],
        type: "Dividend",
        ticker: h.ticker,
        qty: 0,
        native: 1,
        usd: h.qtySeries[i] * h.prices[i] * FX[h.currency] * (h.divYield / 100 / 4),
        note: "Quarterly distribution",
      });
    }
  }
  return rows.sort((a, b) => b.date.getTime() - a.date.getTime());
})();
export const incomeReceived = ledger.filter((r) => r.type === "Dividend").reduce((a, r) => a + r.usd, 0);
