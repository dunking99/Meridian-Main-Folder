import React from "react";

export type GlobePoint = {
  key: string;
  lat: number;
  lon: number;
  value: number;
  weight: number;
  pl: number;
  label: string;
};

const DEG = Math.PI / 180;

export function Globe({
  points,
  size = 330,
  active,
  onSelect,
  onHover,
}: {
  points: GlobePoint[];
  size?: number;
  active?: string | null;
  onSelect?: (k: string) => void;
  onHover?: (k: string | null) => void;
}) {
  const R = size / 2 - 26;
  const C = size / 2;
  const tilt = -16 * DEG;
  const [rot, setRot] = React.useState(40);
  const [drag, setDrag] = React.useState(false);
  const [hov, setHov] = React.useState<string | null>(null);
  const down = React.useRef({ x: 0, r: 0 });

  React.useEffect(() => {
    if (drag) return;
    let raf = 0;
    let last = 0;
    const loop = (t: number) => {
      if (t - last > 34) {
        setRot((r) => (r - 0.22 + 360) % 360);
        last = t;
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [drag]);

  const project = (lat: number, lon: number) => {
    const phi = lat * DEG;
    const lam = lon * DEG;
    const r = (rot * DEG) as number;
    const x = Math.cos(phi) * Math.sin(lam - r);
    const y0 = Math.sin(phi);
    const z0 = Math.cos(phi) * Math.cos(lam - r);
    const y = y0 * Math.cos(tilt) - z0 * Math.sin(tilt);
    const z = y0 * Math.sin(tilt) + z0 * Math.cos(tilt);
    return { x: C + R * x, y: C - R * y, z };
  };

  const arcs: { d: string; tone: "grid" | "prime" | "parallel" }[] = [];
  const push = (coords: [number, number][], tone: "grid" | "prime" | "parallel") => {
    let run: [number, number][] = [];
    let open = false;
    for (const [lat, lon] of coords) {
      const p = project(lat, lon);
      if (p.z > 0) {
        if (!open) {
          if (run.length) arcs.push({ d: lineSeg(run), tone });
          run = [];
        }
        run.push([p.x, p.y]);
        open = true;
      } else {
        open = false;
      }
    }
    if (run.length) arcs.push({ d: lineSeg(run), tone });
  };
  const lineSeg = (pts: [number, number][]) => "M" + pts.map((p) => `${p[0].toFixed(1)},${p[1].toFixed(1)}`).join("L");

  for (let lon = -180; lon < 180; lon += 20) {
    const coords: [number, number][] = [];
    for (let lat = -88; lat <= 88; lat += 4) coords.push([lat, lon]);
    push(coords, lon === 0 ? "prime" : "grid");
  }
  for (let lat = -60; lat <= 60; lat += 20) {
    const coords: [number, number][] = [];
    for (let lon = -180; lon <= 180; lon += 4) coords.push([lat, lon]);
    push(coords, "parallel");
  }

  const maxW = Math.max(...points.map((p) => p.weight));
  const shown = points.map((p) => ({ ...p, pr: project(p.lat, p.lon) })).filter((p) => p.pr.z > -0.05);

  return (
    <div className="relative select-none" style={{ width: size, height: size }}>
      {/* starfield */}
      {Array.from({ length: 26 }, (_, i) => {
        const x = ((i * 37) % 100) / 100;
        const y = ((i * 61) % 100) / 100;
        return (
          <i
            key={i}
            className="absolute rounded-full bg-white"
            style={{ left: `${x * 100}%`, top: `${y * 100}%`, width: i % 5 === 0 ? 2 : 1, height: i % 5 === 0 ? 2 : 1, opacity: 0.14 + (i % 4) * 0.06 }}
          />
        );
      })}
      <svg
        width={size}
        height={size}
        className="absolute inset-0 cursor-grab active:cursor-grabbing"
        onPointerDown={(e) => {
          setDrag(true);
          down.current = { x: e.clientX, r: rot };
        }}
        onPointerUp={() => setDrag(false)}
        onPointerLeave={() => {
          setDrag(false);
          setHov(null);
          onHover?.(null);
        }}
        onPointerMove={(e) => {
          if (!drag) return;
          setRot(down.current.r - (e.clientX - down.current.x) * 0.42);
        }}
      >
        <defs>
          <radialGradient id="sphere" cx="34%" cy="30%" r="78%">
            <stop offset="0%" stopColor="#16384a" />
            <stop offset="45%" stopColor="#0e2130" />
            <stop offset="82%" stopColor="#08131d" />
            <stop offset="100%" stopColor="#050a10" />
          </radialGradient>
          <radialGradient id="limb" cx="50%" cy="50%" r="50%">
            <stop offset="72%" stopColor="#5ee3d0" stopOpacity="0" />
            <stop offset="92%" stopColor="#5ee3d0" stopOpacity="0.16" />
            <stop offset="100%" stopColor="#7db8ff" stopOpacity="0.32" />
          </radialGradient>
        </defs>

        <circle cx={C} cy={C} r={R} fill="url(#sphere)" />
        <circle cx={C} cy={C} r={R} fill="none" stroke="#ffffff" strokeOpacity="0.1" />
        <circle cx={C} cy={C} r={R} fill="url(#limb)" />

        {arcs.map((a, i) => (
          <path
            key={i}
            d={a.d}
            fill="none"
            stroke={a.tone === "prime" ? "#ff7a45" : "#ffffff"}
            strokeOpacity={a.tone === "prime" ? 0.55 : a.tone === "parallel" ? 0.075 : 0.11}
            strokeWidth={a.tone === "prime" ? 1.25 : 0.7}
          />
        ))}

        {shown.map((p) => {
          const dim = p.pr.z < 0.02;
          const rad = 3.2 + Math.sqrt(p.weight / maxW) * 11;
          const col = p.pl >= 0 ? "#3ee0a0" : "#ff5c7a";
          const on = hov === p.key || active === p.key;
          return (
            <g
              key={p.key}
              onClick={() => onSelect?.(p.key)}
              onPointerEnter={() => {
                setHov(p.key);
                onHover?.(p.key);
              }}
              style={{ cursor: "pointer", opacity: dim ? 0.28 : 1, transition: "opacity .4s" }}
            >
              {p.weight / maxW > 0.55 && !dim && (
                <circle cx={p.pr.x} cy={p.pr.y} r={rad} fill="none" stroke={col} strokeWidth="1" opacity="0.5" className="pulse-ring" style={{ transformOrigin: `${p.pr.x}px ${p.pr.y}px` }} />
              )}
              <circle cx={p.pr.x} cy={p.pr.y} r={rad} fill={col} fillOpacity={on ? 0.42 : 0.2} stroke={col} strokeWidth={on ? 1.6 : 1} style={{ filter: on ? `drop-shadow(0 0 12px ${col})` : "none" }} />
              <circle cx={p.pr.x} cy={p.pr.y} r={rad * 0.32} fill={col} />
              {on && (
                <text x={p.pr.x + rad + 5} y={p.pr.y + 3} fill="#eaf0f8" fontSize="9.5" fontFamily="IBM Plex Mono, monospace" style={{ pointerEvents: "none" }}>
                  {p.label}
                </text>
              )}
            </g>
          );
        })}
      </svg>

      {(() => {
        const p = shown.find((s) => s.key === hov);
        if (!p) return null;
        const left = Math.min(Math.max(p.pr.x + 14, 4), size - 168);
        return (
          <div
            className="pointer-events-none absolute z-20 w-[164px] rounded-lg border border-white/10 bg-[#080c12]/95 px-2.5 py-2 backdrop-blur-md"
            style={{ left, top: Math.max(4, Math.min(p.pr.y - 16, size - 86)) }}
          >
            <div className="label mb-1">{p.label}</div>
            <div className="num text-[15px] text-paper">{p.weight.toFixed(1)}%</div>
            <div className="num mt-0.5 text-[10px]" style={{ color: p.pl >= 0 ? "#3ee0a0" : "#ff5c7a" }}>
              {p.pl >= 0 ? "+" : ""}
              {p.pl.toFixed(1)}% on capital
            </div>
          </div>
        );
      })()}

      <div className="pointer-events-none absolute bottom-1 left-1/2 -translate-x-1/2 font-mono text-[8.5px] uppercase tracking-[0.2em] text-fog/70">
        drag to rotate
      </div>
    </div>
  );
}
