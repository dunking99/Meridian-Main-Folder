import React from "react";
import { cx } from "./ui";
import { linePath, useSize } from "./charts";

/* heat colour for P/L */
export const plColor = (v: number, scale = 25) => {
  const k = Math.max(-1, Math.min(1, v / scale));
  const t = Math.abs(k);
  const h = v >= 0 ? 158 : 348;
  const s = 38 + t * 36;
  const l = 22 + t * 20;
  return `hsl(${h} ${s}% ${l}%)`;
};

/* ══════════════ treemap ══════════════ */
type TMItem = { key: string; value: number; pl: number; label: string; sub: string };
type Rect = { x: number; y: number; w: number; h: number };

function split(nodes: TMItem[], x: number, y: number, w: number, h: number, out: (TMItem & Rect)[]) {
  if (!nodes.length || w <= 0 || h <= 0) return;
  if (nodes.length === 1) {
    out.push({ ...nodes[0], x, y, w, h });
    return;
  }
  const total = nodes.reduce((a, b) => a + b.value, 0);
  let acc = nodes[0].value;
  let i = 1;
  while (i < nodes.length - 1 && acc + nodes[i].value < total / 2) {
    acc += nodes[i].value;
    i++;
  }
  const a = nodes.slice(0, i);
  const b = nodes.slice(i);
  const fa = a.reduce((p, c) => p + c.value, 0) / total;
  if (w >= h) {
    split(a, x, y, w * fa, h, out);
    split(b, x + w * fa, y, w * (1 - fa), h, out);
  } else {
    split(a, x, y, w, h * fa, out);
    split(b, x, y + h * fa, w, h * (1 - fa), out);
  }
}

export function Treemap({
  items,
  height = 360,
  onSelect,
  scale = 25,
}: {
  items: TMItem[];
  height?: number;
  onSelect?: (k: string) => void;
  scale?: number;
}) {
  const [hov, setHov] = React.useState<string | null>(null);
  const sorted = [...items].sort((a, b) => b.value - a.value);
  const rects: (TMItem & Rect)[] = [];
  split(sorted, 0, 0, 100, height, rects);
  return (
    <div className="relative w-full" style={{ height }}>
      {rects.map((r) => {
        const big = r.w > 62 && r.h > 46;
        const med = r.w > 40 && r.h > 26;
        const c = plColor(r.pl, scale);
        const on = hov === r.key;
        return (
          <div
            key={r.key}
            onMouseEnter={() => setHov(r.key)}
            onMouseLeave={() => setHov(null)}
            onClick={() => onSelect?.(r.key)}
            className="group absolute cursor-pointer overflow-hidden rounded-[6px] border transition-all duration-300"
            style={{
              left: `${r.x}%`,
              top: r.y,
              width: `calc(${r.w}% - 3px)`,
              height: r.h - 3,
              margin: 1.5,
              background: `linear-gradient(150deg,${c}f2,${c}b4)`,
              borderColor: on ? "rgba(255,255,255,.5)" : "rgba(255,255,255,.09)",
              zIndex: on ? 5 : 1,
              transform: on ? "scale(1.012)" : "none",
              boxShadow: on ? `0 18px 44px -18px #000, 0 0 0 1px ${c}` : "inset 0 1px 0 rgba(255,255,255,.07)",
            }}
          >
            <div className="flex h-full flex-col justify-between p-2">
              <div className="flex items-start justify-between gap-1">
                <span className={cx("num font-medium text-white/95", big ? "text-[15px]" : med ? "text-[12px]" : "text-[10px]")}>
                  {r.label}
                </span>
                {med && (
                  <span className="num rounded px-1 py-[1px] text-[9.5px] text-black/60" style={{ background: "rgba(255,255,255,.35)" }}>
                    {r.sub}
                  </span>
                )}
              </div>
              {big && (
                <div className="num text-[11px] leading-tight text-white/75">
                  <div style={{ color: r.pl >= 0 ? "#0d3f2e" : "#4a0f1e" }} className="text-[13px] font-semibold">
                    {r.pl >= 0 ? "+" : ""}
                    {r.pl.toFixed(1)}%
                  </div>
                </div>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}

/* ══════════════ waterfall ══════════════ */
export function Waterfall({
  items,
  height = 250,
  fmt,
}: {
  items: { key: string; value: number; type: "base" | "flow" | "gain" | "total" }[];
  height?: number;
  fmt: (n: number) => string;
}) {
  const [hov, setHov] = React.useState<number | null>(null);
  let run = 0;
  const steps = items.map((it, i) => {
    if (it.type === "base") {
      run = it.value;
      return { ...it, from: 0, to: it.value, i };
    }
    if (it.type === "total") return { ...it, from: 0, to: it.value, i };
    const from = run;
    run += it.value;
    return { ...it, from, to: run, i };
  });
  const lo = Math.min(...steps.flatMap((s) => [s.from, s.to]));
  const hi = Math.max(...steps.flatMap((s) => [s.from, s.to]));
  const Y = (v: number) => 18 + (1 - (v - lo) / (hi - lo || 1)) * (height - 74);
  const bw = 100 / steps.length;
  return (
    <div className="relative w-full" style={{ height }}>
      <div className="absolute inset-x-0 top-0 flex" style={{ height: height - 56 }}>
        {steps.map((s) => {
          const y0 = Y(Math.min(s.from, s.to));
          const y1 = Y(Math.max(s.from, s.to));
          const isTotal = s.type === "total";
          const c = isTotal ? "#eaf0f8" : s.type === "base" ? "#7c8aa3" : s.value >= 0 ? "#3ee0a0" : "#ff5c7a";
          const on = hov === s.i;
          return (
            <div key={s.key} className="relative h-full" style={{ width: `${bw}%` }} onMouseEnter={() => setHov(s.i)} onMouseLeave={() => setHov(null)}>
              <div
                className="absolute rounded-[3px] transition-all duration-500"
                style={{
                  left: "12%",
                  width: "76%",
                  top: y0,
                  height: Math.max(2, y1 - y0),
                  background: isTotal ? "linear-gradient(180deg,#eaf0f8,#b9c5d8)" : `linear-gradient(180deg,${c},${c}99)`,
                  boxShadow: on ? `0 0 22px ${c}77` : "none",
                  opacity: on ? 1 : 0.88,
                }}
              />
              {on && (
                <div className="num absolute -top-1 left-1/2 z-10 -translate-x-1/2 whitespace-nowrap rounded-md border border-white/10 bg-[#080c12] px-2 py-1 text-[10.5px] text-paper">
                  {s.value >= 0 ? "+" : "−"}
                  {fmt(Math.abs(s.value))}
                </div>
              )}
            </div>
          );
        })}
      </div>
      <div className="absolute inset-x-0 bottom-0 flex" style={{ height: 56 }}>
        {steps.map((s) => (
          <div key={s.key} className="flex items-start justify-center px-1 text-center" style={{ width: `${bw}%` }}>
            <span
              className={cx(
                "font-mono text-[8.5px] uppercase leading-[1.35] tracking-[0.08em]",
                s.type === "total" || s.type === "base" ? "text-mist" : "text-fog",
              )}
              style={{ maxWidth: 92 }}
            >
              {s.key}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ══════════════ gauge ══════════════ */
export function Gauge({ score, size = 260, label }: { score: number; size?: number; label: string }) {
  const R = size / 2 - 26;
  const C = size / 2;
  const span = Math.PI * 0.78;
  const start = 1.5 * Math.PI - span / 2;
  const ang = start + (span * Math.min(100, Math.max(0, score))) / 100;
  const a = (frac: number) => start + span * frac;
  const pol = (r: number, d: number) => [C + r * Math.cos(d), C + r * Math.sin(d)];
  const [needle, setNeedle] = React.useState(0);
  React.useEffect(() => {
    let raf = 0;
    const t0 = performance.now();
    const tick = (t: number) => {
      const k = Math.min(1, (t - t0) / 1300);
      setNeedle(score * (1 - Math.pow(1 - k, 3)));
      if (k < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [score]);
  const na = start + (span * needle) / 100;
  const [nx, ny] = pol(R - 5, na);
  const grade = score >= 85 ? "A" : score >= 72 ? "B+" : score >= 60 ? "B" : score >= 48 ? "C" : "D";
  return (
    <div className="relative" style={{ width: size, height: size * 0.78 }}>
      <svg width={size} height={size} className="overflow-visible">
        <defs>
          <linearGradient id="gaugeg" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#ff5c7a" />
            <stop offset="42%" stopColor="#ffc46b" />
            <stop offset="100%" stopColor="#3ee0a0" />
          </linearGradient>
        </defs>
        {/* tick ring */}
        {Array.from({ length: 51 }, (_, k) => {
          const d = a(k / 50);
          const major = k % 5 === 0;
          const [x1, y1] = pol(R + (major ? 2 : 4), d);
          const [x2, y2] = pol(R + (major ? 12 : 9), d);
          return <line key={k} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#ffffff" strokeOpacity={major ? 0.32 : 0.12} strokeWidth={major ? 1.2 : 1} />;
        })}
        {/* track + value */}
        <path d={describe(C, C, R, a(0), a(1))} fill="none" stroke="#ffffff" strokeOpacity="0.06" strokeWidth="11" strokeLinecap="round" />
        <path d={describe(C, C, R, a(0), ang)} fill="none" stroke="url(#gaugeg)" strokeWidth="11" strokeLinecap="round" style={{ filter: "drop-shadow(0 0 10px rgba(62,224,160,.35))" }} />
        {/* needle — pivots below centre so the score can sit inside the dial */}
        <line x1={C} y1={C + 20} x2={nx} y2={ny} stroke="#eaf0f8" strokeWidth="1.5" strokeLinecap="round" opacity="0.92" />
        <circle cx={C} cy={C + 20} r="4.5" fill="#06080c" stroke="#eaf0f8" strokeWidth="1.4" />
        <circle cx={nx} cy={ny} r="2.4" fill="#eaf0f8" style={{ filter: "drop-shadow(0 0 6px #eaf0f8)" }} />
      </svg>
      <div className="absolute inset-x-0 top-[84px] text-center">
        <div className="display num text-[46px] leading-none text-paper">{score.toFixed(0)}</div>
        <div className="mt-1.5 font-mono text-[8.5px] uppercase tracking-[0.26em] text-fog">{label}</div>
      </div>
      <div className="absolute right-0 top-[6px] flex items-baseline gap-1.5">
        <span className="display text-[24px] leading-none" style={{ color: score >= 72 ? "#3ee0a0" : score >= 60 ? "#ffc46b" : "#ff5c7a" }}>
          {grade}
        </span>
      </div>
    </div>
  );
}
function describe(cx: number, cy: number, r: number, a0: number, a1: number) {
  const p = (d: number) => [cx + r * Math.cos(d), cy + r * Math.sin(d)];
  const [x0, y0] = p(a0);
  const [x1, y1] = p(a1);
  return `M${x0.toFixed(2)},${y0.toFixed(2)} A${r},${r} 0 ${a1 - a0 > Math.PI ? 1 : 0} 1 ${x1.toFixed(2)},${y1.toFixed(2)}`;
}

/* ══════════════ radar ══════════════ */
export function Radar({
  axes,
  size = 240,
}: {
  axes: { name: string; score: number }[];
  size?: number;
}) {
  const C = size / 2;
  const R = C - 42;
  const n = axes.length;
  const pt = (k: number, r: number) => {
    const d = -Math.PI / 2 + (k / n) * Math.PI * 2;
    return [C + r * Math.cos(d), C + r * Math.sin(d)] as [number, number];
  };
  const poly = axes.map((a, k) => pt(k, (a.score / 100) * R));
  const [anim, setAnim] = React.useState(0);
  React.useEffect(() => {
    let raf = 0;
    const t0 = performance.now();
    const tick = (t: number) => {
      const k = Math.min(1, (t - t0) / 1100);
      setAnim(1 - Math.pow(1 - k, 3));
      if (k < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);
  const cur = poly.map(([x, y]) => [C + (x - C) * anim, C + (y - C) * anim] as [number, number]);
  return (
    <svg width={size} height={size} className="overflow-visible">
      {[0.25, 0.5, 0.75, 1].map((f) => (
        <path
          key={f}
          d={linePath(axes.map((_, k) => pt(k, R * f)), true) + "Z"}
          fill="none"
          stroke="#ffffff"
          strokeOpacity={f === 1 ? 0.12 : 0.055}
          strokeDasharray={f === 1 ? undefined : "2 4"}
        />
      ))}
      {axes.map((_, k) => {
        const [x, y] = pt(k, R);
        return <line key={k} x1={C} y1={C} x2={x} y2={y} stroke="#ffffff" strokeOpacity="0.06" />;
      })}
      <path
        d={linePath(cur, true) + "Z"}
        fill="url(#radarg)"
        stroke="#3ee0a0"
        strokeWidth="1.6"
        style={{ filter: "drop-shadow(0 0 12px rgba(62,224,160,.35))" }}
      />
      <defs>
        <radialGradient id="radarg">
          <stop offset="0%" stopColor="#3ee0a0" stopOpacity="0.42" />
          <stop offset="100%" stopColor="#3ee0a0" stopOpacity="0.1" />
        </radialGradient>
      </defs>
      {cur.map(([x, y], k) => (
        <circle key={k} cx={x} cy={y} r="2.6" fill="#06080c" stroke="#3ee0a0" strokeWidth="1.4" />
      ))}
      {axes.map((a, k) => {
        const [x, y] = pt(k, R + 20);
        const anchor = Math.abs(x - C) < 6 ? "middle" : x > C ? "start" : "end";
        return (
          <text key={a.name} x={x} y={y + 3} textAnchor={anchor} fill="#8a96ad" fontSize="8.5" fontFamily="IBM Plex Mono, monospace" letterSpacing="0.06em">
            {a.name.toUpperCase()}
          </text>
        );
      })}
    </svg>
  );
}

/* ══════════════ histogram ══════════════ */
export function Histogram({
  bins,
  height = 130,
  markers = [],
}: {
  bins: { x: number; c: number }[];
  height?: number;
  markers?: { x: number; label: string; color: string }[];
}) {
  const [ref, w] = useSize<HTMLDivElement>();
  const max = Math.max(...bins.map((b) => b.c));
  const lo = bins[0].x;
  const hi = bins[bins.length - 1].x;
  const X = (x: number) => ((x - lo) / (hi - lo)) * (w - 8) + 4;
  const bw = (w - 8) / bins.length - 1.6;
  const normal = bins.map((b) => {
    const mu = bins.reduce((a, x) => a + x.x * x.c, 0) / bins.reduce((a, x) => a + x.c, 0);
    const sg = Math.sqrt(bins.reduce((a, x) => a + (x.x - mu) ** 2 * x.c, 0) / bins.reduce((a, x) => a + x.c, 0));
    const peak = (1 / (sg * Math.sqrt(2 * Math.PI))) * bins.reduce((a, x) => a + x.c, 0) * ((hi - lo) / bins.length);
    return peak * Math.exp(-((b.x - mu) ** 2) / (2 * sg * sg));
  });
  const nmax = Math.max(max, ...normal);
  const H = (c: number) => (c / nmax) * (height - 26);
  return (
    <div ref={ref} className="relative w-full" style={{ height }}>
      {w > 30 && (
        <svg width={w} height={height}>
          <line x1="0" x2={w} y1={height - 20} y2={height - 20} stroke="#ffffff" strokeOpacity="0.08" />
          {bins.map((b, i) => {
            const c = plColor(b.x * 1000, 3);
            return (
              <rect
                key={i}
                x={X(b.x) - bw / 2}
                y={height - 20 - H(b.c)}
                width={Math.max(1.5, bw)}
                height={Math.max(0.5, H(b.c))}
                rx="1.5"
                fill={c}
                opacity="0.95"
                style={{ animation: `rise .6s ${i * 12}ms cubic-bezier(.22,1,.36,1) both` }}
              />
            );
          })}
          <path
            d={linePath(normal.map((v, i) => [X(bins[i].x), height - 20 - H(v)] as [number, number]), true)}
            fill="none"
            stroke="#eaf0f8"
            strokeOpacity="0.5"
            strokeWidth="1.3"
            strokeDasharray="4 3"
          />
          {markers.map((m) => (
            <g key={m.label}>
              <line x1={X(m.x)} x2={X(m.x)} y1="6" y2={height - 20} stroke={m.color} strokeWidth="1.2" strokeDasharray="3 3" />
              <text x={X(m.x)} y="2" textAnchor="middle" fill={m.color} fontSize="8" fontFamily="IBM Plex Mono, monospace">
                {m.label}
              </text>
            </g>
          ))}
          {[-0.03, -0.015, 0, 0.015, 0.03].map((t) => (
            <text key={t} x={X(t)} y={height - 8} textAnchor="middle" fill="#5c6a80" fontSize="8" fontFamily="IBM Plex Mono, monospace">
              {(t * 100).toFixed(1)}%
            </text>
          ))}
        </svg>
      )}
    </div>
  );
}

/* ══════════════ correlation matrix ══════════════ */
export function CorrMatrix({ labels, m }: { labels: string[]; m: number[][] }) {
  const [hov, setHov] = React.useState<[number, number] | null>(null);
  const S = 34;
  const pad = 74;
  return (
    <div className="w-full overflow-x-auto no-scrollbar">
      <div style={{ width: pad + labels.length * S + 6 }}>
        {m.map((row, i) => (
          <div key={i} className="flex items-center" style={{ height: S }}>
            <div
              className="num pr-2 text-right text-[10px]"
              style={{ width: pad, color: hov && (hov[0] === i || hov[1] === i) ? "#eaf0f8" : "#8a96ad" }}
            >
              {labels[i]}
            </div>
            {row.map((v, j) => {
              const a = Math.min(1, Math.abs(v));
              const c = v >= 0 ? "#7db8ff" : "#ff5c7a";
              const on = hov && (hov[0] === i || hov[1] === j);
              return (
                <div
                  key={j}
                  onMouseEnter={() => setHov([i, j])}
                  onMouseLeave={() => setHov(null)}
                  className="group relative flex items-center justify-center transition-all duration-200"
                  style={{
                    width: S - 3,
                    height: S - 3,
                    margin: 1.5,
                    borderRadius: 4,
                    background: i === j ? "rgba(255,255,255,.1)" : `${c}${Math.round(a * 200 + 12).toString(16).padStart(2, "0")}`,
                    boxShadow: on ? `0 0 0 1px ${c}, 0 0 14px ${c}55` : "none",
                  }}
                >
                  <span className="num text-[9.5px] text-white/85">{i === j ? "—" : v.toFixed(2).replace("0.", ".")}</span>
                </div>
              );
            })}
          </div>
        ))}
        <div className="flex" style={{ height: 18 }}>
          <div style={{ width: pad }} />
          {labels.map((l, j) => (
            <div key={l} className="num text-center text-[9.5px]" style={{ width: S - 3, margin: 1.5, color: hov && hov[1] === j ? "#eaf0f8" : "#5c6a80" }}>
              {l}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ══════════════ range bar (52w) ══════════════ */
export function RangeBar({
  lo,
  hi,
  cur,
  cost,
  fmt,
}: {
  lo: number;
  hi: number;
  cur: number;
  cost?: number;
  fmt: (n: number) => string;
}) {
  const p = (v: number) => ((v - lo) / (hi - lo)) * 100;
  return (
    <div>
      <div className="relative h-[9px] w-full rounded-full bg-white/[0.05]">
        <div
          className="absolute inset-y-0 rounded-full"
          style={{ left: 0, width: "100%", background: "linear-gradient(90deg,#ff5c7a4d,#ffffff1455 50%,#3ee0a04d)" }}
        />
        {cost !== undefined && (
          <div className="absolute -top-[4px] h-[17px] w-[1.5px] bg-ember" style={{ left: `${p(cost)}%` }}>
            <span className="num absolute -top-[15px] left-1/2 -translate-x-1/2 whitespace-nowrap text-[8.5px] text-ember">COST</span>
          </div>
        )}
        <div className="absolute -top-[5px] h-[19px] w-[2px] rounded-full bg-paper shadow-[0_0_10px_rgba(234,240,248,.8)]" style={{ left: `${p(cur)}%` }} />
      </div>
      <div className="mt-2 flex justify-between">
        <span className="num text-[10px] text-fog">{fmt(lo)}</span>
        <span className="num text-[10px] text-fog">{fmt(hi)}</span>
      </div>
    </div>
  );
}

/* ══════════════ underwater / drawdown ══════════════ */
export function Underwater({ data, dates, height = 150 }: { data: number[]; dates: Date[]; height?: number }) {
  const [ref, w] = useSize<HTMLDivElement>();
  const [hi, setHi] = React.useState<number | null>(null);
  const lo = Math.min(...data) * 1.12;
  const n = data.length;
  const X = (i: number) => (i / (n - 1)) * (w - 2) + 1;
  const Y = (v: number) => 8 + (v / lo) * (height - 30);
  const base = 8;
  const pts = data.map((v, i) => [X(i), Y(v)] as [number, number]);
  const worst = data.indexOf(Math.min(...data));
  return (
    <div ref={ref} className="relative w-full" style={{ height }}>
      {w > 30 && (
        <svg width={w} height={height}>
          <defs>
            <linearGradient id="ddg" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#ff5c7a" stopOpacity="0.05" />
              <stop offset="100%" stopColor="#ff5c7a" stopOpacity="0.42" />
            </linearGradient>
          </defs>
          <line x1="0" x2={w} y1={base} y2={base} stroke="#ffffff" strokeOpacity="0.16" />
          <path d={`${linePath(pts, true)} L${X(n - 1)},${base} L1,${base} Z`} fill="url(#ddg)" />
          <path d={linePath(pts, true)} fill="none" stroke="#ff5c7a" strokeWidth="1.4" style={{ filter: "drop-shadow(0 0 8px rgba(255,92,122,.45))" }} />
          <g>
            <line x1={X(worst)} x2={X(worst)} y1={Y(data[worst])} y2={base} stroke="#ff5c7a" strokeOpacity=".5" strokeDasharray="2 3" />
            <text x={X(worst)} y={Y(data[worst]) + 12} textAnchor="middle" fill="#ff5c7a" fontSize="9" fontFamily="IBM Plex Mono, monospace">
              {data[worst].toFixed(1)}%
            </text>
          </g>
          {[-0.04, -0.08].map((t) => (
            <text key={t} x="2" y={Y(t) + 3} fill="#5c6a80" fontSize="8.5" fontFamily="IBM Plex Mono, monospace">
              {(t * 100).toFixed(0)}%
            </text>
          ))}
          {hi !== null && <line x1={X(hi)} x2={X(hi)} y1="0" y2={height - 22} stroke="#eaf0f8" strokeOpacity=".3" />}
          {[0, Math.floor(n / 2), n - 1].map((i) => (
            <text key={i} x={X(i)} y={height - 8} textAnchor={i === 0 ? "start" : i === n - 1 ? "end" : "middle"} fill="#5c6a80" fontSize="8.5" fontFamily="IBM Plex Mono, monospace">
              {dates[i].toLocaleDateString("en-GB", { month: "short", year: "2-digit", timeZone: "UTC" })}
            </text>
          ))}
        </svg>
      )}
      <div
        className="absolute inset-0 cursor-crosshair"
        onPointerMove={(e) => {
          const r = (e.currentTarget as HTMLDivElement).getBoundingClientRect();
          setHi(Math.max(0, Math.min(n - 1, Math.round(((e.clientX - r.left) / r.width) * (n - 1)))));
        }}
        onMouseLeave={() => setHi(null)}
      />
      {hi !== null && (
        <div className="num pointer-events-none absolute right-1 top-1 rounded border border-white/10 bg-[#080c12]/95 px-2 py-1 text-[10px]">
          <span className="text-fog">{dates[hi].toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "2-digit", timeZone: "UTC" })}</span>
          <span className="ml-2 text-rose">{data[hi].toFixed(2)}%</span>
        </div>
      )}
    </div>
  );
}
