import React from "react";

export const cx = (...a: (string | false | null | undefined)[]) => a.filter(Boolean).join(" ");

export const MINT = "#3ee0a0";
export const ROSE = "#ff5c7a";
export const EMBER = "#ff7a45";
export const toneOf = (v: number) => (v > 0 ? MINT : v < 0 ? ROSE : "#7c8aa3");

/* ── count-up ─────────────────────────────────────────── */
export function useCountUp(target: number, ms = 1100) {
  const [v, setV] = React.useState(0);
  React.useEffect(() => {
    let raf = 0;
    const t0 = performance.now();
    const from = 0;
    const step = (t: number) => {
      const k = Math.min(1, (t - t0) / ms);
      const e = 1 - Math.pow(1 - k, 3);
      setV(from + (target - from) * e);
      if (k < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [target, ms]);
  return v;
}

/* ── panel ────────────────────────────────────────────── */
export function Panel({
  children,
  className,
  ticks,
  delay = 0,
  hover,
}: {
  children: React.ReactNode;
  className?: string;
  ticks?: boolean;
  delay?: number;
  hover?: boolean;
}) {
  return (
    <div
      className={cx("panel rise", ticks && "ticks", hover && "panel-hover", className)}
      style={delay ? { animationDelay: `${delay}ms` } : undefined}
    >
      {children}
    </div>
  );
}

export function Head({
  kicker,
  title,
  sub,
  right,
  className,
}: {
  kicker?: string;
  title?: string;
  sub?: string;
  right?: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cx("flex items-start justify-between gap-4 px-5 pt-4 pb-3", className)}>
      <div className="min-w-0">
        {kicker && <div className="label mb-1.5">{kicker}</div>}
        {title && <h3 className="display text-[22px] text-paper">{title}</h3>}
        {sub && <p className="mt-1 text-[11.5px] leading-relaxed text-fog">{sub}</p>}
      </div>
      {right && <div className="shrink-0 pt-0.5">{right}</div>}
    </div>
  );
}

/* ── delta ────────────────────────────────────────────── */
export function Caret({ v, size = 8 }: { v: number; size?: number }) {
  const up = v >= 0;
  return (
    <svg width={size} height={size} viewBox="0 0 10 10" className="shrink-0">
      <path d={up ? "M5 1.5 L9 8.5 L1 8.5 Z" : "M5 8.5 L1 1.5 L9 1.5 Z"} fill="currentColor" />
    </svg>
  );
}

export function Delta({
  v,
  pctv,
  className,
  size = "md",
  showAbs = true,
  abs,
}: {
  v: number;
  pctv?: number;
  className?: string;
  size?: "sm" | "md" | "lg";
  showAbs?: boolean;
  abs?: string;
}) {
  const t = toneOf(v);
  const pad = size === "sm" ? "px-1.5 py-[2px] text-[10px]" : size === "lg" ? "px-2.5 py-1.5 text-[14px]" : "px-2 py-[3px] text-[11.5px]";
  return (
    <span
      className={cx("num inline-flex items-center gap-1.5 rounded-md font-medium", pad, className)}
      style={{ color: t, background: `${t}14`, boxShadow: `inset 0 0 0 1px ${t}26` }}
    >
      <Caret v={v} size={size === "lg" ? 9 : 7} />
      {showAbs && <span>{v > 0 ? "+" : ""}</span>}
      <span>{showAbs ? (abs ?? fmtDeltaAbs(v)) : ""}</span>
      {pctv !== undefined && <span className="opacity-70">({pctv > 0 ? "+" : ""}{pctv.toFixed(2)}%)</span>}
    </span>
  );
}
function fmtDeltaAbs(v: number) {
  const a = Math.abs(v);
  if (a >= 1000) return `${v < 0 ? "−" : ""}${(a / 1000).toFixed(2)}k`;
  return `${v < 0 ? "−" : ""}${a.toFixed(0)}`;
}

export const ToneNum = ({ v, children, className }: { v: number; children: React.ReactNode; className?: string }) => (
  <span className={cx("num", className)} style={{ color: toneOf(v) }}>
    {children}
  </span>
);

export function Pill({
  children,
  tone = "neutral",
  className,
  dot,
}: {
  children: React.ReactNode;
  tone?: "neutral" | "mint" | "rose" | "ember" | "azure" | "violet";
  className?: string;
  dot?: boolean;
}) {
  const c = {
    neutral: "#7c8aa3",
    mint: MINT,
    rose: ROSE,
    ember: EMBER,
    azure: "#7db8ff",
    violet: "#a08bff",
  }[tone];
  return (
    <span
      className={cx("inline-flex items-center gap-1.5 rounded-full px-2 py-[3px] font-mono text-[9.5px] uppercase tracking-[0.14em]", className)}
      style={{ color: c, background: `${c}12`, boxShadow: `inset 0 0 0 1px ${c}2e` }}
    >
      {dot && <i className="h-1 w-1 rounded-full" style={{ background: c }} />}
      {children}
    </span>
  );
}

export function Seg<T extends string>({
  items,
  value,
  onChange,
  size = "sm",
}: {
  items: { k: T; label: string }[];
  value: T;
  onChange: (v: T) => void;
  size?: "xs" | "sm";
}) {
  return (
    <div className="inline-flex items-center gap-0.5 rounded-lg border border-white/[0.07] bg-black/30 p-0.5">
      {items.map((it) => {
        const on = it.k === value;
        return (
          <button
            key={it.k}
            onClick={() => onChange(it.k)}
            className={cx(
              "relative rounded-[6px] font-mono uppercase tracking-[0.1em] transition-all duration-200",
              size === "xs" ? "px-2 py-[3px] text-[9px]" : "px-2.5 py-1 text-[9.5px]",
              on ? "text-ink" : "text-fog hover:text-mist",
            )}
            style={on ? { background: "linear-gradient(180deg,#f3e6da,#d9c3b0)" } : undefined}
          >
            {it.label}
          </button>
        );
      })}
    </div>
  );
}

export function Stat({
  label,
  value,
  sub,
  tone,
  align = "left",
  big,
}: {
  label: string;
  value: React.ReactNode;
  sub?: React.ReactNode;
  tone?: string;
  align?: "left" | "right";
  big?: boolean;
}) {
  return (
    <div className={align === "right" ? "text-right" : ""}>
      <div className="label mb-1.5">{label}</div>
      <div
        className={cx("num font-medium tracking-tight", big ? "text-[26px]" : "text-[17px]")}
        style={{ color: tone || "#eaf0f8" }}
      >
        {value}
      </div>
      {sub && <div className="mt-1 text-[10.5px] text-fog">{sub}</div>}
    </div>
  );
}

/* thin in-cell bar */
export function Bar({ v, max, color, h = 3, className }: { v: number; max: number; color: string; h?: number; className?: string }) {
  return (
    <div className={cx("w-full overflow-hidden rounded-full bg-white/[0.055]", className)} style={{ height: h }}>
      <div
        className="h-full rounded-full transition-all duration-700"
        style={{ width: `${Math.min(100, (Math.abs(v) / max) * 100)}%`, background: color, boxShadow: `0 0 8px ${color}66` }}
      />
    </div>
  );
}

export function Dot({ c, size = 7 }: { c: string; size?: number }) {
  return <i className="inline-block shrink-0 rounded-full" style={{ width: size, height: size, background: c, boxShadow: `0 0 8px ${c}88` }} />;
}

export function Rule({ className }: { className?: string }) {
  return <div className={cx("h-px w-full bg-white/[0.06]", className)} />;
}

export function KV({ k, v, tone }: { k: string; v: React.ReactNode; tone?: string }) {
  return (
    <div className="flex items-baseline justify-between gap-3 py-[7px]">
      <span className="text-[11.5px] text-fog">{k}</span>
      <span className="num text-[12.5px] font-medium" style={{ color: tone || "#dfe6f1" }}>
        {v}
      </span>
    </div>
  );
}

export function SectionTitle({ children, right }: { children: React.ReactNode; right?: React.ReactNode }) {
  return (
    <div className="mb-3 flex items-end justify-between">
      <div className="flex items-center gap-2.5">
        <span className="h-[13px] w-[2px] rounded-full" style={{ background: EMBER }} />
        <h2 className="font-mono text-[10px] uppercase tracking-[0.22em] text-mist">{children}</h2>
      </div>
      {right}
    </div>
  );
}
