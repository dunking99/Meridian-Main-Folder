import React from "react";
import { cx } from "./ui";

/* ══════════════ measuring ══════════════ */
export function useSize<T extends HTMLElement>() {
  const ref = React.useRef<T | null>(null);
  const [w, setW] = React.useState(0);
  React.useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const ro = new ResizeObserver((e) => setW(e[0].contentRect.width));
    ro.observe(el);
    setW(el.getBoundingClientRect().width);
    return () => ro.disconnect();
  }, []);
  return [ref, w] as const;
}

/* ══════════════ path helpers ══════════════ */
export function linePath(pts: [number, number][], smooth = false) {
  if (!pts.length) return "";
  if (!smooth) return "M" + pts.map((p) => `${p[0].toFixed(2)},${p[1].toFixed(2)}`).join("L");
  let d = `M${pts[0][0].toFixed(2)},${pts[0][1].toFixed(2)}`;
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[i - 1] || pts[i];
    const p1 = pts[i];
    const p2 = pts[i + 1];
    const p3 = pts[i + 2] || p2;
    const t = 0.18;
    const c1x = p1[0] + (p2[0] - p0[0]) * t;
    const c1y = p1[1] + (p2[1] - p0[1]) * t;
    const c2x = p2[0] - (p3[0] - p1[0]) * t;
    const c2y = p2[1] - (p3[1] - p1[1]) * t;
    d += `C${c1x.toFixed(2)},${c1y.toFixed(2)} ${c2x.toFixed(2)},${c2y.toFixed(2)} ${p2[0].toFixed(2)},${p2[1].toFixed(2)}`;
  }
  return d;
}

export const arcPath = (cx: number, cy: number, r: number, a0: number, a1: number) => {
  const p = (a: number) => [cx + r * Math.cos(a), cy + r * Math.sin(a)];
  const [x0, y0] = p(a0);
  const [x1, y1] = p(a1);
  const large = a1 - a0 > Math.PI ? 1 : 0;
  return `M${x0.toFixed(2)},${y0.toFixed(2)} A${r},${r} 0 ${large} 1 ${x1.toFixed(2)},${y1.toFixed(2)}`;
};

/* ══════════════ sparkline ══════════════ */
export function Sparkline({
  data,
  w = 92,
  h = 26,
  color,
  fill = true,
  dot = true,
  sw = 1.4,
}: {
  data: number[];
  w?: number;
  h?: number;
  color: string;
  fill?: boolean;
  dot?: boolean;
  sw?: number;
}) {
  const uid = React.useId().replace(/:/g, "");
  const min = Math.min(...data);
  const max = Math.max(...data);
  const rng = max - min || 1;
  const pts = data.map((v, i) => [(i / (data.length - 1)) * (w - 2) + 1, h - 2 - ((v - min) / rng) * (h - 4)] as [number, number]);
  const d = linePath(pts, true);
  const last = pts[pts.length - 1];
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} className="overflow-visible">
      {fill && (
        <>
          <defs>
            <linearGradient id={`sp${uid}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={color} stopOpacity="0.32" />
              <stop offset="100%" stopColor={color} stopOpacity="0" />
            </linearGradient>
          </defs>
          <path d={`${d} L${last[0]},${h} L1,${h} Z`} fill={`url(#sp${uid})`} />
        </>
      )}
      <path d={d} fill="none" stroke={color} strokeWidth={sw} strokeLinecap="round" />
      {dot && <circle cx={last[0]} cy={last[1]} r="1.9" fill={color} />}
    </svg>
  );
}

/* ══════════════ the main time chart ══════════════ */
export type Series = { key: string; data: number[]; color: string; fill?: boolean; dashed?: boolean; width?: number; smooth?: boolean };

export function TimeChart({
  series,
  dates,
  height = 220,
  yFmt = (n: number) => n.toFixed(0),
  xFmt = (d: Date) => d.toLocaleDateString("en-GB", { month: "short", year: "2-digit", timeZone: "UTC" }),
  tip,
  events = [],
  animate = true,
  padL = 52,
  padR = 12,
  yTicks = 4,
  className,
  glow = true,
  baseline,
}: {
  series: Series[];
  dates: Date[];
  height?: number;
  yFmt?: (n: number) => string;
  xFmt?: (d: Date) => string;
  tip?: (i: number) => React.ReactNode;
  events?: { i: number; label: string; tone?: string }[];
  animate?: boolean;
  padL?: number;
  padR?: number;
  yTicks?: number;
  className?: string;
  glow?: boolean;
  baseline?: number;
}) {
  const [ref, w] = useSize<HTMLDivElement>();
  const uid = React.useId().replace(/:/g, "");
  const [hi, setHi] = React.useState<number | null>(null);
  const n = dates.length;
  const padT = 14;
  const padB = 22;
  const iw = Math.max(10, w - padL - padR);
  const ih = height - padT - padB;

  const all = series.flatMap((s) => s.data);
  let min = Math.min(...all, ...(baseline !== undefined ? [baseline] : []));
  let max = Math.max(...all, ...(baseline !== undefined ? [baseline] : []));
  const pad = (max - min) * 0.12 || 1;
  min -= pad;
  max += pad;
  const X = (i: number) => padL + (i / (n - 1)) * iw;
  const Y = (v: number) => padT + ih - ((v - min) / (max - min)) * ih;

  const ticks = Array.from({ length: yTicks + 1 }, (_, k) => min + ((max - min) * k) / yTicks);
  const xTickIdx = Array.from({ length: 5 }, (_, k) => Math.round((k / 4) * (n - 1)));

  return (
    <div ref={ref} className={cx("relative w-full select-none", className)} style={{ height }}>
      {w > 40 && (
        <>
          <svg width={w} height={height} className="overflow-visible">
            <defs>
              {series.map((s, k) => (
                <linearGradient key={k} id={`g${uid}${k}`} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={s.color} stopOpacity="0.34" />
                  <stop offset="55%" stopColor={s.color} stopOpacity="0.09" />
                  <stop offset="100%" stopColor={s.color} stopOpacity="0" />
                </linearGradient>
              ))}
              {glow && (
                <filter id={`f${uid}`} x="-20%" y="-40%" width="140%" height="180%">
                  <feGaussianBlur stdDeviation="4" result="b" />
                  <feMerge>
                    <feMergeNode in="b" />
                    <feMergeNode in="SourceGraphic" />
                  </feMerge>
                </filter>
              )}
            </defs>

            {/* grid */}
            {ticks.map((t, k) => (
              <g key={k}>
                <line x1={padL} x2={w - padR} y1={Y(t)} y2={Y(t)} stroke="#ffffff" strokeOpacity={k === 0 ? 0.09 : 0.045} strokeDasharray="2 4" />
                <text x={padL - 9} y={Y(t) + 3} textAnchor="end" className="num" fill="#5c6a80" fontSize="9" fontFamily="IBM Plex Mono, monospace">
                  {yFmt(t)}
                </text>
              </g>
            ))}
            {xTickIdx.map((i, k) => (
              <text
                key={k}
                x={X(i)}
                y={height - 5}
                textAnchor={k === 0 ? "start" : k === 4 ? "end" : "middle"}
                fill="#5c6a80"
                fontSize="9"
                fontFamily="IBM Plex Mono, monospace"
              >
                {xFmt(dates[i])}
              </text>
            ))}

            {/* event markers */}
            {events.map((e, k) => (
              <g key={k}>
                <line x1={X(e.i)} x2={X(e.i)} y1={padT} y2={padT + ih} stroke={e.tone || "#ff7a45"} strokeOpacity="0.28" strokeDasharray="2 3" />
                <circle cx={X(e.i)} cy={padT} r="2.6" fill={e.tone || "#ff7a45"} fillOpacity="0.75" />
              </g>
            ))}

            {/* series */}
            {baseline !== undefined && (
              <line x1={padL} x2={w - padR} y1={Y(baseline)} y2={Y(baseline)} stroke="#eaf0f8" strokeOpacity="0.28" strokeDasharray="4 4" />
            )}
            <g style={animate ? { animation: "growx 1.3s cubic-bezier(.22,1,.36,1) both", transformOrigin: `${padL}px center` } : undefined}>
              {series.map((s, k) => {
                const pts = s.data.map((v, i) => [X(i), Y(v)] as [number, number]);
                const d = linePath(pts, s.smooth ?? true);
                const baseY = baseline !== undefined ? Y(baseline) : padT + ih;
                return (
                  <g key={k}>
                    {s.fill && <path d={`${d} L${X(n - 1)},${baseY} L${padL},${baseY} Z`} fill={`url(#g${uid}${k})`} />}
                    <path
                      d={d}
                      fill="none"
                      stroke={s.color}
                      strokeWidth={s.width ?? 1.7}
                      strokeDasharray={s.dashed ? "3 4" : undefined}
                      strokeLinecap="round"
                      filter={glow && k === 0 ? `url(#f${uid})` : undefined}
                      opacity={s.dashed ? 0.7 : 1}
                    />
                  </g>
                );
              })}
            </g>

            {/* hover */}
            {hi !== null && (
              <g>
                <line x1={X(hi)} x2={X(hi)} y1={padT - 4} y2={padT + ih} stroke="#eaf0f8" strokeOpacity="0.35" />
                {series.map((s, k) => (
                  <circle key={k} cx={X(hi)} cy={Y(s.data[hi])} r="3.6" fill="#06080c" stroke={s.color} strokeWidth="1.6" />
                ))}
              </g>
            )}
          </svg>

          {/* capture layer */}
          <div
            className="absolute inset-0 cursor-crosshair"
            style={{ left: padL, right: padR }}
            onPointerMove={(e) => {
              const r = (e.currentTarget as HTMLDivElement).getBoundingClientRect();
              const k = (e.clientX - r.left) / r.width;
              setHi(Math.max(0, Math.min(n - 1, Math.round(k * (n - 1)))));
            }}
            onPointerLeave={() => setHi(null)}
          />

          {hi !== null && tip && (
            <div
              className="pointer-events-none absolute top-1 z-20 min-w-[164px] rounded-lg border border-white/10 bg-[#080c12]/95 px-3 py-2 shadow-[0_16px_40px_-16px_rgba(0,0,0,.9)] backdrop-blur-md"
              style={{ left: Math.min(Math.max(X(hi) - 82, 0), Math.max(0, w - 172)) }}
            >
              <div className="label mb-1.5">{xFmt(dates[hi])}</div>
              {tip(hi)}
            </div>
          )}
        </>
      )}
    </div>
  );
}

/* ══════════════ stacked ribbon ══════════════ */
export function Ribbon({
  items,
  height = 22,
  gap = 2,
  onHover,
}: {
  items: { key: string; value: number; color: string }[];
  height?: number;
  gap?: number;
  onHover?: (k: string | null) => void;
}) {
  const [hov, setHov] = React.useState<string | null>(null);
  const total = items.reduce((a, b) => a + b.value, 0) || 1;
  const wPct = items.map((i) => (i.value / total) * 100);
  return (
    <div className="flex w-full items-stretch" style={{ gap, height }}>
      {items.map((it, i) => (
        <div
          key={it.key}
          onMouseEnter={() => {
            setHov(it.key);
            onHover?.(it.key);
          }}
          onMouseLeave={() => {
            setHov(null);
            onHover?.(null);
          }}
          className="group relative h-full cursor-default overflow-hidden rounded-[3px] transition-all duration-300"
          style={{
            width: `${wPct[i]}%`,
            background: `linear-gradient(180deg,${it.color},${it.color}bb)`,
            opacity: hov && hov !== it.key ? 0.35 : 1,
            boxShadow: hov === it.key ? `0 0 18px ${it.color}66` : "none",
          }}
        >
          {wPct[i] > 7 && (
            <span className="absolute inset-0 flex items-center justify-center font-mono text-[9px] uppercase tracking-[0.1em] text-black/70">
              {it.key}
            </span>
          )}
        </div>
      ))}
    </div>
  );
}

/* ══════════════ ring ══════════════ */
export function Ring({
  items,
  size = 200,
  thickness = 15,
  center,
  active,
  onHover,
}: {
  items: { key: string; value: number; color: string }[];
  size?: number;
  thickness?: number;
  center?: React.ReactNode;
  active?: string | null;
  onHover?: (k: string | null) => void;
}) {
  const total = items.reduce((a, b) => a + b.value, 0) || 1;
  const gap = 0.028;
  const R = size / 2 - thickness / 2 - 2;
  const C = size / 2;
  let a = -Math.PI / 2;
  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="overflow-visible">
        <circle cx={C} cy={C} r={R} fill="none" stroke="#ffffff" strokeOpacity="0.045" strokeWidth={thickness} />
        {items.map((it) => {
          const span = (it.value / total) * Math.PI * 2;
          const a0 = a + gap / 2;
          const a1 = a + span - gap / 2;
          a += span;
          const dim = active && active !== it.key;
          return (
            <path
              key={it.key}
              d={arcPath(C, C, R, a0, Math.max(a0 + 0.01, a1))}
              fill="none"
              stroke={it.color}
              strokeWidth={active === it.key ? thickness + 5 : thickness}
              strokeLinecap="butt"
              onMouseEnter={() => onHover?.(it.key)}
              onMouseLeave={() => onHover?.(null)}
              style={{
                opacity: dim ? 0.25 : 1,
                transition: "all .35s cubic-bezier(.22,1,.36,1)",
                cursor: "pointer",
                filter: active === it.key ? `drop-shadow(0 0 10px ${it.color}aa)` : undefined,
              }}
            />
          );
        })}
      </svg>
      <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center text-center">{center}</div>
    </div>
  );
}

/* ══════════════ grouped horizontal bars ══════════════ */
export function PairBars({
  rows,
  fmt,
  legend,
}: {
  rows: { label: string; a: number; b: number; ca?: string; cb?: string }[];
  fmt: (n: number) => string;
  legend?: [string, string];
}) {
  const max = Math.max(...rows.flatMap((r) => [Math.abs(r.a), Math.abs(r.b)])) || 1;
  return (
    <div>
      {legend && (
        <div className="mb-3 flex items-center gap-4">
          {legend.map((l, i) => (
            <span key={l} className="flex items-center gap-1.5 font-mono text-[9px] uppercase tracking-[0.14em] text-fog">
              <i className="h-[3px] w-4 rounded-full" style={{ background: i === 0 ? "#3ee0a0" : "#7c8aa3" }} />
              {l}
            </span>
          ))}
        </div>
      )}
      <div className="space-y-2.5">
        {rows.map((r) => {
          const pa = (Math.abs(r.a) / max) * 100;
          const pb = (Math.abs(r.b) / max) * 100;
          const ca = r.ca || (r.a >= 0 ? "#3ee0a0" : "#ff5c7a");
          const cb = r.cb || "#7c8aa3";
          return (
            <div key={r.label} className="group">
              <div className="mb-1 flex items-baseline justify-between">
                <span className="font-mono text-[9.5px] uppercase tracking-[0.14em] text-fog group-hover:text-mist">{r.label}</span>
                <span className="num flex items-center gap-2 text-[10.5px]">
                  <span style={{ color: ca }}>{fmt(r.a)}</span>
                  <span className="text-fog/50">{fmt(r.b)}</span>
                </span>
              </div>
              <div className="space-y-[3px]">
                <div className="h-[7px] w-full overflow-hidden rounded-sm bg-white/[0.04]">
                  <div
                    className="h-full rounded-sm transition-all duration-[900ms]"
                    style={{ width: `${pa}%`, marginLeft: r.a >= 0 ? "50%" : `${50 - pa}%`, background: ca, boxShadow: `0 0 10px ${ca}55` }}
                  />
                </div>
                <div className="h-[4px] w-full overflow-hidden rounded-sm bg-white/[0.03]">
                  <div
                    className="h-full rounded-sm transition-all duration-[900ms]"
                    style={{ width: `${pb}%`, marginLeft: r.b >= 0 ? "50%" : `${50 - pb}%`, background: cb }}
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ══════════════ diverging bar list ══════════════ */
export function DivergeList({
  rows,
  fmt,
}: {
  rows: { label: string; value: number; sub?: string; color?: string; spark?: number[] }[];
  fmt: (n: number) => string;
}) {
  const max = rows.length ? Math.max(...rows.map((r) => Math.abs(r.value))) : 1;
  return (
    <div className="space-y-[7px]">
      {rows.map((r, i) => {
        const c = r.color || (r.value >= 0 ? "#3ee0a0" : "#ff5c7a");
        const p = (Math.abs(r.value) / max) * 50;
        return (
          <div key={r.label + i} className="group flex items-center gap-3">
            <div className="w-[104px] shrink-0 truncate text-[11.5px] text-mist group-hover:text-paper">{r.label}</div>
            <div className="relative h-[16px] flex-1">
              <div className="absolute left-1/2 top-0 h-full w-px bg-white/[0.09]" />
              <div
                className="absolute top-[2px] h-[12px] rounded-[2px] transition-all duration-700"
                style={{
                  width: `${p}%`,
                  left: r.value >= 0 ? "50%" : `${50 - p}%`,
                  background: `linear-gradient(90deg,${c}55,${c})`,
                  boxShadow: `0 0 12px ${c}44`,
                  animation: `slideIn .7s ${i * 40}ms cubic-bezier(.22,1,.36,1) both`,
                }}
              />
            </div>
            {r.spark && <Sparkline data={r.spark} w={38} h={15} color={c} dot={false} sw={1.1} />}
            <div className="num w-[74px] shrink-0 text-right text-[11.5px] font-medium" style={{ color: c }}>
              {fmt(r.value)}
            </div>
          </div>
        );
      })}
    </div>
  );
}
