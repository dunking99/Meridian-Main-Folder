import React from "react";
import { CurCtx, type Cur, useM, positions, portfolioValue, dayChangePct, money } from "./lib/metrics";
import { CURRENCIES, N } from "./data/market";
import { cx, MINT, ROSE, toneOf, Seg } from "./components/ui";
import Overview from "./pages/Overview";
import Holdings from "./pages/Holdings";
import HoldingDetail from "./pages/HoldingDetail";
import Performance from "./pages/Performance";
import Analysis from "./pages/Analysis";
import Journal from "./pages/Journal";
import Activity from "./pages/Activity";
import News from "./pages/News";

type Page = "overview" | "holdings" | "holding" | "performance" | "analysis" | "journal" | "activity" | "news";

const NAV: { group: string; items: { k: Page; label: string; hint: string; live?: boolean }[] }[] = [
  {
    group: "Portfolio",
    items: [
      { k: "overview", label: "Overview", hint: "Value, allocation, movers", live: true },
      { k: "holdings", label: "Holdings", hint: "Every position, ranked", live: true },
      { k: "performance", label: "Performance", hint: "Returns and attribution", live: true },
      { k: "analysis", label: "Analysis", hint: "Risk and exposure", live: true },
    ],
  },
  {
    group: "Record",
    items: [
      { k: "journal", label: "Journal", hint: "Why you own things", live: true },
      { k: "activity", label: "Activity", hint: "Money in and out", live: true },
    ],
  },
  {
    group: "Markets",
    items: [{ k: "news", label: "News", hint: "Only your book", live: true }],
  },
];

const SUBTITLES: Record<Page, string> = {
  overview: "The whole book on one screen",
  holdings: "Every position, ranked and measurable",
  holding: "Position dossier",
  performance: "What the strategy has actually done",
  analysis: "Risk, exposure and condition",
  journal: "The reasoning behind the numbers",
  activity: "Money in, money out, money earned",
  news: "Headlines filtered to your positions",
};

export default function App() {
  const [page, setPage] = React.useState<Page>("overview");
  const [ticker, setTicker] = React.useState<string>("NVDA");
  const [cur, setCur] = React.useState<Cur>("USD");
  const [pal, setPal] = React.useState(false);
  const [q, setQ] = React.useState("");
  const [clock, setClock] = React.useState(new Date());

  React.useEffect(() => {
    const t = setInterval(() => setClock(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  React.useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if ((e.key === "k" && (e.metaKey || e.ctrlKey)) || e.key === "/") {
        e.preventDefault();
        setPal(true);
      }
      if (e.key === "Escape") setPal(false);
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, []);

  const go = (p: string, t?: string) => {
    setPal(false);
    if (t) setTicker(t);
    setPage(p as Page);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const results = q.trim()
    ? positions.filter((p) => `${p.ticker} ${p.name} ${p.sector} ${p.country}`.toLowerCase().includes(q.toLowerCase()))
    : positions.slice(0, 6);

  const flat = NAV.flatMap((g) => g.items.map((i) => ({ ...i, group: g.group })));
  const active = flat.find((i) => i.k === page) ?? flat.find((i) => i.k === "holdings")!;
  const zone = page === "holding" ? "Portfolio" : active.group;

  const time = (tz: string) =>
    clock.toLocaleTimeString("en-GB", { timeZone: tz, hour: "2-digit", minute: "2-digit", hour12: false });

  return (
    <CurCtx.Provider value={cur}>
      <div className="ambient" />
      <div className="relative flex min-h-screen">
        {/* ══════════ sidebar ══════════ */}
        <aside className="sticky top-0 hidden h-screen w-[236px] shrink-0 flex-col border-r border-white/[0.06] bg-[#07090d]/80 backdrop-blur-xl lg:flex">
          <div className="flex items-center gap-3 px-5 py-5">
            <svg width="30" height="30" viewBox="0 0 40 40" className="shrink-0">
              <circle cx="20" cy="20" r="18.5" fill="none" stroke="#ff7a45" strokeOpacity="0.35" />
              <ellipse cx="20" cy="20" rx="8" ry="18.5" fill="none" stroke="#3ee0a0" strokeOpacity="0.5" />
              <ellipse cx="20" cy="20" rx="16" ry="7" fill="none" stroke="#7db8ff" strokeOpacity="0.4" />
              <line x1="1.5" y1="20" x2="38.5" y2="20" stroke="#ff7a45" strokeWidth="1.4" />
              <circle cx="20" cy="20" r="2.6" fill="#ff7a45" />
            </svg>
            <div>
              <div className="display text-[20px] leading-none text-paper">Meridian</div>
              <div className="font-mono text-[8px] uppercase tracking-[0.22em] text-fog">private desk</div>
            </div>
          </div>

          <nav className="flex-1 overflow-y-auto px-3">
            {NAV.map((g) => (
              <div key={g.group} className="mb-5">
                <div className="label mb-2 px-2">{g.group}</div>
                {g.items.map((it) => {
                  const on = page === it.k;
                  return (
                    <button
                      key={it.k}
                      onClick={() => go(it.k)}
                      className={cx(
                        "group relative mb-[3px] flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-left transition-all duration-200",
                        on ? "bg-white/[0.06] text-paper" : "text-fog hover:bg-white/[0.03] hover:text-mist",
                      )}
                    >
                      <span
                        className="absolute left-0 top-1/2 h-0 w-[2px] -translate-y-1/2 rounded-full transition-all duration-300"
                        style={{ background: on ? "#ff7a45" : "transparent", height: on ? 18 : 0, boxShadow: on ? "0 0 10px #ff7a45" : "none" }}
                      />
                      <span className="text-[12.5px]">{it.label}</span>
                      {on && <span className="ml-auto h-1 w-1 rounded-full" style={{ background: "#ff7a45" }} />}
                    </button>
                  );
                })}
              </div>
            ))}
            <div className="mb-4">
              <div className="label mb-2 px-2">Coming</div>
              {["Screener", "Research", "Alerts"].map((s) => (
                <div key={s} className="mb-[3px] flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-[12.5px] text-fog/35">
                  {s}
                </div>
              ))}
            </div>
          </nav>

          <div className="border-t border-white/[0.06] p-4">
            <BookSummary />
          </div>
        </aside>

        {/* ══════════ main ══════════ */}
        <div className="min-w-0 flex-1">
          {/* top bar */}
          <header className="sticky top-0 z-30 border-b border-white/[0.06] bg-[#07090d]/85 backdrop-blur-xl">
            <div className="flex flex-wrap items-center gap-3 px-5 py-3">
              <div className="min-w-0">
                <div className="label mb-0.5">{zone}</div>
                <div className="flex items-baseline gap-2.5">
                  <h1 className="display text-[24px] leading-none text-paper">
                    {page === "holding" ? positions.find((p) => p.ticker === ticker)?.short : active?.label}
                  </h1>
                  <span className="hidden text-[11px] text-fog md:block">{SUBTITLES[page]}</span>
                </div>
              </div>

              <div className="ml-auto flex items-center gap-2.5">
                <button
                  onClick={() => setPal(true)}
                  className="flex items-center gap-2 rounded-lg border border-white/[0.08] bg-black/30 px-2.5 py-1.5 text-[11px] text-fog transition-colors hover:border-white/20 hover:text-mist"
                >
                  <span>⌕</span>
                  <span className="hidden sm:block">Search positions</span>
                  <span className="num rounded border border-white/10 px-1 py-[1px] text-[9px]">⌘K</span>
                </button>
                <Seg items={CURRENCIES.map((x) => ({ k: x.code as Cur, label: x.code }))} value={cur} onChange={setCur} />
                <div className="hidden items-center gap-3 rounded-lg border border-white/[0.07] bg-black/25 px-3 py-1.5 xl:flex">
                  {[
                    ["LDN", time("Europe/London")],
                    ["NYC", time("America/New_York")],
                    ["TYO", time("Asia/Tokyo")],
                  ].map(([k, v]) => (
                    <span key={k} className="num text-[10px] text-fog">
                      {k} <span className="text-mist">{v}</span>
                    </span>
                  ))}
                  <span className="flex items-center gap-1.5">
                    <i className="h-1.5 w-1.5 animate-pulse rounded-full" style={{ background: MINT }} />
                    <span className="font-mono text-[8.5px] uppercase tracking-[0.14em] text-mint">open</span>
                  </span>
                </div>
              </div>
            </div>

            {/* sub nav */}
            <div className="flex items-center gap-1 overflow-x-auto border-t border-white/[0.05] px-4 no-scrollbar">
              {NAV[0].items.concat(NAV[1].items).map((it, i) => (
                <React.Fragment key={it.k}>
                  {i === 4 && <span className="mx-2 h-3 w-px bg-white/10" />}
                  <button
                    onClick={() => go(it.k)}
                    className={cx(
                      "relative whitespace-nowrap px-3 py-2.5 font-mono text-[9.5px] uppercase tracking-[0.16em] transition-colors",
                      page === it.k ? "text-paper" : "text-fog hover:text-mist",
                    )}
                  >
                    {it.label}
                    <span
                      className="absolute inset-x-2 bottom-0 h-[2px] rounded-full transition-all duration-300"
                      style={{ background: page === it.k ? "#ff7a45" : "transparent", boxShadow: page === it.k ? "0 0 10px #ff7a45" : "none" }}
                    />
                  </button>
                </React.Fragment>
              ))}
              <span className="ml-auto hidden shrink-0 font-mono text-[9px] uppercase tracking-[0.16em] text-fog/50 md:block">
                {page === "holding" ? `Portfolio / Holdings / ${ticker}` : `Portfolio / ${active?.label}`}
              </span>
            </div>
          </header>

          <Tape />
          <main className="px-4 py-5 sm:px-5">
            {page === "overview" && <Overview go={go} cur={cur} setCur={setCur} />}
            {page === "holdings" && <Holdings go={go} />}
            {page === "holding" && <HoldingDetail ticker={ticker} go={go} />}
            {page === "performance" && <Performance go={go} />}
            {page === "analysis" && <Analysis go={go} />}
            {page === "journal" && <Journal go={go} />}
            {page === "activity" && <Activity go={go} />}
            {page === "news" && <News go={go} />}
          </main>
        </div>
      </div>

      {/* ══════════ command palette ══════════ */}
      {pal && (
        <div className="fixed inset-0 z-50 flex items-start justify-center bg-black/60 pt-[12vh] backdrop-blur-sm" onClick={() => setPal(false)}>
          <div
            className="w-[min(560px,92vw)] overflow-hidden rounded-2xl border border-white/[0.12] bg-[#0a0e14] shadow-[0_40px_100px_-30px_rgba(0,0,0,.9)]"
            onClick={(e) => e.stopPropagation()}
            style={{ animation: "rise .35s cubic-bezier(.22,1,.36,1) both" }}
          >
            <div className="flex items-center gap-3 border-b border-white/[0.07] px-4 py-3">
              <span className="text-fog">⌕</span>
              <input
                autoFocus
                value={q}
                onChange={(e) => setQ(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && results[0]) go("holding", results[0].ticker);
                }}
                placeholder="Jump to a position, sector or country…"
                className="flex-1 bg-transparent text-[13.5px] text-paper placeholder:text-fog/50 focus:outline-none"
              />
              <span className="num rounded border border-white/10 px-1.5 py-[2px] text-[9px] text-fog">esc</span>
            </div>
            <div className="max-h-[46vh] overflow-y-auto p-2">
              {results.map((p, i) => (
                <button
                  key={p.ticker}
                  onClick={() => go("holding", p.ticker)}
                  className={cx("flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left transition-colors", i === 0 ? "bg-white/[0.05]" : "hover:bg-white/[0.03]")}
                >
                  <span className="text-[14px]">{p.flag}</span>
                  <i className="h-6 w-[3px] shrink-0 rounded-full" style={{ background: p.color }} />
                  <div className="min-w-0 flex-1">
                    <div className="num text-[11.5px] text-paper">{p.ticker}</div>
                    <div className="truncate text-[10.5px] text-fog">{p.name}</div>
                  </div>
                  <div className="num text-right text-[11px] text-mist">{money(p.value, cur, 0)}</div>
                  <div className="num w-[52px] text-right text-[11px]" style={{ color: toneOf(p.plPct) }}>
                    {p.plPct >= 0 ? "+" : ""}
                    {p.plPct.toFixed(1)}%
                  </div>
                </button>
              ))}
              {!results.length && <div className="px-3 py-6 text-center text-[12px] text-fog">No position matches that.</div>}
            </div>
            <div className="flex items-center justify-between border-t border-white/[0.07] px-4 py-2">
              <span className="font-mono text-[9px] uppercase tracking-[0.14em] text-fog/60">↵ open dossier</span>
              <span className="font-mono text-[9px] uppercase tracking-[0.14em] text-fog/60">{positions.length} positions indexed</span>
            </div>
          </div>
        </div>
      )}
    </CurCtx.Provider>
  );
}

/* ── sidebar summary ─────────────────────────────── */
function BookSummary() {
  const M = useM();
  const up = dayChangePct >= 0;
  return (
    <div className="space-y-3">
      <div>
        <div className="label mb-1">Total value</div>
        <div className="num text-[17px] text-paper">{M(portfolioValue)}</div>
        <div className="num mt-0.5 text-[10.5px]" style={{ color: up ? MINT : ROSE }}>
          {up ? "▲" : "▼"} {Math.abs(dayChangePct * 100).toFixed(2)}% today
        </div>
      </div>
      <div className="h-[30px] w-full overflow-hidden rounded-md border border-white/[0.06] bg-black/30">
        <svg width="100%" height="30" viewBox="0 0 100 30" preserveAspectRatio="none">
          <path
            d={(() => {
              const arr = Array.from({ length: 40 }, (_, i) => {
                const p = positions.map((x) => x.spark[Math.floor((i / 40) * (x.spark.length - 1))]);
                return p.reduce((a, b) => a + b, 0) / p.length;
              });
              const mn = Math.min(...arr);
              const mx = Math.max(...arr);
              return arr.map((v, i) => `${i === 0 ? "M" : "L"}${(i / 39) * 100},${28 - ((v - mn) / (mx - mn || 1)) * 26}`).join(" ");
            })()}
            fill="none"
            stroke={MINT}
            strokeWidth="1.2"
            vectorEffect="non-scaling-stroke"
          />
        </svg>
      </div>
      <div className="flex items-center justify-between font-mono text-[8.5px] uppercase tracking-[0.14em] text-fog/60">
        <span>{N} sessions</span>
        <span>single user</span>
      </div>
    </div>
  );
}

/* ── ticker tape ─────────────────────────────────── */
function Tape() {
  const items = positions.filter((p) => !p.isCash);
  const row = [...items, ...items];
  return (
    <div className="relative overflow-hidden border-b border-white/[0.06] bg-black/30">
      <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-16 bg-gradient-to-r from-[#07090d] to-transparent" />
      <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-16 bg-gradient-to-l from-[#07090d] to-transparent" />
      <div className="marquee flex w-max items-center gap-6 py-[7px]">
        {row.map((p, i) => (
          <span key={i} className="flex items-center gap-2 whitespace-nowrap">
            <span className="text-[11px]">{p.flag}</span>
            <span className="num text-[10.5px] text-mist">{p.ticker}</span>
            <span className="num text-[10.5px] text-paper">{p.prices[N - 1] > 1000 ? p.prices[N - 1].toFixed(0) : p.prices[N - 1].toFixed(2)}</span>
            <span className="num text-[10px]" style={{ color: toneOf(p.dayPct) }}>
              {p.dayPct >= 0 ? "▲" : "▼"}
              {Math.abs(p.dayPct * 100).toFixed(2)}%
            </span>
            <span className="h-2.5 w-px bg-white/10" />
          </span>
        ))}
      </div>
    </div>
  );
}
