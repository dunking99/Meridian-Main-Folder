import React from "react";
import { Panel, Head, Pill, Delta, Seg, Rule, cx, MINT, ROSE, EMBER, toneOf, Dot, KV } from "../components/ui";
import { TimeChart, Sparkline } from "../components/charts";
import { RangeBar, plColor } from "../components/objects";
import { N, dates, FX, TRADES, dayIndexFromNow } from "../data/market";
import {
  positions,
  portfolioValue,
  invested,
  useM,
  useCur,
  money,
  num,
  dateShort,
  vol as portVol,
  ledger,
  benchHistory,
  benchName,
  type Pos,
} from "../lib/metrics";
import { THESIS, JOURNAL, NEWS, PEERS } from "../data/content";

const RANGES = [
  { k: "1M", d: 21 },
  { k: "3M", d: 63 },
  { k: "6M", d: 126 },
  { k: "1Y", d: 252 },
  { k: "ALL", d: 0 },
] as const;

export default function HoldingDetail({ ticker, go }: { ticker: string; go: (p: string, t?: string) => void }) {
  const M = useM();
  const c = useCur();
  const [range, setRange] = React.useState<(typeof RANGES)[number]["k"]>("6M");
  const [rel, setRel] = React.useState<"price" | "rel">("price");
  const p = (positions.find((x) => x.ticker === ticker) as Pos) || positions[0];

  const from = RANGES.find((r) => r.k === range)!.d;
  const i0 = from === 0 ? 0 : dates.length - 1 - from;
  const ds = dates.slice(i0);
  const fx = FX[p.currency];
  const px = p.prices.slice(i0);
  const costSeries = p.prices.map(() => p.avgCost).slice(i0);
  const benchRel = benchHistory.slice(i0).map((b) => b / benchHistory[i0]);
  const priceRel = px.map((v) => v / px[0]);
  const chg = (p.prices[N - 1] / p.prices[i0] - 1) * 100;
  const bchg = (benchHistory[N - 1] / benchHistory[i0] - 1) * 100;

  const trades = TRADES.filter((t) => t.ticker === p.ticker).map((t) => ({ ...t, i: dayIndexFromNow(t.ago) - i0 })).filter((t) => t.i > 0);
  const entries = JOURNAL.filter((j) => j.tickers.includes(p.ticker));
  const news = NEWS.filter((n) => n.tickers.includes(p.ticker));
  const divs = ledger.filter((l) => l.ticker === p.ticker && l.type === "Dividend");
  const peers =
    PEERS[p.ticker] ||
    positions
      .filter((x) => x.sector === p.sector && x.ticker !== p.ticker)
      .slice(0, 4)
      .map((x) => ({ ticker: x.ticker, name: x.short, ret1y: x.rets.y1 * 100, pe: x.pe, mcap: x.mcap }))
      .concat([{ ticker: p.ticker, name: p.short, ret1y: p.rets.y1 * 100, pe: p.pe, mcap: p.mcap }]);

  const lo = Math.min(...p.prices);
  const hi = Math.max(...p.prices);
  const posHistory: number[] = [];
  for (let i = 0; i < N; i++) posHistory.push(p.qtySeries[i] * p.prices[i] * fx);

  return (
    <div className="space-y-5">
      {/* ══════ hero ══════ */}
      <Panel delay={0}>
        <div className="grid gap-0 lg:grid-cols-[1.25fr_1fr_1fr]">
          <div className="border-b border-white/[0.06] p-5 lg:border-b-0 lg:border-r">
            <button onClick={() => go("holdings")} className="mb-4 flex items-center gap-1.5 font-mono text-[9px] uppercase tracking-[0.16em] text-fog transition-colors hover:text-paper">
              <span className="transition-transform hover:-translate-x-0.5">←</span> All positions
            </button>
            <div className="flex items-start gap-3">
              <div
                className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-[18px]"
                style={{ background: `${p.color}1c`, boxShadow: `inset 0 0 0 1px ${p.color}44` }}
              >
                {p.flag}
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="num text-[15px] font-medium text-paper">{p.ticker}</span>
                  <span className="num text-[9.5px] text-fog">{p.exchange}</span>
                </div>
                <h1 className="display mt-0.5 text-[26px] leading-tight text-paper">{p.short}</h1>
                <div className="mt-2 flex flex-wrap items-center gap-1.5">
                  <Pill tone="neutral">{p.sector}</Pill>
                  <Pill tone="neutral">{p.industry}</Pill>
                  <Pill tone="azure">{p.currency}</Pill>
                </div>
              </div>
            </div>
            <div className="mt-5 flex items-end gap-3">
              <div className="display num text-[38px] leading-none text-paper">{num(p.prices[N - 1], p.price > 1000 ? 0 : 2)}</div>
              <div className="pb-1.5">
                <Delta v={p.prices[N - 1] - p.prices[N - 2]} pctv={p.dayPct * 100} size="sm" />
                <div className="num mt-1 text-[9.5px] text-fog">native {p.currency}</div>
              </div>
            </div>
            <div className="mt-4">
              <RangeBar lo={lo} hi={hi} cur={p.prices[N - 1]} cost={p.avgCost} fmt={(n) => num(n, n > 1000 ? 0 : 2)} />
              <div className="mt-1 flex justify-between">
                <span className="num text-[9px] text-fog">52-week range</span>
                <span className="num text-[9px]" style={{ color: toneOf((p.prices[N - 1] / p.avgCost - 1) * 100) }}>
                  {((p.prices[N - 1] / p.avgCost - 1) * 100).toFixed(1)}% vs your cost
                </span>
              </div>
            </div>
          </div>

          <div className="border-b border-white/[0.06] p-5 lg:border-b-0 lg:border-r">
            <div className="label mb-3">Your position</div>
            <div className="display num text-[34px] leading-none text-paper">{M(p.value)}</div>
            <div className="num mt-1.5 text-[11px] text-fog">
              {p.weight.toFixed(1)}% of portfolio · {p.plPct >= 0 ? "gaining" : "losing"} {Math.abs(p.plPct).toFixed(1)}%
            </div>
            <div className="mt-4 space-y-0">
              <KV k="Shares held" v={num(p.qty, 0)} />
              <KV k="Average cost" v={`${num(p.avgCost, p.avgCost > 1000 ? 0 : 2)} ${p.currency}`} />
              <KV k="Cost basis" v={M(p.cost)} />
              <KV k="Unrealised P/L" v={`${p.pl >= 0 ? "+" : ""}${M(p.pl)}`} tone={toneOf(p.pl)} />
              <KV k="Contribution today" v={`${p.dayPl >= 0 ? "+" : ""}${M(p.dayPl)}`} tone={toneOf(p.dayPl)} />
              <KV k="Running income" v={`${M(p.divIncome)} · ${p.divYield.toFixed(2)}%`} />
            </div>
            <div className="mt-4 flex gap-2">
              <button className="flex-1 rounded-lg border border-white/[0.09] bg-white/[0.02] py-2 font-mono text-[9px] uppercase tracking-[0.16em] text-mist transition-colors hover:border-white/25 hover:text-paper">
                Add to position
              </button>
              <button className="flex-1 rounded-lg border border-white/[0.09] bg-white/[0.02] py-2 font-mono text-[9px] uppercase tracking-[0.16em] text-mist transition-colors hover:border-white/25 hover:text-paper">
                Write note
              </button>
            </div>
          </div>

          <div className="p-5">
            <div className="label mb-3">Instrument</div>
            <div className="grid grid-cols-2 gap-y-3">
              {[
                { l: "Market cap", v: p.mcap },
                { l: "P/E", v: p.pe ? p.pe.toFixed(1) : "—" },
                { l: "Dividend yield", v: `${p.divYield.toFixed(2)}%` },
                { l: "Beta", v: p.beta.toFixed(2) },
                { l: "Volatility", v: `${p.vol.toFixed(0)}%`, s: `book ${portVol.toFixed(0)}%` },
                { l: "Max drawdown", v: `${p.maxDD.toFixed(1)}%`, tone: ROSE },
                { l: "1-year", v: `${p.rets.y1 >= 0 ? "+" : ""}${(p.rets.y1 * 100).toFixed(1)}%`, tone: toneOf(p.rets.y1) },
                { l: "YTD", v: `${p.rets.ytd >= 0 ? "+" : ""}${(p.rets.ytd * 100).toFixed(1)}%`, tone: toneOf(p.rets.ytd) },
              ].map((x) => (
                <div key={x.l}>
                  <div className="label mb-1">{x.l}</div>
                  <div className="num text-[15px]" style={{ color: x.tone || "#eaf0f8" }}>
                    {x.v}
                  </div>
                  {x.s && <div className="num text-[9.5px] text-fog">{x.s}</div>}
                </div>
              ))}
            </div>
            <Rule className="my-4" />
            <p className="text-[11.5px] leading-relaxed text-mist">
              <span className="label mb-1.5 block">Thesis in one line</span>
              {THESIS[p.ticker] || "No thesis recorded for this position."}
            </p>
          </div>
        </div>
      </Panel>

      {/* ══════ chart ══════ */}
      <Panel delay={60}>
        <Head
          kicker={`${range} view`}
          title={rel === "price" ? "Price against your cost" : "Performance against the world"}
          right={
            <div className="flex items-center gap-2">
              <Seg size="xs" items={[{ k: "price" as const, label: "Price" }, { k: "rel" as const, label: "Relative" }]} value={rel} onChange={setRel} />
              <Seg size="xs" items={RANGES.map((r) => ({ k: r.k, label: r.k }))} value={range} onChange={setRange} />
            </div>
          }
        />
        <div className="px-5 pb-4">
          <div className="mb-2 flex flex-wrap items-center gap-4">
            <span className="num flex items-center gap-1.5 text-[10px] text-fog">
              <i className="h-[3px] w-4 rounded-full" style={{ background: toneOf(chg) }} />
              {p.ticker} {chg >= 0 ? "+" : ""}
              {chg.toFixed(1)}%
            </span>
            <span className="num flex items-center gap-1.5 text-[10px] text-fog">
              <i className="h-[3px] w-4 rounded-full bg-[#7c8aa3]" />
              {benchName} {bchg >= 0 ? "+" : ""}
              {bchg.toFixed(1)}%
            </span>
            <span className="num flex items-center gap-1.5 text-[10px] text-fog">
              <i className="h-[3px] w-4 rounded-full bg-ember" />
              your cost
            </span>
            <span className="num ml-auto text-[10.5px]" style={{ color: toneOf(chg - bchg) }}>
              {chg - bchg >= 0 ? "outperforming" : "underperforming"} by {Math.abs(chg - bchg).toFixed(1)}pt
            </span>
          </div>
          {rel === "price" ? (
            <TimeChart
              height={286}
              dates={ds}
              yFmt={(n) => num(n, n > 1000 ? 0 : 0)}
              series={[
                { key: "px", data: px, color: toneOf(chg), fill: true, width: 1.9, smooth: true },
                { key: "cost", data: costSeries, color: EMBER, dashed: true, width: 1.1, smooth: false },
              ]}
              events={trades.map((t) => ({ i: t.i, label: t.type, tone: t.type === "buy" ? MINT : ROSE }))}
              tip={(i) => (
                <div className="space-y-1">
                  <div className="num text-[12px] text-paper">
                    {num(px[i], p.price > 1000 ? 0 : 2)} {p.currency}
                  </div>
                  <div className="num text-[10px] text-fog">vs cost {p.avgCost.toFixed(0)}</div>
                  <div className="num text-[10px]" style={{ color: toneOf(px[i] / p.avgCost - 1) }}>
                    {((px[i] / p.avgCost - 1) * 100).toFixed(1)}%
                  </div>
                </div>
              )}
            />
          ) : (
            <TimeChart
              height={286}
              dates={ds}
              yFmt={(n) => `${((n - 1) * 100).toFixed(0)}%`}
              series={[
                { key: "rel", data: priceRel, color: toneOf(chg - bchg), fill: true, width: 1.9, smooth: true },
                { key: "bench", data: benchRel, color: "#7c8aa3", dashed: true, width: 1.2, smooth: true },
              ]}
              tip={(i) => (
                <div className="space-y-1">
                  <div className="num text-[12px]" style={{ color: toneOf((priceRel[i] - 1) * 100) }}>
                    {((priceRel[i] - 1) * 100).toFixed(1)}%
                  </div>
                  <div className="num text-[10px] text-fog">world {((benchRel[i] - 1) * 100).toFixed(1)}%</div>
                </div>
              )}
            />
          )}
          <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-white/[0.06] pt-3">
            <span className="label">Your trades in this window</span>
            {trades.length === 0 && <span className="text-[11px] text-fog">none — position untouched</span>}
            {trades.map((t, i) => (
              <span
                key={i}
                className="num rounded-md px-2 py-[3px] text-[10px]"
                style={{ color: t.type === "buy" ? MINT : ROSE, background: `${t.type === "buy" ? MINT : ROSE}12`, boxShadow: `inset 0 0 0 1px ${t.type === "buy" ? MINT : ROSE}22` }}
              >
                {dateShort(dates[dayIndexFromNow(t.ago)])} · {t.type} {t.qty} @ {num(t.qty ? p.prices[dayIndexFromNow(t.ago)] : 0, 0)}
              </span>
            ))}
          </div>
        </div>
      </Panel>

      {/* ══════ row: journey / thesis / news ══════ */}
      <div className="grid gap-5 lg:grid-cols-12">
        <Panel className="lg:col-span-4" delay={120}>
          <Head kicker="How the position grew" title="Your history" right={<Pill tone="neutral">{trades.length} trades</Pill>} />
          <div className="px-5 pb-5">
            <TimeChart
              height={148}
              dates={dates.slice(i0)}
              yFmt={(n) => M(n)}
              series={[{ key: "v", data: posHistory.slice(i0), color: p.color, fill: true, width: 1.7, smooth: true }]}
              tip={(i) => (
                <div className="num space-y-1">
                  <div className="text-[12px] text-paper">{M(posHistory[i0 + i])}</div>
                  <div className="text-[10px] text-fog">{num(p.qtySeries[i0 + i], 0)} shares</div>
                </div>
              )}
            />
            <Rule className="my-3.5" />
            <div className="space-y-0">
              {trades
                .slice()
                .reverse()
                .map((t, i) => {
                  const d = dayIndexFromNow(t.ago);
                  return (
                    <div key={i} className="flex items-center gap-3 border-b border-white/[0.04] py-2 last:border-0">
                      <Dot c={t.type === "buy" ? MINT : ROSE} size={6} />
                      <span className="num w-[62px] text-[10px] text-fog">{dateShort(dates[d])}</span>
                      <span className="text-[11px] uppercase tracking-wide" style={{ color: t.type === "buy" ? MINT : ROSE }}>
                        {t.type}
                      </span>
                      <span className="num text-[11px] text-mist">{t.qty} sh</span>
                      <span className="num ml-auto text-[11px] text-paper">{M(t.qty * p.prices[d] * fx)}</span>
                    </div>
                  );
                })}
              {divs.slice(0, 3).map((d, i) => (
                <div key={i} className="flex items-center gap-3 py-2">
                  <Dot c={EMBER} size={6} />
                  <span className="num w-[62px] text-[10px] text-fog">{dateShort(d.date)}</span>
                  <span className="text-[11px] uppercase tracking-wide text-ember">Dividend</span>
                  <span className="num ml-auto text-[11px] text-paper">{M(d.usd)}</span>
                </div>
              ))}
            </div>
          </div>
        </Panel>

        <Panel className="lg:col-span-4" delay={160}>
          <Head kicker="Journal" title="Thesis & conviction" right={<Pill tone={entries.length ? "violet" : "neutral"}>{entries.length} entries</Pill>} />
          <div className="px-5 pb-5">
            {entries.length === 0 && (
              <div className="rounded-lg border border-dashed border-white/[0.09] p-6 text-center">
                <p className="text-[11.5px] leading-relaxed text-fog">
                  No note written against {p.ticker}. Positions without a recorded reason are the ones that get held for the wrong length of time.
                </p>
                <button className="mt-3 font-mono text-[9px] uppercase tracking-[0.16em] text-mist hover:text-paper">Write one →</button>
              </div>
            )}
            {entries.map((e) => (
              <div key={e.id} className="mb-3 rounded-xl border border-white/[0.06] bg-white/[0.012] p-3.5 last:mb-0">
                <div className="mb-2 flex items-center justify-between gap-2">
                  <span className="num text-[9.5px] text-fog">{dateShort(dates[dayIndexFromNow(e.ago)])}</span>
                  <span
                    className="font-mono text-[8.5px] uppercase tracking-[0.14em]"
                    style={{ color: e.status === "on-track" ? MINT : e.status === "challenged" ? EMBER : "#7c8aa3" }}
                  >
                    {e.status.replace("-", " ")}
                  </span>
                </div>
                <div className="text-[12.5px] font-medium leading-snug text-paper">{e.title}</div>
                <p className="mt-2 line-clamp-4 text-[11px] leading-relaxed text-fog">{e.body}</p>
                <div className="mt-3 flex items-center gap-3">
                  <span className="label">conviction</span>
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map((k) => (
                      <i key={k} className="h-[6px] w-[10px] rounded-[1px]" style={{ background: k <= e.conviction ? plColor(20, 30) : "rgba(255,255,255,.09)" }} />
                    ))}
                  </div>
                  <span className="num ml-auto text-[10px] text-fog">{e.tags.join(" · ")}</span>
                </div>
              </div>
            ))}
            <button onClick={() => go("journal")} className="mt-3 w-full rounded-lg border border-white/[0.07] py-2 font-mono text-[9px] uppercase tracking-[0.16em] text-fog hover:border-white/20 hover:text-paper">
              Open journal →
            </button>
          </div>
        </Panel>

        <Panel className="lg:col-span-4" delay={200}>
          <Head kicker="Enrichment" title="News & peers" right={<Pill tone="neutral">{news.length} stories</Pill>} />
          <div className="px-5 pb-5">
            {news.length === 0 && <p className="text-[11.5px] text-fog">No stories referencing {p.ticker} in your feed.</p>}
            {news.map((n, i) => (
              <button key={i} className="group block w-full border-b border-white/[0.045] py-2.5 text-left last:border-0">
                <div className="mb-1 flex items-center gap-2">
                  <span className="num text-[9.5px] text-fog">{n.source}</span>
                  <span className="h-1 w-1 rounded-full bg-white/20" />
                  <span className="num text-[9.5px] text-fog">{n.ago < 1 ? `${Math.round(n.ago * 24)}h` : `${n.ago.toFixed(0)}d`}</span>
                  <span className="ml-auto h-1.5 w-1.5 rounded-full" style={{ background: n.sentiment === "pos" ? MINT : n.sentiment === "neg" ? ROSE : "#7c8aa3" }} />
                </div>
                <div className="text-[11.5px] leading-snug text-mist group-hover:text-paper">{n.headline}</div>
              </button>
            ))}
            <Rule className="my-4" />
            <div className="label mb-3">Peer set · 1 year</div>
            <div className="space-y-2">
              {[...peers]
                .sort((a, b) => b.ret1y - a.ret1y)
                .map((x) => {
                  const me = x.ticker === p.ticker;
                  const max = Math.max(...peers.map((y) => Math.abs(y.ret1y)));
                  const w = (Math.abs(x.ret1y) / max) * 50;
                  const col = me ? EMBER : x.ret1y >= 0 ? MINT : ROSE;
                  return (
                    <div key={x.ticker} className={cx("group flex items-center gap-2", me && "font-medium")}>
                      <span className="num w-[42px] text-[10.5px]" style={{ color: me ? EMBER : "#b9c5d8" }}>
                        {x.ticker}
                      </span>
                      <div className="relative h-[13px] flex-1">
                        <div className="absolute left-1/2 top-0 h-full w-px bg-white/[0.09]" />
                        <div
                          className="absolute top-[2px] h-[9px] rounded-[2px]"
                          style={{ width: `${w}%`, left: x.ret1y >= 0 ? "50%" : `${50 - w}%`, background: col, opacity: me ? 1 : 0.62, boxShadow: me ? `0 0 12px ${col}` : "none" }}
                        />
                      </div>
                      <span className="num w-[50px] text-right text-[10.5px]" style={{ color: col }}>
                        {x.ret1y >= 0 ? "+" : ""}
                        {x.ret1y.toFixed(1)}%
                      </span>
                      <span className="num w-[38px] text-right text-[9.5px] text-fog">{x.pe ? `${x.pe.toFixed(0)}x` : "—"}</span>
                    </div>
                  );
                })}
            </div>
            <div className="mt-3 text-right font-mono text-[8.5px] uppercase tracking-[0.14em] text-fog/60">return · multiple</div>
          </div>
        </Panel>
      </div>

      {/* ══════ footer stats ══════ */}
      <div className="grid gap-5 lg:grid-cols-4">
        {[
          { l: "Weight in book", v: `${p.weight.toFixed(1)}%`, s: `rank ${positions.findIndex((x) => x.ticker === p.ticker) + 1} of ${positions.length}`, spark: p.spark },
          { l: "Share of total P/L", v: `${((p.pl / (portfolioValue - invested)) * 100).toFixed(0)}%`, s: M(p.pl) },
          { l: "Volatility vs book", v: `${(p.vol / portVol).toFixed(2)}×`, s: `${p.vol.toFixed(0)}% vs ${portVol.toFixed(0)}%` },
          { l: "Income received", v: M(divs.reduce((a, d) => a + d.usd, 0)), s: `${divs.length} distributions` },
        ].map((x, i) => (
          <Panel key={x.l} delay={240 + i * 50}>
            <div className="flex items-center justify-between p-5">
              <div>
                <div className="label mb-1.5">{x.l}</div>
                <div className="num text-[22px] text-paper">{x.v}</div>
                <div className="num mt-1 text-[10px] text-fog">{x.s}</div>
              </div>
              {x.spark && <Sparkline data={x.spark} w={80} h={38} color={toneOf(p.plPct)} />}
            </div>
          </Panel>
        ))}
      </div>

      <div className="px-1 pb-2 font-mono text-[9px] uppercase tracking-[0.2em] text-fog/60">
        {p.name} · {p.country} · priced in {p.currency} at {num(fx, 4)} to USD · displayed in {c} · {money(p.value * (p.currency === "USD" ? 1 : 1), c)}
      </div>
    </div>
  );
}
