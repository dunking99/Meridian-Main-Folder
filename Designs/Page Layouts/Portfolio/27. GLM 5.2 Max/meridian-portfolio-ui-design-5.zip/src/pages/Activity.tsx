import React from "react";
import { Panel, Head, Pill, Seg, Rule, cx, MINT, ROSE, EMBER, toneOf, KV } from "../components/ui";
import { TimeChart, useSize, linePath, Sparkline } from "../components/charts";
import { dates, END, N, DEPOSITS } from "../data/market";
import {
  ledger,
  portfolioValue,
  totalDeposited,
  incomeReceived,
  cashInterestEarned,
  feesPaid,
  navHistory,
  useM,
  money,
  compact,
  dateShort,
  dateLong,
} from "../lib/metrics";
import { CASH } from "../data/market";

/* money-weighted return: solve for r in Σ cf/(1+r)^t = 0 */
function xirr(cfs: { t: number; amt: number }[]) {
  const npv = (r: number) => cfs.reduce((a, f) => a + f.amt / Math.pow(1 + r, f.t), 0);
  let lo = -0.85;
  let hi = 4;
  for (let i = 0; i < 160; i++) {
    const mid = (lo + hi) / 2;
    if (npv(mid) > 0) lo = mid;
    else hi = mid;
  }
  return (lo + hi) / 2;
}

export default function Activity({ go }: { go: (p: string, t?: string) => void }) {
  const M = useM();
  const [filter, setFilter] = React.useState<"all" | "trades" | "income" | "flows">("all");

  const yrs = 365.25 * 86400000;
  const cfs = [
    ...DEPOSITS.map((d) => ({ t: -(END.getTime() - dates[Math.max(0, N - 1 - d.ago)].getTime()) / yrs, amt: -d.amount })),
    { t: 0, amt: portfolioValue },
  ];
  const mwr = xirr(cfs);
  const twr = (navHistory[N - 1] - 1) * 100;
  const annualTwr = (Math.pow(1 + twr / 100, 365 / (N * 1.4)) - 1) * 100;

  const rows = ledger.filter((r) =>
    filter === "all" ? true : filter === "trades" ? r.type === "Buy" || r.type === "Sell" : filter === "income" ? r.type === "Dividend" || r.type === "Interest" : r.type === "Deposit",
  );

  const grouped = rows.reduce<Record<string, typeof rows>>((a, r) => {
    const k = r.date.toLocaleDateString("en-GB", { month: "long", year: "numeric", timeZone: "UTC" });
    (a[k] ||= []).push(r);
    return a;
  }, {});

  const divMonths = ledger
    .filter((r) => r.type === "Dividend")
    .reduce<Record<string, number>>((a, r) => {
      const k = r.date.toLocaleDateString("en-GB", { month: "short", year: "2-digit", timeZone: "UTC" });
      a[k] = (a[k] || 0) + r.usd;
      return a;
    }, {});
  const divArr = Object.entries(divMonths);
  const maxDiv = Math.max(...divArr.map((d) => d[1]));

  const [bref, bw] = useSize<HTMLDivElement>();
  const buySell = ledger.filter((r) => r.type === "Buy" || r.type === "Sell");
  const maxBs = Math.max(...buySell.map((r) => r.usd));

  const TYPE = {
    Buy: { c: MINT, g: "B" },
    Sell: { c: ROSE, g: "S" },
    Dividend: { c: EMBER, g: "D" },
    Deposit: { c: "#7db8ff", g: "↑" },
    Interest: { c: "#a08bff", g: "I" },
  } as const;

  return (
    <div className="space-y-5">
      {/* ══════ hero ══════ */}
      <div className="grid gap-5 lg:grid-cols-12">
        <Panel className="lg:col-span-5" delay={0}>
          <Head kicker="Two truths" title="Money-weighted vs time-weighted" sub="The gap between them is the cost — or the value — of your timing." />
          <div className="px-5 pb-5">
            <div className="flex items-end gap-5">
              <div>
                <div className="label mb-1.5">Money-weighted</div>
                <div className="display num text-[40px] leading-none" style={{ color: toneOf(mwr * 100) }}>
                  {(mwr * 100).toFixed(1)}%
                </div>
                <div className="num mt-1 text-[10px] text-fog">annualised, net of all flows</div>
              </div>
              <div className="border-l border-white/[0.08] pl-5">
                <div className="label mb-1.5">Time-weighted</div>
                <div className="display num text-[40px] leading-none" style={{ color: toneOf(annualTwr) }}>
                  {annualTwr.toFixed(1)}%
                </div>
                <div className="num mt-1 text-[10px] text-fog">annualised, strategy only</div>
              </div>
            </div>
            <Rule className="my-4" />
            <div
              className="rounded-lg border p-3"
              style={{
                borderColor: mwr * 100 > annualTwr ? `${MINT}33` : `${ROSE}33`,
                background: mwr * 100 > annualTwr ? `${MINT}0d` : `${ROSE}0d`,
              }}
            >
              <p className="text-[11.5px] leading-relaxed text-mist">
                {mwr * 100 > annualTwr
                  ? `You added money before the good stretches: your timing is worth ${((mwr * 100 - annualTwr)).toFixed(1)}pt a year on top of the strategy itself.`
                  : `Money went in ahead of the weak stretches: timing has cost you ${Math.abs(mwr * 100 - annualTwr).toFixed(1)}pt a year relative to the strategy itself.`}
              </p>
            </div>
            <div className="mt-4">
              <KV k="Total deposited" v={M(totalDeposited)} />
              <KV k="Portfolio value" v={M(portfolioValue)} />
              <KV k="Net gain on money at work" v={M(portfolioValue - totalDeposited)} tone={toneOf(portfolioValue - totalDeposited)} />
              <KV k="Period" v={`${dateShort(dates[0])} → ${dateShort(END)}`} />
            </div>
          </div>
        </Panel>

        <Panel className="lg:col-span-7" delay={60}>
          <Head
            kicker="Cash account"
            title="Balance and flows"
            sub="Deposits in, executions out, distributions and interest back in."
            right={<Pill tone="azure">{money(CASH.prices[N - 1])} now</Pill>}
          />
          <div className="px-5 pb-5">
            <TimeChart
              height={196}
              dates={dates}
              yFmt={(n) => compact(n, "USD")}
              series={[{ key: "cash", data: CASH.prices, color: "#7db8ff", fill: true, width: 1.7, smooth: true }]}
              events={DEPOSITS.map((d) => ({ i: Math.max(1, N - 1 - d.ago), label: d.note, tone: "#7db8ff" }))}
              tip={(i) => (
                <div className="space-y-1">
                  <div className="num text-[12px] text-paper">{M(CASH.prices[i])}</div>
                  <div className="num text-[10px] text-fog">available to deploy</div>
                </div>
              )}
            />
            <Rule className="my-4" />
            <div className="grid grid-cols-4 gap-4">
              {[
                { l: "Distributions", v: M(incomeReceived), s: `${ledger.filter((r) => r.type === "Dividend").length} payments` },
                { l: "Interest earned", v: M(cashInterestEarned), s: "money market" },
                { l: "Fees & costs", v: M(feesPaid), s: "commissions" },
                { l: "Executions", v: `${buySell.length}`, s: `${ledger.filter((r) => r.type === "Buy").length} buys · ${ledger.filter((r) => r.type === "Sell").length} sells` },
              ].map((x) => (
                <div key={x.l}>
                  <div className="label mb-1">{x.l}</div>
                  <div className="num text-[16px] text-paper">{x.v}</div>
                  <div className="num text-[9.5px] text-fog">{x.s}</div>
                </div>
              ))}
            </div>
          </div>
        </Panel>
      </div>

      {/* ══════ dividends + executions ══════ */}
      <div className="grid gap-5 lg:grid-cols-12">
        <Panel className="lg:col-span-5" delay={100}>
          <Head kicker="Income" title="Distributions by month" right={<Pill tone="ember">{money(incomeReceived)} total</Pill>} />
          <div className="px-5 pb-5">
            <div className="flex items-end gap-[5px]" style={{ height: 130 }}>
              {divArr.map(([k, v]: [string, number], i: number) => (
                <div key={k} className="group relative flex-1">
                  <div
                    className="w-full rounded-t-[3px] transition-all duration-500"
                    style={{
                      height: `${(v / maxDiv) * 104}px`,
                      background: `linear-gradient(180deg,${EMBER},${EMBER}55)`,
                      boxShadow: "inset 0 1px 0 rgba(255,255,255,.15)",
                      animation: `rise .6s ${i * 60}ms cubic-bezier(.22,1,.36,1) both`,
                    }}
                  />
                  <div className="num mt-1.5 -rotate-45 text-[8px] text-fog/70">{k.split(" ")[0]}</div>
                  <div className="num pointer-events-none absolute -top-6 left-1/2 -translate-x-1/2 whitespace-nowrap rounded border border-white/10 bg-[#080c12] px-1.5 py-[2px] text-[9.5px] opacity-0 transition-opacity group-hover:opacity-100">
                    {money(v)}
                  </div>
                </div>
              ))}
            </div>
            <Rule className="my-4" />
            <div className="space-y-1.5">
              {Object.entries(
                ledger
                  .filter((r) => r.type === "Dividend")
                  .reduce<Record<string, number>>((a, r) => {
                    a[r.ticker] = (a[r.ticker] || 0) + r.usd;
                    return a;
                  }, {}),
              )
                .sort((a, b) => b[1] - a[1])
                .slice(0, 6)
                .map(([t, v]) => (
                  <button key={t} onClick={() => go("holding", t)} className="group flex w-full items-center gap-2.5">
                    <span className="num w-11 text-left text-[10.5px] text-mist group-hover:text-paper">{t}</span>
                    <div className="h-[6px] flex-1 overflow-hidden rounded-full bg-white/[0.05]">
                      <div className="h-full rounded-full" style={{ width: `${(v / incomeReceived) * 100 * 3}%`, background: EMBER }} />
                    </div>
                    <span className="num w-[62px] text-right text-[10.5px] text-paper">{money(v)}</span>
                  </button>
                ))}
            </div>
          </div>
        </Panel>

        <Panel className="lg:col-span-7" delay={140}>
          <Head kicker="Execution" title="Size of each trade" sub="Biggest bar is the biggest decision. A pattern of large bars after a fall is averaging down." />
          <div className="px-5 pb-5">
            <div ref={bref} className="relative w-full" style={{ height: 150 }}>
              {bw > 40 && (
                <svg width={bw} height={150}>
                  <line x1="0" x2={bw} y1="18" y2="18" stroke="#fff" strokeOpacity="0.08" />
                  {buySell.map((r, i) => {
                    const x = (i / (buySell.length - 1)) * (bw - 14) + 7;
                    const h = (r.usd / maxBs) * 104;
                    const c = r.type === "Buy" ? MINT : ROSE;
                    return (
                      <g key={i}>
                        <rect x={x - 5} y={18 - 0 + 0} width="10" height="0" fill="none" />
                        <rect
                          x={x - 5}
                          y={r.type === "Buy" ? 20 : 20}
                          width="10"
                          height={h}
                          rx="1.5"
                          fill={c}
                          fillOpacity="0.75"
                          style={{ animation: `rise .6s ${i * 45}ms cubic-bezier(.22,1,.36,1) both` }}
                        />
                        <text x={x} y={r.type === "Buy" ? 20 + h + 10 : 14} textAnchor="middle" fill="#5c6a80" fontSize="7.5" fontFamily="IBM Plex Mono, monospace">
                          {r.ticker}
                        </text>
                      </g>
                    );
                  })}
                  <text x="0" y="150" fill="#5c6a80" fontSize="8" fontFamily="IBM Plex Mono, monospace">
                    oldest
                  </text>
                  <text x={bw} y="150" textAnchor="end" fill="#5c6a80" fontSize="8" fontFamily="IBM Plex Mono, monospace">
                    most recent
                  </text>
                </svg>
              )}
            </div>
            <Rule className="my-3" />
            <div className="grid grid-cols-3 gap-4">
              {[
                { l: "Largest buy", v: M(Math.max(...ledger.filter((r) => r.type === "Buy").map((r) => r.usd))), s: "single execution" },
                { l: "Average ticket", v: M(buySell.reduce((a, r) => a + r.usd, 0) / buySell.length), s: `${buySell.length} trades` },
                { l: "Turnover", v: `${((buySell.reduce((a, r) => a + r.usd, 0) / portfolioValue) * 100).toFixed(0)}%`, s: "of book, all time" },
              ].map((x) => (
                <div key={x.l}>
                  <div className="label mb-1">{x.l}</div>
                  <div className="num text-[16px] text-paper">{x.v}</div>
                  <div className="num text-[9.5px] text-fog">{x.s}</div>
                </div>
              ))}
            </div>
          </div>
        </Panel>
      </div>

      {/* ══════ ledger ══════ */}
      <Panel delay={180}>
        <Head
          kicker={`${dateLong(END)}`}
          title="Ledger"
          sub="Every movement of money through the account, newest first."
          right={
            <Seg
              items={[
                { k: "all" as const, label: "Everything" },
                { k: "trades" as const, label: "Trades" },
                { k: "income" as const, label: "Income" },
                { k: "flows" as const, label: "Flows" },
              ]}
              value={filter}
              onChange={setFilter}
            />
          }
        />
        <div className="max-h-[520px] overflow-y-auto px-5 pb-5">
          {Object.entries(grouped).map(([month, items]) => (
            <div key={month} className="mb-2">
              <div className="sticky top-0 z-10 -mx-5 mb-1 bg-[#0b1017]/95 px-5 py-2 backdrop-blur">
                <div className="flex items-baseline justify-between">
                  <span className="font-mono text-[9.5px] uppercase tracking-[0.18em] text-mist">{month}</span>
                  <span className="num text-[9.5px] text-fog">
                    {items.length} movements ·{" "}
                    <span style={{ color: toneOf(items.reduce((a, r) => a + (r.type === "Deposit" || r.type === "Sell" || r.type === "Dividend" ? r.usd : -r.usd), 0)) }}>
                      {M(items.reduce((a, r) => a + (r.type === "Deposit" || r.type === "Sell" || r.type === "Dividend" ? r.usd : -r.usd), 0))}
                    </span>
                  </span>
                </div>
              </div>
              {items.map((r, i) => {
                const t = TYPE[r.type];
                const inflow = r.type === "Deposit" || r.type === "Sell" || r.type === "Dividend" || r.type === "Interest";
                return (
                  <button
                    key={i}
                    onClick={() => r.type !== "Deposit" && go("holding", r.ticker)}
                    className="group flex w-full items-center gap-3 border-b border-white/[0.04] py-2 text-left transition-colors last:border-0 hover:bg-white/[0.025]"
                  >
                    <span
                      className="num flex h-[22px] w-[22px] shrink-0 items-center justify-center rounded-[5px] text-[10px]"
                      style={{ color: t.c, background: `${t.c}14`, boxShadow: `inset 0 0 0 1px ${t.c}30` }}
                    >
                      {t.g}
                    </span>
                    <span className="num w-[58px] shrink-0 text-[10px] text-fog">{dateShort(r.date)}</span>
                    <span className="num w-[52px] shrink-0 text-[11px] text-mist group-hover:text-paper">{r.ticker}</span>
                    <span className="w-[68px] shrink-0 text-[11px]" style={{ color: t.c }}>
                      {r.type}
                    </span>
                    <span className="num hidden w-[104px] shrink-0 text-[10.5px] text-fog sm:block">
                      {r.qty ? `${r.qty} @ ${r.native.toFixed(r.native > 1000 ? 0 : 2)}` : r.note || "—"}
                    </span>
                    <span className="hidden flex-1 truncate text-[10.5px] text-fog/70 md:block">{r.note}</span>
                    <span className="num ml-auto shrink-0 text-[11.5px]" style={{ color: inflow ? MINT : ROSE }}>
                      {inflow ? "+" : "−"}
                      {M(r.usd)}
                    </span>
                  </button>
                );
              })}
            </div>
          ))}
        </div>
      </Panel>

      <div className="px-1 pb-2 font-mono text-[9px] uppercase tracking-[0.2em] text-fog/60">
        {ledger.length} movements recorded · time-weighted return on the performance page · cash never leaves the account untracked
      </div>
    </div>
  );
}
void Sparkline;
void linePath;
void cx;
void Pill;
