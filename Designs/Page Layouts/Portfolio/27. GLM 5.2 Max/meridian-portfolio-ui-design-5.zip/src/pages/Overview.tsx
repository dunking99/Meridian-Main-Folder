import React from "react";
import { Panel, Head, Delta, Pill, Seg, Rule, cx, useCountUp, EMBER, MINT, ROSE, toneOf } from "../components/ui";
import { TimeChart, Sparkline, Ribbon, Ring, DivergeList } from "../components/charts";
import {
  dates,
  END,
  CURRENCIES,
  DEPOSITS,
  dayIndexFromNow,
  FX,
} from "../data/market";
import {
  portfolioValue,
  dayChange,
  dayChangePct,
  valueHistory,
  benchHistory,
  totalDeposited,
  invested,
  totalPl,
  totalPlPct,
  cash,
  cashWeight,
  positions,
  byWeight,
  movers,
  assetExposure,
  sectorExposure,
  currencyExposure,
  top3,
  hhi,
  dividendRun,
  portfolioYield,
  feesPaid,
  dailyRets,
  useCur,
  useM,
  money,
  compact,
  dateLong,
  benchName,
} from "../lib/metrics";
import { JOURNAL, NEWS } from "../data/content";
import type { Cur } from "../lib/metrics";

const RANGES = [
  { k: "1M", d: 21 },
  { k: "3M", d: 63 },
  { k: "6M", d: 126 },
  { k: "1Y", d: 252 },
  { k: "ALL", d: 0 },
] as const;

export default function Overview({ go, cur, setCur }: { go: (p: string, t?: string) => void; cur: Cur; setCur: (c: Cur) => void }) {
  const [range, setRange] = React.useState<(typeof RANGES)[number]["k"]>("6M");
  const M = useM();
  const c = useCur();
  const shown = useCountUp(portfolioValue);
  const from = RANGES.find((r) => r.k === range)!.d;
  const i0 = from === 0 ? 0 : dates.length - 1 - from;
  const ds = dates.slice(i0);
  const vs = valueHistory.slice(i0);
  const bs = benchHistory.slice(i0);
  const chg = vs[vs.length - 1] / vs[0] - 1;
  const bchg = bs[bs.length - 1] / bs[0] - 1;

  const events = DEPOSITS.map((d) => ({ i: Math.max(0, dayIndexFromNow(d.ago) - i0), label: "Deposit", tone: EMBER })).filter((e) => e.i > 0);

  const tape = dailyRets.slice(-32);
  const tapeMax = Math.max(...tape.map(Math.abs));

  const assetItems = assetExposure.map((a) => ({ key: a.key, value: a.value, color: a.color }));
  const sectorItems = sectorExposure.map((a) => ({ key: a.key, value: a.value, color: a.color }));
  const [ringHov, setRingHov] = React.useState<string | null>(null);

  const nonUsd = 100 - (currencyExposure.find((x) => x.key === "USD")?.weight ?? 100);

  const signals = [
    {
      tone: ROSE,
      tag: "Sizing",
      title: "NVIDIA has outgrown its 10% cap",
      body: `12.4% of the book against a self-imposed limit. The trim you wrote down in your journal is 6 days overdue.`,
      metric: "+2.4pt over",
      cta: "Open thesis",
      to: () => go("holding", "NVDA"),
    },
    {
      tone: EMBER,
      tag: "Cluster",
      title: "One island, three positions",
      body: `NVDA, TSM and ASML are separate line items but a single exposure — 23% of book sits behind the same geopolitical risk.`,
      metric: "23% linked",
      cta: "See exposure",
      to: () => go("analysis"),
    },
    {
      tone: "#7db8ff",
      tag: "Currency",
      title: "Six in ten dollars are really something else",
      body: `${nonUsd.toFixed(0)}% of the book is non-USD and unhedged. A 5% rally in the dollar costs roughly ${((nonUsd / 100) * 5).toFixed(1)}% of total value.`,
      metric: `${nonUsd.toFixed(0)}% unhedged`,
      cta: "Breakdown",
      to: () => go("analysis"),
    },
    {
      tone: MINT,
      tag: "Income",
      title: "Income is covering your costs 6× over",
      body: `${money(dividendRun)} of running yield against ${money(feesPaid + 380)} of annual fees. The book pays for itself.`,
      metric: `${portfolioYield.toFixed(2)}% yield`,
      cta: "Activity",
      to: () => go("activity"),
    },
  ];

  const reviews = JOURNAL.filter((j) => j.reviewIn <= 14 && j.status !== "closed");

  return (
    <div className="space-y-5">
      {/* ══════════ HERO ══════════ */}
      <Panel className="overflow-hidden" delay={0}>
        <div className="grid gap-0 lg:grid-cols-[minmax(320px,400px)_1fr]">
          <div className="relative border-b border-white/[0.06] p-6 lg:border-b-0 lg:border-r">
            <div className="mb-4 flex items-center justify-between">
              <span className="label">Total portfolio value</span>
              <Seg
                size="xs"
                items={CURRENCIES.map((x) => ({ k: x.code as Cur, label: x.symbol }))}
                value={cur}
                onChange={setCur}
              />
            </div>
            <div className="flex items-end gap-3">
              <div
                className="display num bg-clip-text text-[52px] leading-[0.9] tracking-tight text-transparent"
                style={{ backgroundImage: "linear-gradient(178deg,#ffffff 8%,#cfe0f2 62%,#8fa6c2 100%)" }}
              >
                {money(shown, c, 0)}
              </div>
            </div>
            <div className="mt-3 flex flex-wrap items-center gap-2.5">
              <Delta v={dayChange} pctv={dayChangePct * 100} size="md" abs={M(dayChange)} />
              <span className="text-[11px] text-fog">today</span>
              <span className="h-3 w-px bg-white/10" />
              <span className="num text-[11.5px]" style={{ color: toneOf(chg * 100 - bchg * 100) }}>
                {range} {chg >= 0 ? "+" : ""}
                {(chg * 100).toFixed(2)}% vs {bchg >= 0 ? "+" : ""}
                {(bchg * 100).toFixed(2)}% world
              </span>
            </div>

            <div className="mt-7 grid grid-cols-2 gap-y-5">
              {[
                { l: "Capital invested", v: M(invested), s: `${money(totalDeposited)} deposited` },
                { l: "Unrealised P/L", v: M(totalPl), s: `${totalPl >= 0 ? "+" : ""}${totalPlPct.toFixed(1)}% on cost`, tone: toneOf(totalPl) },
                { l: "Cash & equivalents", v: M(cash), s: `${cashWeight.toFixed(1)}% of book` },
                { l: "Running yield", v: `${portfolioYield.toFixed(2)}%`, s: `${money(dividendRun)} a year` },
              ].map((x, i) => (
                <div key={i} className="relative pl-4">
                  <span className="absolute left-0 top-[3px] h-[26px] w-[2px] rounded-full" style={{ background: i === 0 ? "#ffffff22" : i === 1 ? toneOf(totalPl) : i === 2 ? "#7db8ff" : MINT, opacity: 0.8 }} />
                  <div className="label mb-1">{x.l}</div>
                  <div className="num text-[16px] font-medium" style={{ color: x.tone || "#eaf0f8" }}>
                    {x.v}
                  </div>
                  <div className="num mt-0.5 text-[10px] text-fog">{x.s}</div>
                </div>
              ))}
            </div>

            <div className="mt-6 flex items-center gap-2 border-t border-white/[0.06] pt-4">
              <i className="h-1.5 w-1.5 animate-pulse rounded-full" style={{ background: MINT }} />
              <span className="font-mono text-[9.5px] uppercase tracking-[0.16em] text-fog">
                Valued {dateLong(END)} · all figures {c}
              </span>
            </div>
          </div>

          {/* chart */}
          <div className="relative p-5 pl-6">
            <div className="mb-1 flex items-start justify-between">
              <div>
                <div className="label mb-1.5">Value over time</div>
                <div className="flex items-center gap-3">
                  <span className="num text-[19px] font-medium text-paper">{M(vs[vs.length - 1])}</span>
                  <Delta v={(vs[vs.length - 1] - vs[0]) / 100} pctv={chg * 100} size="sm" />
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="hidden items-center gap-3 sm:flex">
                  <span className="flex items-center gap-1.5 font-mono text-[9px] uppercase tracking-[0.14em] text-fog">
                    <i className="h-[3px] w-4 rounded-full bg-mint" />
                    Portfolio
                  </span>
                  <span className="flex items-center gap-1.5 font-mono text-[9px] uppercase tracking-[0.14em] text-fog">
                    <i className="h-[3px] w-4 rounded-full bg-[#7c8aa3]" />
                    {benchName}
                  </span>
                </div>
                <Seg size="xs" items={RANGES.map((r) => ({ k: r.k, label: r.k }))} value={range} onChange={setRange} />
              </div>
            </div>

            <TimeChart
              height={196}
              dates={ds}
              yFmt={(n) => compact(n, c)}
              series={[
                { key: "port", data: vs, color: MINT, fill: true, width: 1.9, smooth: true },
                { key: "bench", data: bs, color: "#7c8aa3", dashed: true, width: 1.2, smooth: true },
              ]}
              events={events}
              tip={(i) => (
                <div className="space-y-1">
                  <div className="num text-[12px] text-paper">{M(vs[i])}</div>
                  <div className="num text-[10px] text-fog">world {M(vs[0] * (bs[i] / bs[0]))}</div>
                </div>
              )}
            />

            {/* session tape */}
            <div className="mt-4 border-t border-white/[0.06] pt-3">
              <div className="mb-2 flex items-center justify-between">
                <span className="label">Last 32 sessions</span>
                <span className="num text-[10px] text-fog">
                  {tape.filter((t) => t > 0).length} up · {tape.filter((t) => t <= 0).length} down
                </span>
              </div>
              <div className="flex items-end gap-[3px]">
                {tape.map((t, i) => {
                  const k = Math.abs(t) / tapeMax;
                  const up = t >= 0;
                  const idx = dates.length - 32 + i;
                  return (
                    <div key={i} className="group relative flex-1" title={`${dates[idx].toLocaleDateString("en-GB", { day: "2-digit", month: "short", timeZone: "UTC" })} · ${(t * 100).toFixed(2)}%`}>
                      <div
                        className="w-full rounded-[1px] transition-all duration-300 group-hover:opacity-100"
                        style={{
                          height: 4 + k * 26,
                          background: up ? MINT : ROSE,
                          opacity: 0.34 + k * 0.6,
                        }}
                      />
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </Panel>

      {/* ══════════ ROW 2 ══════════ */}
      <div className="grid gap-5 lg:grid-cols-12">
        <Panel className="lg:col-span-4" delay={60}>
          <Head kicker="Allocation at a glance" title="Composition" right={<Pill tone="neutral">{positions.length} positions</Pill>} />
          <div className="flex items-center gap-3 px-5">
            <Ring
              size={168}
              thickness={14}
              items={assetItems}
              active={ringHov}
              onHover={setRingHov}
              center={
                <>
                  <div className="num text-[19px] font-medium text-paper">{assetExposure.length}</div>
                  <div className="label mt-0.5">asset types</div>
                </>
              }
            />
            <div className="min-w-0 flex-1 space-y-[7px]">
              {assetExposure.map((a) => (
                <div
                  key={a.key}
                  onMouseEnter={() => setRingHov(a.key)}
                  onMouseLeave={() => setRingHov(null)}
                  className={cx("cursor-default transition-opacity", ringHov && ringHov !== a.key && "opacity-40")}
                >
                  <div className="flex items-baseline justify-between gap-2">
                    <span className="flex items-center gap-1.5 truncate text-[11px] text-mist">
                      <i className="h-[7px] w-[7px] shrink-0 rounded-sm" style={{ background: a.color }} />
                      {a.key}
                    </span>
                    <span className="num text-[11px] text-paper">{a.weight.toFixed(1)}%</span>
                  </div>
                  <div className="mt-1 h-[2px] w-full overflow-hidden rounded-full bg-white/[0.05]">
                    <div className="h-full rounded-full" style={{ width: `${a.weight * 2.4}%`, background: a.color }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="mt-5 px-5 pb-5">
            <div className="mb-2 flex items-center justify-between">
              <span className="label">By sector</span>
              <span className="label">HHI {hhi.toFixed(0)}</span>
            </div>
            <Ribbon items={sectorItems} />
            <div className="mt-3 grid grid-cols-2 gap-x-4 gap-y-1">
              {sectorExposure.slice(0, 8).map((s) => (
                <div key={s.key} className="flex items-center justify-between gap-2 text-[10.5px]">
                  <span className="flex items-center gap-1.5 truncate text-fog">
                    <i className="h-[6px] w-[6px] shrink-0 rounded-full" style={{ background: s.color }} />
                    {s.key}
                  </span>
                  <span className="num text-mist">{s.weight.toFixed(1)}%</span>
                </div>
              ))}
            </div>
            <Rule className="my-3.5" />
            <div className="flex items-center justify-between">
              <span className="text-[11px] text-fog">Top three positions</span>
              <span className="num text-[12.5px]" style={{ color: top3 > 30 ? ROSE : MINT }}>
                {top3.toFixed(1)}%
              </span>
            </div>
          </div>
        </Panel>

        <Panel className="lg:col-span-4" delay={120}>
          <Head
            kicker="What moved"
            title="Today's contribution"
            right={<Delta v={dayChange} pctv={dayChangePct * 100} size="sm" />}
          />
          <div className="px-5 pb-5">
            <DivergeList
              fmt={(n) => M(n)}
              rows={movers.slice(0, 9).map((p) => ({
                label: `${p.flag} ${p.ticker}`,
                value: p.dayPl,
                spark: p.spark.slice(-22),
              }))}
            />
            <Rule className="my-4" />
            <div className="grid grid-cols-2 gap-4">
              <div>
                <div className="label mb-1">Best</div>
                <button onClick={() => go("holding", movers[0].ticker)} className="group text-left">
                  <div className="num text-[16px] text-paper group-hover:underline">
                    {movers[0].ticker} <span className="text-[11px] text-fog">{M(movers[0].dayPl)}</span>
                  </div>
                </button>
              </div>
              <div className="text-right">
                <div className="label mb-1">Worst</div>
                <button onClick={() => go("holding", movers[movers.length - 1].ticker)} className="group text-right">
                  <div className="num text-[16px] text-paper group-hover:underline">
                    {movers[movers.length - 1].ticker}{" "}
                    <span className="text-[11px] text-fog">{M(movers[movers.length - 1].dayPl)}</span>
                  </div>
                </button>
              </div>
            </div>
          </div>
        </Panel>

        <Panel className="lg:col-span-4" delay={180}>
          <Head kicker="Top holdings" title="Where the money is" right={<Pill tone="ember">{byWeight[0].ticker} leads</Pill>} />
          <div className="px-5 pb-4">
            {byWeight.slice(0, 6).map((p, i) => (
              <button
                key={p.ticker}
                onClick={() => go("holding", p.ticker)}
                className="group flex w-full items-center gap-3 border-b border-white/[0.045] py-2.5 text-left last:border-0"
              >
                <span className="num w-3 text-[10px] text-fog/60">{i + 1}</span>
                <i className="h-7 w-[3px] shrink-0 rounded-full" style={{ background: p.color, boxShadow: `0 0 10px ${p.color}66` }} />
                <div className="min-w-0 flex-1">
                  <div className="flex items-baseline justify-between gap-2">
                    <span className="truncate text-[12.5px] text-mist group-hover:text-paper">{p.name}</span>
                    <span className="num text-[11.5px] text-paper">{p.weight.toFixed(1)}%</span>
                  </div>
                  <div className="mt-1 flex items-center gap-2">
                    <div className="h-[2.5px] flex-1 overflow-hidden rounded-full bg-white/[0.05]">
                      <div className="h-full rounded-full" style={{ width: `${p.weight * 3.6}%`, background: p.color }} />
                    </div>
                    <span className="num w-[52px] text-right text-[10.5px]" style={{ color: toneOf(p.plPct) }}>
                      {p.plPct >= 0 ? "+" : ""}
                      {p.plPct.toFixed(1)}%
                    </span>
                  </div>
                </div>
                <Sparkline data={p.spark} w={54} h={22} color={toneOf(p.plPct)} />
              </button>
            ))}
          </div>
          <div className="px-5 pb-5">
            <button
              onClick={() => go("holdings")}
              className="w-full rounded-lg border border-white/[0.07] bg-white/[0.02] py-2 font-mono text-[9.5px] uppercase tracking-[0.18em] text-fog transition-all hover:border-white/20 hover:text-paper"
            >
              All {positions.length} positions →
            </button>
          </div>
        </Panel>
      </div>

      {/* ══════════ ROW 3 · signals + cash ══════════ */}
      <div className="grid gap-5 lg:grid-cols-12">
        <Panel className="lg:col-span-8" delay={220}>
          <Head
            kicker="Cross-reference"
            title="Things this portfolio is telling you"
            sub="Generated from your positions, rules and journal — not market commentary."
            right={<Pill tone="violet" dot>{signals.length} active</Pill>}
          />
          <div className="grid gap-3 px-5 pb-5 sm:grid-cols-2">
            {signals.map((s, i) => (
              <button
                key={i}
                onClick={s.to}
                className="group relative overflow-hidden rounded-xl border border-white/[0.06] bg-white/[0.012] p-4 text-left transition-all duration-300 hover:border-white/[0.16] hover:bg-white/[0.03]"
                style={{ animation: `rise .6s ${280 + i * 70}ms cubic-bezier(.22,1,.36,1) both` }}
              >
                <span className="absolute left-0 top-0 h-full w-[2.5px]" style={{ background: s.tone, boxShadow: `0 0 14px ${s.tone}` }} />
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="label mb-2" style={{ color: s.tone }}>
                      {s.tag}
                    </div>
                    <div className="text-[13px] font-medium leading-snug text-paper">{s.title}</div>
                    <p className="mt-1.5 text-[11px] leading-relaxed text-fog">{s.body}</p>
                  </div>
                  <div className="num shrink-0 text-right text-[12.5px]" style={{ color: s.tone }}>
                    {s.metric}
                  </div>
                </div>
                <div className="mt-3 flex items-center gap-1.5 font-mono text-[9px] uppercase tracking-[0.16em] text-fog transition-colors group-hover:text-paper">
                  {s.cta}
                  <span className="transition-transform duration-300 group-hover:translate-x-1">→</span>
                </div>
              </button>
            ))}
          </div>
        </Panel>

        <Panel className="lg:col-span-4" delay={280}>
          <Head kicker="Dry powder" title="Cash position" right={<Pill tone="azure">{cashWeight.toFixed(1)}%</Pill>} />
          <div className="px-5 pb-5">
            <div className="relative mb-5">
              <div className="relative h-[46px] overflow-hidden rounded-lg border border-white/[0.06] bg-black/40">
                <div className="absolute inset-y-0" style={{ left: "40%", width: "24%", background: "linear-gradient(180deg,rgba(125,184,255,.22),rgba(125,184,255,.08))", borderLeft: "1px solid rgba(125,184,255,.5)", borderRight: "1px solid rgba(125,184,255,.5)" }} />
                <div className="absolute inset-y-0 left-0 rounded-l-lg" style={{ width: `${Math.min(100, cashWeight * 6)}%`, background: "linear-gradient(90deg,rgba(125,184,255,.15),rgba(125,184,255,.75))" }} />
                <div className="absolute inset-y-0 w-[2px] bg-paper shadow-[0_0_12px_rgba(234,240,248,.9)]" style={{ left: `${Math.min(99, cashWeight * 6)}%` }} />
                {[0, 25, 50, 75].map((t) => (
                  <div key={t} className="absolute inset-y-0 w-px bg-white/[0.05]" style={{ left: `${t}%` }} />
                ))}
              </div>
              <div className="mt-1.5 flex justify-between">
                {["0%", "5%", "10%", "15%"].map((l) => (
                  <span key={l} className="num text-[9px] text-fog/70">
                    {l}
                  </span>
                ))}
              </div>
              <div className="mt-2 text-center font-mono text-[9px] uppercase tracking-[0.14em] text-azure/70">target band 5–8%</div>
            </div>
            <div className="space-y-0">
              {[
                { k: "Absolute cash", v: M(cash) },
                { k: "Months of contributions it holds", v: "2.4" },
                { k: "Largest position it could absorb", v: M(cash / 1) },
                { k: "Theses awaiting review", v: `${reviews.length}`, tone: reviews.length > 1 ? ROSE : undefined },
                { k: "Next review due", v: reviews.length ? `${Math.max(0, reviews[0].reviewIn)} days` : "—" },
              ].map((r) => (
                <div key={r.k} className="flex items-baseline justify-between border-b border-white/[0.045] py-2 last:border-0">
                  <span className="text-[11px] text-fog">{r.k}</span>
                  <span className="num text-[12px]" style={{ color: r.tone || "#dfe6f1" }}>
                    {r.v}
                  </span>
                </div>
              ))}
            </div>
            <div className="mt-4 rounded-lg border border-white/[0.06] bg-black/25 p-3">
              <div className="label mb-1.5">Latest note</div>
              <p className="text-[11px] leading-relaxed text-mist">
                “{JOURNAL[0].title}” — <span className="text-fog">{JOURNAL[0].tickers.join(", ")}</span>
              </p>
              <button onClick={() => go("journal")} className="mt-2 font-mono text-[9px] uppercase tracking-[0.16em] text-fog hover:text-paper">
                Open journal →
              </button>
            </div>
          </div>
        </Panel>
      </div>

      {/* ══════════ ROW 4 · news ══════════ */}
      <Panel delay={320}>
        <Head
          kicker="Enrichment"
          title="Headlines touching your book"
          sub="Only stories that reference a position you own."
          right={
            <button onClick={() => go("news")} className="font-mono text-[9px] uppercase tracking-[0.16em] text-fog hover:text-paper">
              All news →
            </button>
          }
        />
        <div className="grid gap-0 border-t border-white/[0.05] sm:grid-cols-2 lg:grid-cols-3">
          {NEWS.slice(0, 6).map((n, i) => (
            <button
              key={i}
              onClick={() => go("holding", n.tickers[0])}
              className="group border-b border-r border-white/[0.045] p-4 text-left transition-colors hover:bg-white/[0.025] sm:[&:nth-child(2n)]:border-r-0 lg:[&:nth-child(2n)]:border-r lg:[&:nth-child(3n)]:border-r-0"
            >
              <div className="mb-2 flex items-center gap-2">
                <span className="num text-[9.5px] text-fog">{n.source}</span>
                <span className="h-1 w-1 rounded-full bg-white/20" />
                <span className="num text-[9.5px] text-fog">{n.ago < 1 ? `${Math.round(n.ago * 24)}h` : `${n.ago.toFixed(0)}d`} ago</span>
                <span className="ml-auto h-1.5 w-1.5 rounded-full" style={{ background: n.sentiment === "pos" ? MINT : n.sentiment === "neg" ? ROSE : "#7c8aa3" }} />
              </div>
              <div className="text-[12px] leading-snug text-mist transition-colors group-hover:text-paper">{n.headline}</div>
              <div className="mt-2.5 flex flex-wrap gap-1.5">
                {n.tickers.map((t) => (
                  <span key={t} className="num rounded border border-white/[0.08] px-1.5 py-[1px] text-[9.5px] text-fog">
                    {t}
                  </span>
                ))}
              </div>
            </button>
          ))}
        </div>
      </Panel>

      <div className="flex items-center justify-between px-1 pb-2">
        <span className="font-mono text-[9px] uppercase tracking-[0.2em] text-fog/60">
          Meridian · private desk · figures in {c} · {Object.keys(FX).length} currencies held
        </span>
        <span className="font-mono text-[9px] uppercase tracking-[0.2em] text-fog/60">End of day 13 Feb 2026</span>
      </div>
    </div>
  );
}
