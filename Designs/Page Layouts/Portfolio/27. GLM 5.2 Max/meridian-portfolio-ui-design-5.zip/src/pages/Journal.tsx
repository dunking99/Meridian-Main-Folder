import React from "react";
import { Panel, Head, Pill, Seg, Rule, cx, MINT, ROSE, EMBER } from "../components/ui";
import { plColor } from "../components/objects";
import { useSize } from "../components/charts";
import { JOURNAL } from "../data/content";
import { dates, dayIndexFromNow } from "../data/market";
import { positions, type Pos } from "../lib/metrics";

const dateShortFromAgo = (ago: number) => {
  const d = dates[dayIndexFromNow(ago)];
  return `${d.toLocaleDateString("en-GB", { day: "2-digit", timeZone: "UTC" })} ${d.toLocaleDateString("en-GB", { month: "short", timeZone: "UTC" })}`;
};

export default function Journal({ go }: { go: (p: string, t?: string) => void }) {
  const [status, setStatus] = React.useState<"all" | "on-track" | "challenged" | "closed">("all");
  const [open, setOpen] = React.useState<string | null>(JOURNAL[0].id);
  const [extra, setExtra] = React.useState<typeof JOURNAL>([]);
  const [draft, setDraft] = React.useState("");
  const [tref, tw] = useSize<HTMLDivElement>();

  const all = [...extra, ...JOURNAL];
  const list = all.filter((e) => status === "all" || e.status === status);
  const counts = {
    on: all.filter((e) => e.status === "on-track").length,
    ch: all.filter((e) => e.status === "challenged").length,
    cl: all.filter((e) => e.status === "closed").length,
  };
  const overdue = all.filter((e) => e.reviewIn <= 7 && e.status !== "closed");

  /* conviction vs outcome */
  const pts = all
    .filter((e) => e.status !== "closed" && e.tickers[0])
    .map((e) => {
      const p = positions.find((x) => x.ticker === e.tickers[0]) as Pos | undefined;
      return { e, p, x: e.conviction, y: p ? p.plPct : 0 };
    });
  const ymax = Math.max(20, ...pts.map((p) => p.y));
  const ymin = Math.min(-20, ...pts.map((p) => p.y));

  return (
    <div className="space-y-5">
      <div className="grid gap-5 lg:grid-cols-12">
        <Panel className="lg:col-span-8" delay={0}>
          <Head
            kicker="Decision record"
            title="Journal"
            sub="Every position should be able to answer the question: why do I own this? Notes are linked to the holdings they discuss."
            right={
              <div className="flex items-center gap-2">
                <Seg
                  items={[
                    { k: "all" as const, label: `All ${all.length}` },
                    { k: "on-track" as const, label: `On ${counts.on}` },
                    { k: "challenged" as const, label: `Challenged ${counts.ch}` },
                    { k: "closed" as const, label: `Closed ${counts.cl}` },
                  ]}
                  value={status}
                  onChange={setStatus}
                />
              </div>
            }
          />
          <div className="space-y-3 px-5 pb-5">
            {list.map((e, i) => {
              const isOpen = open === e.id;
              return (
                <div
                  key={e.id}
                  className={cx(
                    "overflow-hidden rounded-xl border transition-all duration-300",
                    isOpen ? "border-white/[0.14] bg-white/[0.028]" : "border-white/[0.06] bg-white/[0.012] hover:border-white/[0.12]",
                  )}
                  style={{ animation: `rise .55s ${i * 55}ms cubic-bezier(.22,1,.36,1) both` }}
                >
                  <button onClick={() => setOpen(isOpen ? null : e.id)} className="flex w-full items-start gap-3.5 p-4 text-left">
                    <div className="flex w-[54px] shrink-0 flex-col items-start">
                      <span className="num text-[13px] text-paper">{dateShortFromAgo(e.ago).split(" ")[0]}</span>
                      <span className="num text-[9px] uppercase text-fog">{dateShortFromAgo(e.ago).split(" ")[1]}</span>
                    </div>
                    <span
                      className="mt-[3px] h-[38px] w-[2.5px] shrink-0 rounded-full"
                      style={{ background: e.status === "on-track" ? MINT : e.status === "challenged" ? EMBER : "#7c8aa3" }}
                    />
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-[13.5px] font-medium leading-snug text-paper">{e.title}</span>
                      </div>
                      <div className="mt-2 flex flex-wrap items-center gap-2">
                        {e.tickers.map((t) => (
                          <button
                            key={t}
                            onClick={(ev) => {
                              ev.stopPropagation();
                              go("holding", t);
                            }}
                            className="num rounded border border-white/[0.09] px-1.5 py-[1px] text-[9.5px] text-mist transition-colors hover:border-white/30 hover:text-paper"
                          >
                            {t}
                          </button>
                        ))}
                        {e.tags.map((t) => (
                          <span key={t} className="font-mono text-[9px] uppercase tracking-[0.12em] text-fog/70">
                            #{t}
                          </span>
                        ))}
                        <span className="ml-auto flex items-center gap-1.5">
                          <span className="label">conviction</span>
                          <span className="flex gap-[2px]">
                            {[1, 2, 3, 4, 5].map((k) => (
                              <i key={k} className="h-[7px] w-[9px] rounded-[1px]" style={{ background: k <= e.conviction ? plColor(22, 30) : "rgba(255,255,255,.09)" }} />
                            ))}
                          </span>
                        </span>
                      </div>
                    </div>
                    <span
                      className="shrink-0 font-mono text-[8.5px] uppercase tracking-[0.14em]"
                      style={{ color: e.status === "on-track" ? MINT : e.status === "challenged" ? EMBER : "#7c8aa3" }}
                    >
                      {e.status.replace("-", " ")}
                    </span>
                  </button>
                  {isOpen && (
                    <div className="border-t border-white/[0.06] px-4 pb-4 pt-3.5">
                      <p className="max-w-[76ch] text-[12.5px] leading-[1.75] text-mist">{e.body}</p>
                      <div className="mt-3.5 flex flex-wrap items-center gap-3">
                        <span
                          className="num rounded-md px-2 py-[3px] text-[10px]"
                          style={{
                            color: e.reviewIn <= 7 && e.status !== "closed" ? ROSE : "#7c8aa3",
                            background: e.reviewIn <= 7 && e.status !== "closed" ? `${ROSE}14` : "rgba(255,255,255,.03)",
                          }}
                        >
                          {e.status === "closed" ? "archived" : e.reviewIn <= 0 ? "review overdue" : `review in ${e.reviewIn} days`}
                        </span>
                        <button onClick={() => go("holding", e.tickers[0])} className="font-mono text-[9px] uppercase tracking-[0.16em] text-fog hover:text-paper">
                          open {e.tickers[0]} →
                        </button>
                        <button onClick={() => go("performance")} className="font-mono text-[9px] uppercase tracking-[0.16em] text-fog hover:text-paper">
                          performance →
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </Panel>

        <div className="space-y-5 lg:col-span-4">
          <Panel delay={60}>
            <Head kicker="Discipline" title="Review calendar" right={<Pill tone={overdue.length ? "rose" : "mint"}>{overdue.length} due</Pill>} />
            <div className="px-5 pb-5">
              {all
                .filter((e) => e.status !== "closed")
                .sort((a, b) => a.reviewIn - b.reviewIn)
                .map((e) => {
                  const w = Math.max(0, Math.min(100, 100 - (e.reviewIn / 150) * 100));
                  return (
                    <div key={e.id} className="mb-3 last:mb-0">
                      <div className="flex items-baseline justify-between gap-2">
                        <span className="truncate text-[11px] text-mist">{e.title}</span>
                        <span className="num shrink-0 text-[10px]" style={{ color: e.reviewIn <= 0 ? ROSE : e.reviewIn <= 14 ? EMBER : "#7c8aa3" }}>
                          {e.reviewIn <= 0 ? "overdue" : `${e.reviewIn}d`}
                        </span>
                      </div>
                      <div className="mt-1.5 h-[3px] w-full overflow-hidden rounded-full bg-white/[0.05]">
                        <div
                          className="h-full rounded-full"
                          style={{ width: `${w}%`, background: e.reviewIn <= 0 ? ROSE : e.reviewIn <= 14 ? EMBER : "#5ee3d0" }}
                        />
                      </div>
                    </div>
                  );
                })}
              <p className="mt-3 text-[11px] leading-relaxed text-fog">
                A thesis without a review date is an opinion you never have to defend. {overdue.length === 0 ? "Nothing overdue." : `${overdue.length} entr${overdue.length === 1 ? "y" : "ies"} past due.`}
              </p>
            </div>
          </Panel>

          <Panel delay={100}>
            <Head kicker="Honesty check" title="Conviction versus outcome" sub="High conviction should sit above the line. Below it, confidence was a substitute for evidence." />
            <div className="px-5 pb-5">
              <div ref={tref} className="relative w-full" style={{ height: 236 }}>
                {tw > 40 && (
                  <svg width={tw} height={236}>
                    {[0, 0.5, 1].map((f) => (
                      <line key={f} x1="28" x2={tw - 6} y1={200 - f * 168} y2={200 - f * 168} stroke="#fff" strokeOpacity="0.05" strokeDasharray="2 4" />
                    ))}
                    <line x1="28" x2={tw - 6} y1={200 - ((0 - ymin) / (ymax - ymin)) * 168} y2={200 - ((0 - ymin) / (ymax - ymin)) * 168} stroke="#fff" strokeOpacity="0.16" />
                    {pts.map((p, i) => {
                      const x = 34 + ((p.x - 0.5) / 4.5) * (tw - 48);
                      const y = 200 - ((p.y - ymin) / (ymax - ymin)) * 168;
                      const good = p.x >= 3 ? p.y > 0 : true;
                      return (
                        <g key={i} onClick={() => go("holding", p.e.tickers[0])} style={{ cursor: "pointer" }}>
                          <circle
                            cx={x}
                            cy={y}
                            r={11}
                            fill={p.y >= 0 ? MINT : ROSE}
                            fillOpacity={p.x >= 4 ? 0.22 : 0.1}
                            stroke={p.y >= 0 ? MINT : ROSE}
                            strokeWidth="1.2"
                            strokeDasharray={good ? undefined : "3 3"}
                          />
                          <text x={x} y={y + 3} textAnchor="middle" fill="#eaf0f8" fontSize="8" fontFamily="IBM Plex Mono, monospace">
                            {p.e.tickers[0]}
                          </text>
                        </g>
                      );
                    })}
                    <text x="28" y="216" fill="#5c6a80" fontSize="8" fontFamily="IBM Plex Mono, monospace">
                      LOW CONVICTION
                    </text>
                    <text x={tw - 6} y="216" textAnchor="end" fill="#5c6a80" fontSize="8" fontFamily="IBM Plex Mono, monospace">
                      HIGH
                    </text>
                    <text x="6" y={200 - ((ymax - ymin) * 0.98 + ymin - ymin) * 0} fill="#5c6a80" fontSize="8" fontFamily="IBM Plex Mono, monospace" />
                    <text x="4" y="14" fill="#5c6a80" fontSize="8" fontFamily="IBM Plex Mono, monospace">
                      +{ymax.toFixed(0)}%
                    </text>
                    <text x="4" y="200" fill="#5c6a80" fontSize="8" fontFamily="IBM Plex Mono, monospace">
                      {ymin.toFixed(0)}%
                    </text>
                    <text x="4" y={200 - ((0 - ymin) / (ymax - ymin)) * 168 - 4} fill="#8a96ad" fontSize="8" fontFamily="IBM Plex Mono, monospace">
                      break even
                    </text>
                  </svg>
                )}
              </div>
              <Rule className="my-3" />
              <div className="grid grid-cols-3 gap-3">
                {[
                  { l: "Entries", v: `${all.length}`, s: "all time" },
                  { l: "Avg conviction", v: (all.reduce((a, e) => a + e.conviction, 0) / all.length).toFixed(1), s: "of 5" },
                  { l: "Still open", v: `${counts.on + counts.ch}`, s: `${counts.cl} closed` },
                ].map((x) => (
                  <div key={x.l}>
                    <div className="label mb-1">{x.l}</div>
                    <div className="num text-[17px] text-paper">{x.v}</div>
                    <div className="num text-[9.5px] text-fog">{x.s}</div>
                  </div>
                ))}
              </div>
            </div>
          </Panel>

          <Panel delay={140}>
            <Head kicker="New entry" title="Write it down now" />
            <div className="px-5 pb-5">
              <textarea
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                rows={3}
                placeholder="What am I betting on, and what would prove me wrong?"
                className="w-full resize-none rounded-lg border border-white/[0.08] bg-black/35 p-3 text-[11.5px] leading-relaxed text-paper placeholder:text-fog/50 focus:border-white/25 focus:outline-none"
              />
              <button
                disabled={!draft.trim()}
                onClick={() => {
                  setExtra([
                    {
                      id: `n${Date.now()}`,
                      ago: 0,
                      title: draft.length > 58 ? `${draft.slice(0, 58)}…` : draft,
                      tickers: ["VWRD"],
                      conviction: 3,
                      status: "on-track",
                      tags: ["new"],
                      body: draft,
                      reviewIn: 90,
                    },
                    ...extra,
                  ]);
                  setDraft("");
                }}
                className="mt-2 w-full rounded-lg border border-white/[0.1] py-2 font-mono text-[9px] uppercase tracking-[0.18em] transition-colors disabled:opacity-35 enabled:hover:border-white/30 enabled:hover:text-paper"
                style={{ color: MINT }}
              >
                Save to journal
              </button>
              <p className="mt-2.5 text-[10.5px] leading-relaxed text-fog">
                Notes written at the moment of decision are worth ten written in hindsight. Saved entries appear at the top of the list.
              </p>
            </div>
          </Panel>
        </div>
      </div>

      <div className="px-1 pb-2 font-mono text-[9px] uppercase tracking-[0.2em] text-fog/60">
        journal entries are private · cross-linked to {positions.length} positions
      </div>
    </div>
  );
}
