import React from "react";
import { Panel, Head, Pill, Seg, cx, MINT, ROSE, EMBER } from "../components/ui";
import { Sparkline } from "../components/charts";
import { NEWS, WATCHLIST } from "../data/content";
import { positions, useM } from "../lib/metrics";
import { N } from "../data/market";

export default function News({ go }: { go: (p: string, t?: string) => void }) {
  const M = useM();
  const [f, setF] = React.useState<"all" | "pos" | "neg">("all");
  const [topic, setTopic] = React.useState<string>("All");
  const topics = ["All", ...Array.from(new Set(NEWS.map((n) => n.topic)))];
  const list = NEWS.filter((n) => (f === "all" ? true : f === "pos" ? n.sentiment === "pos" : n.sentiment === "neg")).filter((n) => topic === "All" || n.topic === topic);

  const impacted = positions
    .map((p) => ({
      p,
      stories: NEWS.filter((n) => n.tickers.includes(p.ticker)).length,
      sent: NEWS.filter((n) => n.tickers.includes(p.ticker)).reduce((a, n) => a + (n.sentiment === "pos" ? 1 : n.sentiment === "neg" ? -1 : 0), 0),
    }))
    .filter((x) => x.stories > 0)
    .sort((a, b) => b.stories - a.stories);

  return (
    <div className="space-y-5">
      <div className="grid gap-5 lg:grid-cols-12">
        <Panel className="lg:col-span-8" delay={0}>
          <Head
            kicker="Filtered to your book"
            title="News that touches a position"
            sub="Nothing here is general market noise. Each story is anchored to something you own."
            right={
              <Seg
                items={[
                  { k: "all" as const, label: "All" },
                  { k: "pos" as const, label: "Positive" },
                  { k: "neg" as const, label: "Negative" },
                ]}
                value={f}
                onChange={setF}
              />
            }
          />
          <div className="flex flex-wrap gap-1.5 px-5 pb-3">
            {topics.map((t) => (
              <button
                key={t}
                onClick={() => setTopic(t)}
                className={cx(
                  "rounded-full border px-2.5 py-[3px] font-mono text-[9px] uppercase tracking-[0.12em] transition-colors",
                  topic === t ? "border-white/25 bg-white/[0.07] text-paper" : "border-white/[0.07] text-fog hover:text-mist",
                )}
              >
                {t}
              </button>
            ))}
          </div>
          <div className="border-t border-white/[0.05]">
            {list.map((n, i) => (
              <button
                key={i}
                onClick={() => go("holding", n.tickers[0])}
                className="group flex w-full items-start gap-4 border-b border-white/[0.04] p-4 text-left transition-colors last:border-0 hover:bg-white/[0.025]"
                style={{ animation: `rise .5s ${i * 35}ms cubic-bezier(.22,1,.36,1) both` }}
              >
                <div className="w-[64px] shrink-0">
                  <div className="num text-[13px]" style={{ color: n.sentiment === "pos" ? MINT : n.sentiment === "neg" ? ROSE : "#7c8aa3" }}>
                    {n.ago < 1 ? `${Math.round(n.ago * 24)}h` : `${n.ago.toFixed(0)}d`}
                  </div>
                  <div className="num text-[9px] text-fog/60">ago</div>
                </div>
                <span
                  className="mt-[6px] h-[30px] w-[2.5px] shrink-0 rounded-full"
                  style={{ background: n.sentiment === "pos" ? MINT : n.sentiment === "neg" ? ROSE : "#7c8aa3" }}
                />
                <div className="min-w-0 flex-1">
                  <div className="mb-1.5 flex items-center gap-2">
                    <span className="num text-[9.5px] text-fog">{n.source}</span>
                    <span className="h-1 w-1 rounded-full bg-white/20" />
                    <span className="font-mono text-[8.5px] uppercase tracking-[0.14em] text-fog/70">{n.topic}</span>
                  </div>
                  <div className="text-[13px] leading-snug text-mist transition-colors group-hover:text-paper">{n.headline}</div>
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {n.tickers.map((t) => (
                      <span key={t} className="num rounded border border-white/[0.08] px-1.5 py-[1px] text-[9.5px] text-fog group-hover:border-white/20 group-hover:text-mist">
                        {t}
                      </span>
                    ))}
                  </div>
                </div>
              </button>
            ))}
          </div>
        </Panel>

        <div className="space-y-5 lg:col-span-4">
          <Panel delay={60}>
            <Head kicker="Sentiment map" title="Who the news is about" right={<Pill tone="violet">{impacted.length} tickers</Pill>} />
            <div className="px-5 pb-5">
              {impacted.map((x) => (
                <button key={x.p.ticker} onClick={() => go("holding", x.p.ticker)} className="group flex w-full items-center gap-3 border-b border-white/[0.04] py-2 text-left last:border-0">
                  <i className="h-6 w-[3px] shrink-0 rounded-full" style={{ background: x.p.color }} />
                  <span className="num w-[46px] text-[11.5px] text-mist group-hover:text-paper">{x.p.ticker}</span>
                  <div className="flex flex-1 gap-[3px]">
                    {Array.from({ length: Math.max(1, x.stories) }, (_, i) => (
                      <i key={i} className="h-[9px] flex-1 rounded-[1px]" style={{ background: x.sent >= 0 ? `${MINT}cc` : `${ROSE}cc` }} />
                    ))}
                  </div>
                  <span className="num text-[10px] text-fog">{x.stories}</span>
                  <Sparkline data={x.p.spark} w={46} h={16} color={x.p.plPct >= 0 ? MINT : ROSE} dot={false} sw={1} />
                </button>
              ))}
              <p className="mt-3 text-[10.5px] leading-relaxed text-fog">Bar length is story count, colour is the balance of tone. A red row next to a green sparkline is usually where the argument is.</p>
            </div>
          </Panel>

          <Panel delay={100}>
            <Head kicker="Not owned yet" title="Watchlist" right={<Pill tone="neutral">{WATCHLIST.length} names</Pill>} />
            <div className="px-5 pb-5">
              {WATCHLIST.map((w) => (
                <div key={w.ticker} className="flex items-center gap-3 border-b border-white/[0.04] py-2 last:border-0">
                  <span className="num w-[46px] text-[11.5px] text-mist">{w.ticker}</span>
                  <span className="flex-1 truncate text-[10.5px] text-fog">{w.note}</span>
                  <span className="num text-[10.5px] text-paper">{w.price.toFixed(w.price > 1000 ? 0 : 2)}</span>
                  <span className="num w-[48px] text-right text-[10.5px]" style={{ color: w.chg >= 0 ? MINT : ROSE }}>
                    {w.chg >= 0 ? "+" : ""}
                    {w.chg.toFixed(2)}%
                  </span>
                </div>
              ))}
              <div className="mt-3 rounded-lg border border-ember/20 bg-ember/[0.06] p-2.5">
                <p className="text-[10.5px] leading-relaxed text-mist">
                  Averaging into {M(positions.reduce((a, p) => a + p.value, 0) * 0.02)} a month would put the watchlist to work in about nine months without selling anything.
                </p>
              </div>
            </div>
          </Panel>

          <Panel delay={140}>
            <Head kicker="Diary" title="What is coming" />
            <div className="px-5 pb-5">
              {[
                { d: "18 Feb", t: "NVDA · results", note: "largest position, 12.4% of book" },
                { d: "26 Feb", t: "SHEL · capital markets day", note: "dividend policy review" },
                { d: "04 Mar", t: "LVMH · full year", note: "China commentary is the swing factor" },
                { d: "12 Mar", t: "ECB · rate decision", note: "affects IEAC and EUR exposure" },
                { d: "31 Mar", t: "Quarter-end review", note: "2 theses due, 1 overdue" },
              ].map((x) => (
                <div key={x.d} className="flex items-start gap-3 border-b border-white/[0.04] py-2 last:border-0">
                  <span className="num w-[42px] shrink-0 text-[10px] text-fog">{x.d}</span>
                  <div className="min-w-0">
                    <div className="text-[11.5px] text-mist">{x.t}</div>
                    <div className="text-[10px] text-fog">{x.note}</div>
                  </div>
                  <span className="ml-auto h-1.5 w-1.5 shrink-0 rounded-full" style={{ background: EMBER }} />
                </div>
              ))}
            </div>
          </Panel>
        </div>
      </div>

      <div className="px-1 pb-2 font-mono text-[9px] uppercase tracking-[0.2em] text-fog/60">
        {NEWS.length} stories · {positions.length} positions monitored · session {N} days · prices as of last close
      </div>
    </div>
  );
}
