import React from "react";
import { Panel, Head, Pill, Seg, cx, Rule, MINT, ROSE, toneOf, Dot } from "../components/ui";
import { Treemap, plColor } from "../components/objects";
import { Sparkline, DivergeList, Ribbon } from "../components/charts";
import { N, FX } from "../data/market";
import {
  positions,
  byWeight,
  portfolioValue,
  invested,
  totalPl,
  best,
  worst,
  useM,
  useCur,
  money,
  num,
  equity,
} from "../lib/metrics";
import type { Pos } from "../lib/metrics";

type SortKey = "value" | "weight" | "pl" | "plPct" | "dayPct" | "y1" | "m1";
type View = "map" | "table";
type Focus = "all" | "best" | "worst" | "winners" | "losers";

export default function Holdings({ go }: { go: (p: string, t?: string) => void }) {
  const M = useM();
  const c = useCur();
  const [view, setView] = React.useState<View>("map");
  const [sort, setSort] = React.useState<SortKey>("value");
  const [asc, setAsc] = React.useState(false);
  const [focus, setFocus] = React.useState<Focus>("all");
  const [q, setQ] = React.useState("");

  const filtered = React.useMemo(() => {
    let list = [...positions];
    if (q.trim()) {
      const s = q.toLowerCase();
      list = list.filter((p) => p.ticker.toLowerCase().includes(s) || p.name.toLowerCase().includes(s) || p.sector.toLowerCase().includes(s) || p.country.toLowerCase().includes(s));
    }
    const ranked = [...equity].sort((a, b) => b.plPct - a.plPct);
    if (focus === "best") list = list.filter((p) => ranked.slice(0, 3).includes(p));
    if (focus === "worst") list = list.filter((p) => ranked.slice(-3).includes(p));
    if (focus === "winners") list = list.filter((p) => p.pl > 0);
    if (focus === "losers") list = list.filter((p) => p.pl < 0);
    const val = (p: Pos) =>
      sort === "value" ? p.value : sort === "weight" ? p.weight : sort === "pl" ? p.pl : sort === "plPct" ? p.plPct : sort === "dayPct" ? p.dayPct * 100 : sort === "y1" ? p.rets.y1 * 100 : p.rets.m1 * 100;
    return list.sort((a, b) => (asc ? val(a) - val(b) : val(b) - val(a)));
  }, [q, focus, sort, asc]);

  const maxVal = Math.max(...positions.map((p) => p.value));
  const winners = equity.filter((p) => p.pl > 0);
  const losers = equity.filter((p) => p.pl < 0);
  const plAbs = [...equity].sort((a, b) => b.pl - a.pl);
  const median = [...equity].sort((a, b) => a.plPct - b.plPct)[Math.floor(equity.length / 2)];

  const bins = 9;
  const lo = -30;
  const hi = 80;
  const hist = Array.from({ length: bins }, (_, i) => {
    const a = lo + ((hi - lo) * i) / bins;
    const b = a + (hi - lo) / bins;
    return { a, b, n: equity.filter((p) => p.plPct >= a && (i === bins - 1 ? p.plPct <= b : p.plPct < b)).length };
  });
  const histMax = Math.max(...hist.map((h) => h.n));

  const th = (k: SortKey, label: string, className?: string) => (
    <button
      onClick={() => {
        if (sort === k) setAsc(!asc);
        else {
          setSort(k);
          setAsc(false);
        }
      }}
      className={cx("group flex items-center gap-1 whitespace-nowrap font-mono text-[9px] uppercase tracking-[0.13em] transition-colors", sort === k ? "text-paper" : "text-fog hover:text-mist", className)}
    >
      {label}
      <span className={cx("text-[7px] transition-opacity", sort === k ? "opacity-100" : "opacity-0 group-hover:opacity-40")}>{asc ? "▲" : "▼"}</span>
    </button>
  );

  return (
    <div className="space-y-5">
      {/* ══════ podium ══════ */}
      <div className="grid gap-5 lg:grid-cols-12">
        <Panel className="lg:col-span-7" delay={0}>
          <Head
            kicker="Ranked by money made"
            title="Where the P/L actually came from"
            sub="Percentage return flatters small positions. This is the amount, in your base currency."
            right={
              <span className="num text-[10.5px] text-fog">
                <span className="text-mint">+{M(winners.reduce((a, p) => a + p.pl, 0))}</span> / <span className="text-rose">{M(losers.reduce((a, p) => a + p.pl, 0))}</span>
              </span>
            }
          />
          <div className="px-5 pb-5">
            <DivergeList
              fmt={(n) => M(n)}
              rows={plAbs.map((p) => ({
                label: `${p.flag} ${p.ticker}`,
                value: p.pl,
                spark: p.spark.slice(-40),
              }))}
            />
          </div>
        </Panel>

        <Panel className="lg:col-span-5" delay={60}>
          <Head kicker="Shape of the book" title="Distribution of outcomes" right={<Pill tone="neutral">{equity.length} positions</Pill>} />
          <div className="px-5 pb-5">
            <div className="relative flex h-[132px] items-end gap-[3px]">
              {hist.map((h, i) => {
                const mid = (h.a + h.b) / 2;
                const inBin = median.plPct >= h.a && median.plPct < h.b;
                return (
                  <div key={i} className="group relative flex-1" title={`${h.n} positions between ${h.a.toFixed(0)}% and ${h.b.toFixed(0)}%`}>
                    <div
                      className="w-full rounded-t-[3px] transition-all duration-500"
                      style={{
                        height: `${Math.max(2, (h.n / histMax) * 118)}px`,
                        background: `linear-gradient(180deg,${plColor(mid, 60)},${plColor(mid, 60)}55)`,
                        boxShadow: inBin ? `0 0 0 1px #eaf0f899, 0 0 18px ${plColor(mid, 60)}` : "none",
                      }}
                    />
                    <div className="num mt-1.5 text-center text-[9px] text-fog/70">{h.n || ""}</div>
                  </div>
                );
              })}
            </div>
            <div className="mt-1 flex justify-between">
              <span className="num text-[9px] text-fog">−30%</span>
              <span className="num text-[9px] text-fog/70">median {median.plPct >= 0 ? "+" : ""}{median.plPct.toFixed(1)}%</span>
              <span className="num text-[9px] text-fog">+80%</span>
            </div>
            <Rule className="my-4" />
            <div className="grid grid-cols-3 gap-3">
              {[
                { l: "Winners", v: `${winners.length}`, s: M(winners.reduce((a, p) => a + p.value, 0)), tone: MINT },
                { l: "Losers", v: `${losers.length}`, s: M(losers.reduce((a, p) => a + p.value, 0)), tone: ROSE },
                { l: "Win rate by value", v: `${((winners.reduce((a, p) => a + p.value, 0) / equity.reduce((a, p) => a + p.value, 0)) * 100).toFixed(0)}%`, s: "of invested value", tone: "#eaf0f8" },
              ].map((x) => (
                <div key={x.l}>
                  <div className="label mb-1">{x.l}</div>
                  <div className="num text-[19px]" style={{ color: x.tone }}>
                    {x.v}
                  </div>
                  <div className="num mt-0.5 text-[9.5px] text-fog">{x.s}</div>
                </div>
              ))}
            </div>
            <Rule className="my-4" />
            <div className="space-y-2.5">
              {[best, worst].map((p, i) => (
                <button
                  key={p.ticker}
                  onClick={() => go("holding", p.ticker)}
                  className="group flex w-full items-center gap-3 rounded-lg border border-white/[0.06] bg-white/[0.012] p-2.5 text-left transition-all hover:border-white/[0.16]"
                >
                  <span className="num w-4 text-[9px] text-fog/60">{i === 0 ? "▲" : "▼"}</span>
                  <Dot c={p.color} />
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-[12px] text-mist group-hover:text-paper">{p.name}</div>
                    <div className="num text-[9.5px] text-fog">
                      {p.ticker} · {M(p.value)} · {p.weight.toFixed(1)}%
                    </div>
                  </div>
                  <Sparkline data={p.spark} w={62} h={24} color={i === 0 ? MINT : ROSE} />
                  <div className="num w-[68px] text-right text-[14px]" style={{ color: i === 0 ? MINT : ROSE }}>
                    {p.plPct >= 0 ? "+" : ""}
                    {p.plPct.toFixed(1)}%
                  </div>
                </button>
              ))}
            </div>
          </div>
        </Panel>
      </div>

      {/* ══════ explorer ══════ */}
      <Panel delay={120}>
        <div className="flex flex-wrap items-end justify-between gap-3 px-5 pt-4 pb-3.5">
          <div>
            <div className="label mb-1.5">Explorer</div>
            <h3 className="display text-[22px] text-paper">Every position</h3>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search name, ticker, sector…"
                className="w-[212px] rounded-lg border border-white/[0.08] bg-black/35 py-1.5 pl-7 pr-2 text-[11.5px] text-paper placeholder:text-fog/60 focus:border-white/25 focus:outline-none"
              />
              <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[11px] text-fog">⌕</span>
            </div>
            <Seg
              items={[
                { k: "all" as Focus, label: "All" },
                { k: "best" as Focus, label: "Best 3" },
                { k: "worst" as Focus, label: "Worst 3" },
                { k: "winners" as Focus, label: "Winners" },
                { k: "losers" as Focus, label: "Losers" },
              ]}
              value={focus}
              onChange={setFocus}
            />
            <Seg items={[{ k: "map" as View, label: "Map" }, { k: "table" as View, label: "Table" }]} value={view} onChange={setView} />
          </div>
        </div>

        {view === "map" ? (
          <div className="px-4 pb-5">
            <div className="mb-3 flex items-center justify-between px-1">
              <span className="label">Area = current value · colour = return since cost</span>
              <div className="flex items-center gap-2">
                <span className="num text-[9px] text-rose">−25%</span>
                <div className="h-[7px] w-[92px] rounded-full" style={{ background: "linear-gradient(90deg,#ff5c7a,#4a4f58,#3ee0a0)" }} />
                <span className="num text-[9px] text-mint">+25%</span>
              </div>
            </div>
            <Treemap
              height={430}
              scale={25}
              items={filtered.map((p) => ({ key: p.ticker, value: p.value, pl: p.plPct, label: p.ticker, sub: `${p.weight.toFixed(1)}%` }))}
              onSelect={(k) => go("holding", k)}
            />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[940px] border-collapse">
              <thead>
                <tr className="border-y border-white/[0.06] bg-black/25">
                  <th className="w-10 px-3 py-2 text-left" />
                  <th className="px-2 py-2 text-left">{th("value", "Position")}</th>
                  <th className="px-2 py-2 text-right">{th("dayPct", "Price")}</th>
                  <th className="px-2 py-2 text-right">Held</th>
                  <th className="px-2 py-2 text-right">{th("value", "Value")}</th>
                  <th className="w-[110px] px-2 py-2 text-left">{th("weight", "Weight")}</th>
                  <th className="px-2 py-2 text-right">{th("pl", "P/L")}</th>
                  <th className="px-2 py-2 text-right">{th("plPct", "Return")}</th>
                  <th className="px-2 py-2 text-right">{th("m1", "1M")}</th>
                  <th className="px-2 py-2 text-right">{th("y1", "1Y")}</th>
                  <th className="px-2 py-2 text-right">Vol</th>
                  <th className="px-3 py-2 text-right">Trend</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((p, i) => (
                  <tr
                    key={p.ticker}
                    onClick={() => go("holding", p.ticker)}
                    className="group cursor-pointer border-b border-white/[0.04] transition-colors hover:bg-white/[0.03]"
                    style={{ animation: `rise .5s ${i * 18}ms cubic-bezier(.22,1,.36,1) both` }}
                  >
                    <td className="px-3 py-2.5">
                      <span className="text-[13px]">{p.flag}</span>
                    </td>
                    <td className="px-2 py-2.5">
                      <div className="flex items-center gap-2.5">
                        <i className="h-8 w-[3px] shrink-0 rounded-full transition-all group-hover:w-[4px]" style={{ background: p.color, boxShadow: `0 0 12px ${p.color}55` }} />
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5">
                            <span className="num text-[11.5px] font-medium text-paper">{p.ticker}</span>
                            <span className="num text-[9px] text-fog/60">{p.currency}</span>
                          </div>
                          <div className="max-w-[180px] truncate text-[10.5px] text-fog group-hover:text-mist">{p.name}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-2 py-2.5 text-right">
                      <div className="num text-[11.5px] text-mist">{num(p.prices[N - 1], p.price > 1000 ? 0 : 2)}</div>
                      <div className="num text-[9.5px]" style={{ color: toneOf(p.dayPct) }}>
                        {p.isCash ? "—" : `${p.dayPct >= 0 ? "+" : ""}${(p.dayPct * 100).toFixed(2)}%`}
                      </div>
                    </td>
                    <td className="num px-2 py-2.5 text-right text-[10.5px] text-fog">
                      {p.isCash ? "—" : `${num(p.qty, 0)} @ ${num(p.avgCost, p.avgCost > 1000 ? 0 : 2)}`}
                    </td>
                    <td className="num px-2 py-2.5 text-right text-[12px] text-paper">{M(p.value)}</td>
                    <td className="px-2 py-2.5">
                      <div className="flex items-center gap-2">
                        <div className="h-[3px] flex-1 overflow-hidden rounded-full bg-white/[0.05]">
                          <div className="h-full rounded-full transition-all duration-700" style={{ width: `${(p.value / maxVal) * 100}%`, background: p.color }} />
                        </div>
                        <span className="num w-[38px] text-right text-[10.5px] text-mist">{p.weight.toFixed(1)}</span>
                      </div>
                    </td>
                    <td className="num px-2 py-2.5 text-right text-[12px]" style={{ color: toneOf(p.pl) }}>
                      {p.pl >= 0 ? "+" : ""}
                      {M(p.pl)}
                    </td>
                    <td className="px-2 py-2.5 text-right">
                      <span
                        className="num rounded px-1.5 py-[2px] text-[11px]"
                        style={{ color: toneOf(p.plPct), background: `${toneOf(p.plPct)}12`, boxShadow: `inset 0 0 0 1px ${toneOf(p.plPct)}22` }}
                      >
                        {p.plPct >= 0 ? "+" : ""}
                        {p.plPct.toFixed(1)}%
                      </span>
                    </td>
                    <td className="num px-2 py-2.5 text-right text-[10.5px]" style={{ color: toneOf(p.rets.m1) }}>
                      {p.isCash ? "—" : `${p.rets.m1 >= 0 ? "+" : ""}${(p.rets.m1 * 100).toFixed(1)}%`}
                    </td>
                    <td className="num px-2 py-2.5 text-right text-[10.5px]" style={{ color: toneOf(p.rets.y1) }}>
                      {p.isCash ? "—" : `${p.rets.y1 >= 0 ? "+" : ""}${(p.rets.y1 * 100).toFixed(1)}%`}
                    </td>
                    <td className="num px-2 py-2.5 text-right text-[10.5px] text-fog">
                      {p.isCash ? "—" : `${p.vol.toFixed(0)}%`}
                    </td>
                    <td className="px-3 py-2.5 text-right">
                      <div className="flex justify-end">
                        <Sparkline data={p.spark} w={72} h={24} color={toneOf(p.plPct)} />
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="border-t border-white/[0.1] bg-black/30">
                  <td />
                  <td className="px-2 py-3 font-mono text-[9px] uppercase tracking-[0.14em] text-mist">
                    {filtered.length} of {positions.length}
                  </td>
                  <td />
                  <td />
                  <td className="num px-2 py-3 text-right text-[12.5px] text-paper">{M(filtered.reduce((a, p) => a + p.value, 0))}</td>
                  <td className="num px-2 py-3 text-[10.5px] text-mist">
                    {((filtered.reduce((a, p) => a + p.value, 0) / portfolioValue) * 100).toFixed(1)}% of book
                  </td>
                  <td className="num px-2 py-3 text-right text-[12.5px]" style={{ color: toneOf(totalPl) }}>
                    +{M(totalPl)}
                  </td>
                  <td colSpan={5} className="num px-2 py-3 text-right text-[10px] text-fog">
                    invested {M(invested)} · total {M(portfolioValue)}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        )}
      </Panel>

      <div className="grid gap-5 lg:grid-cols-3">
        {[
          {
            t: "Sizing",
            k: "Largest three",
            v: `${byWeight.slice(0, 3).reduce((a, p) => a + p.weight, 0).toFixed(1)}%`,
            body: byWeight.slice(0, 3).map((p) => ({ l: p.ticker, w: p.weight, c: p.color })),
          },
          {
            t: "Spread",
            k: "Smallest three",
            v: `${byWeight.slice(-3).reduce((a, p) => a + p.weight, 0).toFixed(1)}%`,
            body: byWeight.slice(-3).map((p) => ({ l: p.ticker, w: p.weight, c: p.color })),
          },
          {
            t: "Currency",
            k: "Non-USD by value",
            v: `${(100 - positions.filter((p) => p.currency === "USD").reduce((a, p) => a + p.weight, 0)).toFixed(0)}%`,
            body: positions
              .filter((p) => p.currency !== "USD")
              .reduce((acc: { l: string; w: number; c: string }[], p) => {
                const e = acc.find((x) => x.l === p.currency);
                if (e) e.w += p.weight;
                else acc.push({ l: p.currency, w: p.weight, c: "#7db8ff" });
                return acc;
              }, []),
          },
        ].map((g, gi) => (
          <Panel key={g.t} delay={180 + gi * 60}>
            <div className="px-5 pt-4 pb-5">
              <div className="label mb-1.5">{g.t}</div>
              <div className="mb-3 flex items-baseline justify-between">
                <span className="text-[12px] text-mist">{g.k}</span>
                <span className="num text-[19px] text-paper">{g.v}</span>
              </div>
              <Ribbon items={g.body.map((b) => ({ key: b.l, value: b.w, color: b.c }))} height={16} />
              <div className="mt-2.5 flex flex-wrap gap-x-3 gap-y-1">
                {g.body.map((b) => (
                  <span key={b.l} className="num text-[10px] text-fog">
                    {b.l} <span className="text-mist">{b.w.toFixed(1)}%</span>
                  </span>
                ))}
              </div>
            </div>
          </Panel>
        ))}
      </div>

      <div className="px-1 pb-2 font-mono text-[9px] uppercase tracking-[0.2em] text-fog/60">
        Native prices shown in trading currency · converted at current rates · {Object.keys(FX).length} currencies · base {c} · {money(1)}
      </div>
    </div>
  );
}
