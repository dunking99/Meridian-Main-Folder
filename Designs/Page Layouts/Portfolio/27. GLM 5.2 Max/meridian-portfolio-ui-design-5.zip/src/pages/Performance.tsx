import React from "react";
import { Panel, Head, Pill, Seg, Rule, cx, MINT, ROSE, EMBER, toneOf, useCountUp, KV } from "../components/ui";
import { TimeChart, useSize, linePath, PairBars } from "../components/charts";
import { Waterfall, Underwater } from "../components/objects";
import { dates, N } from "../data/market";
import {
  navHistory,
  benchHistory,
  benchName,
  monthlyByYear,
  monthly,
  trailingReturns,
  attribution,
  drawdown,
  vol,
  benchVol,
  sharpe,
  sortino,
  maxDD,
  var95,
  cvar95,
  hitRate,
  beta,
  alpha,
  upCapture,
  downCapture,
  portfolioValue,
  invested,
  totalPl,
  useM,
  money,
  dateShort,
  years,
  equity,
  valueHistory,
  totalDeposited,
} from "../lib/metrics";

export default function Performance({ go }: { go: (p: string, t?: string) => void }) {
  const M = useM();
  const [mode, setMode] = React.useState<"cum" | "rel">("cum");
  const [hover, setHover] = React.useState<string | null>(null);

  const si = (navHistory[N - 1] / navHistory[0] - 1) * 100;
  const bsi = (benchHistory[N - 1] / benchHistory[0] - 1) * 100;
  const anim = useCountUp(si);
  const rel = navHistory.map((v, i) => (v / benchHistory[i]) * 100);
  const g10k = 10000 * (1 + si / 100);
  const b10k = 10000 * (1 + bsi / 100);

  const ddEvents: { start: number; trough: number; end: number; depth: number }[] = (() => {
    const out: { start: number; trough: number; end: number; depth: number }[] = [];
    let peak = navHistory[0];
    let pi = 0;
    let ti = 0;
    let inDD = false;
    for (let i = 1; i < N; i++) {
      if (navHistory[i] > peak) {
        if (inDD) {
          out.push({ start: pi, trough: ti, end: i, depth: (navHistory[ti] / peak - 1) * 100 });
          inDD = false;
        }
        peak = navHistory[i];
        pi = i;
      } else if (navHistory[i] < peak) {
        if (!inDD) {
          inDD = true;
          ti = i;
        }
        if (navHistory[i] < navHistory[ti]) ti = i;
      }
    }
    if (inDD) out.push({ start: pi, trough: ti, end: N - 1, depth: (navHistory[ti] / peak - 1) * 100 });
    return out.sort((a, b) => a.depth - b.depth);
  })();

  /* risk / return scatter */
  const [sref, sw] = useSize<HTMLDivElement>();
  const sc = { w: sw || 400, h: 300 };
  const pts = equity.map((p) => ({ t: p.ticker, x: p.vol, y: p.rets.y1 * 100, r: p.weight, c: p.color }));
  const xmax = Math.max(...pts.map((p) => p.x)) * 1.1;
  const ymax = Math.max(...pts.map((p) => p.y)) * 1.12;
  const ymin = Math.min(...pts.map((p) => p.y)) * 1.15;
  const SX = (v: number) => 46 + (v / xmax) * (sc.w - 62);
  const SY = (v: number) => 16 + (1 - (v - ymin) / (ymax - ymin)) * (sc.h - 52);
  const [scHov, setScHov] = React.useState<string | null>(null);

  const heatColor = (v: number | null) => {
    if (v === null) return "rgba(255,255,255,0.028)";
    const k = Math.max(-1, Math.min(1, v / 6));
    const t = Math.abs(k);
    const h = v >= 0 ? 158 : 348;
    return `hsl(${h} ${30 + t * 40}% ${17 + t * 22}%)`;
  };

  return (
    <div className="space-y-5">
      {/* ══════ hero ══════ */}
      <div className="grid gap-5 lg:grid-cols-12">
        <Panel className="lg:col-span-8" delay={0}>
          <Head
            kicker="Time-weighted, net of flows"
            title="Cumulative performance"
            sub={`Deposits and withdrawals are stripped out — this is the return of the strategy, not the return of your savings habit.`}
            right={
              <Seg
                size="xs"
                items={[
                  { k: "cum" as const, label: "Growth" },
                  { k: "rel" as const, label: "Relative" },
                ]}
                value={mode}
                onChange={setMode}
              />
            }
          />
          <div className="grid grid-cols-4 gap-3 px-5 pb-3">
            {[
              { l: "Since inception", v: `${anim >= 0 ? "+" : ""}${anim.toFixed(1)}%`, s: `world ${bsi >= 0 ? "+" : ""}${bsi.toFixed(1)}%`, tone: toneOf(si) },
              { l: "Growth of 10,000", v: money(g10k), s: `world ${money(b10k)}`, tone: "#eaf0f8" },
              { l: "Excess return", v: `${si - bsi >= 0 ? "+" : ""}${(si - bsi).toFixed(1)}pt`, s: `${((si - bsi) / 1).toFixed(1)}pt over ${Math.round(N / 21)} months`, tone: toneOf(si - bsi) },
              { l: "Positive sessions", v: `${hitRate.toFixed(0)}%`, s: `${Math.round((hitRate / 100) * (N - 1))} of ${N - 1} days`, tone: "#eaf0f8" },
            ].map((x) => (
              <div key={x.l}>
                <div className="label mb-1.5">{x.l}</div>
                <div className="num text-[19px] font-medium" style={{ color: x.tone }}>
                  {x.v}
                </div>
                <div className="num mt-0.5 text-[9.5px] text-fog">{x.s}</div>
              </div>
            ))}
          </div>
          {mode === "cum" ? (
            <div className="px-5 pb-5">
              <TimeChart
                height={252}
                dates={dates}
                baseline={1}
                yFmt={(n) => `${((n - 1) * 100).toFixed(0)}%`}
                series={[
                  { key: "p", data: navHistory, color: si >= 0 ? MINT : ROSE, fill: true, width: 2, smooth: true },
                  { key: "b", data: benchHistory, color: "#7c8aa3", dashed: true, width: 1.3, smooth: true },
                ]}
                tip={(i) => (
                  <div className="space-y-1">
                    <div className="num text-[12px]" style={{ color: toneOf((navHistory[i] - 1) * 100) }}>
                      {((navHistory[i] - 1) * 100).toFixed(2)}%
                    </div>
                    <div className="num text-[10px] text-fog">world {((benchHistory[i] - 1) * 100).toFixed(2)}%</div>
                    <div className="num text-[10px]" style={{ color: toneOf(rel[i] - 100) }}>
                      {rel[i] - 100 >= 0 ? "+" : ""}
                      {(rel[i] - 100).toFixed(2)}pt relative
                    </div>
                  </div>
                )}
              />
              <div className="mt-2 flex items-center gap-4 px-1">
                <span className="num flex items-center gap-1.5 text-[9.5px] text-fog">
                  <i className="h-[3px] w-4 rounded-full bg-mint" /> Portfolio
                </span>
                <span className="num flex items-center gap-1.5 text-[9.5px] text-fog">
                  <i className="h-[3px] w-4 rounded-full bg-[#7c8aa3]" /> {benchName}
                </span>
                <span className="num ml-auto text-[9.5px] text-fog">
                  value today {M(portfolioValue)} · invested {M(invested)}
                </span>
              </div>
            </div>
          ) : (
            <div className="px-5 pb-5">
              <TimeChart
                height={252}
                dates={dates}
                baseline={100}
                yFmt={(n) => `${n.toFixed(0)}`}
                series={[{ key: "rel", data: rel, color: toneOf(rel[N - 1] - 100), fill: true, width: 1.9, smooth: true }]}
                tip={(i) => (
                  <div className="space-y-1">
                    <div className="num text-[12px]" style={{ color: toneOf(rel[i] - 100) }}>
                      {rel[i] - 100 >= 0 ? "+" : ""}
                      {(rel[i] - 100).toFixed(2)}pt
                    </div>
                    <div className="num text-[10px] text-fog">portfolio {((navHistory[i] - 1) * 100).toFixed(1)}%</div>
                  </div>
                )}
              />
              <div className="mt-2 px-1 text-[11px] text-fog">
                Above the line you are beating the index with the same money. The line, not the level, is the thing to watch: a rising line means your decisions are adding something.
              </div>
            </div>
          )}
        </Panel>

        <Panel className="lg:col-span-4" delay={60}>
          <Head kicker="Risk-adjusted" title="The ratio sheet" right={<Pill tone="mint">{sharpe.toFixed(2)} sharpe</Pill>} />
          <div className="px-5 pb-5">
            {[
              { k: "Sharpe ratio", v: sharpe.toFixed(2), d: "return per unit of total risk" },
              { k: "Sortino ratio", v: sortino.toFixed(2), d: "return per unit of downside risk" },
              { k: "Annualised volatility", v: `${vol.toFixed(1)}%`, d: `world ${benchVol.toFixed(1)}%` },
              { k: "Alpha vs world", v: `${alpha >= 0 ? "+" : ""}${alpha.toFixed(1)}%`, d: `beta ${beta.toFixed(2)}`, tone: toneOf(alpha) },
              { k: "Maximum drawdown", v: `${maxDD.toFixed(1)}%`, d: "peak to trough", tone: ROSE },
              { k: "Daily VaR (95%)", v: `${var95.toFixed(2)}%`, d: `CVaR ${cvar95.toFixed(2)}%`, tone: ROSE },
              { k: "Up capture", v: `${upCapture.toFixed(0)}%`, d: "of index gains captured", tone: toneOf(upCapture - 100) },
              { k: "Down capture", v: `${downCapture.toFixed(0)}%`, d: "of index losses suffered", tone: toneOf(100 - downCapture) },
            ].map((r) => (
              <div key={r.k} className="border-b border-white/[0.045] py-2.5 last:border-0">
                <div className="flex items-baseline justify-between">
                  <span className="text-[11.5px] text-mist">{r.k}</span>
                  <span className="num text-[14px]" style={{ color: r.tone || "#eaf0f8" }}>
                    {r.v}
                  </span>
                </div>
                <div className="num mt-0.5 text-[9.5px] text-fog">{r.d}</div>
              </div>
            ))}
            <Rule className="my-3" />
            <div className="rounded-lg border border-white/[0.06] bg-black/25 p-3">
              <div className="label mb-1.5">Read this as</div>
              <p className="text-[11px] leading-relaxed text-mist">
                You are running {vol > benchVol ? "more" : "less"} risk than the index ({vol.toFixed(1)}% vs {benchVol.toFixed(1)}%) and capturing{" "}
                {Math.abs(upCapture - 100).toFixed(0)}% {upCapture > 100 ? "more" : "less"} of the up-moves. The point of active decisions is to keep the down-capture below{" "}
                {upCapture.toFixed(0)}%.
              </p>
            </div>
          </div>
        </Panel>
      </div>

      {/* ══════ monthly heat + trailing ══════ */}
      <div className="grid gap-5 lg:grid-cols-12">
        <Panel className="lg:col-span-8" delay={100}>
          <Head
            kicker="Month by month"
            title="Return ledger"
            sub="Each cell is one calendar month. Read the rows for years, the columns for seasonality."
            right={
              <span className="num flex items-center gap-2 text-[10px] text-fog">
                <span className="text-rose">−6%</span>
                <span className="h-[7px] w-16 rounded-full" style={{ background: "linear-gradient(90deg,hsl(348 70% 39%),hsl(348 30% 17%),hsl(158 30% 17%),hsl(158 70% 39%))" }} />
                <span className="text-mint">+6%</span>
              </span>
            }
          />
          <div className="px-5 pb-5">
            <div className="overflow-x-auto no-scrollbar">
              <table className="w-full min-w-[620px] border-collapse">
                <thead>
                  <tr>
                    <th className="label pb-2 text-left">Year</th>
                    {["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"].map((m, i) => (
                      <th key={i} className="label pb-2 text-center">
                        {m}
                      </th>
                    ))}
                    <th className="label pb-2 text-right">Year</th>
                  </tr>
                </thead>
                <tbody>
                  {monthlyByYear.map((y) => (
                    <tr key={y.year}>
                      <td className="num py-[3px] pr-3 text-[12px] text-paper">{y.year}</td>
                      {y.months.map((m, i) => (
                        <td key={i} className="p-[2px]">
                          <div
                            onMouseEnter={() => setHover(`${y.year}-${i}`)}
                            onMouseLeave={() => setHover(null)}
                            className={cx(
                              "num flex h-[34px] items-center justify-center rounded-[4px] text-[10.5px] transition-all duration-200",
                              m === null && "text-fog/40",
                            )}
                            style={{
                              background: heatColor(m),
                              color: m === null ? "#5c6a80" : Math.abs(m) > 3.5 ? "#eaf0f8" : "#b9c5d8",
                              boxShadow: hover === `${y.year}-${i}` ? "0 0 0 1px #eaf0f8aa" : "none",
                              transform: hover === `${y.year}-${i}` ? "scale(1.08)" : "none",
                            }}
                          >
                            {m === null ? "·" : `${m >= 0 ? "+" : ""}${m.toFixed(1)}`}
                          </div>
                        </td>
                      ))}
                      <td className="num py-[3px] pl-3 text-right text-[12px]" style={{ color: toneOf(y.total) }}>
                        {y.total >= 0 ? "+" : ""}
                        {y.total.toFixed(1)}%
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <Rule className="my-4" />
            <div className="grid grid-cols-3 gap-4">
              {[
                { l: "Positive months", v: `${monthly.filter((m) => m.ret > 0).length}/${monthly.length}`, tone: MINT },
                { l: "Best month", v: `${bestOfMonth().ret >= 0 ? "+" : ""}${bestOfMonth().ret.toFixed(1)}%`, s: `${monthLabel(bestOfMonth())}`, tone: MINT },
                { l: "Worst month", v: `${worstOfMonth().ret.toFixed(1)}%`, s: `${monthLabel(worstOfMonth())}`, tone: ROSE },
              ].map((x) => (
                <div key={x.l}>
                  <div className="label mb-1">{x.l}</div>
                  <div className="num text-[17px]" style={{ color: x.tone }}>
                    {x.v}
                  </div>
                  {x.s && <div className="num text-[9.5px] text-fog">{x.s}</div>}
                </div>
              ))}
            </div>
          </div>
        </Panel>

        <Panel className="lg:col-span-4" delay={140}>
          <Head kicker="Trailing" title="Every window, both ways" sub="Portfolio against the world index over the same window." />
          <div className="px-5 pb-5">
            <PairBars
              legend={["Portfolio", "World"]}
              rows={trailingReturns.map((t) => ({ label: t.label, a: t.port, b: t.bench }))}
              fmt={(n) => `${n >= 0 ? "+" : ""}${n.toFixed(1)}%`}
            />
            <Rule className="my-4" />
            <div className="space-y-1">
              {trailingReturns.map((t) => {
                const d = t.port - t.bench;
                return (
                  <div key={t.key} className="flex items-baseline justify-between">
                    <span className="text-[11px] text-fog">{t.label}</span>
                    <span className="num text-[11px]" style={{ color: toneOf(d) }}>
                      {d >= 0 ? "+" : ""}
                      {d.toFixed(2)}pt
                    </span>
                  </div>
                );
              })}
            </div>
            <div className="mt-3 rounded-lg border border-white/[0.06] bg-black/25 p-3 text-[11px] leading-relaxed text-mist">
              Short windows are noise, long windows are the verdict. The book has beaten the index in{" "}
              {trailingReturns.filter((t) => t.port > t.bench).length} of {trailingReturns.length} windows.
            </div>
          </div>
        </Panel>
      </div>

      {/* ══════ attribution + scatter ══════ */}
      <div className="grid gap-5 lg:grid-cols-12">
        <Panel className="lg:col-span-7" delay={180}>
          <Head
            kicker="Where the money came from"
            title="From opening value to today"
            sub="An exact reconciliation: what you put in, what the market did, what you were paid to wait."
            right={<Pill tone="ember">{M(totalPl)} total P/L</Pill>}
          />
          <div className="px-5 pb-5">
            <Waterfall items={attribution.items} height={278} fmt={(n) => M(n)} />
            <Rule className="my-3" />
            <div className="grid grid-cols-3 gap-3">
              {[
                { l: "Net deposits", v: M(totalDeposited), s: `${((totalDeposited / portfolioValue) * 100).toFixed(0)}% of today's value` },
                { l: "Market moves", v: M(attribution.capGains), s: `${((attribution.capGains / portfolioValue) * 100).toFixed(1)}% of value` },
                { l: "Income received", v: M(attribution.income), s: "dividends, interest" },
              ].map((x) => (
                <div key={x.l}>
                  <div className="label mb-1">{x.l}</div>
                  <div className="num text-[15px] text-paper">{x.v}</div>
                  <div className="num text-[9.5px] text-fog">{x.s}</div>
                </div>
              ))}
            </div>
          </div>
        </Panel>

        <Panel className="lg:col-span-5" delay={220}>
          <Head kicker="Risk versus reward" title="Are you paid for the risk?" sub="Bubble size is position weight. The line is where risk and return trade off evenly." />
          <div className="px-5 pb-5">
            <div ref={sref} className="relative w-full" style={{ height: 300 }}>
              {sw > 40 && (
                <svg width={sw} height={300}>
                  {[0, 0.25, 0.5, 0.75, 1].map((f) => (
                    <line key={f} x1="46" x2={sw - 16} y1={SY(ymin + f * (ymax - ymin))} y2={SY(ymin + f * (ymax - ymin))} stroke="#fff" strokeOpacity="0.045" strokeDasharray="2 4" />
                  ))}
                  {[0, 0.25, 0.5, 0.75, 1].map((f) => (
                    <line key={`v${f}`} y1="16" y2="264" x1={SX(f * xmax)} x2={SX(f * xmax)} stroke="#fff" strokeOpacity="0.035" />
                  ))}
                  <path d={linePath([[SX(0), SY(0)], [SX(xmax), SY((xmax / xmax) * ymax)]], false)} stroke="#ff7a45" strokeOpacity="0.35" strokeWidth="1" strokeDasharray="4 4" fill="none" />
                  <line x1="46" x2={sw - 16} y1={SY(0)} y2={SY(0)} stroke="#fff" strokeOpacity="0.14" />
                  {/* portfolio marker */}
                  <g>
                    <circle cx={SX(vol)} cy={SY(si)} r="15" fill={MINT} fillOpacity="0.1" stroke={MINT} strokeWidth="1.4" strokeDasharray="3 3" />
                    <circle cx={SX(vol)} cy={SY(si)} r="4.5" fill={MINT} style={{ filter: `drop-shadow(0 0 8px ${MINT})` }} />
                    <text x={SX(vol) + 20} y={SY(si) + 3} fill="#eaf0f8" fontSize="9.5" fontFamily="IBM Plex Mono, monospace">
                      YOUR BOOK
                    </text>
                  </g>
                  {pts.map((p) => {
                    const on = scHov === p.t;
                    const r = 5 + Math.sqrt(p.r) * 5.5;
                    return (
                      <g key={p.t} onPointerEnter={() => setScHov(p.t)} onPointerLeave={() => setScHov(null)} onClick={() => go("holding", p.t)} style={{ cursor: "pointer" }}>
                        <circle
                          cx={SX(p.x)}
                          cy={SY(p.y)}
                          r={r}
                          fill={p.c}
                          fillOpacity={on ? 0.5 : 0.24}
                          stroke={p.c}
                          strokeWidth={on ? 1.8 : 1}
                          style={{ filter: on ? `drop-shadow(0 0 10px ${p.c})` : "none" }}
                        />
                        <text
                          x={SX(p.x)}
                          y={SY(p.y) - r - 4}
                          textAnchor="middle"
                          fill={on ? "#eaf0f8" : "#8a96ad"}
                          fontSize={on ? 9.5 : 8.5}
                          fontFamily="IBM Plex Mono, monospace"
                        >
                          {p.t}
                        </text>
                      </g>
                    );
                  })}
                  <text x="46" y="282" fill="#5c6a80" fontSize="8.5" fontFamily="IBM Plex Mono, monospace">
                    VOLATILITY →
                  </text>
                  <text x={sw - 16} y="282" textAnchor="end" fill="#5c6a80" fontSize="8.5" fontFamily="IBM Plex Mono, monospace">
                    {xmax.toFixed(0)}%
                  </text>
                  <text x="12" y={SY(ymax) + 4} fill="#5c6a80" fontSize="8.5" fontFamily="IBM Plex Mono, monospace">
                    {ymax.toFixed(0)}%
                  </text>
                  <text x="12" y={SY(ymin) + 4} fill="#5c6a80" fontSize="8.5" fontFamily="IBM Plex Mono, monospace">
                    {ymin.toFixed(0)}%
                  </text>
                </svg>
              )}
            </div>
            <div className="mt-1 text-[11px] leading-relaxed text-fog">
              Positions above and left of the dashed line earn more per unit of risk than the book average. Anything bottom-right is expensive risk.
            </div>
          </div>
        </Panel>
      </div>

      {/* ══════ drawdowns ══════ */}
      <div className="grid gap-5 lg:grid-cols-12">
        <Panel className="lg:col-span-7" delay={260}>
          <Head kicker="Underwater" title="Every drawdown, and how long it lasted" right={<Pill tone="rose">{maxDD.toFixed(1)}% worst</Pill>} />
          <div className="px-5 pb-5">
            <Underwater data={drawdown} dates={dates} height={186} />
          </div>
        </Panel>

        <Panel className="lg:col-span-5" delay={300}>
          <Head kicker="Pain ledger" title="The five deepest" sub="Depth is only half the story; time underwater is what actually hurts." />
          <div className="px-5 pb-5">
            {ddEvents.slice(0, 5).map((d, i) => (
              <div key={i} className="border-b border-white/[0.045] py-2.5 last:border-0">
                <div className="flex items-baseline justify-between">
                  <span className="num text-[11px] text-mist">
                    {dateShort(dates[d.start])} → {dateShort(dates[d.trough])}
                  </span>
                  <span className="num text-[13px] text-rose">{d.depth.toFixed(1)}%</span>
                </div>
                <div className="mt-1.5 flex items-center gap-2">
                  <div className="relative h-[6px] flex-1 overflow-hidden rounded-full bg-white/[0.05]">
                    <div
                      className="absolute inset-y-0 rounded-full"
                      style={{ left: `${(d.start / N) * 100}%`, width: `${((d.end - d.start) / N) * 100}%`, background: "linear-gradient(90deg,#ff5c7a88,#ff5c7a)" }}
                    />
                  </div>
                  <span className="num w-[92px] text-right text-[10px] text-fog">{d.end - d.start} sessions</span>
                  <span className="num w-[74px] text-right text-[10px]" style={{ color: d.end === N - 1 ? EMBER : MINT }}>
                    {d.end === N - 1 ? "ongoing" : "recovered"}
                  </span>
                </div>
              </div>
            ))}
            <Rule className="my-3" />
            <KV k="Average drawdown" v={`${(ddEvents.reduce((a, d) => a + d.depth, 0) / ddEvents.length).toFixed(1)}%`} />
            <KV k="Longest underwater" v={`${Math.max(...ddEvents.map((d) => d.end - d.start))} sessions`} />
            <KV k="Time spent below peak" v={`${((drawdown.filter((d) => d < -0.1).length / N) * 100).toFixed(0)}%`} />
          </div>
        </Panel>
      </div>

      <div className="px-1 pb-2 font-mono text-[9px] uppercase tracking-[0.2em] text-fog/60">
        {years.length} calendar years · {monthly.length} months · {N} sessions · money-weighted figures on the activity page
      </div>
    </div>
  );
}

const bestOfMonth = () => [...monthly].sort((a, b) => b.ret - a.ret)[0];
const worstOfMonth = () => [...monthly].sort((a, b) => a.ret - b.ret)[0];
const monthLabel = (m: { year: number; month: number }) =>
  new Date(Date.UTC(m.year, m.month)).toLocaleDateString("en-GB", { month: "long", year: "numeric", timeZone: "UTC" });
void valueHistory;
