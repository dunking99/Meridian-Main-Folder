import React from "react";
import { Panel, Head, Pill, Rule, cx, MINT, ROSE, EMBER, toneOf, KV, Dot } from "../components/ui";
import { Gauge, Radar, CorrMatrix, Histogram, plColor } from "../components/objects";
import { Globe } from "../components/Globe";
import { Ribbon, useSize, linePath, DivergeList } from "../components/charts";
import { positions, equity, byWeight, sectorExposure, regionExposure, currencyExposure, assetExposure, corr, retDist, var95, cvar95, vol, benchVol, health, useM, portfolioValue, cashWeight, top3, hhi, cumulativeWeights, dividendRun, portfolioYield, fundTer, feesPaid } from "../lib/metrics";
import { RULES } from "../data/content";
import type { GlobePoint } from "../components/Globe";

const WORLD_SECTOR: Record<string, number> = {
  Technology: 26.4,
  Semiconductors: 11.2,
  Financials: 13.8,
  Healthcare: 10.4,
  "Consumer Discretionary": 9.6,
  "Consumer Staples": 5.8,
  Energy: 3.6,
  Industrials: 9.4,
  Materials: 3.1,
  "Real Assets": 2.4,
  Bonds: 0,
  Cash: 0,
};

export default function Analysis({ go }: { go: (p: string, t?: string) => void }) {
  const M = useM();
  const [globeSel, setGlobeSel] = React.useState<string | null>(null);
  const [cref, cw] = useSize<HTMLDivElement>();

  const countryMap = new Map<string, { value: number; weight: number; pl: number; lat: number; lon: number }>();
  for (const p of positions) {
    if (p.isCash) continue;
    const e = countryMap.get(p.country) || { value: 0, weight: 0, pl: 0, lat: p.lat, lon: p.lon };
    e.value += p.value;
    e.weight += p.weight;
    e.pl += p.pl;
    countryMap.set(p.country, e);
  }
  const globePoints: GlobePoint[] = [...countryMap.entries()].map(([k, v]) => ({
    key: k,
    label: k,
    lat: v.lat,
    lon: v.lon,
    value: v.value,
    weight: v.weight,
    pl: (v.pl / v.value) * 100,
  }));

  const activeBets = sectorExposure
    .map((s) => ({ key: s.key, active: s.weight - (WORLD_SECTOR[s.key] ?? 0), weight: s.weight, world: WORLD_SECTOR[s.key] ?? 0, color: s.color, pl: s.pl }))
    .sort((a, b) => b.active - a.active);

  const volMax = 60;
  const vols = assetExposure.map((a) => {
    const members = positions.filter((p) => p.assetClass === a.key);
    const w = members.reduce((x, p) => x + p.value, 0);
    const v = members.reduce((x, p) => x + p.vol * p.value, 0) / (w || 1);
    return { key: a.key, vol: v, weight: a.weight, color: a.color };
  });

  const scenarios = [
    { name: "World equities −10%", impact: -0.1 * equity.reduce((a, p) => a + p.value * p.beta, 0), note: "beta-weighted" },
    { name: "Semiconductors −20%", impact: -0.2 * (sectorExposure.find((s) => s.key === "Semiconductors")?.value ?? 0), note: "23% linked exposure" },
    { name: "Dollar +5%", impact: -0.05 * (100 - (currencyExposure.find((c) => c.key === "USD")?.weight ?? 100)) * 0.01 * portfolioValue, note: "unhedged" },
    { name: "Rates +100bp", impact: -0.035 * (assetExposure.find((a) => a.key === "Bond")?.value ?? 0), note: "3.5yr duration" },
    { name: "Taiwan shock −30%", impact: -0.3 * (["NVDA", "TSM", "ASML"].map((t) => positions.find((p) => p.ticker === t)?.value ?? 0).reduce((a, b) => a + b, 0)) * 0.4, note: "partial overlap" },
  ].sort((a, b) => a.impact - b.impact);

  const maxCum = 100;
  const nPos = byWeight.length;

  return (
    <div className="space-y-5">
      {/* ══════ condition ══════ */}
      <Panel className="overflow-hidden" delay={0}>
        <div className="grid gap-0 lg:grid-cols-[300px_1fr_330px]">
          <div className="flex flex-col items-center justify-center border-b border-white/[0.06] p-5 lg:border-b-0 lg:border-r">
            <div className="label mb-4 self-start">Portfolio condition</div>
            <Gauge score={health.score} size={272} label="meridian score" />
            <p className="mt-3 text-center text-[11px] leading-relaxed text-fog">
              Weighted across six pillars. {health.score >= 72 ? "Sound, with two things to fix." : "Serviceable, but the tails are wide."}
            </p>
          </div>

          <div className="flex flex-col items-center justify-center p-5">
            <div className="label mb-4 self-start">Pillar profile</div>
            <Radar size={264} axes={health.pillars.map((p) => ({ name: p.name.split(" ")[0], score: p.score }))} />
          </div>

          <div className="border-t border-white/[0.06] p-5 lg:border-t-0 lg:border-l">
            <div className="label mb-3">What is holding the score down</div>
            {[...health.pillars]
              .sort((a, b) => a.score - b.score)
              .slice(0, 4)
              .map((p, i) => (
                <div key={p.name} className="mb-3">
                  <div className="flex items-baseline justify-between">
                    <span className="text-[11.5px] text-mist">{p.name}</span>
                    <span className="num text-[12px]" style={{ color: p.score >= 72 ? MINT : p.score >= 50 ? EMBER : ROSE }}>
                      {p.score.toFixed(0)}
                    </span>
                  </div>
                  <div className="mt-1.5 h-[4px] w-full overflow-hidden rounded-full bg-white/[0.05]">
                    <div
                      className="h-full rounded-full"
                      style={{
                        width: `${p.score}%`,
                        background: p.score >= 72 ? MINT : p.score >= 50 ? EMBER : ROSE,
                        boxShadow: `0 0 10px ${p.score >= 72 ? MINT : p.score >= 50 ? EMBER : ROSE}66`,
                        animation: `slideIn .8s ${i * 90}ms cubic-bezier(.22,1,.36,1) both`,
                      }}
                    />
                  </div>
                  <div className="mt-1 flex justify-between">
                    <span className="num text-[9.5px] text-fog">{p.note}</span>
                    <span className="num text-[9px] text-fog/60">{p.target}</span>
                  </div>
                </div>
              ))}
            <Rule className="my-3" />
            <div className="label mb-2">Rules</div>
            {RULES.map((r) => (
              <div key={r.rule} className="flex items-center gap-2 py-[5px]">
                <Dot c={r.status === "breach" ? ROSE : r.status === "warn" ? EMBER : MINT} size={6} />
                <span className="flex-1 truncate text-[10.5px] text-fog">{r.rule}</span>
                <span className="num text-[9.5px]" style={{ color: r.status === "breach" ? ROSE : r.status === "warn" ? EMBER : MINT }}>
                  {r.detail}
                </span>
              </div>
            ))}
          </div>
        </div>
      </Panel>

      {/* ══════ exposure ══════ */}
      <div className="grid gap-5 lg:grid-cols-12">
        <Panel className="lg:col-span-5" delay={60}>
          <Head
            kicker="Geography"
            title="Where your capital actually sits"
            sub="Each marker is sized by weight and coloured by whether that country has made you money."
            right={<Pill tone="violet">{globePoints.length} countries</Pill>}
          />
          <div className="flex flex-col items-center px-5 pb-5">
            <Globe points={globePoints} size={314} active={globeSel} onSelect={setGlobeSel} onHover={setGlobeSel} />
            <div className="mt-4 w-full">
              {regionExposure
                .filter((r) => r.key !== "—")
                .slice(0, 7)
                .map((r) => (
                <button
                  key={r.key}
                  onMouseEnter={() => setGlobeSel(r.key)}
                  onMouseLeave={() => setGlobeSel(null)}
                  onClick={() => setGlobeSel(globeSel === r.key ? null : r.key)}
                  className={cx(
                    "flex w-full items-center gap-3 border-b border-white/[0.04] py-[7px] text-left transition-colors last:border-0",
                    globeSel === r.key ? "bg-white/[0.03]" : "hover:bg-white/[0.02]",
                  )}
                >
                  <span className="w-[104px] shrink-0 truncate text-[11.5px] text-mist">{r.key}</span>
                  <div className="h-[4px] flex-1 overflow-hidden rounded-full bg-white/[0.05]">
                    <div className="h-full rounded-full" style={{ width: `${r.weight * 2.2}%`, background: "#5ee3d0" }} />
                  </div>
                  <span className="num w-[42px] text-right text-[11px] text-paper">{r.weight.toFixed(1)}%</span>
                  <span className="num w-[54px] text-right text-[10.5px]" style={{ color: toneOf(r.pl) }}>
                    {r.pl >= 0 ? "+" : ""}
                    {M(r.pl)}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </Panel>

        <div className="space-y-5 lg:col-span-7">
          <Panel delay={100}>
            <Head
              kicker="Active bets"
              title="Sector weight against the world index"
              sub="Positive bars are where you have chosen to be different. Everything else is just index risk you are paying to hold."
              right={<Pill tone="ember">{activeBets.filter((a) => a.active > 0).length} overweights</Pill>}
            />
            <div className="px-5 pb-5">
              <DivergeList
                fmt={(n) => `${n >= 0 ? "+" : ""}${n.toFixed(1)}pt`}
                rows={activeBets.map((a) => ({ label: a.key, value: a.active }))}
              />
              <Rule className="my-4" />
              <div className="grid grid-cols-2 gap-x-6 gap-y-1.5">
                {activeBets.map((a) => (
                  <div key={a.key} className="flex items-center justify-between gap-2">
                    <span className="flex items-center gap-1.5 truncate text-[10.5px] text-fog">
                      <i className="h-[6px] w-[6px] shrink-0 rounded-sm" style={{ background: a.color }} />
                      {a.key}
                    </span>
                    <span className="num shrink-0 text-[10px] text-mist">
                      {a.weight.toFixed(1)}% vs {a.world.toFixed(1)}%
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </Panel>

          <div className="grid gap-5 sm:grid-cols-2">
            <Panel delay={140}>
              <Head kicker="Currency" title="Translation risk" right={<Pill tone="azure">{currencyExposure.length} currencies</Pill>} />
              <div className="px-5 pb-5">
                <Ribbon items={currencyExposure.map((c) => ({ key: c.key, value: c.value, color: c.key === "USD" ? "#5c6a80" : "#7db8ff" }))} height={18} />
                <div className="mt-3 space-y-0">
                  {currencyExposure.map((c) => (
                    <div key={c.key} className="flex items-baseline justify-between border-b border-white/[0.04] py-[6px] last:border-0">
                      <span className="num text-[11px] text-mist">{c.key}</span>
                      <span className="num text-[10px] text-fog">
                        {c.count} position{c.count > 1 ? "s" : ""}
                      </span>
                      <span className="num text-[11.5px] text-paper">{c.weight.toFixed(1)}%</span>
                    </div>
                  ))}
                </div>
                <div className="mt-3 rounded-lg border border-azure/20 bg-azure/[0.06] p-2.5">
                  <p className="text-[10.5px] leading-relaxed text-mist">
                    <span className="num text-azure">{(100 - (currencyExposure.find((c) => c.key === "USD")?.weight ?? 100)).toFixed(0)}%</span> of the book is unhedged foreign currency. A
                    10% dollar rally would cost about {M(portfolioValue * 0.1 * ((100 - (currencyExposure.find((c) => c.key === "USD")?.weight ?? 100)) / 100) * 0.7)} without any equity
                    moving.
                  </p>
                </div>
              </div>
            </Panel>

            <Panel delay={180}>
              <Head kicker="Risk spectrum" title="How much noise you carry" right={<Pill tone="mint">{vol.toFixed(1)}%</Pill>} />
              <div className="px-5 pb-5">
                <div className="relative pt-6">
                  {vols.map((v) => (
                    <div key={v.key} className="mb-2.5">
                      <div className="mb-1 flex justify-between">
                        <span className="text-[10.5px] text-fog">{v.key}</span>
                        <span className="num text-[10px] text-mist">{v.vol.toFixed(0)}%</span>
                      </div>
                      <div className="relative h-[7px] w-full rounded-full bg-white/[0.05]">
                        <div
                          className="absolute inset-y-0 left-0 rounded-full"
                          style={{ width: `${(v.vol / volMax) * 100}%`, background: `linear-gradient(90deg,${v.color}55,${v.color})` }}
                        />
                      </div>
                    </div>
                  ))}
                  <div className="relative h-[9px] w-full rounded-full bg-white/[0.04]">
                    <div className="absolute inset-y-0 left-0 rounded-full" style={{ width: `${(vol / volMax) * 100}%`, background: "linear-gradient(90deg,#3ee0a066,#3ee0a0)" }} />
                    <div className="absolute -top-1 h-[17px] w-[2px] bg-paper" style={{ left: `${(vol / volMax) * 100}%` }} />
                    <div className="absolute -top-1 h-[17px] w-[2px] bg-ember" style={{ left: `${(benchVol / volMax) * 100}%` }} />
                  </div>
                  <div className="mt-2 flex justify-between">
                    <span className="num text-[9px] text-fog">0%</span>
                    <span className="num text-[9px] text-fog">{volMax}%</span>
                  </div>
                  <div className="mt-1 flex gap-4">
                    <span className="num flex items-center gap-1.5 text-[9px] text-paper">
                      <i className="h-[3px] w-3 bg-paper" /> your book {vol.toFixed(1)}%
                    </span>
                    <span className="num flex items-center gap-1.5 text-[9px] text-ember">
                      <i className="h-[3px] w-3 bg-ember" /> world {benchVol.toFixed(1)}%
                    </span>
                  </div>
                </div>
              </div>
            </Panel>
          </div>
        </div>
      </div>

      {/* ══════ structure ══════ */}
      <div className="grid gap-5 lg:grid-cols-12">
        <Panel className="lg:col-span-5" delay={220}>
          <Head kicker="Concentration" title="How quickly the book narrows" sub="The curve shows how much of the portfolio the top N positions cover." right={<Pill tone={top3 > 30 ? "rose" : "mint"}>top 3 = {top3.toFixed(0)}%</Pill>} />
          <div className="px-5 pb-5">
            <div ref={cref} className="relative w-full" style={{ height: 210 }}>
              {cw > 40 && (
                <svg width={cw} height={210}>
                  {[0, 25, 50, 75, 100].map((t) => (
                    <g key={t}>
                      <line x1="34" x2={cw - 8} y1={200 - (t / maxCum) * 176} y2={200 - (t / maxCum) * 176} stroke="#fff" strokeOpacity="0.05" strokeDasharray="2 4" />
                      <text x="28" y={204 - (t / maxCum) * 176} textAnchor="end" fill="#5c6a80" fontSize="8.5" fontFamily="IBM Plex Mono, monospace">
                        {t}
                      </text>
                    </g>
                  ))}
                  <rect x="34" y={200 - (60 / maxCum) * 176} width={cw - 42} height={(20 / maxCum) * 176} fill="#7db8ff" fillOpacity="0.06" />
                  <path
                    d={linePath(cumulativeWeights.map((v, i) => [34 + (i / (nPos - 1)) * (cw - 42), 200 - (v / maxCum) * 176] as [number, number]), true)}
                    fill="none"
                    stroke={EMBER}
                    strokeWidth="1.9"
                    style={{ filter: "drop-shadow(0 0 8px rgba(255,122,69,.45))" }}
                  />
                  {cumulativeWeights.map((v, i) => (
                    <g key={i}>
                      <circle cx={34 + (i / (nPos - 1)) * (cw - 42)} cy={200 - (v / maxCum) * 176} r={byWeight[i].weight > 8 ? 3.4 : 2} fill="#06080c" stroke={byWeight[i].color} strokeWidth="1.4" />
                    </g>
                  ))}
                  <text x="36" y={200 - (70 / maxCum) * 176} fill="#7db8ff" fontSize="8" fontFamily="IBM Plex Mono, monospace">
                    COMFORT BAND 40–60% BY TOP 5
                  </text>
                  <text x="34" y="212" fill="#5c6a80" fontSize="8.5" fontFamily="IBM Plex Mono, monospace">
                    1
                  </text>
                  <text x={cw - 8} y="212" textAnchor="end" fill="#5c6a80" fontSize="8.5" fontFamily="IBM Plex Mono, monospace">
                    {nPos} positions
                  </text>
                </svg>
              )}
            </div>
            <Rule className="my-3" />
            <div className="grid grid-cols-3 gap-3">
              {[
                { l: "HHI", v: hhi.toFixed(0), s: "under 20 is spread" },
                { l: "Effective positions", v: (100 / hhi).toFixed(1), s: "of 18 held" },
                { l: "Largest", v: `${byWeight[0].weight.toFixed(1)}%`, s: byWeight[0].ticker },
              ].map((x) => (
                <div key={x.l}>
                  <div className="label mb-1">{x.l}</div>
                  <div className="num text-[16px] text-paper">{x.v}</div>
                  <div className="num text-[9.5px] text-fog">{x.s}</div>
                </div>
              ))}
            </div>
          </div>
        </Panel>

        <Panel className="lg:col-span-7" delay={260}>
          <Head
            kicker="Co-movement"
            title="Correlation of daily returns"
            sub="The reason diversification fails: everything on the right of the top row moves together."
            right={<Pill tone="azure">1.0 = identical</Pill>}
          />
          <div className="px-5 pb-5">
            <CorrMatrix labels={corr.labels} m={corr.m} />
            <div className="mt-3 flex items-center gap-4">
              <span className="num flex items-center gap-1.5 text-[9.5px] text-fog">
                <i className="h-2 w-6 rounded-sm" style={{ background: "#ff5c7a" }} /> move apart
              </span>
              <span className="num flex items-center gap-1.5 text-[9.5px] text-fog">
                <i className="h-2 w-6 rounded-sm" style={{ background: "#7db8ff" }} /> move together
              </span>
              <span className="num ml-auto text-[9.5px] text-fog">trailing 12 months, daily</span>
            </div>
          </div>
        </Panel>
      </div>

      {/* ══════ stress + distribution ══════ */}
      <div className="grid gap-5 lg:grid-cols-12">
        <Panel className="lg:col-span-5" delay={300}>
          <Head kicker="Scenario board" title="What a bad month looks like" sub="Not forecasts — mechanical sensitivities of the book you hold today." />
          <div className="px-5 pb-5">
            {scenarios.map((s, i) => {
              const pctv = (s.impact / portfolioValue) * 100;
              const max = Math.max(...scenarios.map((x) => Math.abs(x.impact)));
              const w = (Math.abs(s.impact) / max) * 100;
              return (
                <div key={s.name} className="mb-3.5 last:mb-0">
                  <div className="mb-1.5 flex items-baseline justify-between">
                    <span className="text-[11.5px] text-mist">{s.name}</span>
                    <span className="num text-[12.5px]" style={{ color: ROSE }}>
                      {M(s.impact)}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="h-[9px] flex-1 overflow-hidden rounded-full bg-white/[0.04]">
                      <div
                        className="h-full rounded-full"
                        style={{
                          width: `${w}%`,
                          background: `linear-gradient(90deg,${plColor(-25, 25)},${plColor(-10, 25)})`,
                          animation: `slideIn .8s ${i * 90}ms cubic-bezier(.22,1,.36,1) both`,
                        }}
                      />
                    </div>
                    <span className="num w-[42px] text-right text-[10px] text-rose">−{Math.abs(pctv).toFixed(1)}%</span>
                  </div>
                  <div className="num mt-1 text-[9px] text-fog/70">{s.note}</div>
                </div>
              );
            })}
            <Rule className="my-3" />
            <KV k="Combined worst case" v={M(scenarios.reduce((a, s) => a + s.impact, 0))} tone={ROSE} />
            <KV k="Cash available to deploy" v={M(portfolioValue * (cashWeight / 100))} />
          </div>
        </Panel>

        <Panel className="lg:col-span-7" delay={340}>
          <Head
            kicker="Distribution"
            title="The shape of a normal day"
            sub="Daily total returns over the last 12 months, with the fitted normal curve. Fat tails are the reason VaR exists."
            right={<Pill tone="rose">VaR 95% {var95.toFixed(2)}%</Pill>}
          />
          <div className="px-5 pb-5">
            <Histogram
              bins={retDist}
              height={168}
              markers={[
                { x: var95 / 100, label: "VaR", color: ROSE },
                { x: cvar95 / 100, label: "CVaR", color: EMBER },
              ]}
            />
            <Rule className="my-4" />
            <div className="grid grid-cols-4 gap-4">
              {[
                { l: "Best day", v: "+2.41%", s: "18 Nov 25" },
                { l: "Worst day", v: "−2.18%", s: "04 Apr 25" },
                { l: "Days beyond ±2%", v: "11", s: `of ${retDist.reduce((a, b) => a + b.c, 0)}` },
                { l: "Running yield", v: `${portfolioYield.toFixed(2)}%`, s: M(dividendRun) },
              ].map((x) => (
                <div key={x.l}>
                  <div className="label mb-1">{x.l}</div>
                  <div className="num text-[15px] text-paper">{x.v}</div>
                  <div className="num text-[9.5px] text-fog">{x.s}</div>
                </div>
              ))}
            </div>
            <Rule className="my-4" />
            <div className="grid grid-cols-3 gap-4">
              <div>
                <div className="label mb-1.5">Blended fee load</div>
                <div className="num text-[15px] text-paper">{fundTer.toFixed(3)}%</div>
                <div className="num text-[9.5px] text-fog">{M(portfolioValue * (fundTer / 100))} a year</div>
              </div>
              <div>
                <div className="label mb-1.5">Trading costs paid</div>
                <div className="num text-[15px] text-paper">{M(feesPaid)}</div>
                <div className="num text-[9.5px] text-fog">18 executions</div>
              </div>
              <div>
                <div className="label mb-1.5">Cost as % of P/L</div>
                <div className="num text-[15px] text-paper">{((feesPaid / Math.max(1, portfolioValue - 500000)) * 100).toFixed(1)}%</div>
                <div className="num text-[9.5px] text-fog">fees vs gains</div>
              </div>
            </div>
          </div>
        </Panel>
      </div>

      <div className="px-1 pb-2 font-mono text-[9px] uppercase tracking-[0.2em] text-fog/60">
        scenario impacts are mechanical, not probabilistic · world index weights are free-float adjusted ·{" "}
        <button onClick={() => go("holdings")} className="hover:text-paper">
          see the positions →
        </button>
      </div>
    </div>
  );
}
