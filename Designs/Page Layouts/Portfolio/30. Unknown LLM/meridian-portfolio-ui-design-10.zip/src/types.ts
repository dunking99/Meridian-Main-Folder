export type CurrencyCode = 'USD' | 'EUR' | 'GBP' | 'JPY' | 'CHF';

export interface CurrencyRate {
  code: CurrencyCode;
  symbol: string;
  name: string;
  rateToUSD: number; // Multiply USD value by rateToUSD to get local
}

export type SectorName = 
  | 'Semiconductors & AI'
  | 'Enterprise Cloud & Software'
  | 'Consumer & Services'
  | 'Healthcare & Biotech'
  | 'Defense & Heavy Industrials'
  | 'Consumer Discretionary'
  | 'Sovereign Debt & Fixed Income'
  | 'Real Assets & Gold'
  | 'Liquid Cash Reserves';

export type RegionName = 'North America' | 'Europe' | 'Asia-Pacific' | 'Global / Multi-National';

export interface Holding {
  id: string;
  symbol: string;
  name: string;
  exchange: string;
  sector: SectorName;
  region: RegionName;
  currency: string;
  shares: number;
  avgCost: number;
  currentPrice: number;
  prevClose: number;
  dayChangePercent: number;
  peRatio: number | null;
  forwardPE: number | null;
  dividendYield: number;
  annualDividend: number;
  beta: number;
  marketCap: string;
  targetWeightPercent: number;
  high52w: number;
  low52w: number;
  thesis: string;
  conviction: 'High' | 'Medium' | 'Speculative';
  lastRebalanced: string;
  tags: string[];
  recentCatalyst: string;
  priceHistory: number[]; // 30-day sparkline
  financialHealth: 'Pristine' | 'Robust' | 'Watchlist' | 'Distressed';
  nextEarningsDate: string;
}

export interface MonthlyReturn {
  year: number;
  month: number; // 0-11
  portfolioReturn: number; // e.g. +3.4% or -1.8%
  benchmarkReturn: number;
}

export interface BenchmarkComparison {
  name: string;
  ytd: number;
  oneYear: number;
  threeYear: number;
  volatility: number;
  sharpe: number;
  maxDrawdown: number;
  beta: number;
  color: string;
}

export interface RiskMetrics {
  sharpeRatio: number;
  sortinoRatio: number;
  annualizedVol: number;
  betaVsSP500: number;
  valueAtRisk95: number; // 1-day 95% VaR %
  maxDrawdown: number;
  maxDrawdownPeriod: string;
  correlationToSP500: number;
  currentCashDragPercent: number;
  rSquared: number;
}

export interface HealthDimension {
  name: string;
  score: number; // 0 - 100
  status: 'Optimal' | 'Alert' | 'Caution' | 'Strong';
  observation: string;
  recommendation: string;
}

export interface StressScenario {
  id: string;
  title: string;
  narrative: string;
  estimatedImpactPercent: number;
  mostVulnerableAsset: string;
  primaryCushion: string;
}

export interface NewsArticle {
  id: string;
  title: string;
  source: string;
  timeAgo: string;
  impact: 'Bullish' | 'Bearish' | 'Neutral' | 'Critical';
  summary: string;
  relatedHoldings: string[];
  readTime: string;
}

export interface JournalEntry {
  id: string;
  date: string;
  holdingSymbol: string;
  action: 'BUY' | 'SELL' | 'THESIS_UPDATE' | 'EARNINGS_REVIEW' | 'ALERT_NOTE';
  title: string;
  content: string;
  convictionAtTime: 'High' | 'Medium' | 'Speculative';
  priceAtRecord: number;
}

export interface MarketMacroItem {
  symbol: string;
  name: string;
  category: 'Index' | 'Rates' | 'Commodity' | 'Currency' | 'Volatility';
  value: number;
  changePercent: number;
  unit?: string;
  sentiment: 'Risk-On' | 'Tightening' | 'Elevated' | 'Neutral' | 'Hedging';
}
