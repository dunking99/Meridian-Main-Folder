import React, { useState } from 'react';
import { 
  Award, 
  BarChart3, 
  Activity,
  Zap
} from 'lucide-react';
import { MONTHLY_RETURNS, BENCHMARKS } from '../data/portfolioData';

interface PerformanceViewProps {
  onNavigate?: (path: string) => void;
}

export const PerformanceView: React.FC<PerformanceViewProps> = () => {
  const [returnType, setReturnType] = useState<'NET' | 'ALPHA'>('NET');

  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const years = [2024, 2025];

  // Helper to get monthly return
  const getMonthData = (year: number, monthIdx: number) => {
    return MONTHLY_RETURNS.find(m => m.year === year && m.month === monthIdx);
  };

  // Calculate annual returns
  const getYearTotal = (year: number) => {
    const yearReturns = MONTHLY_RETURNS.filter(m => m.year === year);
    if (yearReturns.length === 0) return 0;
    // Compounded annual return
    let compounded = 1;
    yearReturns.forEach(r => {
      compounded *= (1 + r.portfolioReturn / 100);
    });
    return (compounded - 1) * 100;
  };

  const getYearBenchmarkTotal = (year: number) => {
    const yearReturns = MONTHLY_RETURNS.filter(m => m.year === year);
    if (yearReturns.length === 0) return 0;
    let compounded = 1;
    yearReturns.forEach(r => {
      compounded *= (1 + r.benchmarkReturn / 100);
    });
    return (compounded - 1) * 100;
  };

  // Underwater Drawdown data points for the SVG Trench
  const drawdownPoints = [
    { label: 'Jan 24', dd: 0 },
    { label: 'Feb 24', dd: 0 },
    { label: 'Mar 24', dd: -1.2 },
    { label: 'Apr 24', dd: -5.4 },
    { label: 'May 24', dd: 0 },
    { label: 'Jun 24', dd: 0 },
    { label: 'Jul 24', dd: -3.8 },
    { label: 'Aug 24', dd: -11.4 }, // Deepest trench
    { label: 'Sep 24', dd: -4.1 },
    { label: 'Oct 24', dd: -2.3 },
    { label: 'Nov 24', dd: 0 },
    { label: 'Dec 24', dd: -1.7 },
    { label: 'Jan 25', dd: 0 },
    { label: 'Feb 25', dd: 0 },
  ];

  const ddSvgWidth = 700;
  const ddSvgHeight = 160;
  const ddPadX = 30;
  const ddPadY = 20;
  const maxDD = -15; // bottom scale

  const ddCoords = drawdownPoints.map((d, i) => {
    const x = ddPadX + (i / (drawdownPoints.length - 1)) * (ddSvgWidth - ddPadX * 2);
    // 0 dd is at top (ddPadY), -15 is at bottom (ddSvgHeight - ddPadY)
    const y = ddPadY + (Math.abs(d.dd) / Math.abs(maxDD)) * (ddSvgHeight - ddPadY * 2);
    return { x, y, dd: d.dd, label: d.label };
  });

  const ddPolyline = ddCoords.map(c => `${c.x},${c.y}`).join(' ');
  const ddArea = `${ddPadX},${ddPadY} ${ddPolyline} ${ddSvgWidth - ddPadX},${ddPadY}`;

  return (
    <div className="space-y-6 pb-12">
      {/* Performance Top Hero Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-white tracking-wide">
              PERFORMANCE LEDGER & BENCHMARK ALPHA
            </h1>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-[#0A2640] text-[#00F0FF] border border-[#00F0FF]/30">
              CUMULATIVE ROI +61.2%
            </span>
          </div>
          <p className="text-xs text-[#6F95B7] mt-0.5">
            Institutional multi-horizon audit of compounded returns, factor risk-adjusted alpha, and drawdown resilience.
          </p>
        </div>

        {/* Quick Stat Pill */}
        <div className="flex items-center gap-2">
          <div className="px-3 py-1.5 rounded-lg bg-[#091D2F] border border-[#14395D] flex items-center gap-2 font-mono text-xs">
            <Award className="w-4 h-4 text-[#00F0FF]" />
            <span className="text-[#6D93B5]">Information Ratio:</span>
            <span className="text-white font-bold">1.42 (High Alpha)</span>
          </div>
        </div>
      </div>

      {/* Trailing Returns Comparison Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="p-4 rounded-xl bg-[#091D2F] border border-[#133A5F]">
          <div className="text-[10px] font-mono text-[#618BAE] uppercase">Year To Date (YTD)</div>
          <div className="text-2xl font-bold font-mono text-[#34D399] mt-1">+8.3%</div>
          <div className="text-xs text-[#80A6CA] font-mono mt-0.5">
            vs S&P 500: <strong className="text-white">+5.9%</strong> (+2.4% alpha)
          </div>
        </div>

        <div className="p-4 rounded-xl bg-[#091D2F] border border-[#133A5F]">
          <div className="text-[10px] font-mono text-[#618BAE] uppercase">1-Year Trailing Return</div>
          <div className="text-2xl font-bold font-mono text-[#34D399] mt-1">+28.4%</div>
          <div className="text-xs text-[#80A6CA] font-mono mt-0.5">
            vs S&P 500: <strong className="text-white">+23.2%</strong> (+5.2% alpha)
          </div>
        </div>

        <div className="p-4 rounded-xl bg-[#091D2F] border border-[#133A5F]">
          <div className="text-[10px] font-mono text-[#618BAE] uppercase">3-Year Trailing Return</div>
          <div className="text-2xl font-bold font-mono text-[#34D399] mt-1">+61.2%</div>
          <div className="text-xs text-[#80A6CA] font-mono mt-0.5">
            vs S&P 500: <strong className="text-white">+42.1%</strong> (+19.1% alpha)
          </div>
        </div>

        <div className="p-4 rounded-xl bg-[#091D2F] border border-[#133A5F]">
          <div className="text-[10px] font-mono text-[#618BAE] uppercase">Sharpe / Volatility</div>
          <div className="text-2xl font-bold font-mono text-white mt-1">1.76 / 14.8%</div>
          <div className="text-xs text-[#00F0FF] font-mono mt-0.5">
            Top decile efficiency vs 60/40
          </div>
        </div>
      </div>

      {/* SHOWPIECE 1: INSTITUTIONAL MONTHLY RETURNS HEATMAP CALENDAR */}
      <div className="p-5 rounded-2xl bg-[#091D2F] border border-[#133A5F] shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-[#00F0FF]" />
              <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wider">
                MONTHLY RETURNS MATRIX (COMPOUNDED HEATMAP)
              </h3>
            </div>
            <p className="text-xs text-[#6F95B7] mt-0.5">
              Exact monthly net performance and active benchmark delta. Darker green indicates strong outperformance; rose indicates consolidation.
            </p>
          </div>

          <div className="flex items-center gap-2 bg-[#061421] p-1 rounded-lg border border-[#12314F] text-xs font-mono">
            <button
              onClick={() => setReturnType('NET')}
              className={`px-2.5 py-1 rounded transition-all ${
                returnType === 'NET' ? 'bg-[#00F0FF] text-[#07131D] font-bold' : 'text-[#6D93B5] hover:text-white'
              }`}
            >
              Net Return %
            </button>
            <button
              onClick={() => setReturnType('ALPHA')}
              className={`px-2.5 py-1 rounded transition-all ${
                returnType === 'ALPHA' ? 'bg-[#00F0FF] text-[#07131D] font-bold' : 'text-[#6D93B5] hover:text-white'
              }`}
            >
              Active Alpha vs S&P
            </button>
          </div>
        </div>

        {/* Heatmap Grid */}
        <div className="overflow-x-auto">
          <table className="w-full text-center text-xs font-mono border-collapse">
            <thead>
              <tr className="border-b border-[#123555] text-[#5581A6] text-[10px] uppercase">
                <th className="p-2.5 text-left pl-3 font-semibold">Year</th>
                {months.map(m => (
                  <th key={m} className="p-2.5 font-semibold">{m}</th>
                ))}
                <th className="p-2.5 font-bold text-white border-l border-[#123555]">YTD Total</th>
                <th className="p-2.5 font-bold text-[#8FB5DB]">Benchmark</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#102C48]">
              {years.map(year => {
                const yearTotal = getYearTotal(year);
                const yearBench = getYearBenchmarkTotal(year);

                return (
                  <tr key={year} className="hover:bg-[#0C243B]/40 transition-colors">
                    <td className="p-3 text-left pl-3 font-bold text-white">{year}</td>
                    {months.map((m, idx) => {
                      const data = getMonthData(year, idx);
                      if (!data) {
                        return (
                          <td key={m} className="p-2 text-[#3D5B77] bg-[#071725]/40 text-[10px]">
                            —
                          </td>
                        );
                      }

                      const val = returnType === 'NET' 
                        ? data.portfolioReturn 
                        : (data.portfolioReturn - data.benchmarkReturn);

                      const isPositive = val >= 0;

                      // Color intensity based on return size
                      let bgClass = '';
                      if (val > 5.0) bgClass = 'bg-[#10B981]/35 text-[#6EE7B7] font-bold border border-[#10B981]/40';
                      else if (val > 2.0) bgClass = 'bg-[#10B981]/20 text-[#34D399] font-semibold';
                      else if (val >= 0) bgClass = 'bg-[#10B981]/10 text-[#34D399]';
                      else if (val > -3.0) bgClass = 'bg-[#F43F5E]/15 text-[#FB7185]';
                      else bgClass = 'bg-[#F43F5E]/30 text-[#FDA4AF] font-bold border border-[#F43F5E]/40';

                      return (
                        <td key={m} className="p-2">
                          <div className={`py-1.5 px-1 rounded-md text-xs tabular-nums ${bgClass}`}>
                            {isPositive ? '+' : ''}{val.toFixed(1)}%
                          </div>
                        </td>
                      );
                    })}

                    {/* Annual Total */}
                    <td className="p-2 border-l border-[#123555]">
                      <div className={`py-1.5 px-2 rounded-md font-bold text-xs ${
                        yearTotal >= 0 ? 'bg-[#10B981]/25 text-[#34D399]' : 'bg-[#F43F5E]/25 text-[#FB7185]'
                      }`}>
                        {yearTotal >= 0 ? '+' : ''}{yearTotal.toFixed(1)}%
                      </div>
                    </td>

                    {/* Benchmark Annual Total */}
                    <td className="p-2 text-[#94A3B8] font-semibold">
                      +{yearBench.toFixed(1)}%
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* SHOWPIECE 2: MULTI-HORIZON BENCHMARK BATTLE LADDER */}
      <div className="p-5 rounded-2xl bg-[#091D2F] border border-[#133A5F] shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4 text-[#00F0FF]" />
              <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wider">
                BENCHMARK BATTLE LADDER & FACTOR DECOMPOSITION
              </h3>
            </div>
            <p className="text-xs text-[#6F95B7] mt-0.5">
              Head-to-head performance metrics against standard passive index portfolios.
            </p>
          </div>

          <div className="text-xs font-mono text-[#5881A4]">
            Data window: 3-Year Annualized
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono border-collapse">
            <thead>
              <tr className="border-b border-[#123555] bg-[#071625] text-[#5581A6] text-[10px] uppercase">
                <th className="p-3 pl-4">Asset / Benchmark</th>
                <th className="p-3 text-right">YTD</th>
                <th className="p-3 text-right">1-Year Return</th>
                <th className="p-3 text-right">3-Year Compounded</th>
                <th className="p-3 text-right">Annual Volatility</th>
                <th className="p-3 text-right">Sharpe Ratio</th>
                <th className="p-3 text-right pr-4">Max Drawdown</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#102C48]">
              {BENCHMARKS.map((b, idx) => {
                const isMeridian = idx === 0;

                return (
                  <tr
                    key={b.name}
                    className={`transition-colors ${
                      isMeridian 
                        ? 'bg-[#00F0FF]/10 hover:bg-[#00F0FF]/15 border-l-2 border-[#00F0FF]' 
                        : 'hover:bg-[#0C243B]/40'
                    }`}
                  >
                    <td className="p-3 pl-4">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: b.color }} />
                        <span className={`font-bold ${isMeridian ? 'text-[#00F0FF]' : 'text-white'}`}>
                          {b.name}
                        </span>
                        {isMeridian && (
                          <span className="text-[9px] px-1.5 py-0.2 rounded bg-[#00F0FF]/20 text-[#00F0FF] border border-[#00F0FF]/30">
                            YOUR PORTFOLIO
                          </span>
                        )}
                      </div>
                    </td>

                    <td className="p-3 text-right font-bold text-[#34D399]">
                      +{b.ytd.toFixed(1)}%
                    </td>

                    <td className="p-3 text-right font-bold text-[#34D399]">
                      +{b.oneYear.toFixed(1)}%
                    </td>

                    <td className="p-3 text-right font-bold text-white">
                      +{b.threeYear.toFixed(1)}%
                    </td>

                    <td className="p-3 text-right text-[#CBD5E1]">
                      {b.volatility.toFixed(1)}%
                    </td>

                    <td className={`p-3 text-right font-bold ${isMeridian ? 'text-[#00F0FF]' : 'text-[#CBD5E1]'}`}>
                      {b.sharpe.toFixed(2)}
                    </td>

                    <td className="p-3 text-right pr-4 font-semibold text-[#FB7185]">
                      {b.maxDrawdown.toFixed(1)}%
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* SHOWPIECE 3: UNDERWATER DRAWDOWN OCEAN TRENCH */}
      <div className="p-5 rounded-2xl bg-[#091D2F] border border-[#133A5F] shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-[#FB7185]" />
              <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wider">
                UNDERWATER DRAWDOWN OCEAN TRENCH (PEAK-TO-TROUGH STRESS)
              </h3>
            </div>
            <p className="text-xs text-[#6F95B7] mt-0.5">
              Measures depth beneath previous equity high-water mark. Shallow trenches prove robust downside capital defense.
            </p>
          </div>

          <div className="flex items-center gap-4 text-xs font-mono">
            <div>
              <span className="text-[#6D93B5]">MAX DRAWDOWN:</span>
              <strong className="text-[#FB7185] ml-1.5">-11.4%</strong>
            </div>
            <div>
              <span className="text-[#6D93B5]">RECOVERY DURATION:</span>
              <strong className="text-white ml-1.5">44 Days</strong>
            </div>
          </div>
        </div>

        {/* SVG Drawdown Chart */}
        <div className="w-full overflow-x-auto bg-[#071625] p-3 rounded-xl border border-[#12314F]">
          <svg viewBox={`0 0 ${ddSvgWidth} ${ddSvgHeight}`} className="w-full h-40 select-none">
            <defs>
              <linearGradient id="trenchGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#FB7185" stopOpacity="0.05" />
                <stop offset="100%" stopColor="#FB7185" stopOpacity="0.4" />
              </linearGradient>
            </defs>

            {/* High-water mark baseline (0% DD) */}
            <line
              x1={ddPadX}
              y1={ddPadY}
              x2={ddSvgWidth - ddPadX}
              y2={ddPadY}
              stroke="#34D399"
              strokeWidth="1.5"
              strokeDasharray="4,4"
            />
            <text x={ddPadX} y={ddPadY - 6} fill="#34D399" fontSize="10" fontFamily="monospace">
              0.0% High-Water Mark (Peak Equity)
            </text>

            {/* -10% guideline */}
            <line
              x1={ddPadX}
              y1={ddPadY + (10 / 15) * (ddSvgHeight - ddPadY * 2)}
              x2={ddSvgWidth - ddPadX}
              y2={ddPadY + (10 / 15) * (ddSvgHeight - ddPadY * 2)}
              stroke="#1F3C59"
              strokeWidth="1"
              strokeDasharray="2,2"
            />
            <text x={ddPadX} y={ddPadY + (10 / 15) * (ddSvgHeight - ddPadY * 2) - 4} fill="#547D9F" fontSize="9" fontFamily="monospace">
              -10.0% Correction Threshold
            </text>

            {/* Drawdown polygon fill */}
            <polygon points={ddArea} fill="url(#trenchGradient)" />

            {/* Drawdown stroke line */}
            <polyline
              fill="none"
              stroke="#FB7185"
              strokeWidth="2"
              points={ddPolyline}
            />

            {/* Deepest point badge */}
            <circle
              cx={ddCoords[7].x}
              cy={ddCoords[7].y}
              r="5"
              fill="#07131D"
              stroke="#FB7185"
              strokeWidth="2"
            />
            <text
              x={ddCoords[7].x}
              y={ddCoords[7].y + 16}
              fill="#FB7185"
              fontSize="10"
              fontFamily="monospace"
              fontWeight="bold"
              textAnchor="middle"
            >
              -11.4% (Aug 24)
            </text>
          </svg>
        </div>

        <div className="flex items-center justify-between text-[11px] font-mono text-[#5881A4] px-2">
          <span>Stress Episode: Yen Carry Trade Unwind & Rate Volatility (Jul-Aug 2024)</span>
          <span className="text-[#34D399]">Full High-Water Mark Restoration: Sept 18, 2024</span>
        </div>
      </div>
    </div>
  );
};
