import React, { useState } from 'react';
import { 
  Activity, 
  Globe2, 
  Coins, 
  PieChart, 
  Flame, 
  Scale 
} from 'lucide-react';
import { CurrencyRate } from '../types';
import { HEALTH_DIMENSIONS, STRESS_SCENARIOS, RISK_PROFILE } from '../data/portfolioData';
import { HoldingCalculations } from '../utils/portfolioCalculations';

interface AnalysisViewProps {
  enrichedHoldings: HoldingCalculations[];
  sectors: { name: string; valueUSD: number; weightPercent: number }[];
  regions: { name: string; valueUSD: number; weightPercent: number }[];
  currency: CurrencyRate;
  onNavigate: (path: string) => void;
}

export const AnalysisView: React.FC<AnalysisViewProps> = ({
  sectors,
  regions,
  onNavigate
}) => {
  const [selectedFactor, setSelectedFactor] = useState<number>(0);
  const [activeScenario, setActiveScenario] = useState<string>('s-1');

  // Currency exposure breakdown calculation
  const currencyExposures = [
    { code: 'USD', name: 'US Dollar', percent: 79.4, color: '#00F0FF' },
    { code: 'EUR', name: 'Euro', percent: 14.2, color: '#38BDF8' },
    { code: 'TWD', name: 'Taiwan Dollar', percent: 4.4, color: '#818CF8' },
    { code: 'HKD', name: 'Hong Kong Dollar', percent: 2.0, color: '#F59E0B' },
  ];

  const currentScenario = STRESS_SCENARIOS.find(s => s.id === activeScenario) || STRESS_SCENARIOS[0];

  return (
    <div className="space-y-6 pb-12">
      {/* Analysis Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-white tracking-wide">
              RISK ARCHITECTURE & EXPOSURE ENGINE
            </h1>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-[#0A2640] text-[#00F0FF] border border-[#00F0FF]/30">
              MERIDIAN AUDIT SCORE: 84 / 100
            </span>
          </div>
          <p className="text-xs text-[#6F95B7] mt-0.5">
            Deep factor risk attribution, multi-currency geographic decomposition, and macroeconomic stress simulations.
          </p>
        </div>

        {/* Quick action button to rebalance */}
        <button
          onClick={() => onNavigate('#portfolio/rebalance')}
          className="px-3 py-1.5 rounded-lg bg-[#0E3554] hover:bg-[#14476F] border border-[#00F0FF]/30 text-[#00F0FF] text-xs font-semibold flex items-center gap-1.5 self-start md:self-auto transition-all"
        >
          <Scale className="w-3.5 h-3.5" />
          <span>Adjust Exposure via Rebalancer</span>
        </button>
      </div>

      {/* Risk Metrics Quick Matrix */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="p-4 rounded-xl bg-[#091D2F] border border-[#133A5F]">
          <div className="text-[10px] font-mono text-[#618BAE] uppercase">1-Day VaR (95% Conf.)</div>
          <div className="text-2xl font-bold font-mono text-[#FB7185] mt-1">
            {RISK_PROFILE.valueAtRisk95}%
          </div>
          <div className="text-xs text-[#80A6CA] font-mono mt-0.5">
            Max expected 24H loss at 95% certainty
          </div>
        </div>

        <div className="p-4 rounded-xl bg-[#091D2F] border border-[#133A5F]">
          <div className="text-[10px] font-mono text-[#618BAE] uppercase">Annual Volatility</div>
          <div className="text-2xl font-bold font-mono text-white mt-1">
            {RISK_PROFILE.annualizedVol}%
          </div>
          <div className="text-xs text-[#80A6CA] font-mono mt-0.5">
            Annualized standard deviation
          </div>
        </div>

        <div className="p-4 rounded-xl bg-[#091D2F] border border-[#133A5F]">
          <div className="text-[10px] font-mono text-[#618BAE] uppercase">S&P Correlation & R²</div>
          <div className="text-2xl font-bold font-mono text-[#00F0FF] mt-1">
            0.89 / 0.81
          </div>
          <div className="text-xs text-[#80A6CA] font-mono mt-0.5">
            Strong market beta correlation
          </div>
        </div>

        <div className="p-4 rounded-xl bg-[#091D2F] border border-[#133A5F]">
          <div className="text-[10px] font-mono text-[#618BAE] uppercase">Cash Yield Drag</div>
          <div className="text-2xl font-bold font-mono text-[#34D399] mt-1">
            0.58%
          </div>
          <div className="text-xs text-[#80A6CA] font-mono mt-0.5">
            Minimal drag; yielding 4.65%
          </div>
        </div>
      </div>

      {/* SHOWPIECE 1: MERIDIAN 6-FACTOR HEALTH AUDIT RADAR */}
      <div className="p-5 rounded-2xl bg-[#091D2F] border border-[#133A5F] shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-[#00F0FF]" />
              <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wider">
                MERIDIAN 6-FACTOR CONDITION ASSESSMENT
              </h3>
            </div>
            <p className="text-xs text-[#6F95B7] mt-0.5">
              Comprehensive institutional health scorecard evaluating portfolio durability across 6 independent axes.
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono">
            <span className="text-[#6D93B5]">OVERALL RATING:</span>
            <span className="px-2 py-0.5 rounded bg-[#10B981]/20 text-[#34D399] font-bold border border-[#10B981]/40">
              ROBUST & DEFENSIBLE
            </span>
          </div>
        </div>

        {/* 6-Factor Interactive Selection Strip */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2 pt-2">
          {HEALTH_DIMENSIONS.map((dim, idx) => {
            const isSelected = selectedFactor === idx;
            const isAlert = dim.status === 'Alert';
            const isCaution = dim.status === 'Caution';

            return (
              <button
                key={dim.name}
                onClick={() => setSelectedFactor(idx)}
                className={`p-3 rounded-xl border text-left transition-all ${
                  isSelected
                    ? 'bg-[#0E3554] border-[#00F0FF] shadow-[0_0_12px_rgba(0,240,255,0.2)]'
                    : 'bg-[#07192A] border-[#133250] hover:border-[#1F4D77]'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className={`text-[10px] font-mono font-bold px-1.5 py-0.2 rounded ${
                    isAlert 
                      ? 'bg-[#F43F5E]/20 text-[#FB7185]' 
                      : isCaution
                      ? 'bg-[#F59E0B]/20 text-[#F59E0B]'
                      : 'bg-[#10B981]/20 text-[#34D399]'
                  }`}>
                    {dim.status}
                  </span>
                  <span className="text-xs font-mono font-bold text-white">{dim.score}</span>
                </div>
                <div className="text-xs font-semibold text-white truncate max-w-[120px]">
                  {dim.name.split('&')[0]}
                </div>
              </button>
            );
          })}
        </div>

        {/* Detailed Factor Inspection Card */}
        {(() => {
          const activeDim = HEALTH_DIMENSIONS[selectedFactor];
          return (
            <div className="p-4 rounded-xl bg-[#071625] border border-[#14395D] space-y-3 animate-in fade-in">
              <div className="flex items-center justify-between border-b border-[#12314F] pb-3">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-bold text-white font-mono">{activeDim.name}</span>
                  <span className="text-xs font-mono text-[#00F0FF]">Score: {activeDim.score}/100</span>
                </div>
                <span className="text-xs font-mono text-[#6A94BB]">DIAGNOSTIC INSPECTION</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
                <div className="space-y-1">
                  <div className="text-[#6D93B5] uppercase text-[10px]">Observable Market Signal:</div>
                  <p className="text-white bg-[#0A1F33] p-3 rounded-lg border border-[#133A5F] leading-relaxed">
                    {activeDim.observation}
                  </p>
                </div>

                <div className="space-y-1">
                  <div className="text-[#00F0FF] uppercase text-[10px]">Meridian Tactical Directive:</div>
                  <p className="text-[#CBD5E1] bg-[#0A1F33] p-3 rounded-lg border border-[#133A5F] leading-relaxed">
                    {activeDim.recommendation}
                  </p>
                </div>
              </div>
            </div>
          );
        })()}
      </div>

      {/* SHOWPIECE 2: MULTI-DIMENSIONAL EXPOSURE TRI-DECOMPOSITION */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Dimension 1: Sector Exposure */}
        <div className="p-5 rounded-2xl bg-[#091D2F] border border-[#133A5F] space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <PieChart className="w-4 h-4 text-[#00F0FF]" />
              <h3 className="text-xs font-bold font-mono uppercase text-white tracking-wider">
                SECTOR CONCENTRATION
              </h3>
            </div>
            <span className="text-[10px] font-mono text-[#5580A5]">MAX CAP 35%</span>
          </div>

          <div className="space-y-2 pt-1">
            {sectors.slice(0, 5).map(s => (
              <div key={s.name} className="space-y-1">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-[#CBD5E1] truncate max-w-[170px]">{s.name}</span>
                  <span className="text-white font-bold">{s.weightPercent.toFixed(1)}%</span>
                </div>
                <div className="w-full h-1.5 bg-[#061421] rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-[#0E4466] to-[#00F0FF]"
                    style={{ width: `${s.weightPercent}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Dimension 2: Geographic / Regional Exposure */}
        <div className="p-5 rounded-2xl bg-[#091D2F] border border-[#133A5F] space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Globe2 className="w-4 h-4 text-[#38BDF8]" />
              <h3 className="text-xs font-bold font-mono uppercase text-white tracking-wider">
                GEOGRAPHIC JURISDICTION
              </h3>
            </div>
            <span className="text-[10px] font-mono text-[#5580A5]">GLOBAL DIVERSIFIED</span>
          </div>

          <div className="space-y-2 pt-1">
            {regions.map(r => (
              <div key={r.name} className="space-y-1">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-[#CBD5E1]">{r.name}</span>
                  <span className="text-white font-bold">{r.weightPercent.toFixed(1)}%</span>
                </div>
                <div className="w-full h-1.5 bg-[#061421] rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-[#0E4466] to-[#38BDF8]"
                    style={{ width: `${r.weightPercent}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Dimension 3: Currency Denomination Exposure */}
        <div className="p-5 rounded-2xl bg-[#091D2F] border border-[#133A5F] space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Coins className="w-4 h-4 text-[#34D399]" />
              <h3 className="text-xs font-bold font-mono uppercase text-white tracking-wider">
                CURRENCY SOVEREIGNTY
              </h3>
            </div>
            <span className="text-[10px] font-mono text-[#5580A5]">FX SENSITIVITY</span>
          </div>

          <div className="space-y-2 pt-1">
            {currencyExposures.map(c => (
              <div key={c.code} className="space-y-1">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-[#CBD5E1]">{c.code} ({c.name})</span>
                  <span className="text-white font-bold">{c.percent}%</span>
                </div>
                <div className="w-full h-1.5 bg-[#061421] rounded-full overflow-hidden">
                  <div
                    className="h-full"
                    style={{ width: `${c.percent}%`, backgroundColor: c.color }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* SHOWPIECE 3: SCENARIO STRESS ENGINE */}
      <div className="p-5 rounded-2xl bg-[#091D2F] border border-[#133A5F] shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <Flame className="w-4 h-4 text-[#FB7185]" />
              <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wider">
                MACRO SHOCK & CRISIS STRESS ENGINE
              </h3>
            </div>
            <p className="text-xs text-[#6F95B7] mt-0.5">
              Simulated deterministic shocks against historical volatility regimes and liquidity stress.
            </p>
          </div>

          <span className="text-xs font-mono text-[#FB7185] bg-[#FB7185]/10 px-2.5 py-1 rounded-md border border-[#FB7185]/30">
            Simulated Drawdown Test
          </span>
        </div>

        {/* Stress Scenarios Selector Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
          {STRESS_SCENARIOS.map(sc => {
            const isSelected = activeScenario === sc.id;
            return (
              <button
                key={sc.id}
                onClick={() => setActiveScenario(sc.id)}
                className={`p-3 rounded-xl border text-left transition-all ${
                  isSelected
                    ? 'bg-[#181E2F] border-[#FB7185] shadow-[0_0_12px_rgba(251,113,133,0.2)]'
                    : 'bg-[#071725] border-[#133250] hover:border-[#22507B]'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-bold text-white font-mono truncate max-w-[130px]">
                    {sc.title.split('(')[0]}
                  </span>
                  <span className="text-xs font-mono font-bold text-[#FB7185]">
                    {sc.estimatedImpactPercent}%
                  </span>
                </div>
                <div className="text-[10px] text-[#6E95BA] truncate">
                  {sc.narrative}
                </div>
              </button>
            );
          })}
        </div>

        {/* Selected Scenario Active War-Room Readout */}
        <div className="p-4 rounded-xl bg-[#061421] border border-[#163B5F] space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#12314F] pb-2 text-xs font-mono">
            <span className="text-white font-bold">{currentScenario.title}</span>
            <span className="text-[#FB7185] font-bold text-sm">
              Estimated Net Portfolio Drawdown: {currentScenario.estimatedImpactPercent}%
            </span>
          </div>

          <p className="text-xs text-[#CBD5E1] leading-relaxed">
            {currentScenario.narrative}
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-xs font-mono">
            <div className="p-2.5 rounded-lg bg-[#2A1119] border border-[#FB7185]/30">
              <div className="text-[10px] text-[#FB7185] uppercase font-bold">Vulnerable Holdings Under Fire:</div>
              <div className="text-white font-semibold mt-1">{currentScenario.mostVulnerableAsset}</div>
            </div>

            <div className="p-2.5 rounded-lg bg-[#0B2A20] border border-[#10B981]/30">
              <div className="text-[10px] text-[#34D399] uppercase font-bold">Asymmetric Defensive Cushion:</div>
              <div className="text-white font-semibold mt-1">{currentScenario.primaryCushion}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
