import React from 'react';
import { 
  ArrowUpRight, 
  ArrowDownRight, 
  Plus, 
  Target
} from 'lucide-react';

interface WatchlistViewProps {
  onOpenTradeModal: () => void;
}

export const WatchlistView: React.FC<WatchlistViewProps> = ({ onOpenTradeModal }) => {
  const watchlist = [
    {
      symbol: 'BRK.B',
      name: 'Berkshire Hathaway Inc.',
      price: 462.40,
      dayChange: 0.32,
      targetBuyPrice: 430.00,
      peRatio: 18.4,
      thesis: 'Ultimate cash-flow compounding conglomerate with $320B cash fortress ready to deploy in panic.',
      status: 'Wait for pullback'
    },
    {
      symbol: 'MELI',
      name: 'MercadoLibre, Inc.',
      price: 1892.50,
      dayChange: -1.45,
      targetBuyPrice: 1750.00,
      peRatio: 42.1,
      thesis: 'Dominant Latin American fintech + commerce duopoly with expanding credit and fintech margins.',
      status: 'Trigger Zone Near'
    },
    {
      symbol: 'PLTR',
      name: 'Palantir Technologies',
      price: 68.20,
      dayChange: 3.12,
      targetBuyPrice: 52.00,
      peRatio: 94.2,
      thesis: 'Enterprise AIP bootcamps driving exponential commercial adoption; valuation currently too stretched.',
      status: 'Overvalued - Hold'
    },
    {
      symbol: 'ARM',
      name: 'Arm Holdings plc',
      price: 138.40,
      dayChange: 2.15,
      targetBuyPrice: 110.00,
      peRatio: 78.5,
      thesis: 'Architecture royalty rate increases on v9 adoption across smartphones, servers, and automotive.',
      status: 'Wait for pullback'
    }
  ];

  return (
    <div className="space-y-6 pb-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-white tracking-wide">
              WATCHLIST RADAR & PIPELINE TARGETS
            </h1>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-[#0A2640] text-[#00F0FF] border border-[#00F0FF]/30">
              4 CANDIDATES
            </span>
          </div>
          <p className="text-xs text-[#6F95B7] mt-0.5">
            Pre-researched compounders queued for deployment when valuation triggers or margin of safety is met.
          </p>
        </div>

        <button
          onClick={onOpenTradeModal}
          className="px-3 py-1.5 rounded-lg bg-[#0E3554] hover:bg-[#14476F] border border-[#00F0FF]/30 text-[#00F0FF] text-xs font-semibold flex items-center gap-1.5 transition-all self-start md:self-auto"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add Candidate to Portfolio</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {watchlist.map(item => {
          const isPos = item.dayChange >= 0;
          return (
            <div
              key={item.symbol}
              className="p-5 rounded-2xl bg-[#091D2F] border border-[#133A5F] hover:border-[#1E4D77] transition-all space-y-3"
            >
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-base font-bold font-mono text-white">${item.symbol}</span>
                    <span className="text-xs text-[#8DB2D6] font-semibold">{item.name}</span>
                  </div>
                </div>
                <div className="text-right font-mono">
                  <div className="text-sm font-bold text-white">${item.price.toFixed(2)}</div>
                  <div className={`text-xs font-semibold flex items-center justify-end ${isPos ? 'text-[#34D399]' : 'text-[#FB7185]'}`}>
                    {isPos ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                    {isPos ? `+${item.dayChange.toFixed(2)}%` : `${item.dayChange.toFixed(2)}%`}
                  </div>
                </div>
              </div>

              <p className="text-xs text-[#CBD5E1] leading-relaxed bg-[#071625] p-3 rounded-xl border border-[#12314F]">
                {item.thesis}
              </p>

              <div className="pt-2 border-t border-[#12314F] flex items-center justify-between text-xs font-mono">
                <div className="flex items-center gap-2">
                  <Target className="w-3.5 h-3.5 text-[#00F0FF]" />
                  <span className="text-[#6D93B5]">Buy Target:</span>
                  <strong className="text-white">${item.targetBuyPrice.toFixed(2)}</strong>
                </div>

                <span className="px-2 py-0.5 rounded bg-[#0A2640] text-[#00F0FF] border border-[#00F0FF]/30 font-semibold text-[11px]">
                  {item.status}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
