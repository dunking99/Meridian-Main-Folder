import React from 'react';
import { 
  Calendar, 
  ShieldCheck 
} from 'lucide-react';
import { CurrencyRate } from '../types';
import { HoldingCalculations, formatCurrency } from '../utils/portfolioCalculations';

interface IncomeViewProps {
  enrichedHoldings: HoldingCalculations[];
  annualIncomeUSD: number;
  portfolioYieldPercent: number;
  currency: CurrencyRate;
  onNavigate: (path: string) => void;
}

export const IncomeView: React.FC<IncomeViewProps> = ({
  enrichedHoldings,
  annualIncomeUSD,
  portfolioYieldPercent,
  currency,
  onNavigate
}) => {
  // Monthly projected distributions (Jan - Dec)
  const monthlyDistributions = [
    { month: 'Jan', amountUSD: 380, payers: ['TLT', 'USD_CASH'] },
    { month: 'Feb', amountUSD: 520, payers: ['AAPL', 'USD_CASH'] },
    { month: 'Mar', amountUSD: 740, payers: ['MSFT', 'NVO', 'TLT', 'USD_CASH'] },
    { month: 'Apr', amountUSD: 610, payers: ['ASML', 'TSM', 'USD_CASH'] },
    { month: 'May', amountUSD: 850, payers: ['RHM', 'NVO', 'USD_CASH'] },
    { month: 'Jun', amountUSD: 690, payers: ['MSFT', 'TLT', 'USD_CASH'] },
    { month: 'Jul', amountUSD: 410, payers: ['TSM', 'USD_CASH'] },
    { month: 'Aug', amountUSD: 490, payers: ['AAPL', 'USD_CASH'] },
    { month: 'Sep', amountUSD: 720, payers: ['MSFT', 'TLT', 'USD_CASH'] },
    { month: 'Oct', amountUSD: 580, payers: ['TSM', 'USD_CASH'] },
    { month: 'Nov', amountUSD: 480, payers: ['NVO', 'USD_CASH'] },
    { month: 'Dec', amountUSD: 820, payers: ['MSFT', 'TLT', 'BABA', 'USD_CASH'] },
  ];

  const maxMonthUSD = Math.max(...monthlyDistributions.map(m => m.amountUSD));

  // Dividend payers sorted by annual income contribution
  const dividendPayers = enrichedHoldings
    .filter(h => (h.holding.annualDividend || 0) > 0 || h.holding.dividendYield > 0)
    .map(h => {
      const annualDivForHolding = (h.holding.annualDividend || 0) * h.holding.shares;
      return {
        holding: h.holding,
        annualDiv: annualDivForHolding,
        yield: h.holding.dividendYield,
        shares: h.holding.shares,
        weight: h.weightPercent
      };
    })
    .sort((a, b) => b.annualDiv - a.annualDiv);

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-white tracking-wide">
              PASSIVE CASH FLOW & DIVIDEND ENGINE
            </h1>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-[#0A2640] text-[#00F0FF] border border-[#00F0FF]/30">
              YIELD 2.12% NET
            </span>
          </div>
          <p className="text-xs text-[#6F95B7] mt-0.5">
            Forward 12-month calendar of dividend distributions, safety ratings, and yield on invested cost.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="px-3 py-1.5 rounded-lg bg-[#091D2F] border border-[#14395D] flex items-center gap-2 font-mono text-xs">
            <ShieldCheck className="w-4 h-4 text-[#34D399]" />
            <span className="text-[#6D93B5]">Dividend Safety Score:</span>
            <span className="text-white font-bold">96 / 100 (High Coverage)</span>
          </div>
        </div>
      </div>

      {/* Income Summary Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="p-4 rounded-xl bg-[#091D2F] border border-[#133A5F]">
          <div className="text-[10px] font-mono text-[#618BAE] uppercase">Projected Annual Cash Flow</div>
          <div className="text-2xl font-bold font-mono text-[#34D399] mt-1">
            {formatCurrency(annualIncomeUSD, currency)}
          </div>
          <div className="text-xs text-[#80A6CA] font-mono mt-0.5">
            ~{formatCurrency(annualIncomeUSD / 12, currency)} monthly average
          </div>
        </div>

        <div className="p-4 rounded-xl bg-[#091D2F] border border-[#133A5F]">
          <div className="text-[10px] font-mono text-[#618BAE] uppercase">Portfolio Forward Yield</div>
          <div className="text-2xl font-bold font-mono text-white mt-1">
            {portfolioYieldPercent.toFixed(2)}%
          </div>
          <div className="text-xs text-[#80A6CA] font-mono mt-0.5">
            Equity dividends + 4.65% cash sweep
          </div>
        </div>

        <div className="p-4 rounded-xl bg-[#091D2F] border border-[#133A5F]">
          <div className="text-[10px] font-mono text-[#618BAE] uppercase">Yield on Invested Cost</div>
          <div className="text-2xl font-bold font-mono text-[#00F0FF] mt-1">
            2.94%
          </div>
          <div className="text-xs text-[#80A6CA] font-mono mt-0.5">
            Compound growth from original basis
          </div>
        </div>

        <div className="p-4 rounded-xl bg-[#091D2F] border border-[#133A5F]">
          <div className="text-[10px] font-mono text-[#618BAE] uppercase">5-Yr Dividend CAGR</div>
          <div className="text-2xl font-bold font-mono text-white mt-1">
            +11.8%
          </div>
          <div className="text-xs text-[#34D399] font-mono mt-0.5">
            Outpacing core CPI inflation
          </div>
        </div>
      </div>

      {/* SHOWPIECE: 12-MONTH DIVIDEND DISTRIBUTION BAR CALENDAR */}
      <div className="p-5 rounded-2xl bg-[#091D2F] border border-[#133A5F] shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-[#00F0FF]" />
              <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wider">
                12-MONTH FORWARD PAYOUT CALENDAR
              </h3>
            </div>
            <p className="text-xs text-[#6F95B7] mt-0.5">
              Estimated distributions arriving by month with contributing asset badges.
            </p>
          </div>

          <div className="text-xs font-mono text-[#5881A4]">
            Peak Payout Month: <strong className="text-white">May ({formatCurrency(850, currency)})</strong>
          </div>
        </div>

        {/* Bar chart grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 lg:grid-cols-12 gap-2 pt-3">
          {monthlyDistributions.map(item => {
            const heightPct = (item.amountUSD / maxMonthUSD) * 100;
            return (
              <div
                key={item.month}
                className="p-2.5 rounded-xl bg-[#071625] border border-[#12314F] hover:border-[#00F0FF]/40 flex flex-col justify-between transition-all group"
              >
                <div className="text-[11px] font-mono font-bold text-white text-center pb-1 border-b border-[#102C48]">
                  {item.month}
                </div>

                {/* Vertical bar */}
                <div className="py-3 flex flex-col justify-end h-24 items-center">
                  <div
                    className="w-full max-w-[28px] rounded-t-md bg-gradient-to-t from-[#0E4466] to-[#00F0FF] group-hover:to-[#38BDF8] transition-all"
                    style={{ height: `${heightPct}%` }}
                  />
                </div>

                <div className="text-center font-mono text-xs font-bold text-[#34D399]">
                  {formatCurrency(item.amountUSD, currency, true)}
                </div>

                <div className="mt-1 text-[9px] text-[#5A82A5] font-mono text-center truncate" title={item.payers.join(', ')}>
                  {item.payers.length} assets
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* DIVIDEND CONTRIBUTOR BREAKDOWN TABLE */}
      <div className="p-5 rounded-2xl bg-[#091D2F] border border-[#133A5F] shadow-xl space-y-4">
        <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wider">
          ANNUAL CASH FLOW CONTRIBUTION BY ASSET
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono border-collapse">
            <thead>
              <tr className="border-b border-[#123555] bg-[#071625] text-[#5581A6] text-[10px] uppercase">
                <th className="p-3 pl-4">Asset</th>
                <th className="p-3 text-right">Dividend Yield</th>
                <th className="p-3 text-right">Annual Div / Sh</th>
                <th className="p-3 text-right">Shares Held</th>
                <th className="p-3 text-right">Annual Projected Income</th>
                <th className="p-3 text-right pr-4">Income Share %</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#102C48]">
              {dividendPayers.map(item => {
                const incomeSharePct = annualIncomeUSD > 0 ? (item.annualDiv / annualIncomeUSD) * 100 : 0;
                return (
                  <tr
                    key={item.holding.id}
                    onClick={() => onNavigate(`#portfolio/holdings/${item.holding.symbol}`)}
                    className="hover:bg-[#0E2D4A]/50 cursor-pointer transition-colors"
                  >
                    <td className="p-3 pl-4">
                      <span className="font-bold text-white">${item.holding.symbol}</span>
                      <span className="text-[#6D95BA] ml-2 text-[11px]">{item.holding.name}</span>
                    </td>

                    <td className="p-3 text-right font-bold text-[#34D399]">
                      {item.yield.toFixed(2)}%
                    </td>

                    <td className="p-3 text-right text-white">
                      ${item.holding.annualDividend.toFixed(2)}
                    </td>

                    <td className="p-3 text-right text-[#CBD5E1]">
                      {item.shares.toLocaleString()}
                    </td>

                    <td className="p-3 text-right font-bold text-[#00F0FF]">
                      {formatCurrency(item.annualDiv, currency)}
                    </td>

                    <td className="p-3 text-right pr-4 font-semibold text-white">
                      {incomeSharePct.toFixed(1)}%
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
