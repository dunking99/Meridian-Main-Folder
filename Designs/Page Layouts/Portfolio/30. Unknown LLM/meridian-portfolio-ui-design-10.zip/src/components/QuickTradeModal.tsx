import React, { useState } from 'react';
import { 
  X, 
  ArrowUpRight, 
  ArrowDownRight, 
  Check 
} from 'lucide-react';
import { Holding, CurrencyRate } from '../types';
import { formatCurrency } from '../utils/portfolioCalculations';

interface QuickTradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  holdings: Holding[];
  initialHolding?: Holding | null;
  currency: CurrencyRate;
  onExecuteTrade: (trade: {
    symbol: string;
    type: 'BUY' | 'SELL';
    shares: number;
    price: number;
  }) => void;
}

export const QuickTradeModal: React.FC<QuickTradeModalProps> = ({
  isOpen,
  onClose,
  holdings,
  initialHolding,
  currency,
  onExecuteTrade
}) => {
  if (!isOpen) return null;

  const [selectedSymbol, setSelectedSymbol] = useState<string>(
    initialHolding ? initialHolding.symbol : holdings[0]?.symbol || 'NVDA'
  );
  const [tradeType, setTradeType] = useState<'BUY' | 'SELL'>('BUY');
  const [shares, setShares] = useState<number>(10);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const selectedHolding = holdings.find(h => h.symbol === selectedSymbol) || holdings[0];
  const totalTradeValueUSD = (shares || 0) * (selectedHolding?.currentPrice || 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedHolding || shares <= 0) return;

    if (tradeType === 'SELL' && shares > selectedHolding.shares) {
      alert(`Cannot sell more shares than currently held (${selectedHolding.shares} shs).`);
      return;
    }

    onExecuteTrade({
      symbol: selectedSymbol,
      type: tradeType,
      shares,
      price: selectedHolding.currentPrice
    });

    setSuccessMessage(`Simulated ${tradeType} of ${shares} ${selectedSymbol} executed at $${selectedHolding.currentPrice.toFixed(2)}.`);
    setTimeout(() => {
      setSuccessMessage(null);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#091E33] border border-[#16446E] rounded-2xl w-full max-w-md overflow-hidden shadow-2xl animate-in fade-in zoom-in-95 duration-150">
        <div className="p-4 border-b border-[#133A5F] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-sm font-bold text-white font-mono uppercase tracking-wider">
              SIMULATE LOT ORDER
            </span>
            <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-[#00F0FF]/15 text-[#00F0FF] border border-[#00F0FF]/30">
              PAPER TRADING
            </span>
          </div>

          <button onClick={onClose} className="p-1 text-[#6A94BA] hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        {successMessage ? (
          <div className="p-8 text-center space-y-3">
            <div className="w-12 h-12 rounded-full bg-[#10B981]/20 text-[#34D399] flex items-center justify-center mx-auto border border-[#10B981]/40">
              <Check className="w-6 h-6" />
            </div>
            <div className="text-sm font-bold text-white font-mono">ORDER CONFIRMED</div>
            <p className="text-xs text-[#CBD5E1]">{successMessage}</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-5 space-y-4">
            {/* Buy / Sell Toggle */}
            <div className="grid grid-cols-2 gap-2 bg-[#061421] p-1 rounded-xl border border-[#12314F]">
              <button
                type="button"
                onClick={() => setTradeType('BUY')}
                className={`py-2 rounded-lg text-xs font-mono font-bold transition-all flex items-center justify-center gap-1.5 ${
                  tradeType === 'BUY'
                    ? 'bg-[#10B981] text-[#07131D]'
                    : 'text-[#6D93B5] hover:text-white'
                }`}
              >
                <ArrowUpRight className="w-3.5 h-3.5" />
                <span>BUY / ACCUMULATE</span>
              </button>
              <button
                type="button"
                onClick={() => setTradeType('SELL')}
                className={`py-2 rounded-lg text-xs font-mono font-bold transition-all flex items-center justify-center gap-1.5 ${
                  tradeType === 'SELL'
                    ? 'bg-[#F43F5E] text-white'
                    : 'text-[#6D93B5] hover:text-white'
                }`}
              >
                <ArrowDownRight className="w-3.5 h-3.5" />
                <span>SELL / TRIM</span>
              </button>
            </div>

            {/* Select Asset */}
            <div>
              <label className="block text-xs font-mono text-[#6D93B5] mb-1">Target Position</label>
              <select
                value={selectedSymbol}
                onChange={e => setSelectedSymbol(e.target.value)}
                className="w-full px-3 py-2 bg-[#061421] border border-[#14395D] rounded-lg text-white font-mono text-xs focus:outline-none focus:border-[#00F0FF]"
              >
                {holdings.map(h => (
                  <option key={h.id} value={h.symbol}>
                    ${h.symbol} — {h.name} (${h.currentPrice.toFixed(2)})
                  </option>
                ))}
              </select>
            </div>

            {/* Shares input */}
            <div>
              <div className="flex justify-between items-center text-xs font-mono text-[#6D93B5] mb-1">
                <span>Number of Units</span>
                <span>Currently Held: {selectedHolding.shares} shs</span>
              </div>
              <input
                type="number"
                min="1"
                value={shares}
                onChange={e => setShares(Math.max(1, parseInt(e.target.value) || 0))}
                className="w-full px-3 py-2 bg-[#061421] border border-[#14395D] rounded-lg text-white font-mono text-sm focus:outline-none focus:border-[#00F0FF]"
              />
            </div>

            {/* Trade Summary */}
            <div className="p-3 rounded-xl bg-[#071625] border border-[#12314F] space-y-1.5 text-xs font-mono">
              <div className="flex justify-between text-[#6D93B5]">
                <span>Market Execution Price:</span>
                <span className="text-white">${selectedHolding.currentPrice.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-[#6D93B5]">
                <span>Total Consideration:</span>
                <span className="text-[#00F0FF] font-bold">
                  {formatCurrency(totalTradeValueUSD, currency)}
                </span>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-mono text-[#6D93B5] hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                className={`px-5 py-2 rounded-lg text-xs font-mono font-bold transition-all ${
                  tradeType === 'BUY'
                    ? 'bg-[#00F0FF] hover:bg-[#38BDF8] text-[#07131D]'
                    : 'bg-[#F43F5E] hover:bg-[#FB7185] text-white'
                }`}
              >
                Execute Simulated {tradeType}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
