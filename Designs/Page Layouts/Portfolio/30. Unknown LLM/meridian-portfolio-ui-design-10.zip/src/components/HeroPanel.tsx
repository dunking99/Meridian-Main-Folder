import React from 'react';
import { 
  PieChart, 
  Layers, 
  TrendingUp, 
  ShieldAlert, 
  Scale, 
  DollarSign, 
  Globe2, 
  Newspaper, 
  Bookmark, 
  BookOpen, 
  Compass,
  ArrowUpRight,
  ArrowDownRight,
  PlusCircle,
  Activity
} from 'lucide-react';
import { CurrencyCode, CurrencyRate } from '../types';
import { CURRENCIES } from '../data/portfolioData';
import { formatCurrency, formatPercent } from '../utils/portfolioCalculations';

interface HeroPanelProps {
  currentPath: string;
  onNavigate: (path: string) => void;
  currency: CurrencyRate;
  onCurrencyChange: (code: CurrencyCode) => void;
  totalValueUSD: number;
  todayGainUSD: number;
  todayChangePercent: number;
  healthScore: number;
  topGainer: { symbol: string; change: number };
  worstLoser: { symbol: string; change: number };
  onOpenTradeModal: () => void;
}

export const HeroPanel: React.FC<HeroPanelProps> = ({
  currentPath,
  onNavigate,
  currency,
  onCurrencyChange,
  totalValueUSD,
  todayGainUSD,
  todayChangePercent,
  healthScore,
  topGainer,
  worstLoser,
  onOpenTradeModal
}) => {
  const isPositiveDay = todayGainUSD >= 0;

  const navItems = [
    {
      group: 'PORTFOLIO',
      items: [
        { path: '#portfolio/overview', label: 'Overview', icon: PieChart, badge: 'Live' },
        { path: '#portfolio/holdings', label: 'Holdings Matrix', icon: Layers, count: '11' },
        { path: '#portfolio/performance', label: 'Performance & Alpha', icon: TrendingUp },
        { path: '#portfolio/analysis', label: 'Risk & Condition', icon: ShieldAlert, alert: true },
        { path: '#portfolio/rebalance', label: 'Drift & Rebalance', icon: Scale },
        { path: '#portfolio/income', label: 'Income & Cash Flow', icon: DollarSign },
      ]
    },
    {
      group: 'INTELLIGENCE & CONTEXT',
      items: [
        { path: '#markets', label: 'Macro & Global Markets', icon: Globe2 },
        { path: '#news', label: 'Holdings Intelligence', icon: Newspaper, count: '6' },
        { path: '#watchlist', label: 'Watchlist & Radars', icon: Bookmark },
        { path: '#journal', label: 'Thesis & Decisions', icon: BookOpen, count: '4' },
      ]
    }
  ];

  // Micro sparkline for 24H intraday trend
  const sparklinePoints = isPositiveDay
    ? "0,28 15,25 30,22 45,26 60,18 75,20 90,14 105,16 120,8 135,11 150,5 165,7 180,3"
    : "0,5 15,9 30,8 45,14 60,12 75,19 90,16 105,22 120,20 135,25 150,24 165,27 180,30";

  return (
    <aside className="w-full lg:w-[320px] xl:w-[350px] shrink-0 bg-[#081726] border-r border-[#13304D]/70 flex flex-col min-h-screen text-[#E2E8F0]">
      {/* Brand Header */}
      <div className="p-5 border-b border-[#122A44] flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-[#00F0FF]/25 via-[#0E4466] to-[#051E33] border border-[#00F0FF]/40 flex items-center justify-center shadow-[0_0_15px_rgba(0,240,255,0.18)]">
            <Compass className="w-5 h-5 text-[#00F0FF]" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold tracking-wider text-base text-white">MERIDIAN</span>
              <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-[#0E3554] text-[#00F0FF] border border-[#00F0FF]/30">OS</span>
            </div>
            <p className="text-[11px] text-[#7E9EB8] tracking-tight">Sovereign Markets Intelligence</p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 px-2 py-1 rounded bg-[#0A1F33] border border-[#173D61] text-[11px] font-mono text-[#00F0FF]">
          <span className="w-1.5 h-1.5 rounded-full bg-[#00F0FF] animate-pulse"></span>
          <span>T+0</span>
        </div>
      </div>

      {/* Persistent Hero Metric: Total Net Worth */}
      <div className="p-5 bg-gradient-to-b from-[#0B1E32] to-[#081726] border-b border-[#122A44] relative overflow-hidden">
        {/* Glow ambient background */}
        <div className="absolute -top-12 -right-12 w-36 h-36 bg-[#00F0FF]/5 rounded-full blur-2xl pointer-events-none" />

        <div className="flex items-center justify-between text-xs text-[#7E9EB8] mb-1.5">
          <span className="uppercase tracking-wider font-semibold text-[10px] text-[#6F95B5]">PORTFOLIO NET ASSETS</span>
          
          {/* Currency Switcher */}
          <div className="flex items-center gap-0.5 bg-[#06121E] p-0.5 rounded-md border border-[#14324E]">
            {Object.keys(CURRENCIES).map((cKey) => {
              const active = currency.code === cKey;
              return (
                <button
                  key={cKey}
                  onClick={() => onCurrencyChange(cKey as CurrencyCode)}
                  className={`px-1.5 py-0.5 text-[10px] font-mono rounded font-medium transition-all ${
                    active
                      ? 'bg-[#00F0FF] text-[#07131D] font-bold shadow-[0_0_8px_rgba(0,240,255,0.4)]'
                      : 'text-[#6F95B5] hover:text-[#E2E8F0] hover:bg-[#0F2840]'
                  }`}
                  title={`Switch currency to ${cKey}`}
                >
                  {cKey}
                </button>
              );
            })}
          </div>
        </div>

        {/* Master Value */}
        <div className="mt-1">
          <div className="text-2xl xl:text-3xl font-bold tracking-tight text-white tabular-nums drop-shadow-sm">
            {formatCurrency(totalValueUSD, currency)}
          </div>

          <div className="flex items-center gap-2 mt-2">
            <span
              className={`inline-flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded-md tabular-nums ${
                isPositiveDay
                  ? 'bg-[#10B981]/15 text-[#34D399] border border-[#10B981]/30'
                  : 'bg-[#F43F5E]/15 text-[#FB7185] border border-[#F43F5E]/30'
              }`}
            >
              {isPositiveDay ? (
                <ArrowUpRight className="w-3.5 h-3.5" />
              ) : (
                <ArrowDownRight className="w-3.5 h-3.5" />
              )}
              {formatPercent(todayChangePercent)} ({formatCurrency(todayGainUSD, currency)})
            </span>
            <span className="text-[11px] text-[#6F95B5]">today</span>
          </div>
        </div>

        {/* Intraday elevation graph sparkline */}
        <div className="mt-3.5 pt-2.5 border-t border-[#122A44]/80 flex items-center justify-between">
          <div className="text-[10px] text-[#6F95B5] font-mono">
            INTRADAY TRAJECTORY
          </div>
          <svg className="w-24 h-6 overflow-visible" viewBox="0 0 180 32">
            <defs>
              <linearGradient id="sparklineGlow" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={isPositiveDay ? "#34D399" : "#FB7185"} stopOpacity="0.4" />
                <stop offset="100%" stopColor={isPositiveDay ? "#34D399" : "#FB7185"} stopOpacity="0.0" />
              </linearGradient>
            </defs>
            <polyline
              fill="none"
              stroke={isPositiveDay ? "#34D399" : "#FB7185"}
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              points={sparklinePoints}
            />
          </svg>
        </div>
      </div>

      {/* Health Score Mini Barometer */}
      <div className="px-5 py-3 border-b border-[#122A44] bg-[#071523]/60 flex items-center justify-between text-xs">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-md bg-[#00F0FF]/10 border border-[#00F0FF]/25 flex items-center justify-center text-[#00F0FF]">
            <Activity className="w-3.5 h-3.5" />
          </div>
          <div>
            <div className="text-[10px] text-[#6F95B5] uppercase font-mono tracking-wider">Health Rating</div>
            <div className="font-semibold text-white">Condition: Robust</div>
          </div>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="text-base font-bold text-[#00F0FF] tabular-nums font-mono">{healthScore}</span>
          <span className="text-[10px] text-[#6F95B5]">/100</span>
        </div>
      </div>

      {/* Navigation Groups */}
      <div className="flex-1 overflow-y-auto px-3 py-4 space-y-6">
        {navItems.map((group) => (
          <div key={group.group}>
            <div className="px-2.5 mb-1.5 text-[10px] font-mono uppercase tracking-wider text-[#547B9C] font-semibold">
              {group.group}
            </div>
            <nav className="space-y-0.5">
              {group.items.map((item) => {
                const Icon = item.icon;
                // Match active path (exact match or holding sub-path)
                const isActive = currentPath === item.path || 
                  (item.path === '#portfolio/holdings' && currentPath.startsWith('#portfolio/holdings/'));

                return (
                  <button
                    key={item.path}
                    onClick={() => onNavigate(item.path)}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-all group ${
                      isActive
                        ? 'bg-gradient-to-r from-[#00F0FF]/20 to-[#0A2E4C] text-[#00F0FF] border border-[#00F0FF]/35 shadow-[0_2px_12px_rgba(0,240,255,0.1)]'
                        : 'text-[#9CB7D0] hover:text-white hover:bg-[#0D2439]'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <Icon
                        className={`w-4 h-4 transition-colors ${
                          isActive ? 'text-[#00F0FF]' : 'text-[#648BAF] group-hover:text-[#94B8DC]'
                        }`}
                      />
                      <span>{item.label}</span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {item.badge && (
                        <span className="text-[9px] px-1.5 py-0.2 rounded bg-[#00F0FF]/20 text-[#00F0FF] border border-[#00F0FF]/30 font-mono font-bold">
                          {item.badge}
                        </span>
                      )}
                      {item.count && (
                        <span className="text-[10px] font-mono text-[#6287A9] group-hover:text-[#8CB2D4]">
                          {item.count}
                        </span>
                      )}
                      {item.alert && (
                        <span className="w-1.5 h-1.5 rounded-full bg-[#F59E0B] shadow-[0_0_6px_#F59E0B]" />
                      )}
                    </div>
                  </button>
                );
              })}
            </nav>
          </div>
        ))}
      </div>

      {/* Hero Panel Bottom Drawer: Top Mover Radar & Action */}
      <div className="p-4 border-t border-[#122A44] bg-[#06121E]">
        <div className="text-[10px] font-mono uppercase tracking-wider text-[#577F9F] mb-2 font-semibold flex items-center justify-between">
          <span>PULSE MOVERS (24H)</span>
          <span className="text-[9px] text-[#43647F]">TICKER</span>
        </div>

        <div className="grid grid-cols-2 gap-2 mb-3">
          {/* Top Gainer */}
          <button
            onClick={() => onNavigate(`#portfolio/holdings/${topGainer.symbol}`)}
            className="p-2 rounded bg-[#0A1D2F] border border-[#10B981]/25 hover:border-[#10B981]/60 text-left transition-all group"
          >
            <div className="text-[10px] text-[#7197B8] flex items-center justify-between">
              <span>LEADER</span>
              <ArrowUpRight className="w-3 h-3 text-[#34D399]" />
            </div>
            <div className="text-xs font-bold text-white group-hover:text-[#00F0FF] font-mono">
              ${topGainer.symbol}
            </div>
            <div className="text-[11px] font-semibold text-[#34D399] font-mono">
              +{topGainer.change.toFixed(2)}%
            </div>
          </button>

          {/* Worst Loser */}
          <button
            onClick={() => onNavigate(`#portfolio/holdings/${worstLoser.symbol}`)}
            className="p-2 rounded bg-[#0A1D2F] border border-[#F43F5E]/25 hover:border-[#F43F5E]/60 text-left transition-all group"
          >
            <div className="text-[10px] text-[#7197B8] flex items-center justify-between">
              <span>LAGGARD</span>
              <ArrowDownRight className="w-3 h-3 text-[#FB7185]" />
            </div>
            <div className="text-xs font-bold text-white group-hover:text-[#00F0FF] font-mono">
              ${worstLoser.symbol}
            </div>
            <div className="text-[11px] font-semibold text-[#FB7185] font-mono">
              {worstLoser.change.toFixed(2)}%
            </div>
          </button>
        </div>

        {/* Quick Simulator Button */}
        <button
          onClick={onOpenTradeModal}
          className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-lg bg-[#0E3554] hover:bg-[#14476F] border border-[#00F0FF]/30 hover:border-[#00F0FF]/60 text-[#00F0FF] hover:text-white text-xs font-semibold transition-all shadow-[0_0_15px_rgba(0,240,255,0.08)]"
        >
          <PlusCircle className="w-3.5 h-3.5" />
          <span>Simulate Trade or Lot</span>
        </button>
      </div>
    </aside>
  );
};
