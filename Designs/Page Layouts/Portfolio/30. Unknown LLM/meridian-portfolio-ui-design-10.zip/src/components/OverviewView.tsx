import React, { useState } from 'react';
import { 
  TrendingUp, 
  ArrowUpRight, 
  ArrowDownRight, 
  Layers, 
  ChevronRight, 
  Zap, 
  Target, 
  Sparkles 
} from 'lucide-react';
import { Holding, CurrencyRate } from '../types';
import { HoldingCalculations, formatCurrency, formatPercent } from '../utils/portfolioCalculations';

interface OverviewViewProps {
  holdings: Holding[];
  enrichedHoldings: HoldingCalculations[];
  sectors: { name: string; valueUSD: number; weightPercent: number; count: number; dayChangePercent: number }[];
  totalValueUSD: number;
  totalGainUSD: number;
  totalGainPercent: number;
  todayGainUSD: number;
  todayChangePercent: number;
  currency: CurrencyRate;
  onNavigate: (path: string) => void;
}

export const OverviewView: React.FC<OverviewViewProps> = ({
  enrichedHoldings,
  sectors,
  totalValueUSD,
  totalGainUSD,
  totalGainPercent,
  todayGainUSD,
  todayChangePercent,
  currency,
  onNavigate
}) => {
  const [timeRange, setTimeRange] = useState<'1W' | '1M' | 'YTD' | '1Y' | '3Y' | 'ALL'>('1Y');
  const [benchmarkOverlay, setBenchmarkOverlay] = useState<'SPX' | 'NDX' | '6040' | 'NONE'>('SPX');
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);
  const [selectedSector, setSelectedSector] = useState<string | null>(null);

  // Time range data generator
  const getChartData = () => {
    switch (timeRange) {
      case '1W':
        return [
          { label: 'Mon', val: 284200, bench: 281000 },
          { label: 'Tue', val: 286400, bench: 282400 },
          { label: 'Wed', val: 285100, bench: 281900 },
          { label: 'Thu', val: 288900, bench: 283500 },
          { label: 'Fri', val: 291480, bench: 284900 },
        ];
      case '1M':
        return [
          { label: 'W1', val: 278000, bench: 275000 },
          { label: 'W2', val: 281200, bench: 277400 },
          { label: 'W3', val: 279500, bench: 276800 },
          { label: 'W4', val: 287400, bench: 281000 },
          { label: 'Now', val: 291480, bench: 284900 },
        ];
      case 'YTD':
        return [
          { label: 'Jan 02', val: 268500, bench: 268500 },
          { label: 'Jan 15', val: 273200, bench: 271000 },
          { label: 'Jan 31', val: 278900, bench: 275600 },
          { label: 'Feb 15', val: 284000, bench: 279200 },
          { label: 'Current', val: 291480, bench: 284900 },
        ];
      case '3Y':
        return [
          { label: '2022 Q1', val: 181000, bench: 195000 },
          { label: '2022 Q4', val: 164000, bench: 168000 },
          { label: '2023 Q2', val: 205000, bench: 198000 },
          { label: '2023 Q4', val: 232000, bench: 224000 },
          { label: '2024 Q2', val: 262000, bench: 251000 },
          { label: '2024 Q4', val: 278000, bench: 266000 },
          { label: '2025 Current', val: 291480, bench: 274000 },
        ];
      case 'ALL':
        return [
          { label: '2020', val: 95000, bench: 95000 },
          { label: '2021', val: 154000, bench: 122000 },
          { label: '2022', val: 142000, bench: 104000 },
          { label: '2023', val: 212000, bench: 152000 },
          { label: '2024', val: 270000, bench: 198000 },
          { label: '2025', val: 291480, bench: 215000 },
        ];
      case '1Y':
      default:
        return [
          { label: 'Mar 24', val: 228000, bench: 232000 },
          { label: 'Apr 24', val: 221000, bench: 224000 },
          { label: 'May 24', val: 236000, bench: 235000 },
          { label: 'Jun 24', val: 247000, bench: 244000 },
          { label: 'Jul 24', val: 242000, bench: 240000 },
          { label: 'Aug 24', val: 249000, bench: 245000 },
          { label: 'Sep 24', val: 254000, bench: 249000 },
          { label: 'Oct 24', val: 251000, bench: 246000 },
          { label: 'Nov 24', val: 269000, bench: 260000 },
          { label: 'Dec 24', val: 266000, bench: 256000 },
          { label: 'Jan 25', val: 279000, bench: 267000 },
          { label: 'Feb 25', val: 291480, bench: 276000 },
        ];
    }
  };

  const chartData = getChartData();
  const minVal = Math.min(...chartData.map(d => Math.min(d.val, benchmarkOverlay !== 'NONE' ? d.bench : d.val))) * 0.96;
  const maxVal = Math.max(...chartData.map(d => Math.max(d.val, benchmarkOverlay !== 'NONE' ? d.bench : d.val))) * 1.04;

  const svgWidth = 740;
  const svgHeight = 220;
  const paddingX = 40;
  const paddingY = 25;

  const pointsPortfolio = chartData.map((d, i) => {
    const x = paddingX + (i / (chartData.length - 1)) * (svgWidth - paddingX * 2);
    const y = svgHeight - paddingY - ((d.val - minVal) / (maxVal - minVal)) * (svgHeight - paddingY * 2);
    return { x, y, data: d };
  });

  const pointsBenchmark = chartData.map((d, i) => {
    const x = paddingX + (i / (chartData.length - 1)) * (svgWidth - paddingX * 2);
    const y = svgHeight - paddingY - ((d.bench - minVal) / (maxVal - minVal)) * (svgHeight - paddingY * 2);
    return { x, y, data: d };
  });

  const polylinePortfolio = pointsPortfolio.map(p => `${p.x},${p.y}`).join(' ');
  const polylineBenchmark = pointsBenchmark.map(p => `${p.x},${p.y}`).join(' ');
  const areaPortfolio = `${paddingX},${svgHeight - paddingY} ${polylinePortfolio} ${svgWidth - paddingX},${svgHeight - paddingY}`;

  const currentHover = hoverIndex !== null ? pointsPortfolio[hoverIndex] : pointsPortfolio[pointsPortfolio.length - 1];
  const benchmarkHover = hoverIndex !== null ? pointsBenchmark[hoverIndex] : pointsBenchmark[pointsBenchmark.length - 1];

  // Top holdings sorted by weight
  const topHoldings = [...enrichedHoldings].sort((a, b) => b.weightPercent - a.weightPercent).slice(0, 6);

  // Movers sorted by day change
  const sortedMovers = [...enrichedHoldings].sort((a, b) => Math.abs(b.holding.dayChangePercent) - Math.abs(a.holding.dayChangePercent));
  const topMovers = sortedMovers.slice(0, 4);

  // Sector colors palette: deep oceanic blues, teals, cyans, seafoams, amber, gold
  const sectorColors = [
    '#00F0FF', // Neon Cyan
    '#38BDF8', // Sky Cyan
    '#2DD4BF', // Teal
    '#34D399', // Emerald
    '#818CF8', // Indigo
    '#F59E0B', // Amber
    '#FB7185', // Rose
    '#94A3B8', // Slate
    '#64748B'  // Muted Slate
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Overview Top Command Strip */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-3.5">
        {/* Card 1: Aggregate Net Assets */}
        <div className="p-4 rounded-xl bg-[#091D2F] border border-[#14395D] relative overflow-hidden group">
          <div className="flex items-center justify-between text-[#6D93B5] text-xs mb-1 font-mono">
            <span>TOTAL ASSET POOL</span>
            <span className="text-[10px] text-[#00F0FF] px-1.5 py-0.5 rounded bg-[#00F0FF]/10 border border-[#00F0FF]/25">LIVE</span>
          </div>
          <div className="text-2xl font-bold text-white tabular-nums">
            {formatCurrency(totalValueUSD, currency)}
          </div>
          <div className="mt-2 flex items-center gap-2 text-xs">
            <span className={`inline-flex items-center font-mono font-semibold ${todayGainUSD >= 0 ? 'text-[#34D399]' : 'text-[#FB7185]'}`}>
              {todayGainUSD >= 0 ? <ArrowUpRight className="w-3.5 h-3.5" /> : <ArrowDownRight className="w-3.5 h-3.5" />}
              {formatPercent(todayChangePercent)}
            </span>
            <span className="text-[#6D93B5]">({formatCurrency(todayGainUSD, currency)} today)</span>
          </div>
        </div>

        {/* Card 2: Cumulative Unrealized Capital Gain */}
        <div className="p-4 rounded-xl bg-[#091D2F] border border-[#14395D]">
          <div className="flex items-center justify-between text-[#6D93B5] text-xs mb-1 font-mono">
            <span>ALL-TIME CAPITAL GAIN</span>
            <TrendingUp className="w-3.5 h-3.5 text-[#34D399]" />
          </div>
          <div className="text-2xl font-bold text-[#34D399] tabular-nums">
            +{formatCurrency(totalGainUSD, currency)}
          </div>
          <div className="mt-2 text-xs font-mono text-[#8EB0CD]">
            Total ROI: <span className="text-white font-semibold">+{totalGainPercent.toFixed(2)}%</span> on invested capital
          </div>
        </div>

        {/* Card 3: Meridian Quality & Beta Score */}
        <div className="p-4 rounded-xl bg-[#091D2F] border border-[#14395D]">
          <div className="flex items-center justify-between text-[#6D93B5] text-xs mb-1 font-mono">
            <span>PORTFOLIO BETA & SHARPE</span>
            <Zap className="w-3.5 h-3.5 text-[#00F0FF]" />
          </div>
          <div className="flex items-baseline gap-3">
            <span className="text-2xl font-bold text-white tabular-nums font-mono">1.08</span>
            <span className="text-xs text-[#7198BD]">Beta vs S&P</span>
          </div>
          <div className="mt-2 flex items-center justify-between text-xs text-[#8EB0CD] font-mono">
            <span>Sharpe Ratio: <strong className="text-[#00F0FF]">1.76</strong></span>
            <span>Sortino: <strong className="text-white">2.42</strong></span>
          </div>
        </div>

        {/* Card 4: Drift & Rebalance Alert */}
        <div className="p-4 rounded-xl bg-[#091D2F] border border-[#14395D] flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#6D93B5] text-xs mb-1 font-mono">
            <span>TARGET ALLOCATION STATUS</span>
            <span className="w-2 h-2 rounded-full bg-[#F59E0B] shadow-[0_0_8px_#F59E0B]" />
          </div>
          <div>
            <div className="text-base font-bold text-white flex items-center gap-1.5">
              <span>2 Positions Drifted</span>
              <span className="text-xs text-[#F59E0B] font-mono">&gt; 2.5%</span>
            </div>
            <p className="text-[11px] text-[#7198BD] mt-0.5">NVDA overweight (+3.8%), BABA underweight (-1.6%)</p>
          </div>
          <button
            onClick={() => onNavigate('#portfolio/rebalance')}
            className="mt-2 flex items-center justify-between text-[11px] font-mono text-[#00F0FF] hover:underline"
          >
            <span>Review Rebalancing Engine</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* SHOWPIECE 1: Interactive Multi-Horizon Equity Chart with Benchmark Overlay */}
      <div className="p-5 rounded-2xl bg-gradient-to-b from-[#091D2F] to-[#071625] border border-[#133A5F] shadow-xl relative">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-white tracking-wide">
                PORTFOLIO VALUATION TRAJECTORY
              </h2>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-[#0A2640] text-[#00F0FF] border border-[#00F0FF]/30">
                ALPHA ENGINE
              </span>
            </div>
            <p className="text-xs text-[#6F95B7] mt-0.5">
              Total equity compounding over time with institutional benchmark comparisons and scrub crosshair.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Benchmark Overlay Selector */}
            <div className="flex items-center gap-1 bg-[#061421] p-1 rounded-lg border border-[#12314F] text-xs font-mono">
              <span className="text-[10px] text-[#557F9F] px-1.5 uppercase">Benchmark:</span>
              <button
                onClick={() => setBenchmarkOverlay('SPX')}
                className={`px-2 py-0.5 rounded ${benchmarkOverlay === 'SPX' ? 'bg-[#184468] text-white font-bold' : 'text-[#779EB] hover:text-white'}`}
              >
                S&P 500
              </button>
              <button
                onClick={() => setBenchmarkOverlay('NDX')}
                className={`px-2 py-0.5 rounded ${benchmarkOverlay === 'NDX' ? 'bg-[#184468] text-[#38BDF8] font-bold' : 'text-[#779EB] hover:text-white'}`}
              >
                Nasdaq 100
              </button>
              <button
                onClick={() => setBenchmarkOverlay('6040')}
                className={`px-2 py-0.5 rounded ${benchmarkOverlay === '6040' ? 'bg-[#184468] text-white font-bold' : 'text-[#779EB] hover:text-white'}`}
              >
                60/40
              </button>
              <button
                onClick={() => setBenchmarkOverlay('NONE')}
                className={`px-2 py-0.5 rounded ${benchmarkOverlay === 'NONE' ? 'bg-[#184468] text-white font-bold' : 'text-[#779EB] hover:text-white'}`}
              >
                Off
              </button>
            </div>

            {/* Time Horizon Pills */}
            <div className="flex items-center bg-[#061421] p-1 rounded-lg border border-[#12314F] text-xs font-mono">
              {(['1W', '1M', 'YTD', '1Y', '3Y', 'ALL'] as const).map((r) => (
                <button
                  key={r}
                  onClick={() => {
                    setTimeRange(r);
                    setHoverIndex(null);
                  }}
                  className={`px-2.5 py-1 rounded text-xs transition-all ${
                    timeRange === r
                      ? 'bg-[#00F0FF] text-[#07131D] font-bold shadow-[0_0_10px_rgba(0,240,255,0.35)]'
                      : 'text-[#6D93B5] hover:text-white'
                  }`}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Hover Readout Bar */}
        <div className="p-3 mb-2 rounded-xl bg-[#061421]/90 border border-[#123250] flex flex-wrap items-center justify-between gap-4 text-xs font-mono">
          <div className="flex items-center gap-3">
            <span className="text-[#5984A9]">PERIOD:</span>
            <span className="text-white font-bold">{currentHover.data.label}</span>
          </div>

          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#00F0FF] shadow-[0_0_8px_#00F0FF]"></span>
              <span className="text-[#7EA2C1]">Meridian Portfolio:</span>
              <span className="text-white font-bold text-sm">
                {formatCurrency(currentHover.data.val, currency)}
              </span>
            </div>

            {benchmarkOverlay !== 'NONE' && (
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#94A3B8]"></span>
                <span className="text-[#7EA2C1]">{benchmarkOverlay}:</span>
                <span className="text-[#CBD5E1] font-semibold">
                  {formatCurrency(benchmarkHover.data.bench, currency)}
                </span>
                <span className="text-[#34D399] font-bold text-[11px] ml-1">
                  +{((currentHover.data.val - benchmarkHover.data.bench) / benchmarkHover.data.bench * 100).toFixed(1)}% Alpha
                </span>
              </div>
            )}
          </div>
        </div>

        {/* SVG Equity Chart with Hover Crosshairs */}
        <div className="relative w-full overflow-x-auto">
          <svg
            viewBox={`0 0 ${svgWidth} ${svgHeight}`}
            className="w-full h-56 select-none cursor-crosshair"
            onMouseLeave={() => setHoverIndex(null)}
          >
            <defs>
              <linearGradient id="oceanGlow" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#00F0FF" stopOpacity="0.28" />
                <stop offset="60%" stopColor="#0E3E64" stopOpacity="0.10" />
                <stop offset="100%" stopColor="#071725" stopOpacity="0.0" />
              </linearGradient>

              <pattern id="gridLines" width="60" height="40" patternUnits="userSpaceOnUse">
                <path d="M 60 0 L 0 0 0 40" fill="none" stroke="#122A44" strokeWidth="0.8" strokeDasharray="3,3" />
              </pattern>
            </defs>

            {/* Subtle background grid */}
            <rect width={svgWidth} height={svgHeight} fill="url(#gridLines)" opacity="0.6" />

            {/* Shaded Area */}
            <polygon points={areaPortfolio} fill="url(#oceanGlow)" />

            {/* Benchmark line (if enabled) */}
            {benchmarkOverlay !== 'NONE' && (
              <polyline
                fill="none"
                stroke="#64748B"
                strokeWidth="1.8"
                strokeDasharray="4,4"
                points={polylineBenchmark}
              />
            )}

            {/* Main Portfolio Equity Curve */}
            <polyline
              fill="none"
              stroke="#00F0FF"
              strokeWidth="2.8"
              strokeLinecap="round"
              strokeLinejoin="round"
              points={polylinePortfolio}
            />

            {/* Interactive Data Points and Scrub */}
            {pointsPortfolio.map((p, i) => (
              <g key={i}>
                {/* Vertical hover crosshair */}
                {hoverIndex === i && (
                  <>
                    <line
                      x1={p.x}
                      y1={paddingY}
                      x2={p.x}
                      y2={svgHeight - paddingY}
                      stroke="#00F0FF"
                      strokeWidth="1.2"
                      strokeDasharray="2,2"
                    />
                    <circle
                      cx={p.x}
                      cy={p.y}
                      r="6"
                      fill="#07131D"
                      stroke="#00F0FF"
                      strokeWidth="2.5"
                    />
                  </>
                )}

                {/* Invisible hit area for scrubbing */}
                <rect
                  x={p.x - 20}
                  y={0}
                  width="40"
                  height={svgHeight}
                  fill="transparent"
                  onMouseEnter={() => setHoverIndex(i)}
                />
              </g>
            ))}
          </svg>
        </div>

        <div className="flex items-center justify-between px-2 pt-2 text-[10px] text-[#5A82A5] font-mono border-t border-[#122F4C]">
          <span>START: {chartData[0].label} ({formatCurrency(chartData[0].val, currency)})</span>
          <span className="text-[#00F0FF]">MAX ELEVATION: {formatCurrency(maxVal, currency)}</span>
          <span>CURRENT: {chartData[chartData.length - 1].label} ({formatCurrency(chartData[chartData.length - 1].val, currency)})</span>
        </div>
      </div>

      {/* SHOWPIECE 2: Deep Sea Concentric Ring & Sector Allocation Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Col: Concentric Allocation Ring & Active Sector Drilldown */}
        <div className="lg:col-span-7 p-5 rounded-2xl bg-[#091D2F] border border-[#133A5F]">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-[#00F0FF]" />
                <h3 className="text-sm font-bold text-white tracking-wide uppercase font-mono">
                  SECTOR ALLOCATION & CONCENTRATION CORRIDOR
                </h3>
              </div>
              <p className="text-xs text-[#6F95B7] mt-0.5">
                Visualizing invested capital density across industry pillars. Click any sector to isolate holdings.
              </p>
            </div>

            {selectedSector && (
              <button
                onClick={() => setSelectedSector(null)}
                className="text-xs font-mono text-[#00F0FF] hover:underline"
              >
                Clear filter
              </button>
            )}
          </div>

          {/* Allocation Bar Spectrum */}
          <div className="w-full h-5 rounded-lg overflow-hidden flex bg-[#061421] border border-[#14395D] mb-4">
            {sectors.map((sec, idx) => {
              const color = sectorColors[idx % sectorColors.length];
              const isSelected = selectedSector === sec.name;
              return (
                <div
                  key={sec.name}
                  onClick={() => setSelectedSector(selectedSector === sec.name ? null : sec.name)}
                  style={{
                    width: `${sec.weightPercent}%`,
                    backgroundColor: color,
                    opacity: selectedSector ? (isSelected ? 1.0 : 0.25) : 0.95
                  }}
                  className="h-full transition-all cursor-pointer hover:opacity-100 relative group"
                  title={`${sec.name}: ${sec.weightPercent.toFixed(1)}%`}
                />
              );
            })}
          </div>

          {/* Sectors Interactive Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {sectors.map((sec, idx) => {
              const color = sectorColors[idx % sectorColors.length];
              const isSelected = selectedSector === sec.name;
              return (
                <button
                  key={sec.name}
                  onClick={() => setSelectedSector(isSelected ? null : sec.name)}
                  className={`p-2.5 rounded-xl border text-left transition-all ${
                    isSelected
                      ? 'bg-[#0E3150] border-[#00F0FF] shadow-[0_0_12px_rgba(0,240,255,0.15)]'
                      : 'bg-[#07192A] border-[#133250] hover:border-[#225585]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: color }} />
                      <span className="text-xs font-semibold text-white truncate max-w-[140px]">{sec.name}</span>
                    </div>
                    <span className="text-xs font-mono font-bold text-[#00F0FF]">
                      {sec.weightPercent.toFixed(1)}%
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-[#6D93B5] font-mono">
                    <span>{formatCurrency(sec.valueUSD, currency)}</span>
                    <span className={sec.dayChangePercent >= 0 ? 'text-[#34D399]' : 'text-[#FB7185]'}>
                      {formatPercent(sec.dayChangePercent)}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Drilldown view when sector selected */}
          {selectedSector && (
            <div className="mt-4 p-3 rounded-xl bg-[#061421] border border-[#00F0FF]/30 animate-in fade-in">
              <div className="text-xs font-mono text-[#00F0FF] mb-2 font-semibold">
                Holdings in {selectedSector}:
              </div>
              <div className="space-y-1.5">
                {enrichedHoldings
                  .filter(h => h.holding.sector === selectedSector)
                  .map(h => (
                    <div
                      key={h.holding.id}
                      onClick={() => onNavigate(`#portfolio/holdings/${h.holding.symbol}`)}
                      className="flex items-center justify-between p-2 rounded bg-[#0A1F33] hover:bg-[#10304E] cursor-pointer text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-white">${h.holding.symbol}</span>
                        <span className="text-[#84A9CC]">{h.holding.name}</span>
                      </div>
                      <div className="flex items-center gap-3 font-mono">
                        <span className="text-white">{formatCurrency(h.currentValueUSD, currency)}</span>
                        <span className="text-[#00F0FF] font-semibold">{h.weightPercent.toFixed(1)}% weight</span>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          )}
        </div>

        {/* Right Col: Top Holdings & Mover Pulse Radar */}
        <div className="lg:col-span-5 space-y-4">
          {/* Top Holdings Quick Dossier */}
          <div className="p-5 rounded-2xl bg-[#091D2F] border border-[#133A5F]">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Target className="w-4 h-4 text-[#00F0FF]" />
                <h3 className="text-xs font-mono font-bold uppercase text-white tracking-wider">
                  TOP HOLDINGS ANCHORS
                </h3>
              </div>
              <button
                onClick={() => onNavigate('#portfolio/holdings')}
                className="text-xs font-mono text-[#00F0FF] hover:underline flex items-center gap-1"
              >
                <span>View All (11)</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-2">
              {topHoldings.map((item) => (
                <div
                  key={item.holding.id}
                  onClick={() => onNavigate(`#portfolio/holdings/${item.holding.symbol}`)}
                  className="p-2.5 rounded-xl bg-[#07192A] hover:bg-[#0E2C4A] border border-[#12314F] hover:border-[#00F0FF]/40 cursor-pointer transition-all flex items-center justify-between group"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-[#0C243B] border border-[#173E63] flex items-center justify-center font-mono font-bold text-xs text-white group-hover:text-[#00F0FF]">
                      {item.holding.symbol.slice(0, 3)}
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white group-hover:text-[#00F0FF] transition-colors">
                        ${item.holding.symbol}
                      </div>
                      <div className="text-[10px] text-[#6991B4] truncate max-w-[120px]">
                        {item.holding.name}
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="text-xs font-mono font-semibold text-white">
                      {formatCurrency(item.currentValueUSD, currency)}
                    </div>
                    <div className="text-[10px] font-mono text-[#00F0FF]">
                      {item.weightPercent.toFixed(1)}% of pool
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* SHOWPIECE 3: Extreme Movers Pulse Spectrum */}
          <div className="p-5 rounded-2xl bg-[#091D2F] border border-[#133A5F]">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#34D399]" />
                <h3 className="text-xs font-mono font-bold uppercase text-white tracking-wider">
                  VOLATILITY PULSE & NOTABLE MOVERS
                </h3>
              </div>
              <span className="text-[10px] font-mono text-[#5C84A7]">SESSION DELTA</span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {topMovers.map((m) => {
                const isPos = m.holding.dayChangePercent >= 0;
                return (
                  <div
                    key={m.holding.id}
                    onClick={() => onNavigate(`#portfolio/holdings/${m.holding.symbol}`)}
                    className="p-2.5 rounded-xl bg-[#07192A] border border-[#12314F] hover:border-[#1F4C77] cursor-pointer transition-all"
                  >
                    <div className="flex items-center justify-between text-xs font-mono font-bold text-white mb-1">
                      <span>${m.holding.symbol}</span>
                      <span className={isPos ? 'text-[#34D399]' : 'text-[#FB7185]'}>
                        {formatPercent(m.holding.dayChangePercent)}
                      </span>
                    </div>
                    <div className="text-[10px] text-[#638CAF] truncate">
                      {m.holding.sector}
                    </div>
                    <div className="mt-1 text-[10px] font-mono text-[#91B4D6]">
                      Impact: {isPos ? '+' : ''}{formatCurrency(m.dayGainUSD, currency)}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
