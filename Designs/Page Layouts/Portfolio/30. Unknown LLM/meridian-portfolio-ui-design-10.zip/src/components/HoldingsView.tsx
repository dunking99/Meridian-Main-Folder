import React, { useState } from 'react';
import { 
  ArrowUpDown, 
  ArrowUpRight, 
  ArrowDownRight, 
  Grid3X3, 
  List, 
  Search, 
  AlertTriangle
} from 'lucide-react';
import { CurrencyRate } from '../types';
import { HoldingCalculations, formatCurrency, formatPercent } from '../utils/portfolioCalculations';

interface HoldingsViewProps {
  enrichedHoldings: HoldingCalculations[];
  currency: CurrencyRate;
  onNavigate: (path: string) => void;
  onOpenTradeModal: () => void;
}

export const HoldingsView: React.FC<HoldingsViewProps> = ({
  enrichedHoldings,
  currency,
  onNavigate,
  onOpenTradeModal
}) => {
  const [filterMode, setFilterMode] = useState<'ALL' | 'WINNERS' | 'LOSERS' | 'DRIFTED' | 'HIGH_CONVICTION'>('ALL');
  const [viewMode, setViewMode] = useState<'TABLE' | 'MATRIX'>('TABLE');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'weight' | 'gain' | 'dayChange' | 'value' | 'symbol'>('weight');
  const [sortAsc, setSortAsc] = useState(false);

  // Filter logic
  let filtered = enrichedHoldings.filter(item => {
    const matchesSearch = 
      item.holding.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.holding.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.holding.sector.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (!matchesSearch) return false;

    if (filterMode === 'WINNERS') return item.totalGainUSD > 0;
    if (filterMode === 'LOSERS') return item.totalGainUSD <= 0;
    if (filterMode === 'DRIFTED') return Math.abs(item.driftPercent) >= 2.0;
    if (filterMode === 'HIGH_CONVICTION') return item.holding.conviction === 'High';
    return true;
  });

  // Sort logic
  filtered.sort((a, b) => {
    let diff = 0;
    if (sortBy === 'weight') diff = b.weightPercent - a.weightPercent;
    if (sortBy === 'gain') diff = b.totalGainPercent - a.totalGainPercent;
    if (sortBy === 'dayChange') diff = b.holding.dayChangePercent - a.holding.dayChangePercent;
    if (sortBy === 'value') diff = b.currentValueUSD - a.currentValueUSD;
    if (sortBy === 'symbol') diff = a.holding.symbol.localeCompare(b.holding.symbol);
    return sortAsc ? -diff : diff;
  });

  const handleSort = (field: 'weight' | 'gain' | 'dayChange' | 'value' | 'symbol') => {
    if (sortBy === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortBy(field);
      setSortAsc(false);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Sub-page Header & Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-white tracking-wide">
              HOLDINGS REPOSITORY & DISPERSION
            </h1>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-[#0A2640] text-[#00F0FF] border border-[#00F0FF]/30">
              {filtered.length} ASSETS
            </span>
          </div>
          <p className="text-xs text-[#6F95B7] mt-0.5">
            Full ledger of equity, sovereign bond, real asset and cash reserves with real-time mark-to-market.
          </p>
        </div>

        {/* View mode & Action */}
        <div className="flex items-center gap-2">
          {/* Table vs Visual Matrix switch */}
          <div className="flex items-center bg-[#061421] p-1 rounded-lg border border-[#12314F] text-xs">
            <button
              onClick={() => setViewMode('TABLE')}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded transition-all ${
                viewMode === 'TABLE' ? 'bg-[#00F0FF] text-[#07131D] font-bold' : 'text-[#6D93B5] hover:text-white'
              }`}
            >
              <List className="w-3.5 h-3.5" />
              <span>Table</span>
            </button>
            <button
              onClick={() => setViewMode('MATRIX')}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded transition-all ${
                viewMode === 'MATRIX' ? 'bg-[#00F0FF] text-[#07131D] font-bold' : 'text-[#6D93B5] hover:text-white'
              }`}
            >
              <Grid3X3 className="w-3.5 h-3.5" />
              <span>Dispersion Matrix</span>
            </button>
          </div>

          <button
            onClick={onOpenTradeModal}
            className="px-3 py-1.5 rounded-lg bg-[#0E3554] hover:bg-[#14476F] border border-[#00F0FF]/30 text-[#00F0FF] text-xs font-semibold flex items-center gap-1.5 transition-all"
          >
            <span>+ Add Position</span>
          </button>
        </div>
      </div>

      {/* Filter and Quick Focus Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-3 rounded-xl bg-[#091D2F] border border-[#133A5F]">
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto">
          <span className="text-[10px] font-mono text-[#557F9F] uppercase px-1">Focus:</span>
          {(['ALL', 'WINNERS', 'LOSERS', 'DRIFTED', 'HIGH_CONVICTION'] as const).map((mode) => (
            <button
              key={mode}
              onClick={() => setFilterMode(mode)}
              className={`px-2.5 py-1 text-xs rounded-lg font-mono transition-all whitespace-nowrap ${
                filterMode === mode
                  ? 'bg-[#12395C] text-white border border-[#00F0FF]/40 font-bold'
                  : 'text-[#6990B3] hover:text-white hover:bg-[#0A2238]'
              }`}
            >
              {mode === 'ALL' && 'All Holdings'}
              {mode === 'WINNERS' && 'Top Gainers'}
              {mode === 'LOSERS' && 'Laggards / Drawdown'}
              {mode === 'DRIFTED' && 'Drift Alert (±2%)'}
              {mode === 'HIGH_CONVICTION' && 'High Conviction'}
            </button>
          ))}
        </div>

        {/* Search Input */}
        <div className="relative w-full sm:w-56">
          <Search className="w-3.5 h-3.5 text-[#557F9F] absolute left-2.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Filter by ticker or name..."
            className="w-full pl-8 pr-3 py-1 text-xs bg-[#061421] border border-[#12314F] rounded-lg text-white placeholder-[#557F9F] focus:outline-none focus:border-[#00F0FF]"
          />
        </div>
      </div>

      {/* SHOWPIECE 1: PERFORMANCE-SIZE DISPERSION TREEMAP & MATRIX */}
      {viewMode === 'MATRIX' && (
        <div className="p-5 rounded-2xl bg-[#091D2F] border border-[#133A5F] space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wider">
                RELATIVE WEIGHT & CAPITAL PERFORMANCE DISPERSION
              </h3>
              <p className="text-xs text-[#6F95B7] mt-0.5">
                Box dimension represents portfolio allocation weight; surface glow indicates all-time return.
              </p>
            </div>
            <div className="flex items-center gap-3 text-xs font-mono">
              <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded bg-[#34D399]" /> Gain (&gt;20%)</span>
              <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded bg-[#00F0FF]" /> Moderate Gain</span>
              <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded bg-[#FB7185]" /> Unrealized Loss</span>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
            {filtered.map((item) => {
              const isProfit = item.totalGainUSD >= 0;
              const isHugeProfit = item.totalGainPercent > 35;

              return (
                <div
                  key={item.holding.id}
                  onClick={() => onNavigate(`#portfolio/holdings/${item.holding.symbol}`)}
                  style={{ minHeight: `${Math.max(105, item.weightPercent * 9)}px` }}
                  className={`p-3.5 rounded-xl border cursor-pointer transition-all hover:scale-[1.02] flex flex-col justify-between group ${
                    isHugeProfit
                      ? 'bg-gradient-to-br from-[#0B2C3D] to-[#081B2B] border-[#34D399]/40 hover:border-[#34D399]'
                      : isProfit
                      ? 'bg-gradient-to-br from-[#0A243A] to-[#07192A] border-[#00F0FF]/30 hover:border-[#00F0FF]'
                      : 'bg-gradient-to-br from-[#29141D] to-[#140A10] border-[#FB7185]/40 hover:border-[#FB7185]'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-mono font-bold text-sm text-white group-hover:text-[#00F0FF]">
                        ${item.holding.symbol}
                      </span>
                      <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-[#061421] text-[#93B6D8] border border-[#14324E]">
                        {item.weightPercent.toFixed(1)}% WT
                      </span>
                    </div>
                    <div className="text-xs text-[#8BB2D6] truncate">
                      {item.holding.name}
                    </div>
                  </div>

                  <div className="mt-3 pt-2 border-t border-white/5 flex items-end justify-between">
                    <div>
                      <div className="text-xs font-mono font-bold text-white">
                        {formatCurrency(item.currentValueUSD, currency)}
                      </div>
                      <div className="text-[10px] text-[#6D95BA] font-mono">
                        {item.holding.shares} shs @ ${item.holding.currentPrice.toFixed(2)}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className={`text-xs font-mono font-bold ${isProfit ? 'text-[#34D399]' : 'text-[#FB7185]'}`}>
                        {formatPercent(item.totalGainPercent)}
                      </div>
                      <div className="text-[10px] font-mono text-[#7D9FBF]">
                        {isProfit ? '+' : ''}{formatCurrency(item.totalGainUSD, currency, true)}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* SHOWPIECE 2: FULL DENSE HOLDINGS MASTER TABLE */}
      {viewMode === 'TABLE' && (
        <div className="rounded-2xl bg-[#091D2F] border border-[#133A5F] overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-[#123555] bg-[#071625] text-[#5581A6] font-mono uppercase text-[10px] tracking-wider select-none">
                  <th 
                    onClick={() => handleSort('symbol')} 
                    className="p-3.5 pl-5 cursor-pointer hover:text-white"
                  >
                    <div className="flex items-center gap-1.5">
                      <span>Holding / Asset</span>
                      <ArrowUpDown className="w-3 h-3" />
                    </div>
                  </th>
                  <th className="p-3.5 hidden md:table-cell">Sector & Anchor</th>
                  <th className="p-3.5 text-right">Market Price</th>
                  <th 
                    onClick={() => handleSort('dayChange')} 
                    className="p-3.5 text-right cursor-pointer hover:text-white"
                  >
                    <div className="flex items-center justify-end gap-1.5">
                      <span>24H Change</span>
                      <ArrowUpDown className="w-3 h-3" />
                    </div>
                  </th>
                  <th className="p-3.5 text-right hidden sm:table-cell">Position & Cost</th>
                  <th 
                    onClick={() => handleSort('value')} 
                    className="p-3.5 text-right cursor-pointer hover:text-white"
                  >
                    <div className="flex items-center justify-end gap-1.5">
                      <span>Market Value</span>
                      <ArrowUpDown className="w-3 h-3" />
                    </div>
                  </th>
                  <th 
                    onClick={() => handleSort('gain')} 
                    className="p-3.5 text-right cursor-pointer hover:text-white"
                  >
                    <div className="flex items-center justify-end gap-1.5">
                      <span>Unrealized P&L</span>
                      <ArrowUpDown className="w-3 h-3" />
                    </div>
                  </th>
                  <th 
                    onClick={() => handleSort('weight')} 
                    className="p-3.5 text-right pr-5 cursor-pointer hover:text-white"
                  >
                    <div className="flex items-center justify-end gap-1.5">
                      <span>Weight vs Target</span>
                      <ArrowUpDown className="w-3 h-3" />
                    </div>
                  </th>
                  <th className="p-3.5 text-center pr-4">30D Trend</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#102C48]">
                {filtered.map((item) => {
                  const isProfit = item.totalGainUSD >= 0;
                  const isDayPos = item.holding.dayChangePercent >= 0;
                  const hasDrift = Math.abs(item.driftPercent) >= 2.0;

                  // Mini 30d sparkline points
                  const sparkPts = item.holding.priceHistory.map((val, idx) => {
                    const min = Math.min(...item.holding.priceHistory);
                    const max = Math.max(...item.holding.priceHistory);
                    const range = max - min || 1;
                    const x = (idx / (item.holding.priceHistory.length - 1)) * 50;
                    const y = 18 - ((val - min) / range) * 14;
                    return `${x},${y}`;
                  }).join(' ');

                  return (
                    <tr
                      key={item.holding.id}
                      onClick={() => onNavigate(`#portfolio/holdings/${item.holding.symbol}`)}
                      className="hover:bg-[#0E2D4A]/60 cursor-pointer transition-colors group"
                    >
                      {/* Symbol & Name */}
                      <td className="p-3.5 pl-5">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-[#071625] border border-[#14395D] flex items-center justify-center font-mono font-bold text-xs text-white group-hover:text-[#00F0FF] group-hover:border-[#00F0FF]/50 transition-all">
                            {item.holding.symbol.slice(0, 3)}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-mono font-bold text-white group-hover:text-[#00F0FF] transition-colors">
                                ${item.holding.symbol}
                              </span>
                              <span className="text-[9px] font-mono px-1 rounded bg-[#0A243D] text-[#6994BC]">
                                {item.holding.exchange}
                              </span>
                            </div>
                            <div className="text-[11px] text-[#7E9EB8] truncate max-w-[150px]">
                              {item.holding.name}
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Sector & Conviction */}
                      <td className="p-3.5 hidden md:table-cell">
                        <div className="text-xs text-[#CBD5E1]">{item.holding.sector}</div>
                        <div className="flex items-center gap-1.5 mt-0.5">
                          <span className={`text-[9px] font-mono px-1.5 py-0.2 rounded font-semibold ${
                            item.holding.conviction === 'High' 
                              ? 'bg-[#00F0FF]/15 text-[#00F0FF] border border-[#00F0FF]/30'
                              : item.holding.conviction === 'Medium'
                              ? 'bg-[#38BDF8]/15 text-[#38BDF8]'
                              : 'bg-[#F59E0B]/15 text-[#F59E0B]'
                          }`}>
                            {item.holding.conviction} Conviction
                          </span>
                        </div>
                      </td>

                      {/* Market Price */}
                      <td className="p-3.5 text-right font-mono font-semibold text-white">
                        ${item.holding.currentPrice.toFixed(2)}
                      </td>

                      {/* Day Change */}
                      <td className="p-3.5 text-right font-mono">
                        <span className={`inline-flex items-center gap-0.5 font-bold ${
                          isDayPos ? 'text-[#34D399]' : 'text-[#FB7185]'
                        }`}>
                          {isDayPos ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                          {formatPercent(item.holding.dayChangePercent)}
                        </span>
                      </td>

                      {/* Shares & Avg Cost */}
                      <td className="p-3.5 text-right hidden sm:table-cell font-mono">
                        <div className="text-white">{item.holding.shares} shs</div>
                        <div className="text-[10px] text-[#668EA9]">Cost: ${item.holding.avgCost.toFixed(2)}</div>
                      </td>

                      {/* Market Value */}
                      <td className="p-3.5 text-right font-mono">
                        <div className="font-bold text-white text-xs">
                          {formatCurrency(item.currentValueUSD, currency)}
                        </div>
                      </td>

                      {/* Unrealized P&L */}
                      <td className="p-3.5 text-right font-mono">
                        <div className={`font-bold ${isProfit ? 'text-[#34D399]' : 'text-[#FB7185]'}`}>
                          {isProfit ? '+' : ''}{formatCurrency(item.totalGainUSD, currency)}
                        </div>
                        <div className={`text-[10px] ${isProfit ? 'text-[#34D399]' : 'text-[#FB7185]'}`}>
                          {formatPercent(item.totalGainPercent)}
                        </div>
                      </td>

                      {/* Weight vs Target & Drift bar */}
                      <td className="p-3.5 text-right pr-5 font-mono">
                        <div className="flex items-center justify-end gap-2">
                          <div>
                            <span className="font-bold text-white text-xs">{item.weightPercent.toFixed(1)}%</span>
                            <span className="text-[10px] text-[#5581A6] ml-1">/ {item.holding.targetWeightPercent}%</span>
                          </div>
                          {hasDrift && (
                            <span className={`text-[9px] px-1 rounded flex items-center gap-0.5 ${
                              item.driftPercent > 0 
                                ? 'bg-[#00F0FF]/15 text-[#00F0FF]' 
                                : 'bg-[#F59E0B]/15 text-[#F59E0B]'
                            }`} title={`Drift: ${item.driftPercent > 0 ? '+' : ''}${item.driftPercent.toFixed(1)}%`}>
                              <AlertTriangle className="w-2.5 h-2.5" />
                              {item.driftPercent > 0 ? `+${item.driftPercent.toFixed(1)}%` : `${item.driftPercent.toFixed(1)}%`}
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Sparkline mini */}
                      <td className="p-3.5 text-center pr-4">
                        <svg className="w-14 h-5 mx-auto overflow-visible" viewBox="0 0 50 20">
                          <polyline
                            fill="none"
                            stroke={isProfit ? '#34D399' : '#FB7185'}
                            strokeWidth="1.6"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            points={sparkPts}
                          />
                        </svg>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div className="p-3.5 bg-[#061421] border-t border-[#12314F] flex items-center justify-between text-xs font-mono text-[#5881A4] px-5">
            <span>Showing {filtered.length} of {enrichedHoldings.length} total positions</span>
            <span>Click any holding row to open detailed institutional dossier</span>
          </div>
        </div>
      )}
    </div>
  );
};
