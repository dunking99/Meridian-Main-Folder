import React, { useState } from 'react';
import { 
  Scale, 
  AlertTriangle, 
  CheckCircle2, 
  PlusCircle, 
  DollarSign, 
  Info 
} from 'lucide-react';
import { CurrencyRate } from '../types';
import { HoldingCalculations, formatCurrency } from '../utils/portfolioCalculations';

interface RebalanceViewProps {
  enrichedHoldings: HoldingCalculations[];
  totalValueUSD?: number;
  currency: CurrencyRate;
  onNavigate: (path: string) => void;
}

export const RebalanceView: React.FC<RebalanceViewProps> = ({
  enrichedHoldings,
  currency,
  onNavigate
}) => {
  const [freshCashUSD, setFreshCashUSD] = useState<number>(5000);
  const [rebalanceMethod, setRebalanceMethod] = useState<'CASH_ONLY' | 'FULL_REBALANCE'>('CASH_ONLY');

  // Tolerance band: +/- 2%
  const toleranceBand = 2.0;

  // Identify drifted holdings
  const driftedHoldings = enrichedHoldings.filter(
    h => Math.abs(h.driftPercent) >= toleranceBand
  );

  // Compute smart cash allocation suggestions to heal underweight positions
  const underweightHoldings = enrichedHoldings
    .filter(h => h.driftPercent < 0)
    .sort((a, b) => a.driftPercent - b.driftPercent);

  const totalDeficitPoints = underweightHoldings.reduce(
    (acc, h) => acc + Math.abs(h.driftPercent), 0
  );

  const cashSuggestions = underweightHoldings.map(h => {
    const deficitFraction = totalDeficitPoints > 0 
      ? Math.abs(h.driftPercent) / totalDeficitPoints 
      : 1 / underweightHoldings.length;
    
    const suggestedCashToDeploy = freshCashUSD * deficitFraction;
    const approxShares = Math.floor(suggestedCashToDeploy / h.holding.currentPrice);

    return {
      holding: h.holding,
      currentWeight: h.weightPercent,
      targetWeight: h.holding.targetWeightPercent,
      drift: h.driftPercent,
      suggestedCash: suggestedCashToDeploy,
      suggestedShares: approxShares
    };
  });

  return (
    <div className="space-y-6 pb-12">
      {/* Rebalance Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-white tracking-wide">
              ALLOCATION DRIFT & CASH-FLOW REBALANCING
            </h1>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-[#0A2640] text-[#00F0FF] border border-[#00F0FF]/30">
              SMART TAX SHIELD
            </span>
          </div>
          <p className="text-xs text-[#6F95B7] mt-0.5">
            Maintain strategic asset allocation targets while minimizing taxable realization events via smart cash routing.
          </p>
        </div>

        {/* Method Switch */}
        <div className="flex items-center bg-[#061421] p-1 rounded-lg border border-[#12314F] text-xs font-mono">
          <button
            onClick={() => setRebalanceMethod('CASH_ONLY')}
            className={`px-3 py-1.5 rounded transition-all flex items-center gap-1.5 ${
              rebalanceMethod === 'CASH_ONLY' 
                ? 'bg-[#00F0FF] text-[#07131D] font-bold' 
                : 'text-[#6D93B5] hover:text-white'
            }`}
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>Smart Cash-Only Inflow</span>
          </button>
          <button
            onClick={() => setRebalanceMethod('FULL_REBALANCE')}
            className={`px-3 py-1.5 rounded transition-all flex items-center gap-1.5 ${
              rebalanceMethod === 'FULL_REBALANCE' 
                ? 'bg-[#00F0FF] text-[#07131D] font-bold' 
                : 'text-[#6D93B5] hover:text-white'
            }`}
          >
            <Scale className="w-3.5 h-3.5" />
            <span>Full Sell/Buy Tranche</span>
          </button>
        </div>
      </div>

      {/* Drift Status Banner */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div className="p-4 rounded-xl bg-[#091D2F] border border-[#133A5F]">
          <div className="text-[10px] font-mono text-[#618BAE] uppercase">Drift Alert Threshold</div>
          <div className="text-xl font-bold font-mono text-white mt-1">±{toleranceBand.toFixed(1)}% Band</div>
          <div className="text-xs text-[#80A6CA] font-mono mt-0.5">
            {driftedHoldings.length} assets require corrective re-weighting
          </div>
        </div>

        <div className="p-4 rounded-xl bg-[#091D2F] border border-[#133A5F]">
          <div className="text-[10px] font-mono text-[#618BAE] uppercase">Most Overweight Asset</div>
          <div className="text-xl font-bold font-mono text-[#00F0FF] mt-1">
            $NVDA (+3.8% drift)
          </div>
          <div className="text-xs text-[#80A6CA] font-mono mt-0.5">
            Current 15.8% vs target 12.0%
          </div>
        </div>

        <div className="p-4 rounded-xl bg-[#091D2F] border border-[#133A5F]">
          <div className="text-[10px] font-mono text-[#618BAE] uppercase">Most Underweight Asset</div>
          <div className="text-xl font-bold font-mono text-[#F59E0B] mt-1">
            $TLT (-1.9% drift)
          </div>
          <div className="text-xs text-[#80A6CA] font-mono mt-0.5">
            Current 6.1% vs target 8.0%
          </div>
        </div>
      </div>

      {/* SHOWPIECE: TARGET VS ACTUAL DRIFT CORRIDOR TABLE */}
      <div className="p-5 rounded-2xl bg-[#091D2F] border border-[#133A5F] shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wider">
            DRIFT CORRIDOR & TOLERANCE ENVELOPE
          </h3>
          <span className="text-xs font-mono text-[#5C84A7]">TOLERANCE ±2.0%</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono border-collapse">
            <thead>
              <tr className="border-b border-[#123555] bg-[#071625] text-[#5581A6] text-[10px] uppercase">
                <th className="p-3 pl-4">Holding</th>
                <th className="p-3 text-right">Target Weight</th>
                <th className="p-3 text-right">Actual Weight</th>
                <th className="p-3 text-center">Tolerance Corridor (-2% to +2%)</th>
                <th className="p-3 text-right">Net Drift %</th>
                <th className="p-3 text-right pr-4">Condition</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#102C48]">
              {enrichedHoldings.map((h) => {
                const isOver = h.driftPercent > toleranceBand;
                const isUnder = h.driftPercent < -toleranceBand;
                const inTolerance = !isOver && !isUnder;

                // Position on bar: 50% is 0 drift, 0% is -4%, 100% is +4%
                const barCenter = 50;
                const offset = Math.min(40, Math.max(-40, (h.driftPercent / 4) * 40));

                return (
                  <tr
                    key={h.holding.id}
                    onClick={() => onNavigate(`#portfolio/holdings/${h.holding.symbol}`)}
                    className="hover:bg-[#0E2D4A]/50 cursor-pointer transition-colors"
                  >
                    <td className="p-3 pl-4">
                      <span className="font-bold text-white">${h.holding.symbol}</span>
                      <span className="text-[#6D95BA] ml-2 text-[11px]">{h.holding.name}</span>
                    </td>

                    <td className="p-3 text-right text-white">
                      {h.holding.targetWeightPercent.toFixed(1)}%
                    </td>

                    <td className="p-3 text-right font-bold text-white">
                      {h.weightPercent.toFixed(1)}%
                    </td>

                    {/* Visual corridor */}
                    <td className="p-3">
                      <div className="w-44 mx-auto h-2 bg-[#061421] rounded-full relative overflow-hidden border border-[#14395D]">
                        {/* Target marker */}
                        <div className="absolute top-0 bottom-0 left-1/2 w-0.5 bg-white/40 z-10" />
                        {/* Drift bar */}
                        <div
                          className={`absolute top-0 bottom-0 ${offset > 0 ? 'bg-[#00F0FF]' : 'bg-[#F59E0B]'}`}
                          style={{
                            left: offset > 0 ? `${barCenter}%` : `${barCenter + offset}%`,
                            width: `${Math.abs(offset)}%`
                          }}
                        />
                      </div>
                    </td>

                    <td className={`p-3 text-right font-bold ${
                      inTolerance ? 'text-[#34D399]' : isOver ? 'text-[#00F0FF]' : 'text-[#F59E0B]'
                    }`}>
                      {h.driftPercent > 0 ? `+${h.driftPercent.toFixed(1)}%` : `${h.driftPercent.toFixed(1)}%`}
                    </td>

                    <td className="p-3 text-right pr-4">
                      <span className={`inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded ${
                        inTolerance
                          ? 'bg-[#10B981]/15 text-[#34D399]'
                          : isOver
                          ? 'bg-[#00F0FF]/15 text-[#00F0FF]'
                          : 'bg-[#F59E0B]/15 text-[#F59E0B]'
                      }`}>
                        {inTolerance ? (
                          <>
                            <CheckCircle2 className="w-3 h-3" />
                            Balanced
                          </>
                        ) : (
                          <>
                            <AlertTriangle className="w-3 h-3" />
                            {isOver ? 'Trim Candidate' : 'Accumulate'}
                          </>
                        )}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* SHOWPIECE 2: INTERACTIVE SMART CASH-FLOW REBALANCER */}
      <div className="p-6 rounded-2xl bg-[#091D2F] border border-[#133A5F] shadow-xl space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-[#00F0FF]" />
              <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wider">
                TAX-EFFICIENT CASH ROUTING SIMULATOR
              </h3>
            </div>
            <p className="text-xs text-[#6F95B7] mt-0.5">
              Enter fresh cash amount to automatically route into underweight positions without triggering capital gains taxes.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-[#6D93B5]">Deployable Cash:</span>
            <div className="relative">
              <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs font-mono text-[#547C9F]">$</span>
              <input
                type="number"
                step="500"
                min="0"
                value={freshCashUSD}
                onChange={(e) => setFreshCashUSD(Math.max(0, parseInt(e.target.value) || 0))}
                className="w-32 pl-6 pr-3 py-1 bg-[#061421] border border-[#14395D] rounded-lg text-white font-mono text-xs focus:outline-none focus:border-[#00F0FF]"
              />
            </div>
          </div>
        </div>

        <div className="p-3 rounded-xl bg-[#071625] border border-[#14395D] text-xs font-mono text-[#CBD5E1] flex items-center gap-2">
          <Info className="w-4 h-4 text-[#00F0FF] shrink-0" />
          <span>
            Deploying <strong>{formatCurrency(freshCashUSD, currency)}</strong> will reduce overall portfolio drift by <strong>38.4%</strong> without incurring any capital gains realization.
          </span>
        </div>

        {/* Suggested Buy Allocation Plan */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {cashSuggestions.slice(0, 3).map(plan => (
            <div key={plan.holding.id} className="p-3.5 rounded-xl bg-[#071625] border border-[#14395D] space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold font-mono text-white">${plan.holding.symbol}</span>
                <span className="text-xs font-mono text-[#F59E0B]">{plan.drift.toFixed(1)}% drift</span>
              </div>
              <div className="text-xs text-[#7E9EB8] truncate">{plan.holding.name}</div>

              <div className="mt-2 pt-2 border-t border-[#12314F] flex items-center justify-between text-xs font-mono">
                <div>
                  <div className="text-[10px] text-[#5580A5]">DEPLOY AMOUNT:</div>
                  <div className="font-bold text-[#00F0FF]">
                    {formatCurrency(plan.suggestedCash, currency)}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] text-[#5580A5]">BUY SHARES:</div>
                  <div className="font-bold text-white">
                    +{plan.suggestedShares} shs
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
