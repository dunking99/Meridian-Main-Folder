import React, { useState } from 'react';
import { 
  BookOpen, 
  Plus, 
  Calendar 
} from 'lucide-react';
import { JOURNAL_ENTRIES } from '../data/portfolioData';
import { JournalEntry } from '../types';

interface JournalViewProps {
  onNavigate: (path: string) => void;
}

export const JournalView: React.FC<JournalViewProps> = ({ onNavigate }) => {
  const [entries, setEntries] = useState<JournalEntry[]>(JOURNAL_ENTRIES);
  const [filterAction, setFilterAction] = useState<string>('ALL');
  const [isAdding, setIsAdding] = useState<boolean>(false);

  // New entry form state
  const [newSymbol, setNewSymbol] = useState('');
  const [newAction, setNewAction] = useState<'BUY' | 'SELL' | 'THESIS_UPDATE' | 'ALERT_NOTE'>('THESIS_UPDATE');
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');
  const [newPrice, setNewPrice] = useState('130.00');

  const filtered = filterAction === 'ALL'
    ? entries
    : entries.filter(e => e.action === filterAction);

  const handleAddEntry = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSymbol || !newTitle || !newContent) return;

    const newJ: JournalEntry = {
      id: `j-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      holdingSymbol: newSymbol.toUpperCase().trim(),
      action: newAction,
      title: newTitle,
      content: newContent,
      convictionAtTime: 'High',
      priceAtRecord: parseFloat(newPrice) || 100
    };

    setEntries([newJ, ...entries]);
    setIsAdding(false);
    setNewSymbol('');
    setNewTitle('');
    setNewContent('');
  };

  return (
    <div className="space-y-6 pb-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-white tracking-wide">
              INVESTMENT THESIS & DECISION LOG
            </h1>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-[#0A2640] text-[#00F0FF] border border-[#00F0FF]/30">
              AUDIT TRAIL
            </span>
          </div>
          <p className="text-xs text-[#6F95B7] mt-0.5">
            Preserve behavioral discipline by documenting every buy, sell, and thesis evolution at the moment of execution.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsAdding(!isAdding)}
            className="px-3 py-1.5 rounded-lg bg-[#00F0FF] hover:bg-[#38BDF8] text-[#07131D] text-xs font-bold font-mono transition-all flex items-center gap-1.5 shadow-[0_0_12px_rgba(0,240,255,0.2)]"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{isAdding ? 'Close Note Form' : 'Log New Thesis / Decision'}</span>
          </button>
        </div>
      </div>

      {/* New Entry Drawer */}
      {isAdding && (
        <form onSubmit={handleAddEntry} className="p-5 rounded-2xl bg-[#0B2238] border border-[#00F0FF]/40 space-y-4 animate-in fade-in">
          <div className="text-sm font-bold text-white font-mono uppercase tracking-wide flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-[#00F0FF]" />
            <span>Record New Journal Entry</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-mono text-[#6F95B7] mb-1">Holding Ticker</label>
              <input
                type="text"
                value={newSymbol}
                onChange={e => setNewSymbol(e.target.value)}
                placeholder="e.g. NVDA, MSFT"
                required
                className="w-full px-3 py-1.5 bg-[#061421] border border-[#14395D] rounded-lg text-white font-mono text-xs focus:outline-none focus:border-[#00F0FF]"
              />
            </div>

            <div>
              <label className="block text-xs font-mono text-[#6F95B7] mb-1">Action Type</label>
              <select
                value={newAction}
                onChange={e => setNewAction(e.target.value as any)}
                className="w-full px-3 py-1.5 bg-[#061421] border border-[#14395D] rounded-lg text-white font-mono text-xs focus:outline-none focus:border-[#00F0FF]"
              >
                <option value="THESIS_UPDATE">THESIS UPDATE</option>
                <option value="BUY">BUY ORDER</option>
                <option value="SELL">SELL / TRIM</option>
                <option value="ALERT_NOTE">ALERT NOTE</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-mono text-[#6F95B7] mb-1">Spot Price at Decision</label>
              <input
                type="number"
                step="0.01"
                value={newPrice}
                onChange={e => setNewPrice(e.target.value)}
                required
                className="w-full px-3 py-1.5 bg-[#061421] border border-[#14395D] rounded-lg text-white font-mono text-xs focus:outline-none focus:border-[#00F0FF]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-mono text-[#6F95B7] mb-1">Entry Title</label>
            <input
              type="text"
              value={newTitle}
              onChange={e => setNewTitle(e.target.value)}
              placeholder="Summary headline of rationale..."
              required
              className="w-full px-3 py-1.5 bg-[#061421] border border-[#14395D] rounded-lg text-white text-xs focus:outline-none focus:border-[#00F0FF]"
            />
          </div>

          <div>
            <label className="block text-xs font-mono text-[#6F95B7] mb-1">Detailed Rationale & Counter-Theses</label>
            <textarea
              rows={3}
              value={newContent}
              onChange={e => setNewContent(e.target.value)}
              placeholder="Why was this action taken? What would prove this thesis wrong?"
              required
              className="w-full p-3 bg-[#061421] border border-[#14395D] rounded-lg text-white text-xs focus:outline-none focus:border-[#00F0FF] leading-relaxed"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setIsAdding(false)}
              className="px-3 py-1.5 text-xs font-mono text-[#749ABA] hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 bg-[#00F0FF] hover:bg-[#38BDF8] text-[#07131D] text-xs font-bold font-mono rounded-lg transition-all"
            >
              Save to Permanent Log
            </button>
          </div>
        </form>
      )}

      {/* Filter bar */}
      <div className="flex items-center gap-1.5 bg-[#061421] p-1 rounded-lg border border-[#12314F] text-xs font-mono w-fit">
        {['ALL', 'THESIS_UPDATE', 'BUY', 'ALERT_NOTE'].map(mode => (
          <button
            key={mode}
            onClick={() => setFilterAction(mode)}
            className={`px-3 py-1 rounded transition-all ${
              filterAction === mode 
                ? 'bg-[#00F0FF] text-[#07131D] font-bold' 
                : 'text-[#6D93B5] hover:text-white'
            }`}
          >
            {mode === 'ALL' ? 'All Entries' : mode.replace('_', ' ')}
          </button>
        ))}
      </div>

      {/* Entry Cards */}
      <div className="space-y-3.5">
        {filtered.map(entry => (
          <div
            key={entry.id}
            className="p-5 rounded-2xl bg-[#091D2F] border border-[#133A5F] hover:border-[#1E4D77] transition-all space-y-3"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#12314F] pb-3">
              <div className="flex items-center gap-2.5">
                <button
                  onClick={() => onNavigate(`#portfolio/holdings/${entry.holdingSymbol}`)}
                  className="px-2 py-0.5 rounded text-xs font-mono font-bold bg-[#0A2640] text-[#00F0FF] border border-[#00F0FF]/30 hover:bg-[#00F0FF] hover:text-[#07131D] transition-all"
                >
                  ${entry.holdingSymbol}
                </button>
                <span className="text-xs font-mono px-2 py-0.5 rounded bg-[#071625] text-[#86ABCE] border border-[#13324F]">
                  {entry.action}
                </span>
                <span className="text-xs font-mono text-[#34D399] font-semibold">
                  {entry.convictionAtTime} Conviction
                </span>
              </div>

              <div className="flex items-center gap-3 text-xs font-mono text-[#628AA9]">
                <span className="flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5" />
                  {entry.date}
                </span>
                <span>Spot: ${entry.priceAtRecord.toFixed(2)}</span>
              </div>
            </div>

            <h3 className="text-base font-bold text-white tracking-wide">
              {entry.title}
            </h3>

            <p className="text-xs text-[#CBD5E1] leading-relaxed bg-[#071625] p-3.5 rounded-xl border border-[#12314F]">
              {entry.content}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};
