import React, { useState } from 'react';
import { 
  Search, 
  Menu, 
  X, 
  ShieldCheck, 
  Coins 
} from 'lucide-react';
import { Holding, CurrencyRate } from '../types';
import { formatCurrency, formatPercent } from '../utils/portfolioCalculations';

interface TopNavProps {
  currentPath: string;
  onNavigate: (path: string) => void;
  holdings: Holding[];
  currency: CurrencyRate;
  totalGainUSD: number;
  totalGainPercent: number;
  annualIncomeUSD: number;
  portfolioYieldPercent: number;
  cashDragPercent: number;
  onOpenMobileMenu: () => void;
}

export const TopNav: React.FC<TopNavProps> = ({
  currentPath,
  onNavigate,
  holdings,
  currency,
  totalGainUSD,
  totalGainPercent,
  annualIncomeUSD,
  portfolioYieldPercent,
  cashDragPercent,
  onOpenMobileMenu
}) => {
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Determine breadcrumb
  let section = 'PORTFOLIO';
  let subSection = 'OVERVIEW';

  if (currentPath.includes('holdings')) {
    section = 'PORTFOLIO';
    if (currentPath.includes('/holdings/')) {
      const sym = currentPath.split('/holdings/')[1];
      subSection = `DOSSIER // $${sym}`;
    } else {
      subSection = 'HOLDINGS MATRIX';
    }
  } else if (currentPath.includes('performance')) {
    subSection = 'PERFORMANCE & BENCHMARKS';
  } else if (currentPath.includes('analysis')) {
    subSection = 'RISK & EXPOSURE ENGINE';
  } else if (currentPath.includes('rebalance')) {
    subSection = 'DRIFT BAND & CASH REBALANCE';
  } else if (currentPath.includes('income')) {
    subSection = 'INCOME & DIVIDEND CALENDAR';
  } else if (currentPath.includes('markets')) {
    section = 'INTELLIGENCE';
    subSection = 'GLOBAL MACRO RADAR';
  } else if (currentPath.includes('news')) {
    section = 'INTELLIGENCE';
    subSection = 'PORTFOLIO NEWS STREAM';
  } else if (currentPath.includes('watchlist')) {
    section = 'INTELLIGENCE';
    subSection = 'WATCHLIST RADAR';
  } else if (currentPath.includes('journal')) {
    section = 'INTELLIGENCE';
    subSection = 'THESIS & DECISION LOG';
  }

  const filteredHoldings = searchQuery.trim() === '' 
    ? holdings.slice(0, 5) 
    : holdings.filter(h => 
        h.symbol.toLowerCase().includes(searchQuery.toLowerCase()) || 
        h.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        h.sector.toLowerCase().includes(searchQuery.toLowerCase())
      );

  return (
    <header className="sticky top-0 z-30 bg-[#081827]/95 backdrop-blur-md border-b border-[#122F4C] px-4 lg:px-7 py-3">
      <div className="flex items-center justify-between gap-4">
        {/* Left: Mobile hamburger & Breadcrumbs */}
        <div className="flex items-center gap-3">
          <button
            onClick={onOpenMobileMenu}
            className="lg:hidden p-1.5 rounded-md bg-[#0D263D] text-[#8BB2D6] hover:text-white"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2 font-mono text-xs">
            <span className="text-[#5984A9]">{section}</span>
            <span className="text-[#2C5275]">/</span>
            <span className="text-[#00F0FF] font-semibold tracking-wide">{subSection}</span>
          </div>
        </div>

        {/* Center: Live Portfolio Health & Stats Strip (Desktop) */}
        <div className="hidden xl:flex items-center gap-6 px-4 py-1.5 rounded-lg bg-[#061421] border border-[#112F4B] text-xs">
          {/* Total Unrealized Gain */}
          <div className="flex items-center gap-2">
            <div className="text-[10px] text-[#618BAE] uppercase font-mono">Total P&L:</div>
            <div className="font-mono font-semibold tabular-nums text-[#34D399]">
              +{formatCurrency(totalGainUSD, currency)} ({formatPercent(totalGainPercent)})
            </div>
          </div>

          <div className="w-px h-3.5 bg-[#173D60]" />

          {/* Annual Yield */}
          <div className="flex items-center gap-2">
            <Coins className="w-3.5 h-3.5 text-[#00F0FF]" />
            <div className="text-[10px] text-[#618BAE] uppercase font-mono">Passive Yield:</div>
            <div className="font-mono font-semibold tabular-nums text-white">
              {formatCurrency(annualIncomeUSD, currency)} / yr
              <span className="text-[11px] text-[#00F0FF] ml-1">({portfolioYieldPercent.toFixed(2)}%)</span>
            </div>
          </div>

          <div className="w-px h-3.5 bg-[#173D60]" />

          {/* Cash Buffer */}
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-3.5 h-3.5 text-[#38BDF8]" />
            <div className="text-[10px] text-[#618BAE] uppercase font-mono">Cash Cushion:</div>
            <div className="font-mono font-semibold tabular-nums text-[#38BDF8]">
              {cashDragPercent.toFixed(1)}% Liquid
            </div>
          </div>
        </div>

        {/* Right: Quick Search & Actions */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setSearchOpen(true)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#0C243B] hover:bg-[#113251] border border-[#163E63] text-xs text-[#7FABCة] hover:text-white transition-all"
          >
            <Search className="w-3.5 h-3.5 text-[#00F0FF]" />
            <span className="hidden sm:inline text-[#8EB7DC]">Quick jump to holding...</span>
            <kbd className="hidden sm:inline-block px-1.5 py-0.5 text-[9px] font-mono bg-[#071725] text-[#5581A6] rounded border border-[#183B5E]">⌘K</kbd>
          </button>
        </div>
      </div>

      {/* Quick Search Modal */}
      {searchOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-start justify-center pt-20 px-4">
          <div className="bg-[#0A1D30] border border-[#1E4D77] rounded-xl shadow-2xl w-full max-w-xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="p-3 border-b border-[#14395D] flex items-center gap-3">
              <Search className="w-4 h-4 text-[#00F0FF]" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search holdings by ticker, name, or sector..."
                autoFocus
                className="bg-transparent border-none outline-none text-sm text-white placeholder-[#5A85A9] w-full font-mono"
              />
              <button
                onClick={() => {
                  setSearchOpen(false);
                  setSearchQuery('');
                }}
                className="p-1 text-[#5A85A9] hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-2 max-h-80 overflow-y-auto divide-y divide-[#122F4C]">
              <div className="text-[10px] font-mono uppercase text-[#4D7699] px-3 py-1.5">
                {searchQuery ? `Matching Assets (${filteredHoldings.length})` : 'Core Holdings'}
              </div>

              {filteredHoldings.map((h) => (
                <button
                  key={h.id}
                  onClick={() => {
                    onNavigate(`#portfolio/holdings/${h.symbol}`);
                    setSearchOpen(false);
                    setSearchQuery('');
                  }}
                  className="w-full flex items-center justify-between px-3 py-2.5 hover:bg-[#0E2E4E] transition-all text-left group"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-xs font-mono font-bold text-white group-hover:text-[#00F0FF]">
                      ${h.symbol}
                    </span>
                    <div>
                      <div className="text-xs text-[#CBD5E1]">{h.name}</div>
                      <div className="text-[10px] text-[#638DAF]">{h.sector}</div>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="text-xs font-mono font-semibold text-white">
                      ${h.currentPrice.toFixed(2)}
                    </div>
                    <div className={`text-[10px] font-mono font-semibold ${h.dayChangePercent >= 0 ? 'text-[#34D399]' : 'text-[#FB7185]'}`}>
                      {formatPercent(h.dayChangePercent)}
                    </div>
                  </div>
                </button>
              ))}

              {filteredHoldings.length === 0 && (
                <div className="py-6 text-center text-xs text-[#628BAF]">
                  No holdings found matching "{searchQuery}"
                </div>
              )}
            </div>

            <div className="p-2 bg-[#061421] border-t border-[#13324F] flex items-center justify-between text-[10px] font-mono text-[#527B9E] px-3">
              <span>Press ESC to dismiss</span>
              <span>Click to view detailed dossier</span>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
