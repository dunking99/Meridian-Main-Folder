import React from 'react';
import { 
  ArrowUpRight, 
  ArrowDownRight, 
  Activity, 
  Gauge 
} from 'lucide-react';
import { MACRO_RADAR } from '../data/portfolioData';

export const MarketsView: React.FC = () => {
  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-white tracking-wide">
              GLOBAL MACRO RADAR & CROSS-ASSET MONITOR
            </h1>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-[#0A2640] text-[#00F0FF] border border-[#00F0FF]/30">
              SYNCHRONIZED FEED
            </span>
          </div>
          <p className="text-xs text-[#6F95B7] mt-0.5">
            Key macroeconomic sovereign drivers: US 10-Yr Yield, DXY Currency Index, Brent Crude, Gold, and Volatility Index.
          </p>
        </div>

        <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#091D2F] border border-[#14395D] text-xs font-mono">
          <Activity className="w-3.5 h-3.5 text-[#34D399] animate-pulse" />
          <span className="text-[#6D93B5]">Macro Regime:</span>
          <span className="text-white font-bold">Late-Cycle Expansion / Disinflation</span>
        </div>
      </div>

      {/* Macro Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        {MACRO_RADAR.map(item => {
          const isPos = item.changePercent >= 0;
          return (
            <div
              key={item.symbol}
              className="p-4 rounded-xl bg-[#091D2F] border border-[#133A5F] hover:border-[#1F4C77] transition-all space-y-2"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-[#00F0FF]">${item.symbol}</span>
                <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-[#061421] text-[#86ABCE] border border-[#13324F]">
                  {item.category}
                </span>
              </div>
              <div className="text-sm font-semibold text-white">{item.name}</div>

              <div className="pt-2 border-t border-[#12314F] flex items-baseline justify-between font-mono">
                <div className="text-xl font-bold text-white">
                  {item.unit ? `${item.value.toFixed(2)}${item.unit}` : item.value > 1000 ? item.value.toLocaleString() : item.value.toFixed(2)}
                </div>
                <div className={`text-xs font-bold flex items-center ${isPos ? 'text-[#34D399]' : 'text-[#FB7185]'}`}>
                  {isPos ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                  {item.changePercent > 0 ? `+${item.changePercent.toFixed(2)}%` : `${item.changePercent.toFixed(2)}%`}
                </div>
              </div>

              <div className="text-[10px] font-mono text-[#5881A4] flex items-center justify-between">
                <span>Sentiment Pulse:</span>
                <span className="text-white font-semibold">{item.sentiment}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Sovereign Yield Curve & Credit Spread Visualizer */}
      <div className="p-5 rounded-2xl bg-[#091D2F] border border-[#133A5F] shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Gauge className="w-4 h-4 text-[#00F0FF]" />
            <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wider">
              US TREASURY BENCHMARK YIELD CURVE SLOPE
            </h3>
          </div>
          <span className="text-xs font-mono text-[#34D399]">SLIGHT NORMALIZATION (+14 BPS 2s10s)</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 pt-2">
          {[
            { tenor: '3-Month', yieldRate: '4.82%', change: '-0.01' },
            { tenor: '2-Year', yieldRate: '4.34%', change: '+0.03' },
            { tenor: '5-Year', yieldRate: '4.38%', change: '+0.02' },
            { tenor: '10-Year', yieldRate: '4.48%', change: '+0.02' },
            { tenor: '30-Year', yieldRate: '4.68%', change: '+0.04' },
          ].map(curve => (
            <div key={curve.tenor} className="p-3 rounded-xl bg-[#071625] border border-[#133250] text-center">
              <div className="text-[10px] font-mono text-[#6A94BA] uppercase">{curve.tenor}</div>
              <div className="text-lg font-bold font-mono text-white mt-1">{curve.yieldRate}</div>
              <div className="text-[10px] font-mono text-[#8BB2D6] mt-0.5">{curve.change} bps today</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
