import React, { useState } from 'react';
import { 
  ArrowLeft, 
  ArrowUpRight, 
  ArrowDownRight, 
  ShieldCheck, 
  Calendar, 
  FileText, 
  ExternalLink,
  Plus,
  Coins,
  Newspaper
} from 'lucide-react';
import { Holding, CurrencyRate } from '../types';
import { HoldingCalculations, formatCurrency, formatPercent } from '../utils/portfolioCalculations';
import { NEWS_STREAM, JOURNAL_ENTRIES } from '../data/portfolioData';

interface HoldingDetailViewProps {
  holding: Holding;
  calculation: HoldingCalculations;
  currency: CurrencyRate;
  onBack: () => void;
  onNavigate: (path: string) => void;
  onOpenTradeModalWithHolding: (holding: Holding) => void;
}

export const HoldingDetailView: React.FC<HoldingDetailViewProps> = ({
  holding,
  calculation,
  currency,
  onBack,
  onNavigate,
  onOpenTradeModalWithHolding
}) => {
  const [activeTab, setActiveTab] = useState<'OVERVIEW' | 'THESIS' | 'NEWS' | 'SIMULATOR'>('OVERVIEW');
  const [simSharesToAdd, setSimSharesToAdd] = useState<number>(10);

  const isProfit = calculation.totalGainUSD >= 0;
  const isDayPos = holding.dayChangePercent >= 0;

  // 52 week range calculation
  const low52 = holding.low52w;
  const high52 = holding.high52w;
  const range52 = high52 - low52 || 1;
  const currentPosPct = Math.min(100, Math.max(0, ((holding.currentPrice - low52) / range52) * 100));

  // Cross-referenced news and journal entries
  const relatedNews = NEWS_STREAM.filter(n => n.relatedHoldings.includes(holding.symbol));
  const relatedJournal = JOURNAL_ENTRIES.filter(j => j.holdingSymbol === holding.symbol);

  // Simulator calculations
  const simNewShares = holding.shares + (Number(simSharesToAdd) || 0);
  const simAddedCost = (Number(simSharesToAdd) || 0) * holding.currentPrice;
  const simNewTotalCost = (holding.shares * holding.avgCost) + simAddedCost;
  const simNewAvgCost = simNewShares > 0 ? simNewTotalCost / simNewShares : holding.avgCost;

  return (
    <div className="space-y-6 pb-16">
      {/* Back button and navigation breadcrumb */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-xs font-mono text-[#6F98BC] hover:text-[#00F0FF] transition-colors group"
        >
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" />
          <span>RETURN TO HOLDINGS REPOSITORY</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onOpenTradeModalWithHolding(holding)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#00F0FF] hover:bg-[#38BDF8] text-[#07131D] text-xs font-bold font-mono transition-all shadow-[0_0_12px_rgba(0,240,255,0.25)]"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Transact ${holding.symbol}</span>
          </button>
        </div>
      </div>

      {/* Hero Dossier Card */}
      <div className="p-6 rounded-2xl bg-gradient-to-b from-[#0B233A] to-[#081827] border border-[#16436B] shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-[#00F0FF]/5 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col md:flex-row md:items-start justify-between gap-6 relative z-10">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <span className="text-2xl lg:text-3xl font-black font-mono tracking-tight text-white">
                ${holding.symbol}
              </span>
              <span className="px-2 py-0.5 rounded text-xs font-mono bg-[#0A2640] text-[#00F0FF] border border-[#00F0FF]/30">
                {holding.exchange}
              </span>
              <span className={`px-2 py-0.5 rounded text-xs font-mono font-semibold ${
                holding.financialHealth === 'Pristine'
                  ? 'bg-[#10B981]/20 text-[#34D399] border border-[#10B981]/30'
                  : 'bg-[#F59E0B]/20 text-[#F59E0B] border border-[#F59E0B]/30'
              }`}>
                Health: {holding.financialHealth}
              </span>
            </div>
            <h1 className="text-lg text-[#CBD5E1] font-semibold">{holding.name}</h1>
            <div className="flex flex-wrap items-center gap-2 mt-2">
              <span className="text-xs px-2.5 py-1 rounded-md bg-[#07192A] text-[#86ACD1] border border-[#14395D]">
                {holding.sector}
              </span>
              <span className="text-xs px-2.5 py-1 rounded-md bg-[#07192A] text-[#86ACD1] border border-[#14395D]">
                {holding.region}
              </span>
              {holding.tags.map(t => (
                <span key={t} className="text-xs px-2 py-0.5 rounded-md bg-[#0A2338] text-[#5584AB] border border-[#10304C]">
                  #{t}
                </span>
              ))}
            </div>
          </div>

          {/* Current Spot Price & Session Change */}
          <div className="text-left md:text-right">
            <div className="text-xs text-[#6F95B7] font-mono uppercase mb-1">SPOT PRICE</div>
            <div className="text-3xl font-bold font-mono text-white">
              ${holding.currentPrice.toFixed(2)}
            </div>
            <div className="flex items-center md:justify-end gap-1.5 mt-1 font-mono text-xs">
              <span className={`inline-flex items-center font-bold ${isDayPos ? 'text-[#34D399]' : 'text-[#FB7185]'}`}>
                {isDayPos ? <ArrowUpRight className="w-3.5 h-3.5" /> : <ArrowDownRight className="w-3.5 h-3.5" />}
                {formatPercent(holding.dayChangePercent)}
              </span>
              <span className="text-[#6F95B7]">vs prev close ${holding.prevClose.toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* 52-Week Range Corridor */}
        <div className="mt-6 pt-5 border-t border-[#133A5F]">
          <div className="flex items-center justify-between text-xs font-mono text-[#6A94BA] mb-2">
            <span>52W LOW: ${low52.toFixed(2)}</span>
            <span className="text-white font-bold">52-WEEK PRICE TRAJECTORY CHANNEL</span>
            <span>52W HIGH: ${high52.toFixed(2)}</span>
          </div>

          <div className="relative w-full h-3 bg-[#061421] rounded-full overflow-hidden border border-[#14395D]">
            <div
              className="absolute top-0 bottom-0 left-0 bg-gradient-to-r from-[#0E4466] to-[#00F0FF] rounded-full opacity-75"
              style={{ width: `${currentPosPct}%` }}
            />
          </div>
          <div className="flex justify-between items-center mt-1 text-[10px] font-mono text-[#5881A4]">
            <span>Channel floor</span>
            <span className="text-[#00F0FF] font-bold">
              Current Spot is {currentPosPct.toFixed(1)}% of 52W range
            </span>
            <span>Channel ceiling</span>
          </div>
        </div>
      </div>

      {/* Position Metrics Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="p-4 rounded-xl bg-[#091D2F] border border-[#133A5F]">
          <div className="text-[10px] font-mono text-[#618BAE] uppercase">Total Position Value</div>
          <div className="text-xl font-bold text-white font-mono mt-1">
            {formatCurrency(calculation.currentValueUSD, currency)}
          </div>
          <div className="text-xs text-[#80A6CA] font-mono mt-0.5">
            {holding.shares.toLocaleString()} units @ ${holding.currentPrice.toFixed(2)}
          </div>
        </div>

        <div className="p-4 rounded-xl bg-[#091D2F] border border-[#133A5F]">
          <div className="text-[10px] font-mono text-[#618BAE] uppercase">Cost Basis & Avg Price</div>
          <div className="text-xl font-bold text-white font-mono mt-1">
            {formatCurrency(calculation.totalCostUSD, currency)}
          </div>
          <div className="text-xs text-[#80A6CA] font-mono mt-0.5">
            Avg Cost: ${holding.avgCost.toFixed(2)}
          </div>
        </div>

        <div className="p-4 rounded-xl bg-[#091D2F] border border-[#133A5F]">
          <div className="text-[10px] font-mono text-[#618BAE] uppercase">Unrealized Capital P&L</div>
          <div className={`text-xl font-bold font-mono mt-1 ${isProfit ? 'text-[#34D399]' : 'text-[#FB7185]'}`}>
            {isProfit ? '+' : ''}{formatCurrency(calculation.totalGainUSD, currency)}
          </div>
          <div className={`text-xs font-mono mt-0.5 ${isProfit ? 'text-[#34D399]' : 'text-[#FB7185]'}`}>
            {formatPercent(calculation.totalGainPercent)} total ROI
          </div>
        </div>

        <div className="p-4 rounded-xl bg-[#091D2F] border border-[#133A5F]">
          <div className="text-[10px] font-mono text-[#618BAE] uppercase">Weight & Target Drift</div>
          <div className="text-xl font-bold text-white font-mono mt-1">
            {calculation.weightPercent.toFixed(1)}%
          </div>
          <div className="text-xs font-mono mt-0.5 flex items-center gap-1">
            <span className="text-[#6D95BA]">Target: {holding.targetWeightPercent}%</span>
            <span className={`font-semibold ${calculation.driftPercent > 0 ? 'text-[#00F0FF]' : 'text-[#F59E0B]'}`}>
              ({calculation.driftPercent > 0 ? '+' : ''}{calculation.driftPercent.toFixed(1)}% drift)
            </span>
          </div>
        </div>
      </div>

      {/* Tabs Menu */}
      <div className="border-b border-[#14395D] flex items-center gap-2">
        <button
          onClick={() => setActiveTab('OVERVIEW')}
          className={`px-4 py-2 text-xs font-mono font-bold transition-all border-b-2 ${
            activeTab === 'OVERVIEW'
              ? 'border-[#00F0FF] text-[#00F0FF]'
              : 'border-transparent text-[#6F95B7] hover:text-white'
          }`}
        >
          Valuation Multiples & Fundamentals
        </button>
        <button
          onClick={() => setActiveTab('THESIS')}
          className={`px-4 py-2 text-xs font-mono font-bold transition-all border-b-2 flex items-center gap-1.5 ${
            activeTab === 'THESIS'
              ? 'border-[#00F0FF] text-[#00F0FF]'
              : 'border-transparent text-[#6F95B7] hover:text-white'
          }`}
        >
          <FileText className="w-3.5 h-3.5" />
          <span>Thesis & Journal ({relatedJournal.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('NEWS')}
          className={`px-4 py-2 text-xs font-mono font-bold transition-all border-b-2 flex items-center gap-1.5 ${
            activeTab === 'NEWS'
              ? 'border-[#00F0FF] text-[#00F0FF]'
              : 'border-transparent text-[#6F95B7] hover:text-white'
          }`}
        >
          <Newspaper className="w-3.5 h-3.5" />
          <span>Holdings News ({relatedNews.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('SIMULATOR')}
          className={`px-4 py-2 text-xs font-mono font-bold transition-all border-b-2 flex items-center gap-1.5 ${
            activeTab === 'SIMULATOR'
              ? 'border-[#00F0FF] text-[#00F0FF]'
              : 'border-transparent text-[#6F95B7] hover:text-white'
          }`}
        >
          <Coins className="w-3.5 h-3.5" />
          <span>Lot & Basis Simulator</span>
        </button>
      </div>

      {/* TAB CONTENT: OVERVIEW / FUNDAMENTALS */}
      {activeTab === 'OVERVIEW' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* Institutional Multiples Card */}
          <div className="p-5 rounded-xl bg-[#091D2F] border border-[#133A5F] space-y-3">
            <div className="text-xs font-mono text-[#00F0FF] font-bold uppercase tracking-wider flex items-center justify-between">
              <span>VALUATION MULTIPLES</span>
              <span className="text-[10px] text-[#5A82A5]">MARKET DATA</span>
            </div>
            <div className="divide-y divide-[#12314F] text-xs font-mono">
              <div className="py-2 flex justify-between">
                <span className="text-[#6D93B5]">Trailing P/E:</span>
                <span className="text-white font-bold">{holding.peRatio ? `${holding.peRatio}x` : 'N/A (Asset/ETF)'}</span>
              </div>
              <div className="py-2 flex justify-between">
                <span className="text-[#6D93B5]">Forward P/E:</span>
                <span className="text-white font-bold">{holding.forwardPE ? `${holding.forwardPE}x` : 'N/A'}</span>
              </div>
              <div className="py-2 flex justify-between">
                <span className="text-[#6D93B5]">Dividend Yield:</span>
                <span className="text-[#34D399] font-bold">{holding.dividendYield.toFixed(2)}%</span>
              </div>
              <div className="py-2 flex justify-between">
                <span className="text-[#6D93B5]">Annual Dividend / Sh:</span>
                <span className="text-white font-bold">${holding.annualDividend.toFixed(2)}</span>
              </div>
              <div className="py-2 flex justify-between">
                <span className="text-[#6D93B5]">Beta (vs S&P 500):</span>
                <span className="text-white font-bold">{holding.beta}</span>
              </div>
              <div className="py-2 flex justify-between">
                <span className="text-[#6D93B5]">Market Capitalization:</span>
                <span className="text-white font-bold">{holding.marketCap}</span>
              </div>
            </div>
          </div>

          {/* Catalysts & Operational Health */}
          <div className="p-5 rounded-xl bg-[#091D2F] border border-[#133A5F] space-y-3">
            <div className="text-xs font-mono text-[#00F0FF] font-bold uppercase tracking-wider">
              RECENT CATALYST & EVENT RADAR
            </div>
            <div className="p-3 rounded-lg bg-[#071625] border border-[#143A5E] text-xs text-[#CBD5E1] leading-relaxed">
              {holding.recentCatalyst}
            </div>

            <div className="mt-3 pt-3 border-t border-[#12314F] space-y-2 text-xs font-mono">
              <div className="flex items-center justify-between">
                <span className="text-[#6D93B5]">Next Earnings Date:</span>
                <span className="text-white font-semibold flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-[#00F0FF]" />
                  {holding.nextEarningsDate}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[#6D93B5]">Balance Sheet Status:</span>
                <span className="text-[#34D399] font-semibold flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  {holding.financialHealth}
                </span>
              </div>
            </div>
          </div>

          {/* Thesis Snapshot Card */}
          <div className="p-5 rounded-xl bg-[#091D2F] border border-[#133A5F] space-y-3">
            <div className="text-xs font-mono text-[#00F0FF] font-bold uppercase tracking-wider flex items-center justify-between">
              <span>INVESTMENT THESIS</span>
              <span className="text-[10px] text-[#38BDF8]">{holding.conviction} Conviction</span>
            </div>
            <p className="text-xs text-[#CBD5E1] leading-relaxed italic bg-[#071625] p-3 rounded-lg border border-[#143A5E]">
              "{holding.thesis}"
            </p>
            <div className="text-[11px] text-[#6993B8] font-mono">
              Last formal audit date: <strong className="text-white">{holding.lastRebalanced}</strong>
            </div>
          </div>
        </div>
      )}

      {/* TAB CONTENT: THESIS & JOURNAL */}
      {activeTab === 'THESIS' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wide">
              DECISION AUDIT TRAIL FOR ${holding.symbol}
            </h3>
            <button
              onClick={() => onNavigate('#journal')}
              className="text-xs font-mono text-[#00F0FF] hover:underline flex items-center gap-1"
            >
              <span>View Full Investment Journal</span>
              <ExternalLink className="w-3 h-3" />
            </button>
          </div>

          {relatedJournal.length > 0 ? (
            <div className="space-y-3">
              {relatedJournal.map(entry => (
                <div key={entry.id} className="p-4 rounded-xl bg-[#091D2F] border border-[#133A5F] space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#0A2640] text-[#00F0FF] border border-[#00F0FF]/30">
                        {entry.action}
                      </span>
                      <h4 className="text-sm font-bold text-white">{entry.title}</h4>
                    </div>
                    <span className="text-xs font-mono text-[#618EAF]">{entry.date}</span>
                  </div>
                  <p className="text-xs text-[#CBD5E1] leading-relaxed">
                    {entry.content}
                  </p>
                  <div className="text-[11px] font-mono text-[#6F95B7] pt-2 border-t border-[#12314F]">
                    Execution Spot Price: <strong className="text-white">${entry.priceAtRecord.toFixed(2)}</strong>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-8 rounded-xl bg-[#091D2F] border border-[#133A5F] text-center text-xs text-[#6F95B7]">
              No individual journal notes recorded yet for ${holding.symbol}. Use the journal to log your hypothesis and milestones.
            </div>
          )}
        </div>
      )}

      {/* TAB CONTENT: NEWS */}
      {activeTab === 'NEWS' && (
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wide">
            INTELLIGENCE DISPATCHES TIED TO ${holding.symbol}
          </h3>

          {relatedNews.length > 0 ? (
            <div className="space-y-3">
              {relatedNews.map(item => (
                <div key={item.id} className="p-4 rounded-xl bg-[#091D2F] border border-[#133A5F] space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono text-[#00F0FF]">{item.source} • {item.timeAgo}</span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                      item.impact === 'Bullish' ? 'bg-[#10B981]/20 text-[#34D399]' : 'bg-[#FB7185]/20 text-[#FB7185]'
                    }`}>
                      {item.impact}
                    </span>
                  </div>
                  <h4 className="text-sm font-bold text-white">{item.title}</h4>
                  <p className="text-xs text-[#8EB0CD] leading-relaxed">{item.summary}</p>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-8 rounded-xl bg-[#091D2F] border border-[#133A5F] text-center text-xs text-[#6F95B7]">
              No breaking news alerts recorded for ${holding.symbol} in the last 48 hours.
            </div>
          )}
        </div>
      )}

      {/* TAB CONTENT: LOT & BASIS SIMULATOR */}
      {activeTab === 'SIMULATOR' && (
        <div className="p-6 rounded-2xl bg-[#091D2F] border border-[#133A5F] max-w-2xl space-y-5">
          <div>
            <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wide">
              AVERAGE COST BASIS & ALLOCATION SIMULATOR
            </h3>
            <p className="text-xs text-[#6F95B7] mt-0.5">
              Simulate adding new shares at current price to calculate updated average cost basis and capital commitment.
            </p>
          </div>

          <div className="space-y-3">
            <label className="block text-xs font-mono text-[#8EB0CD]">
              Number of shares to add:
            </label>
            <div className="flex items-center gap-3">
              <input
                type="number"
                min="1"
                value={simSharesToAdd}
                onChange={(e) => setSimSharesToAdd(Math.max(1, parseInt(e.target.value) || 0))}
                className="w-32 px-3 py-2 bg-[#061421] border border-[#14395D] rounded-lg text-white font-mono text-sm focus:outline-none focus:border-[#00F0FF]"
              />
              <span className="text-xs font-mono text-[#6F95B7]">
                @ ${holding.currentPrice.toFixed(2)} = <strong className="text-white">${simAddedCost.toFixed(2)}</strong>
              </span>
            </div>
          </div>

          {/* Results Comparison Grid */}
          <div className="grid grid-cols-2 gap-3 pt-3 border-t border-[#12314F]">
            <div className="p-3 rounded-lg bg-[#071625] border border-[#12314F] text-xs font-mono">
              <div className="text-[#6D93B5]">CURRENT BASIS</div>
              <div className="text-white font-bold text-base mt-1">${holding.avgCost.toFixed(2)} / sh</div>
              <div className="text-[11px] text-[#7E9EB8] mt-0.5">{holding.shares} shares</div>
            </div>

            <div className="p-3 rounded-lg bg-[#071625] border border-[#00F0FF]/30 text-xs font-mono">
              <div className="text-[#00F0FF]">SIMULATED BASIS</div>
              <div className="text-[#00F0FF] font-bold text-base mt-1">${simNewAvgCost.toFixed(2)} / sh</div>
              <div className="text-[11px] text-[#CBD5E1] mt-0.5">{simNewShares} shares total</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
