import React, { useState } from 'react';
import { 
  ExternalLink, 
  Clock, 
  ArrowUpRight, 
  ArrowDownRight
} from 'lucide-react';
import { NEWS_STREAM } from '../data/portfolioData';

interface NewsViewProps {
  onNavigate: (path: string) => void;
}

export const NewsView: React.FC<NewsViewProps> = ({ onNavigate }) => {
  const [filterImpact, setFilterImpact] = useState<'ALL' | 'Bullish' | 'Bearish'>('ALL');

  const filteredNews = filterImpact === 'ALL'
    ? NEWS_STREAM
    : NEWS_STREAM.filter(n => n.impact === filterImpact);

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-white tracking-wide">
              PORTFOLIO HOLDINGS INTELLIGENCE
            </h1>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-[#0A2640] text-[#00F0FF] border border-[#00F0FF]/30">
              FILTERED SIGNAL
            </span>
          </div>
          <p className="text-xs text-[#6F95B7] mt-0.5">
            Curated market dispatches, regulatory filings, and earnings catalysts strictly tied to your active holdings.
          </p>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center bg-[#061421] p-1 rounded-lg border border-[#12314F] text-xs font-mono">
          {(['ALL', 'Bullish', 'Bearish'] as const).map(mode => (
            <button
              key={mode}
              onClick={() => setFilterImpact(mode)}
              className={`px-3 py-1 rounded transition-all ${
                filterImpact === mode 
                  ? 'bg-[#00F0FF] text-[#07131D] font-bold' 
                  : 'text-[#6D93B5] hover:text-white'
              }`}
            >
              {mode === 'ALL' ? 'All Signals' : mode}
            </button>
          ))}
        </div>
      </div>

      {/* News Articles Grid */}
      <div className="space-y-3.5">
        {filteredNews.map(item => {
          const isBull = item.impact === 'Bullish';
          return (
            <div
              key={item.id}
              className="p-5 rounded-2xl bg-[#091D2F] border border-[#133A5F] hover:border-[#1F4C77] transition-all space-y-3"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center gap-2 text-xs font-mono">
                  <span className="text-[#00F0FF] font-bold">{item.source}</span>
                  <span className="text-[#365A7C]">•</span>
                  <span className="text-[#6D95BA] flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {item.timeAgo}
                  </span>
                  <span className="text-[#365A7C]">•</span>
                  <span className="text-[#6D95BA]">{item.readTime}</span>
                </div>

                <span className={`inline-flex items-center gap-1 text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                  isBull 
                    ? 'bg-[#10B981]/20 text-[#34D399] border border-[#10B981]/30' 
                    : 'bg-[#F43F5E]/20 text-[#FB7185] border border-[#F43F5E]/30'
                }`}>
                  {isBull ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                  {item.impact}
                </span>
              </div>

              <h2 className="text-base font-bold text-white tracking-tight leading-snug">
                {item.title}
              </h2>

              <p className="text-xs text-[#CBD5E1] leading-relaxed">
                {item.summary}
              </p>

              {/* Cross-reference holdings tags */}
              <div className="pt-2 border-t border-[#12314F] flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono text-[#5881A4] uppercase">Tied Holdings:</span>
                  <div className="flex items-center gap-1.5">
                    {item.relatedHoldings.map(sym => (
                      <button
                        key={sym}
                        onClick={() => onNavigate(`#portfolio/holdings/${sym}`)}
                        className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-[#071625] text-white hover:text-[#00F0FF] border border-[#14395D] hover:border-[#00F0FF]/50 transition-all"
                      >
                        ${sym}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="text-[11px] font-mono text-[#5881A4] flex items-center gap-1">
                  <span>Verified Filing Link</span>
                  <ExternalLink className="w-3 h-3" />
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
