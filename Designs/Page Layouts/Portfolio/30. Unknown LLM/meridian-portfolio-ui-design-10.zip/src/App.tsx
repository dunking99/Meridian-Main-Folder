import { useState, useEffect } from 'react';
import { CurrencyCode, Holding } from './types';
import { CURRENCIES, INITIAL_HOLDINGS } from './data/portfolioData';
import { computePortfolioStats } from './utils/portfolioCalculations';
import { HeroPanel } from './components/HeroPanel';
import { TopNav } from './components/TopNav';
import { OverviewView } from './components/OverviewView';
import { HoldingsView } from './components/HoldingsView';
import { HoldingDetailView } from './components/HoldingDetailView';
import { PerformanceView } from './components/PerformanceView';
import { AnalysisView } from './components/AnalysisView';
import { RebalanceView } from './components/RebalanceView';
import { IncomeView } from './components/IncomeView';
import { MarketsView } from './components/MarketsView';
import { NewsView } from './components/NewsView';
import { WatchlistView } from './components/WatchlistView';
import { JournalView } from './components/JournalView';
import { QuickTradeModal } from './components/QuickTradeModal';
import { X } from 'lucide-react';

export function App() {
  // Navigation state using hash
  const [currentHash, setCurrentHash] = useState<string>(() => {
    return window.location.hash || '#portfolio/overview';
  });

  // Currency selection state
  const [currencyCode, setCurrencyCode] = useState<CurrencyCode>('USD');
  const currency = CURRENCIES[currencyCode] || CURRENCIES.USD;

  // Holdings state (allows simulated trading/updates)
  const [holdings, setHoldings] = useState<Holding[]>(INITIAL_HOLDINGS);

  // Trade modal state
  const [tradeModalOpen, setTradeModalOpen] = useState(false);
  const [tradeModalHolding, setTradeModalHolding] = useState<Holding | null>(null);

  // Mobile menu open
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Synchronize hash changes
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash || '#portfolio/overview';
      setCurrentHash(hash);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    window.addEventListener('hashchange', handleHashChange);
    if (!window.location.hash) {
      window.location.hash = '#portfolio/overview';
    }

    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const navigateTo = (newHash: string) => {
    window.location.hash = newHash;
    setCurrentHash(newHash);
    setMobileMenuOpen(false);
  };

  // Re-compute all aggregate portfolio statistics
  const stats = computePortfolioStats(holdings);

  // Parse holding symbol if on detail route
  let selectedHoldingSymbol: string | null = null;
  if (currentHash.startsWith('#portfolio/holdings/')) {
    selectedHoldingSymbol = currentHash.replace('#portfolio/holdings/', '').toUpperCase();
  }

  const selectedHoldingCalculation = selectedHoldingSymbol
    ? stats.enrichedHoldings.find(h => h.holding.symbol.toUpperCase() === selectedHoldingSymbol)
    : null;

  // Handle simulated trade
  const handleExecuteTrade = (trade: {
    symbol: string;
    type: 'BUY' | 'SELL';
    shares: number;
    price: number;
  }) => {
    setHoldings(prev => {
      return prev.map(h => {
        if (h.symbol !== trade.symbol) return h;

        if (trade.type === 'BUY') {
          const newShares = h.shares + trade.shares;
          const currentTotalCost = h.shares * h.avgCost;
          const addedCost = trade.shares * trade.price;
          const newAvgCost = (currentTotalCost + addedCost) / newShares;
          return {
            ...h,
            shares: newShares,
            avgCost: newAvgCost
          };
        } else {
          const newShares = Math.max(0, h.shares - trade.shares);
          return {
            ...h,
            shares: newShares
          };
        }
      });
    });
  };

  return (
    <div className="min-h-screen bg-[#07131D] text-[#E2E8F0] flex flex-col lg:flex-row antialiased selection:bg-[#00F0FF]/25 selection:text-[#00F0FF]">
      {/* Mobile Drawer Backdrop */}
      {mobileMenuOpen && (
        <div 
          onClick={() => setMobileMenuOpen(false)}
          className="fixed inset-0 z-40 bg-black/70 backdrop-blur-sm lg:hidden"
        />
      )}

      {/* Persistent Hero Panel on Left */}
      <div className={`
        fixed inset-y-0 left-0 z-50 transform lg:transform-none lg:static transition-transform duration-200 ease-in-out
        ${mobileMenuOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
        <div className="relative h-full flex flex-col">
          {/* Mobile close button */}
          <button
            onClick={() => setMobileMenuOpen(false)}
            className="absolute top-4 right-4 z-50 p-1.5 rounded-lg bg-[#0C243B] text-[#7FABCة] hover:text-white lg:hidden"
          >
            <X className="w-5 h-5" />
          </button>

          <HeroPanel
            currentPath={currentHash}
            onNavigate={navigateTo}
            currency={currency}
            onCurrencyChange={setCurrencyCode}
            totalValueUSD={stats.totalValueUSD}
            todayGainUSD={stats.todayGainUSD}
            todayChangePercent={stats.todayChangePercent}
            healthScore={84}
            topGainer={{
              symbol: stats.topDayGainer?.holding.symbol || 'NVDA',
              change: stats.topDayGainer?.holding.dayChangePercent || 0
            }}
            worstLoser={{
              symbol: stats.worstDayLoser?.holding.symbol || 'BABA',
              change: stats.worstDayLoser?.holding.dayChangePercent || 0
            }}
            onOpenTradeModal={() => {
              setTradeModalHolding(null);
              setTradeModalOpen(true);
            }}
          />
        </div>
      </div>

      {/* Right Canvas / Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 bg-[#07131D]">
        {/* Top Sticky Bar */}
        <TopNav
          currentPath={currentHash}
          onNavigate={navigateTo}
          holdings={holdings}
          currency={currency}
          totalGainUSD={stats.totalGainUSD}
          totalGainPercent={stats.totalGainPercent}
          annualIncomeUSD={stats.annualIncomeUSD}
          portfolioYieldPercent={stats.portfolioYieldPercent}
          cashDragPercent={stats.enrichedHoldings.find(h => h.holding.symbol === 'USD_CASH')?.weightPercent || 6.2}
          onOpenMobileMenu={() => setMobileMenuOpen(true)}
        />

        {/* Dynamic Sub-Page View Port */}
        <main className="flex-1 px-4 sm:px-6 lg:px-8 py-6 max-w-7xl mx-auto w-full">
          {/* 1. Holding Dossier Detail View */}
          {selectedHoldingCalculation ? (
            <HoldingDetailView
              holding={selectedHoldingCalculation.holding}
              calculation={selectedHoldingCalculation}
              currency={currency}
              onBack={() => navigateTo('#portfolio/holdings')}
              onNavigate={navigateTo}
              onOpenTradeModalWithHolding={(h) => {
                setTradeModalHolding(h);
                setTradeModalOpen(true);
              }}
            />
          ) : currentHash === '#portfolio/holdings' ? (
            /* 2. Holdings Master View */
            <HoldingsView
              enrichedHoldings={stats.enrichedHoldings}
              currency={currency}
              onNavigate={navigateTo}
              onOpenTradeModal={() => {
                setTradeModalHolding(null);
                setTradeModalOpen(true);
              }}
            />
          ) : currentHash === '#portfolio/performance' ? (
            /* 3. Performance & Alpha View */
            <PerformanceView onNavigate={navigateTo} />
          ) : currentHash === '#portfolio/analysis' ? (
            /* 4. Risk & Exposure Analysis View */
            <AnalysisView
              enrichedHoldings={stats.enrichedHoldings}
              sectors={stats.sectors}
              regions={stats.regions}
              currency={currency}
              onNavigate={navigateTo}
            />
          ) : currentHash === '#portfolio/rebalance' ? (
            /* 5. Drift & Rebalance Engine View */
            <RebalanceView
              enrichedHoldings={stats.enrichedHoldings}
              currency={currency}
              onNavigate={navigateTo}
            />
          ) : currentHash === '#portfolio/income' ? (
            /* 6. Income & Cash Flow View */
            <IncomeView
              enrichedHoldings={stats.enrichedHoldings}
              annualIncomeUSD={stats.annualIncomeUSD}
              portfolioYieldPercent={stats.portfolioYieldPercent}
              currency={currency}
              onNavigate={navigateTo}
            />
          ) : currentHash === '#markets' ? (
            /* 7. Macro & Global Markets View */
            <MarketsView />
          ) : currentHash === '#news' ? (
            /* 8. Portfolio Holdings Intelligence Feed */
            <NewsView onNavigate={navigateTo} />
          ) : currentHash === '#watchlist' ? (
            /* 9. Watchlist Radars */
            <WatchlistView onOpenTradeModal={() => {
              setTradeModalHolding(null);
              setTradeModalOpen(true);
            }} />
          ) : currentHash === '#journal' ? (
            /* 10. Thesis & Decision Log */
            <JournalView onNavigate={navigateTo} />
          ) : (
            /* Default: Overview View */
            <OverviewView
              holdings={holdings}
              enrichedHoldings={stats.enrichedHoldings}
              sectors={stats.sectors}
              totalValueUSD={stats.totalValueUSD}
              totalGainUSD={stats.totalGainUSD}
              totalGainPercent={stats.totalGainPercent}
              todayGainUSD={stats.todayGainUSD}
              todayChangePercent={stats.todayChangePercent}
              currency={currency}
              onNavigate={navigateTo}
            />
          )}
        </main>
      </div>

      {/* Quick Simulated Lot Order Modal */}
      <QuickTradeModal
        isOpen={tradeModalOpen}
        onClose={() => setTradeModalOpen(false)}
        holdings={holdings}
        initialHolding={tradeModalHolding}
        currency={currency}
        onExecuteTrade={handleExecuteTrade}
      />
    </div>
  );
}
export default App;
