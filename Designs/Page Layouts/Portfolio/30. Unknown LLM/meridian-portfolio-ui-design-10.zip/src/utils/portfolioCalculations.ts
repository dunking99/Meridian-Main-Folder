import { Holding, CurrencyRate } from '../types';

export function convertValue(amountInUSD: number, rate: CurrencyRate): number {
  return amountInUSD * rate.rateToUSD;
}

export function formatCurrency(amount: number, rate: CurrencyRate, compact = false): string {
  const converted = convertValue(amount, rate);
  
  if (compact && Math.abs(converted) >= 1_000_000) {
    return `${rate.symbol}${(converted / 1_000_000).toFixed(2)}M`;
  }
  if (compact && Math.abs(converted) >= 1_000) {
    return `${rate.symbol}${(converted / 1_000).toFixed(1)}k`;
  }

  // Format with standard locale
  const formattedNumber = new Intl.NumberFormat('en-US', {
    minimumFractionDigits: rate.code === 'JPY' ? 0 : 2,
    maximumFractionDigits: rate.code === 'JPY' ? 0 : 2,
  }).format(converted);

  return `${rate.symbol}${formattedNumber}`;
}

export function formatPercent(value: number, includeSign = true): string {
  const sign = includeSign && value > 0 ? '+' : '';
  return `${sign}${value.toFixed(2)}%`;
}

export interface HoldingCalculations {
  holding: Holding;
  currentValueUSD: number;
  totalCostUSD: number;
  totalGainUSD: number;
  totalGainPercent: number;
  dayGainUSD: number;
  weightPercent: number;
  driftPercent: number; // weightPercent - targetWeightPercent
}

export function computePortfolioStats(holdings: Holding[]) {
  let totalValueUSD = 0;
  let totalCostUSD = 0;
  let todayGainUSD = 0;
  let yesterdayTotalValueUSD = 0;
  let annualIncomeUSD = 0;

  const calculatedHoldings = holdings.map((h) => {
    // Current price in USD:
    // If currency is EUR, convert to USD based on fixed EURUSD rate (~1.08)
    const fxToUSD = h.currency === 'EUR' ? 1.083 : 1.0;
    const priceUSD = h.currentPrice * fxToUSD;
    const costUSD = h.avgCost * fxToUSD;
    const prevPriceUSD = h.prevClose * fxToUSD;

    const valueUSD = h.shares * priceUSD;
    const costBasisUSD = h.shares * costUSD;
    const gainUSD = valueUSD - costBasisUSD;
    const gainPct = costBasisUSD > 0 ? (gainUSD / costBasisUSD) * 100 : 0;
    
    const dayGain = h.shares * (priceUSD - prevPriceUSD);
    const holdingYesterdayVal = h.shares * prevPriceUSD;

    totalValueUSD += valueUSD;
    totalCostUSD += costBasisUSD;
    todayGainUSD += dayGain;
    yesterdayTotalValueUSD += holdingYesterdayVal;

    // Annual dividend
    const divUSD = (h.annualDividend || 0) * fxToUSD * h.shares;
    annualIncomeUSD += divUSD;

    return {
      holding: h,
      currentValueUSD: valueUSD,
      totalCostUSD: costBasisUSD,
      totalGainUSD: gainUSD,
      totalGainPercent: gainPct,
      dayGainUSD: dayGain,
      priceUSD,
      costUSD
    };
  });

  const todayChangePercent = yesterdayTotalValueUSD > 0
    ? (todayGainUSD / yesterdayTotalValueUSD) * 100
    : 0;

  const totalGainUSD = totalValueUSD - totalCostUSD;
  const totalGainPercent = totalCostUSD > 0 ? (totalGainUSD / totalCostUSD) * 100 : 0;
  const portfolioYieldPercent = totalValueUSD > 0 ? (annualIncomeUSD / totalValueUSD) * 100 : 0;

  // Add weights and drift
  const enrichedHoldings: HoldingCalculations[] = calculatedHoldings.map((ch) => {
    const weight = totalValueUSD > 0 ? (ch.currentValueUSD / totalValueUSD) * 100 : 0;
    const drift = weight - ch.holding.targetWeightPercent;
    return {
      ...ch,
      weightPercent: weight,
      driftPercent: drift
    };
  });

  // Sector breakdown
  const sectorMap: Record<string, { valueUSD: number; count: number; dayGainUSD: number }> = {};
  enrichedHoldings.forEach(item => {
    const s = item.holding.sector;
    if (!sectorMap[s]) sectorMap[s] = { valueUSD: 0, count: 0, dayGainUSD: 0 };
    sectorMap[s].valueUSD += item.currentValueUSD;
    sectorMap[s].count += 1;
    sectorMap[s].dayGainUSD += item.dayGainUSD;
  });

  const sectors = Object.entries(sectorMap).map(([sector, data]) => ({
    name: sector,
    valueUSD: data.valueUSD,
    weightPercent: (data.valueUSD / totalValueUSD) * 100,
    count: data.count,
    dayChangePercent: (data.dayGainUSD / (data.valueUSD - data.dayGainUSD)) * 100
  })).sort((a, b) => b.valueUSD - a.valueUSD);

  // Region breakdown
  const regionMap: Record<string, number> = {};
  enrichedHoldings.forEach(item => {
    const r = item.holding.region;
    regionMap[r] = (regionMap[r] || 0) + item.currentValueUSD;
  });

  const regions = Object.entries(regionMap).map(([region, val]) => ({
    name: region,
    valueUSD: val,
    weightPercent: (val / totalValueUSD) * 100
  })).sort((a, b) => b.valueUSD - a.valueUSD);

  // Top and worst movers today
  const sortedByDay = [...enrichedHoldings].sort(
    (a, b) => b.holding.dayChangePercent - a.holding.dayChangePercent
  );
  const topDayGainer = sortedByDay[0];
  const worstDayLoser = sortedByDay[sortedByDay.length - 1];

  // Best and worst all-time
  const sortedByTotal = [...enrichedHoldings].sort(
    (a, b) => b.totalGainPercent - a.totalGainPercent
  );
  const bestAllTime = sortedByTotal[0];
  const worstAllTime = sortedByTotal[sortedByTotal.length - 1];

  return {
    totalValueUSD,
    totalCostUSD,
    totalGainUSD,
    totalGainPercent,
    todayGainUSD,
    todayChangePercent,
    annualIncomeUSD,
    portfolioYieldPercent,
    enrichedHoldings,
    sectors,
    regions,
    topDayGainer,
    worstDayLoser,
    bestAllTime,
    worstAllTime
  };
}
