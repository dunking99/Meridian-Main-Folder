import { seeded } from "../lib/format";

export type Holding = {
  id: string;
  ticker: string;
  name: string;
  type: "Stock" | "ETF" | "Crypto" | "Cash";
  sector: string;
  region: string;
  country: string;
  ccy: string;
  price: number;
  dayChg: number; // %
  weekChg: number;
  qty: number;
  avgCost: number;
  spark: number[];
  beta: number;
  pe: number | null;
  divYield: number;
  mktCap: string;
  high52: number;
  low52: number;
  color: string;
  thesis: string;
  catalyst: string;
  risk: string;
};

function mkSpark(seed: number, drift: number, vol: number, n = 28, start = 100) {
  const rnd = seeded(seed);
  const out: number[] = [start];
  for (let i = 1; i < n; i++) {
    const shock = (rnd() - 0.48) * vol + drift;
    out.push(out[i - 1] * (1 + shock / 100));
  }
  return out;
}

export const HOLDINGS: Holding[] = [
  { id: "nvda", ticker: "NVDA", name: "NVIDIA Corp", type: "Stock", sector: "Semiconductors", region: "North America", country: "United States", ccy: "USD", price: 187.42, dayChg: 4.32, weekChg: 7.8, qty: 320, avgCost: 88.4, spark: mkSpark(11, 0.55, 3.4), beta: 1.68, pe: 54.2, divYield: 0.04, mktCap: "$4.6T", high52: 195.4, low52: 86.6, color: "#76b900", thesis: "AI compute remains the scarcest asset in tech. Blackwell ramp + sovereign demand lock in 2 years of growth.", catalyst: "GTC keynote Mar 18 · Blackwell Ultra shipments", risk: "Single-name concentration (11.9%). Export controls on China.", },
  { id: "aapl", ticker: "AAPL", name: "Apple Inc", type: "Stock", sector: "Consumer Tech", region: "North America", country: "United States", ccy: "USD", price: 232.15, dayChg: 0.84, weekChg: 1.2, qty: 280, avgCost: 172.5, spark: mkSpark(22, 0.18, 1.6), beta: 1.04, pe: 35.8, divYield: 0.42, mktCap: "$3.5T", high52: 260.1, low52: 164.1, color: "#e8edf5", thesis: "Installed base + services flywheel. Apple Intelligence cycle could re-accelerate hardware.", catalyst: "iPhone 17 cycle · Services margin expansion", risk: "China demand softness, premium valuation.", },
  { id: "msft", ticker: "MSFT", name: "Microsoft", type: "Stock", sector: "Cloud & Software", region: "North America", country: "United States", ccy: "USD", price: 428.15, dayChg: 1.12, weekChg: 2.4, qty: 95, avgCost: 312.8, spark: mkSpark(33, 0.22, 1.7), beta: 0.98, pe: 36.4, divYield: 0.72, mktCap: "$3.2T", high52: 468.3, low52: 309.0, color: "#38bdf8", thesis: "Copilot monetization + Azure re-acceleration. Best risk-adjusted compounder in the book.", catalyst: "Azure growth inflection · Copilot seats", risk: "AI capex intensity pressuring FCF.", },
  { id: "amzn", ticker: "AMZN", name: "Amazon.com", type: "Stock", sector: "Cloud & Retail", region: "North America", country: "United States", ccy: "USD", price: 197.12, dayChg: -0.64, weekChg: 0.8, qty: 210, avgCost: 142.3, spark: mkSpark(44, 0.2, 2.1), beta: 1.14, pe: 42.1, divYield: 0, mktCap: "$2.1T", high52: 220.5, low52: 151.6, color: "#fb923c", thesis: "AWS margin recovery + advertising is now a $60B high-margin engine.", catalyst: "AWS re-acceleration · Prime Day data", risk: "Consumer slowdown, Kuiper capex.", },
  { id: "meta", ticker: "META", name: "Meta Platforms", type: "Stock", sector: "Social & AI", region: "North America", country: "United States", ccy: "USD", price: 585.2, dayChg: 2.18, weekChg: 4.1, qty: 70, avgCost: 328.4, spark: mkSpark(55, 0.35, 2.6), beta: 1.22, pe: 27.6, divYield: 0.34, mktCap: "$1.5T", high52: 638.4, low52: 358.2, color: "#60a5fa", thesis: "Reels + Advantage+ rebuilt the ad engine. Llama optionality is free.", catalyst: "Reality Labs losses narrowing · Election ad spend", risk: "Regulatory overhang in EU.", },
  { id: "avgo", ticker: "AVGO", name: "Broadcom", type: "Stock", sector: "Semiconductors", region: "North America", country: "United States", ccy: "USD", price: 172.44, dayChg: 3.05, weekChg: 5.6, qty: 220, avgCost: 98.2, spark: mkSpark(66, 0.4, 2.8), beta: 1.32, pe: 31.2, divYield: 1.22, mktCap: "$805B", high52: 186.4, low52: 122.3, color: "#f87171", thesis: "VMware cross-sell + custom AI ASICs (Google, Meta) = dual growth legs.", catalyst: "VMware ARR · AI networking orders", risk: "M&A leverage, cyclical semis.", },
  { id: "tsm", ticker: "TSM", name: "Taiwan Semi", type: "Stock", sector: "Semiconductors", region: "Asia-Pacific", country: "Taiwan", ccy: "TWD", price: 198.44, dayChg: 1.86, weekChg: 3.2, qty: 180, avgCost: 118.6, spark: mkSpark(77, 0.3, 2.2), beta: 1.08, pe: 29.4, divYield: 1.05, mktCap: "$1.03T", high52: 205.6, low52: 125.8, color: "#fbbf24", thesis: "The foundry toll road for all AI silicon. 3nm sold out, 2nm pricing power.", catalyst: "CoWoS capacity doubling · Arizona fab", risk: "Geopolitical (Taiwan) concentration.", },
  { id: "asml", ticker: "ASML", name: "ASML Holding", type: "Stock", sector: "Semicon Equipment", region: "Europe", country: "Netherlands", ccy: "EUR", price: 698.2, dayChg: -1.42, weekChg: -2.8, qty: 42, avgCost: 742.5, spark: mkSpark(88, -0.1, 2.4), beta: 1.28, pe: 33.8, divYield: 0.92, mktCap: "$276B", high52: 1021.0, low52: 610.2, color: "#a78bfa", thesis: "Monopoly on EUV. High-NA orders from 2026 secure the next node.", catalyst: "High-NA bookings · China service revenue", risk: "Only loser YTD — memory capex delay.", },
  { id: "mc", ticker: "MC", name: "LVMH Moët Hennessy", type: "Stock", sector: "Luxury", region: "Europe", country: "France", ccy: "EUR", price: 735.4, dayChg: 0.42, weekChg: -0.6, qty: 35, avgCost: 812.2, spark: mkSpark(99, -0.05, 1.8), beta: 0.92, pe: 24.6, divYield: 1.82, mktCap: "$368B", high52: 879.0, low52: 588.4, color: "#f9a8d4", thesis: "Luxury trough is priced in. Cognac + China recovery = rerating.", catalyst: "China stimulus · Fashion & Leather rebound", risk: "Prolonged aspirational-consumer weakness.", },
  { id: "spy", ticker: "SPY", name: "S&P 500 ETF", type: "ETF", sector: "Broad Market", region: "North America", country: "United States", ccy: "USD", price: 582.32, dayChg: 0.62, weekChg: 1.1, qty: 110, avgCost: 478.4, spark: mkSpark(111, 0.16, 1.1), beta: 1.0, pe: 28.2, divYield: 1.28, mktCap: "$588B AUM", high52: 602.1, low52: 481.8, color: "#34d399", thesis: "Core ballast. Keeps single-stock risk honest and harvests market beta.", catalyst: "—", risk: "None — ballast.", },
  { id: "ibit", ticker: "IBIT", name: "iShares Bitcoin ETF", type: "Crypto", sector: "Digital Gold", region: "Global", country: "Global", ccy: "USD", price: 61.84, dayChg: 5.84, weekChg: 11.4, qty: 600, avgCost: 38.2, spark: mkSpark(122, 0.5, 4.2), beta: 1.9, pe: null, divYield: 0, mktCap: "$68B AUM", high52: 66.4, low52: 28.1, color: "#f97316", thesis: "Scarce, liquid, non-sovereign. 5–7% sleeve improves convexity.", catalyst: "ETF inflows · Halving supply shock", risk: "60% drawdowns are normal. Size accordingly.", },
  { id: "cash", ticker: "CASH", name: "USD Cash · Sweep", type: "Cash", sector: "Cash", region: "North America", country: "United States", ccy: "USD", price: 1, dayChg: 0.0, weekChg: 0.0, qty: 28400, avgCost: 1, spark: mkSpark(133, 0.0, 0.05, 28, 100), beta: 0, pe: null, divYield: 4.3, mktCap: "—", high52: 1, low52: 1, color: "#94a3b8", thesis: "Dry powder earning 4.3%. Two months of planned buying.", catalyst: "Deploy on -7% pullback", risk: "Cash drag in melt-up.", },
];

export type Enriched = Holding & { value: number; gain: number; gainPct: number; dayPL: number; weight: number };

export function enrich(holdings: Holding[]): Enriched[] {
  const total = holdings.reduce((s, h) => s + h.price * h.qty, 0);
  return holdings
    .map((h) => {
      const value = h.price * h.qty;
      const cost = h.avgCost * h.qty;
      const gain = value - cost;
      return {
        ...h,
        value,
        gain,
        gainPct: cost ? (gain / cost) * 100 : 0,
        dayPL: (value * h.dayChg) / 100,
        weight: (value / total) * 100,
      };
    })
    .sort((a, b) => b.value - a.value);
}

export const ENRICHED = enrich(HOLDINGS);
export const TOTAL = ENRICHED.reduce((s, h) => s + h.value, 0);
export const DAY_PL = ENRICHED.reduce((s, h) => s + h.dayPL, 0);
export const DAY_PCT = (DAY_PL / (TOTAL - DAY_PL)) * 100;
export const TOTAL_GAIN = ENRICHED.reduce((s, h) => s + h.gain, 0);
export const TOTAL_COST = TOTAL - TOTAL_GAIN;

// ---- history (365d) ----
export function buildHistory() {
  const rnd = seeded(7);
  const pts: { t: string; v: number; b: number }[] = [];
  const now = new Date("2026-09-24");
  let v = TOTAL / 1.42; // ~42% gain over year
  let b = TOTAL / 1.31;
  for (let i = 364; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(d.getDate() - i);
    const prog = (364 - i) / 364;
    const driftV = 0.0016 + Math.sin(prog * 9) * 0.0006;
    const driftB = 0.0011;
    const shockV = (rnd() - 0.485) * 0.024;
    const shockB = (rnd() - 0.49) * 0.016;
    // inject drawdown in April
    const dd = prog > 0.52 && prog < 0.6 ? -0.004 : 0;
    v = v * (1 + driftV + shockV + dd);
    b = b * (1 + driftB + shockB + dd * 0.8);
    if (i === 0) { v = TOTAL; b = TOTAL / 1.084; }
    pts.push({ t: d.toISOString().slice(0, 10), v, b });
  }
  return pts;
}
export const HISTORY = buildHistory();

// monthly returns: [year, months jan..dec], null = future
export const MONTHLY: { year: number; months: (number | null)[]; bench: (number | null)[] }[] = [
  { year: 2024, months: [1.8, 2.4, 3.1, -2.6, 3.8, 2.2, 1.4, 2.9, 1.1, -1.2, 4.6, 2.8], bench: [1.6, 2.1, 2.4, -3.1, 2.8, 1.9, 1.1, 2.2, 1.4, -1.8, 3.4, 2.1] },
  { year: 2025, months: [2.2, -1.4, 1.9, -6.4, 5.2, 3.6, 2.8, 1.6, -0.8, 3.2, 2.4, 1.9], bench: [1.8, -1.8, 1.2, -5.8, 4.1, 2.9, 2.2, 1.1, -1.2, 2.4, 1.8, 1.4] },
  { year: 2026, months: [3.4, 1.2, -2.1, -4.8, 6.8, 4.2, 3.1, 2.4, 1.67, null, null, null], bench: [2.8, 0.9, -2.4, -4.2, 5.4, 3.4, 2.6, 1.9, 1.02, null, null, null] },
];

export const TRAILING = [
  { label: "1D", p: 1.67, b: 0.62 },
  { label: "1W", p: 3.42, b: 1.84 },
  { label: "1M", p: 6.18, b: 4.12 },
  { label: "3M", p: 12.84, b: 8.92 },
  { label: "6M", p: 9.42, b: 6.18 },
  { label: "YTD", p: 18.64, b: 12.42 },
  { label: "1Y", p: 34.28, b: 22.14 },
  { label: "3Y", p: 98.4, b: 62.8 },
  { label: "Since inception", p: 214.6, b: 148.2 },
];

export const ATTRIBUTION = [
  { ticker: "NVDA", contrib: 6.42 },
  { ticker: "IBIT", contrib: 3.18 },
  { ticker: "META", contrib: 2.44 },
  { ticker: "AVGO", contrib: 2.02 },
  { ticker: "MSFT", contrib: 1.48 },
  { ticker: "SPY", contrib: 1.22 },
  { ticker: "AAPL", contrib: 0.84 },
  { ticker: "TSM", contrib: 0.78 },
  { ticker: "AMZN", contrib: -0.12 },
  { ticker: "ASML", contrib: -0.48 },
  { ticker: "MC", contrib: -0.34 },
];

export const SECTORS = [
  { name: "Semiconductors", w: 30.4, bench: 11.2, color: "#cdf138" },
  { name: "Cloud & Software", w: 16.8, bench: 12.4, color: "#38bdf8" },
  { name: "Consumer Tech", w: 12.9, bench: 8.1, color: "#e8edf5" },
  { name: "Broad Market", w: 12.7, bench: 100, color: "#34d399" },
  { name: "Social & AI", w: 8.1, bench: 4.2, color: "#60a5fa" },
  { name: "Cloud & Retail", w: 8.2, bench: 5.4, color: "#fb923c" },
  { name: "Digital Gold", w: 7.3, bench: 0, color: "#f97316" },
  { name: "Luxury", w: 5.1, bench: 0.8, color: "#f9a8d4" },
  { name: "Semicon Equipment", w: 5.8, bench: 1.1, color: "#a78bfa" },
];

export const REGIONS = [
  { name: "United States", w: 78.4, x: 22, y: 42, holdings: 8 },
  { name: "Taiwan", w: 7.1, x: 76, y: 48, holdings: 1 },
  { name: "Netherlands", w: 5.8, x: 51, y: 28, holdings: 1 },
  { name: "France", w: 5.1, x: 49, y: 32, holdings: 1 },
  { name: "Global (BTC)", w: 7.3, x: 50, y: 58, holdings: 1 },
];

export const CCYS = [
  { c: "USD", w: 82.4, color: "#cdf138" },
  { c: "EUR", w: 10.9, color: "#a78bfa" },
  { c: "TWD", w: 7.1, color: "#fbbf24" },
];

export const TRANSACTIONS = [
  { d: "Sep 22", type: "BUY", ticker: "AVGO", detail: "40 sh @ $166.20", amount: 6648, icon: "buy" },
  { d: "Sep 18", type: "DIV", ticker: "MSFT", detail: "$0.83/sh · 95 sh", amount: 78.85, icon: "div" },
  { d: "Sep 12", type: "BUY", ticker: "IBIT", detail: "80 sh @ $57.40", amount: 4592, icon: "buy" },
  { d: "Sep 04", type: "SELL", ticker: "AAPL", detail: "20 sh @ $238.10", amount: 4762, icon: "sell" },
  { d: "Aug 28", type: "DIV", ticker: "SPY", detail: "$1.78/sh · 110 sh", amount: 195.8, icon: "div" },
  { d: "Aug 15", type: "BUY", ticker: "TSM", detail: "25 sh @ $182.10", amount: 4552, icon: "buy" },
];

export const EVENTS = [
  { d: "Oct 02", ticker: "META", what: "AI Connect keynote", tag: "Catalyst" },
  { d: "Oct 28", ticker: "MSFT", what: "Q1 earnings", tag: "Earnings" },
  { d: "Oct 30", ticker: "AAPL", what: "Q4 earnings", tag: "Earnings" },
  { d: "Nov 19", ticker: "NVDA", what: "Q3 earnings", tag: "Earnings" },
  { d: "Dec 12", ticker: "SPY", what: "Dividend $1.92 est.", tag: "Dividend" },
];

export const NEWS = [
  { t: "Blackwell Ultra shipments accelerate — ODM checks", src: "SemiAnalysis", time: "2h", tickers: ["NVDA", "AVGO", "TSM"] },
  { t: "Apple Intelligence rollout expands to EU", src: "Meridian Wire", time: "5h", tickers: ["AAPL"] },
  { t: "Bitcoin ETF streak: 12th straight inflow week", src: "CoinDesk", time: "8h", tickers: ["IBIT"] },
  { t: "ASML High-NA orders: Intel + TSMC confirm 2026 slots", src: "Reuters", time: "1d", tickers: ["ASML"] },
];
