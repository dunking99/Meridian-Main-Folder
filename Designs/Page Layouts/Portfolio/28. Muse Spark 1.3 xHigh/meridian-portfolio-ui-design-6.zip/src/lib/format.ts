export const FX: Record<string, { rate: number; symbol: string; label: string; flag: string }> = {
  USD: { rate: 1, symbol: "$", label: "US Dollar", flag: "US" },
  EUR: { rate: 0.92, symbol: "€", label: "Euro", flag: "EU" },
  GBP: { rate: 0.79, symbol: "£", label: "British Pound", flag: "UK" },
  CHF: { rate: 0.88, symbol: "CHF ", label: "Swiss Franc", flag: "CH" },
  JPY: { rate: 149.6, symbol: "¥", label: "Japanese Yen", flag: "JP" },
};

export function fmtMoney(usd: number, ccy = "USD", opts?: { decimals?: number; compact?: boolean }) {
  const fx = FX[ccy] ?? FX.USD;
  const v = usd * fx.rate;
  const d = opts?.decimals ?? (Math.abs(v) >= 10000 ? 0 : 2);
  if (opts?.compact && Math.abs(v) >= 1000000) return `${fx.symbol}${(v / 1000000).toFixed(2)}M`;
  if (opts?.compact && Math.abs(v) >= 1000) return `${fx.symbol}${(v / 1000).toFixed(1)}k`;
  return (
    fx.symbol +
    v.toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d })
  );
}

export function fmtPct(x: number, digits = 2) {
  const s = x >= 0 ? "+" : "";
  return `${s}${x.toFixed(digits)}%`;
}

export function fmtNum(x: number, digits = 2) {
  return x.toLocaleString("en-US", { minimumFractionDigits: digits, maximumFractionDigits: digits });
}

export function cx(...xs: (string | false | null | undefined)[]) {
  return xs.filter(Boolean).join(" ");
}

// deterministic pseudo random
export function seeded(seed: number) {
  let s = seed;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

export function sparkPath(values: number[], w: number, h: number, pad = 2) {
  const min = Math.min(...values);
  const max = Math.max(...values);
  const rng = max - min || 1;
  const stepX = (w - pad * 2) / (values.length - 1);
  return values
    .map((v, i) => {
      const x = pad + i * stepX;
      const y = h - pad - ((v - min) / rng) * (h - pad * 2);
      return `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");
}

export function areaPath(values: number[], w: number, h: number, pad = 4) {
  const line = sparkPath(values, w, h, pad);
  return `${line} L${(w - pad).toFixed(1)},${h} L${pad},${h} Z`;
}
