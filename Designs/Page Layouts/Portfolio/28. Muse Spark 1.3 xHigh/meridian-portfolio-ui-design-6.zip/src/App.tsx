import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Flame, BadgeCheck } from "lucide-react";
import { Sidebar, Topbar, TabNav, type TabId } from "./components/chrome";
import Overview from "./components/overview";
import { HoldingsView } from "./components/holdings";
import Performance from "./components/performance";
import Analysis from "./components/analysis";

export default function App() {
  const [tab, setTab] = useState<TabId>("overview");
  const [ccy, setCcy] = useState("USD");
  const [query, setQuery] = useState("");
  const [openId, setOpenId] = useState<string | null>(null);

  const openHolding = (id: string) => {
    if (tab !== "holdings") setTab("holdings");
    // slight delay so tab mounts before overlay
    requestAnimationFrame(() => setOpenId(id));
  };

  return (
    <div className="aurora min-h-screen bg-[#05080f] text-[#e8edf5]">
      <div className="mx-auto flex min-h-screen max-w-[1440px]">
        <Sidebar activeApp="portfolio" />
        <div className="min-w-0 flex-1">
          <Topbar ccy={ccy} setCcy={setCcy} query={query} setQuery={setQuery} />

          <main className="px-4 pt-6 pb-16 md:px-8">
            {/* portfolio masthead */}
            <div className="flex flex-wrap items-end justify-between gap-4">
              <div>
                <div className="flex items-center gap-2.5">
                  <span className="inline-flex items-center gap-1.5 rounded-full border border-[#cdf138]/30 bg-[#cdf138]/10 px-2.5 py-1 text-[11px] font-bold text-[#cdf138]"><Flame size={12} /> Growth · Concentrated</span>
                  <span className="inline-flex items-center gap-1 text-[11.5px] text-white/40"><BadgeCheck size={13} className="text-sky-300" /> Rebalanced Aug 30 · Next review Oct 31</span>
                </div>
                <h1 className="font-display mt-2 text-[38px] leading-[1.02] font-light tracking-tight md:text-[46px]">
                  Portfolio <span className="text-white/30 italic">— Jonas Growth</span>
                </h1>
                <p className="mt-1.5 max-w-[620px] text-[13.5px] leading-relaxed text-white/45">
                  One book, four lenses. Every number cross-links — a mover in <b className="text-white/70">Overview</b> opens its dossier in <b className="text-white/70">Holdings</b>, explains its <b className="text-white/70">Performance</b>, and justifies its <b className="text-white/70">Analysis</b>.
                </p>
              </div>
              <div className="hidden md:block text-right">
                <div className="mono-num text-[11px] tracking-[0.18em] text-white/35 uppercase">Reporting in {ccy}</div>
                <div className="mono-num mt-1 text-[13px] text-white/60">1 USD = {(ccy === "EUR" ? "0.92 €" : ccy === "GBP" ? "0.79 £" : ccy === "CHF" ? "0.88 CHF" : ccy === "JPY" ? "¥149.6" : "$1.00")} · ECB 15:30</div>
              </div>
            </div>

            <div className="mt-5"><TabNav tab={tab} setTab={setTab} /></div>

            <div className="mt-4">
              <AnimatePresence mode="wait">
                <motion.div key={tab + ccy} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}>
                  {tab === "overview" && <Overview ccy={ccy} onOpen={openHolding} />}
                  {tab === "holdings" && <HoldingsView ccy={ccy} query={query} openId={openId} setOpenId={setOpenId} />}
                  {tab === "performance" && <Performance ccy={ccy} />}
                  {tab === "analysis" && <Analysis ccy={ccy} onOpen={openHolding} />}
                </motion.div>
              </AnimatePresence>
            </div>

            <footer className="mt-10 flex flex-wrap items-center gap-3 border-t border-white/[0.07] pt-6 text-[11.5px] text-white/30">
              <span className="font-display text-[15px] text-white/50 italic">Meridian</span>
              <span>· Portfolio is the source of truth — Markets, News, Watchlist, Ideas & Journal all read from it.</span>
              <span className="ml-auto">Prices delayed 15m · Illustrative data · Built for one investor: you.</span>
            </footer>
          </main>
        </div>
      </div>
    </div>
  );
}
