import { useState, Fragment } from "react";
import { motion } from "framer-motion";
import { ShieldAlert, Globe2, Coins, Layers, FlaskConical, HeartPulse, ArrowUpRight, TriangleAlert } from "lucide-react";
import { SECTORS, REGIONS, CCYS, ENRICHED } from "../data/portfolio";
import { fmtMoney, cx } from "../lib/format";
import { Card, SectionHead, LogoOrb } from "./chrome";

function RiskDial({ score }: { score: number }) {
  const W = 320, H = 190, cx0 = 160, cy0 = 160, R = 125;
  const a0 = Math.PI;
  const ang = a0 + (score / 100) * Math.PI;
  const ticks = Array.from({ length: 41 }, (_, i) => {
    const a = a0 + (i / 40) * Math.PI;
    const maj = i % 5 === 0;
    const r1 = R - (maj ? 18 : 10), r2 = R - 4;
    return { x1: cx0 + Math.cos(a) * r1, y1: cy0 + Math.sin(a) * r1, x2: cx0 + Math.cos(a) * r2, y2: cy0 + Math.sin(a) * r2, maj, a };
  });
  const arc = (s: number, e: number, r = R - 26) => {
    const x1 = cx0 + Math.cos(a0 + s * Math.PI) * r, y1 = cy0 + Math.sin(a0 + s * Math.PI) * r;
    const x2 = cx0 + Math.cos(a0 + e * Math.PI) * r, y2 = cy0 + Math.sin(a0 + e * Math.PI) * r;
    return `M${x1},${y1} A${r},${r} 0 0 1 ${x2},${y2}`;
  };
  const nx = cx0 + Math.cos(ang) * (R - 44), ny = cy0 + Math.sin(ang) * (R - 44);
  return (
    <div className="relative">
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full">
        <defs>
          <linearGradient id="dialg" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#34d399" /><stop offset="45%" stopColor="#cdf138" /><stop offset="75%" stopColor="#fbbf24" /><stop offset="100%" stopColor="#ff6b7a" />
          </linearGradient>
        </defs>
        {ticks.map((t, i) => <line key={i} x1={t.x1} y1={t.y1} x2={t.x2} y2={t.y2} stroke={t.maj ? "rgba(255,255,255,0.5)" : "rgba(255,255,255,0.18)"} strokeWidth={t.maj ? 2 : 1} />)}
        <path d={arc(0, 1)} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth={14} strokeLinecap="round" />
        <motion.path d={arc(0, score / 100)} fill="none" stroke="url(#dialg)" strokeWidth={14} strokeLinecap="round" initial={{ pathLength: 0 }} whileInView={{ pathLength: 1 }} viewport={{ once: true }} transition={{ duration: 1.4 }} style={{ filter: "drop-shadow(0 0 12px rgba(205,241,56,0.4))" }} />
        <line x1={cx0} y1={cy0} x2={nx} y2={ny} stroke="white" strokeWidth={3} strokeLinecap="round" />
        <circle cx={cx0} cy={cy0} r={10} fill="#0b111e" stroke="white" strokeWidth={2.5} />
        <circle cx={cx0} cy={cy0} r={3.5} fill="#cdf138" />
        <text x={28} y={178} fill="rgba(255,255,255,0.35)" fontSize={10} fontWeight={700}>DEFENSIVE</text>
        <text x={252} y={178} fill="rgba(255,255,255,0.35)" fontSize={10} fontWeight={700}>DEGEN</text>
      </svg>
      <div className="absolute inset-x-0 bottom-0 text-center">
        <div className="mono-num text-[44px] leading-none font-black">{score}</div>
        <div className="mt-1 inline-block rounded-full bg-[#cdf138]/12 border border-[#cdf138]/30 px-3 py-1 text-[11.5px] font-bold text-[#cdf138]">Growth-tilted · controlled</div>
      </div>
    </div>
  );
}

function DotMap() {
  // stylized dotted world: rows of dots, landmasses brighter
  const rows = 18, cols = 52;
  const land = (r: number, c: number) => {
    // rough continent blobs
    const na = c > 4 && c < 15 && r > 4 && r < 11;
    const sa = c > 11 && c < 16 && r >= 11 && r < 15;
    const eu = c > 24 && c < 29 && r > 4 && r < 8;
    const af = c > 25 && c < 30 && r >= 8 && r < 13;
    const as = c > 30 && c < 44 && r > 4 && r < 12;
    const au = c > 40 && c < 45 && r >= 13 && r < 15;
    return na || sa || eu || af || as || au;
  };
  return (
    <div className="relative overflow-hidden rounded-2xl border border-white/[0.08] bg-[#04070d] p-4">
      <div className="grid" style={{ gridTemplateColumns: `repeat(${cols}, 1fr)`, gap: 3 }}>
        {Array.from({ length: rows * cols }, (_, i) => {
          const r = Math.floor(i / cols), c = i % cols;
          const isLand = land(r, c);
          // holding hotspots
          const hot = REGIONS.some((rg) => Math.abs(rg.x / 2 - c) < 2 && Math.abs(rg.y / 5.5 - r) < 1.6);
          return <span key={i} className={cx("h-[5px] w-[5px] rounded-full", hot ? "bg-[#cdf138] shadow-[0_0_8px_#cdf138]" : isLand ? "bg-white/[0.22]" : "bg-white/[0.05]")} />;
        })}
      </div>
      <div className="pointer-events-none absolute inset-0">
        {REGIONS.map((rg) => (
          <div key={rg.name} className="group absolute" style={{ left: `${rg.x}%`, top: `${rg.y}%` }}>
            <span className="absolute -inset-3 animate-ping rounded-full bg-[#cdf138]/20" />
            <span className="absolute top-4 left-1/2 z-10 hidden -translate-x-1/2 rounded-lg border border-white/15 bg-black/90 px-2 py-1 text-[10.5px] font-bold whitespace-nowrap group-hover:block">{rg.name} · {rg.w}%</span>
          </div>
        ))}
      </div>
      <div className="relative mt-3 flex flex-wrap gap-2">
        {REGIONS.map((rg) => (
          <span key={rg.name} className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.05] px-2.5 py-1 text-[11px] font-semibold"><span className="h-1.5 w-1.5 rounded-full bg-[#cdf138]" />{rg.name} <b className="mono-num">{rg.w}%</b></span>
        ))}
      </div>
    </div>
  );
}

const PILLARS = [
  { k: "Diversification", s: 68, note: "9 stocks + ballast; NVDA 11.9% is the load", color: "#7dd3fc" },
  { k: "Quality", s: 91, note: "ROIC 28% avg · all FCF-positive ex-IBIT", color: "#cdf138" },
  { k: "Valuation", s: 58, note: "32× blended fwd P/E — paying for growth", color: "#fbbf24" },
  { k: "Momentum", s: 86, note: "Above 50/200d on 8 of 11 risk assets", color: "#a78bfa" },
  { k: "Risk control", s: 74, note: "Beta 1.18 · DD −9.2% vs −8.1% market", color: "#34d399" },
  { k: "Income", s: 44, note: "0.7% yield · $3.4k/yr — growth book", color: "#fb923c" },
];

const CORR = [
  ["NVDA", 1, 0.62, 0.58, 0.44, 0.31, 0.52],
  ["AAPL", 0.62, 1, 0.71, 0.55, 0.28, 0.68],
  ["MSFT", 0.58, 0.71, 1, 0.6, 0.24, 0.74],
  ["IBIT", 0.44, 0.55, 0.6, 1, 0.12, 0.48],
  ["MC", 0.31, 0.28, 0.24, 0.12, 1, 0.35],
  ["SPY", 0.52, 0.68, 0.74, 0.48, 0.35, 1],
] as const;

export default function Analysis({ ccy, onOpen }: { ccy: string; onOpen: (id: string) => void }) {
  const [shock, setShock] = useState(-15);
  const beta = 1.18;
  const portShock = shock * beta * (shock < 0 ? 0.94 : 1.02);

  return (
    <div className="space-y-4">
      <div className="grid gap-4 xl:grid-cols-[1fr_1fr_1.2fr]">
        <Card className="p-6">
          <SectionHead kicker="Riskometer" title="How risky?" sub="A speedometer, not a number. 68 = built to run, not to hide." />
          <div className="mt-2"><RiskDial score={68} /></div>
          <div className="mt-4 grid grid-cols-2 gap-2">
            {[["Volatility", "22.4%", "vs 16.1% SPY"], ["Sharpe", "1.42", "risk well paid"], ["Max drawdown", "−9.2%", "41d recovery"], ["Value at Risk 95%", "−2.1%/day", "≈ −$10.8k"]].map(([k, v, s]) => (
              <div key={k} className="rounded-xl border border-white/[0.07] bg-white/[0.03] p-2.5"><div className="text-[10px] font-bold tracking-[0.14em] text-white/35 uppercase">{k}</div><div className="mono-num mt-0.5 text-[15px] font-bold">{v}</div><div className="text-[11px] text-white/40">{s}</div></div>
            ))}
          </div>
        </Card>

        <Card className="p-6">
          <SectionHead kicker="Condition" title="Health score 82" sub="Six pillars. Fix orange before chasing green." />
          <div className="mt-4 space-y-3">
            {PILLARS.map((p, i) => (
              <div key={p.k}>
                <div className="flex items-center justify-between text-[12px]"><span className="font-semibold text-white/75">{p.k}</span><span className="mono-num font-bold" style={{ color: p.color }}>{p.s}</span></div>
                <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-white/[0.07]">
                  <motion.div initial={{ width: 0 }} whileInView={{ width: `${p.s}%` }} viewport={{ once: true }} transition={{ duration: 1, delay: i * 0.08 }} className="h-full rounded-full" style={{ background: `linear-gradient(90deg, ${p.color}55, ${p.color})`, boxShadow: `0 0 12px ${p.color}66` }} />
                </div>
                <div className="mt-1 text-[11px] text-white/35">{p.note}</div>
              </div>
            ))}
          </div>
        </Card>

        <Card className="aurora p-6">
          <SectionHead kicker="Verdict" title="The state of the book" />
          <div className="mt-3 flex items-center gap-2">
            <HeartPulse size={16} className="text-[#cdf138]" />
            <span className="font-display text-[26px] italic">Robust — with one loud concentration.</span>
          </div>
          <p className="mt-2 text-[13px] leading-relaxed text-white/60">Quality and momentum carry you. Valuation and single-name load are the tax. Nothing here says <i>de-risk</i> — everything says <i>rebalance the winners into the laggards you still believe in</i>.</p>
          <div className="mt-4 space-y-2">
            {[
              ["Trim NVDA into weakness cover", "Sell 25 sh (~$4.7k) if weight >13%. Recycle into ASML — same AI chain, 20% off highs.", "#cdf138"],
              ["Add one defensive spine", "Healthcare or staples 4–6% sleeve would cut beta 1.18 → ~1.08 without killing alpha.", "#7dd3fc"],
              ["Hedge the euro tail", "10.9% EUR exposure unhedged. A 10% EUR slide = −$5.6k phantom loss. Consider 50% hedge.", "#a78bfa"],
            ].map(([t, d, c], i) => (
              <motion.div key={t as string} initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.12 }} className="flex gap-3 rounded-2xl border border-white/[0.08] bg-black/30 p-3.5">
                <span className="mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-xl text-[13px] font-black text-black" style={{ background: c as string }}>{i + 1}</span>
                <span><b className="block text-[13px]">{t}</b><span className="mt-0.5 block text-[12px] leading-relaxed text-white/50">{d}</span></span>
              </motion.div>
            ))}
          </div>
        </Card>
      </div>

      {/* exposures */}
      <div className="grid gap-4 xl:grid-cols-2">
        <Card className="p-6 md:p-7">
          <SectionHead kicker="Sector map" title="Where you're exposed" sub="Lime = your weight · hollow dot = S&P 500. The gap is your active bet." />
          <div className="mt-5 space-y-3">
            {SECTORS.map((s, i) => (
              <div key={s.name} className="group">
                <div className="flex items-center gap-2 text-[12.5px]"><Layers size={12} className="text-white/30" /><span className="font-semibold">{s.name}</span><span className="mono-num ml-auto font-bold">{s.w}%</span></div>
                <div className="relative mt-1.5 h-[22px] overflow-hidden rounded-lg bg-white/[0.04]">
                  <motion.div initial={{ width: 0 }} whileInView={{ width: `${Math.min(100, s.w * 2.4)}%` }} viewport={{ once: true }} transition={{ duration: 0.9, delay: i * 0.05 }} className="absolute inset-y-0 left-0 rounded-lg opacity-90" style={{ background: `linear-gradient(90deg, ${s.color}44, ${s.color})` }} />
                  {s.bench <= 40 && <span className="absolute top-1/2 h-3 w-3 -translate-y-1/2 rounded-full border-2 border-white/70 bg-transparent" style={{ left: `min(calc(${Math.min(100, s.bench * 2.4)}%), calc(100% - 14px))` }} title={`Benchmark ${s.bench}%`} />}
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 flex items-center gap-2 rounded-xl border border-amber-300/20 bg-amber-300/[0.06] p-3 text-[12px] text-white/60"><TriangleAlert size={15} className="shrink-0 text-amber-300" /> Semiconductors at 30% (vs 11% market) is a <b className="text-white">3× overweight</b> — deliberate, but it <i>is</i> the portfolio.</div>
        </Card>

        <div className="space-y-4">
          <Card className="p-6">
            <SectionHead kicker="Geography" title="A dotted planet" sub="Every glow dot is where your capital sleeps. Hover a pin." />
            <div className="mt-4"><DotMap /></div>
            <div className="mt-3 flex items-center gap-2 text-[11.5px] text-white/40"><Globe2 size={13} /> 78% US-listed, but 13% of revenue exposure is Asia-Pacific supply chain (TSM + ASML + NVDA fab).</div>
          </Card>
          <Card className="p-6">
            <SectionHead kicker="Currency" title="What FX moves you" />
            <div className="mt-4 space-y-2.5">
              {CCYS.map((c) => (
                <div key={c.c} className="flex items-center gap-3">
                  <span className="mono-num w-10 text-[12px] font-black">{c.c}</span>
                  <div className="h-3 flex-1 overflow-hidden rounded-full bg-white/[0.06]"><motion.div initial={{ width: 0 }} whileInView={{ width: `${c.w}%` }} viewport={{ once: true }} transition={{ duration: 0.9 }} className="h-full rounded-full" style={{ background: c.color }} /></div>
                  <span className="mono-num w-12 text-right text-[12.5px] font-bold">{c.w}%</span>
                </div>
              ))}
            </div>
            <div className="mt-3 flex items-center gap-2 rounded-xl bg-white/[0.03] border border-white/[0.07] p-3 text-[12px] text-white/55"><Coins size={14} className="text-[#cdf138]" /> EUR + TWD = 18% — a 5% dollar spike costs you ≈ <b className="mono-num text-white">−$9.2k</b> on translation alone.</div>
          </Card>
        </div>
      </div>

      {/* stress lab + correlation */}
      <div className="grid gap-4 xl:grid-cols-[1.25fr_1fr]">
        <Card className="relative overflow-hidden p-6 md:p-7">
          <div className="absolute -top-24 -right-24 h-64 w-64 rounded-full bg-[#ff6b7a]/10 blur-3xl" />
          <SectionHead kicker="Stress lab" title="What if markets crack?" sub="Drag the shock. Beta-adjusted, per-name — this is the number that should let you sleep." right={<span className="inline-flex items-center gap-1.5 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-1.5 text-[12px] font-bold"><FlaskConical size={13} className="text-[#cdf138]" /> Interactive</span>} />
          <div className="mt-5 flex flex-wrap items-center gap-4">
            <input type="range" min={-30} max={15} value={shock} onChange={(e) => setShock(Number(e.target.value))} className="h-2 flex-1 min-w-[200px] cursor-pointer appearance-none rounded-full bg-gradient-to-r from-rose-500 via-white/20 to-[#cdf138]" />
            <div className="flex items-center gap-3 rounded-2xl border border-white/10 bg-black/40 px-5 py-3">
              <span className="text-[11px] font-bold tracking-wider text-white/40 uppercase">Market {shock >= 0 ? "+" : ""}{shock}% → you</span>
              <span className={cx("mono-num text-[24px] font-black", portShock >= 0 ? "text-[#cdf138]" : "text-rose-300")}>{portShock >= 0 ? "+" : ""}{portShock.toFixed(1)}%</span>
              <span className="mono-num text-[13px] text-white/50">{fmtMoney(512840 * portShock / 100, ccy, { decimals: 0 })}</span>
            </div>
          </div>
          <div className="mt-5 grid gap-1.5 sm:grid-cols-2">
            {ENRICHED.filter((h) => h.ticker !== "CASH").slice(0, 8).map((h) => {
              const hit = shock * h.beta * 0.96;
              const val = (h.value * hit) / 100;
              return (
                <button key={h.id} onClick={() => onOpen(h.id)} className="flex items-center gap-2.5 rounded-xl border border-white/[0.06] bg-white/[0.02] px-3 py-2 text-left hover:border-white/20">
                  <LogoOrb ticker={h.ticker} color={h.color} size={28} />
                  <span className="min-w-0 flex-1"><span className="block truncate text-[12px] font-bold">{h.ticker} <span className="font-normal text-white/35">β {h.beta.toFixed(2)}</span></span>
                    <span className="relative mt-1 block h-1.5 overflow-hidden rounded-full bg-white/[0.07]"><span className={cx("absolute inset-y-0 left-1/2 rounded-full", hit >= 0 ? "bg-[#cdf138]" : "bg-rose-400")} style={{ width: `${Math.min(50, Math.abs(hit) * 1.6)}%`, [hit >= 0 ? "left" : "right"]: "50%" } as React.CSSProperties} /></span></span>
                  <span className={cx("mono-num text-[12px] font-bold", hit >= 0 ? "text-[#cdf138]" : "text-rose-300")}>{fmtMoney(val, ccy, { decimals: 0 })}</span>
                </button>
              );
            })}
          </div>
          <div className="mt-4 flex items-start gap-2 text-[12px] text-white/50"><ShieldAlert size={15} className="mt-0.5 shrink-0 text-amber-300" /> At −20% market, cash + SPY ballast saves you ≈ <b className="text-white">$6.1k</b> vs a pure-tech book. That's what the 18% ballast is <i>for</i>.</div>
        </Card>

        <div className="space-y-4">
          <Card className="p-6">
            <SectionHead kicker="Entanglement" title="Correlation web" sub="1.0 = joined at the hip. MC marches alone — that's valuable." />
            <div className="mt-4 overflow-hidden rounded-2xl border border-white/[0.07]">
              <div className="grid grid-cols-7 gap-px bg-white/[0.06] text-center">
                <span className="bg-[#0b111e] p-2" />
                {CORR.map((r) => <span key={r[0] as string} className="mono-num bg-[#0b111e] p-2 text-[10px] font-bold text-white/60">{(r[0] as string).slice(0, 4)}</span>)}
                {CORR.map((r) => (
                  <Fragment key={r[0] as string}>
                    <span className="mono-num bg-[#0b111e] p-2 text-[10px] font-bold text-white/60">{(r[0] as string).slice(0, 4)}</span>
                    {(r.slice(1) as unknown as number[]).map((v, j) => (
                      <span key={j} className="mono-num p-2 text-[11px] font-bold" style={{ background: `rgba(205,241,56,${v * v * 0.55})`, color: v > 0.6 ? "#05080f" : "#e8edf5" }}>{v.toFixed(2)}</span>
                    ))}
                  </Fragment>
                ))}
              </div>
            </div>
          </Card>
          <div className="flex items-center gap-3 rounded-3xl border border-white/[0.08] bg-gradient-to-r from-violet-500/15 to-sky-500/10 px-5 py-4 text-[13px]">
            <ArrowUpRight size={16} className="text-violet-300" />
            <span className="text-white/60"><b className="text-white">Diversifier of the month: LVMH.</b> 0.24 correlation to MSFT — when tech sneezes, Paris shrugs.</span>
          </div>
        </div>
      </div>
    </div>
  );
}
