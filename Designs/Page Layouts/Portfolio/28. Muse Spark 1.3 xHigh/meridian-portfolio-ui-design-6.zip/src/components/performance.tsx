import { useState } from "react";
import { motion } from "framer-motion";
import { Swords, CalendarDays, PieChart, Waves, Crosshair, Award } from "lucide-react";
import { MONTHLY, TRAILING, ATTRIBUTION, HISTORY } from "../data/portfolio";
import { fmtPct, cx } from "../lib/format";
import { Card, SectionHead } from "./chrome";

const MO = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

function cellColor(v: number | null) {
  if (v === null) return "bg-white/[0.02] border-white/[0.05] text-white/20";
  if (v >= 4) return "bg-[#cdf138] text-black border-[#cdf138] shadow-[0_0_18px_rgba(205,241,56,0.35)]";
  if (v >= 2) return "bg-[#cdf138]/70 text-black border-transparent";
  if (v >= 0.5) return "bg-[#cdf138]/30 text-[#e9ff9a] border-transparent";
  if (v >= -0.5) return "bg-white/[0.05] text-white/60 border-white/10";
  if (v >= -2.5) return "bg-rose-400/25 text-rose-200 border-transparent";
  if (v >= -5) return "bg-rose-400/55 text-white border-transparent";
  return "bg-[#ff2d55] text-white border-transparent shadow-[0_0_18px_rgba(255,45,85,0.4)]";
}

function GrowthDuel(_props: { ccy: string }) {
  const [hover, setHover] = useState<number | null>(null);
  const data = HISTORY.slice(-267); // YTD-ish
  // normalize to 100
  const p0 = data[0].v, b0 = data[0].b;
  const pn = data.map((d) => (d.v / p0) * 100);
  const bn = data.map((d) => (d.b / b0) * 100);
  const W = 900, H = 300, PAD = 10;
  const min = Math.min(...pn, ...bn) - 1, max = Math.max(...pn, ...bn) + 1;
  const X = (i: number) => PAD + (i / (data.length - 1)) * (W - PAD * 2);
  const Y = (v: number) => H - PAD - ((v - min) / (max - min)) * (H - PAD * 2 - 20);
  const line = (arr: number[]) => arr.map((v, i) => `${i === 0 ? "M" : "L"}${X(i).toFixed(1)},${Y(v).toFixed(1)}`).join(" ");

  return (
    <div onMouseMove={(e) => {
      const r = (e.currentTarget as HTMLDivElement).getBoundingClientRect();
      const px = ((e.clientX - r.left) / r.width) * W;
      const i = Math.round(((px - PAD) / (W - PAD * 2)) * (data.length - 1));
      setHover(Math.max(0, Math.min(data.length - 1, i)));
    }} onMouseLeave={() => setHover(null)} className="relative cursor-crosshair">
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full" preserveAspectRatio="none" style={{ height: 270 }}>
        <defs>
          <linearGradient id="duelFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#cdf138" stopOpacity="0.25" /><stop offset="100%" stopColor="#cdf138" stopOpacity="0" />
          </linearGradient>
        </defs>
        {[100, 105, 110, 115].map((g) => (
          <g key={g}><line x1={0} x2={W} y1={Y(g)} y2={Y(g)} stroke="rgba(255,255,255,0.07)" strokeDasharray="3 6" /><text x={W - 4} y={Y(g) - 5} textAnchor="end" fill="rgba(255,255,255,0.3)" fontSize={10}>{g}</text></g>
        ))}
        <path d={`${line(pn)} L${X(pn.length - 1).toFixed(1)},${H} L${X(0).toFixed(1)},${H} Z`} fill="url(#duelFill)" />
        {/* alpha band between lines */}
        <path d={`${line(pn)} L${X(0).toFixed(1)},${Y(bn[0]).toFixed(1)} ${bn.map((v, i) => `L${X(i).toFixed(1)},${Y(v).toFixed(1)}`).reverse().join(" ")} Z`} fill="rgba(205,241,56,0.08)" />
        <path d={line(bn)} fill="none" stroke="rgba(255,255,255,0.4)" strokeWidth={1.6} strokeDasharray="6 5" />
        <path d={line(pn)} fill="none" stroke="#cdf138" strokeWidth={3} strokeLinecap="round" style={{ filter: "drop-shadow(0 0 16px rgba(205,241,56,0.45))" }} />
        {hover !== null && (
          <g><line x1={X(hover)} x2={X(hover)} y1={0} y2={H} stroke="white" strokeOpacity={0.3} /><circle cx={X(hover)} cy={Y(pn[hover])} r={5.5} fill="#cdf138" stroke="#05080f" strokeWidth={2.5} /><circle cx={X(hover)} cy={Y(bn[hover])} r={4} fill="white" stroke="#05080f" strokeWidth={2} /></g>
        )}
      </svg>
      {hover !== null && (
        <div className="pointer-events-none absolute z-10 -translate-x-1/2 rounded-2xl border border-white/15 bg-[#0b111e]/95 px-4 py-2.5 backdrop-blur" style={{ left: `${(X(hover) / W) * 100}%`, top: 0 }}>
          <div className="text-[11px] text-white/45">{data[hover].t}</div>
          <div className="mono-num text-[13px] font-bold text-[#cdf138]">You {pn[hover].toFixed(1)}</div>
          <div className="mono-num text-[12px] text-white/55">SPY {bn[hover].toFixed(1)}</div>
        </div>
      )}
    </div>
  );
}

export default function Performance({ ccy }: { ccy: string }) {
  const [calMode, setCalMode] = useState<"you" | "diff">("you");
  const maxAttr = Math.max(...ATTRIBUTION.map((a) => Math.abs(a.contrib)));

  return (
    <div className="space-y-4">
      {/* trailing strip */}
      <Card className="p-6 md:p-7">
        <SectionHead kicker="Scoreboard" title="Trailing & cumulative" sub="Every horizon that matters — you vs the S&P 500 total return. Green edge = alpha you actually kept." />
        <div className="mt-5 grid grid-cols-3 gap-2 md:grid-cols-9">
          {TRAILING.map((t, i) => {
            const edge = t.p - t.b;
            return (
              <motion.div key={t.label} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
                className={cx("rounded-2xl border p-3 text-center", t.label === "YTD" ? "border-[#cdf138]/50 bg-[#cdf138]/[0.07] shadow-[0_0_30px_-10px_rgba(205,241,56,0.5)]" : "border-white/[0.07] bg-white/[0.025]")}>
                <div className="text-[10px] font-bold tracking-[0.14em] text-white/35 uppercase">{t.label}</div>
                <div className={cx("mono-num mt-1 text-[15px] font-black", t.p >= 0 ? "text-white" : "text-rose-300")}>{fmtPct(t.p, t.p > 50 ? 1 : 2)}</div>
                <div className={cx("mono-num mt-0.5 inline-block rounded-md px-1.5 py-0.5 text-[10.5px] font-bold", edge >= 0 ? "bg-[#cdf138]/15 text-[#cdf138]" : "bg-rose-400/15 text-rose-300")}>{edge >= 0 ? "+" : ""}{edge.toFixed(1)}</div>
              </motion.div>
            );
          })}
        </div>
      </Card>

      <div className="grid gap-4 xl:grid-cols-[1.4fr_1fr]">
        <Card className="p-6 md:p-7">
          <SectionHead kicker="The duel" title="You vs the benchmark" sub="Growth of $100 since Jan 1. The lime wash between the lines is your excess return — hover to inspect any day." right={<span className="inline-flex items-center gap-1.5 rounded-full bg-[#cdf138]/10 border border-[#cdf138]/25 px-3 py-1.5 text-[12px] font-bold text-[#cdf138]"><Swords size={13} /> Winning by 6.2 pts</span>} />
          <div className="mt-5"><GrowthDuel ccy={ccy} /></div>
          <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
            {[["Alpha (YTD)", "+6.22 pts", "top decile"], ["Beta", "1.18", " Punchy, not reckless"], ["Win rate (days)", "56.4%", "126 of 223"], ["Tracking err.", "7.8%", "active by design"]].map(([k, v, s]) => (
              <div key={k} className="rounded-xl border border-white/[0.07] bg-black/25 p-3"><div className="text-[10px] font-bold tracking-[0.14em] text-white/35 uppercase">{k}</div><div className="mono-num mt-1 text-[16px] font-bold">{v}</div><div className="text-[11px] text-white/40">{s}</div></div>
            ))}
          </div>
        </Card>

        <Card className="p-6">
          <SectionHead kicker="Attribution" title="Who earned it?" sub="Contribution to YTD return, in points. Not weight — impact." />
          <div className="mt-5 space-y-2">
            {ATTRIBUTION.map((a, i) => (
              <div key={a.ticker} className="flex items-center gap-2.5">
                <span className="mono-num w-12 text-[11.5px] font-bold text-white/70">{a.ticker}</span>
                <div className="relative h-7 flex-1 overflow-hidden rounded-lg bg-white/[0.04]">
                  <div className="absolute top-0 bottom-0 left-1/2 w-px bg-white/15" />
                  {a.contrib >= 0 ? (
                    <motion.div initial={{ width: 0 }} whileInView={{ width: `${(a.contrib / maxAttr) * 48}%` }} viewport={{ once: true }} transition={{ delay: i * 0.05, duration: 0.7 }} className="absolute top-1 bottom-1 left-1/2 rounded-md bg-gradient-to-r from-[#cdf138]/60 to-[#cdf138]" style={{ width: `${(a.contrib / maxAttr) * 48}%` }} />
                  ) : (
                    <motion.div initial={{ width: 0 }} whileInView={{ width: `${(Math.abs(a.contrib) / maxAttr) * 48}%` }} viewport={{ once: true }} className="absolute top-1 bottom-1 right-1/2 rounded-md bg-gradient-to-l from-rose-400/70 to-rose-500" style={{ width: `${(Math.abs(a.contrib) / maxAttr) * 48}%` }} />
                  )}
                </div>
                <span className={cx("mono-num w-16 text-right text-[12px] font-bold", a.contrib >= 0 ? "text-[#cdf138]" : "text-rose-300")}>{a.contrib >= 0 ? "+" : ""}{a.contrib.toFixed(2)}</span>
              </div>
            ))}
          </div>
          <div className="mt-4 rounded-xl border border-white/[0.08] bg-white/[0.03] p-3 text-[12px] leading-relaxed text-white/55"><b className="text-white">Takeaway:</b> 3 names (NVDA, IBIT, META) = 64% of your edge. That's working — until it isn't. See Analysis → concentration.</div>
        </Card>
      </div>

      {/* monthly calendar */}
      <Card className="p-6 md:p-7">
        <SectionHead kicker="Seasonality" title="Month by month" sub="A heat calendar — not a table. Deep lime = compounding months, red = the tuition you paid (April, twice)." right={
          <div className="flex rounded-xl border border-white/10 bg-black/30 p-1">
            <button onClick={() => setCalMode("you")} className={cx("rounded-lg px-3 py-1.5 text-[12px] font-bold", calMode === "you" ? "bg-white text-black" : "text-white/50")}>Your returns</button>
            <button onClick={() => setCalMode("diff")} className={cx("rounded-lg px-3 py-1.5 text-[12px] font-bold", calMode === "diff" ? "bg-[#cdf138] text-black" : "text-white/50")}>Edge vs SPY</button>
          </div>
        } />
        <div className="mt-5 space-y-3">
          {MONTHLY.map((y) => {
            const vals = y.months.map((m, i) => m === null ? null : calMode === "you" ? m : m - (y.bench[i] ?? 0));
            const yearTot = y.months.every((m) => m === null) ? null : (y.months.reduce<number>((s, m) => s + (m ?? 0), 0));
            return (
              <div key={y.year} className="flex flex-col gap-2 md:flex-row md:items-center">
                <div className="flex w-[86px] shrink-0 items-center gap-2">
                  <span className="font-display text-[20px] italic">{y.year}</span>
                  {yearTot !== null && <span className={cx("mono-num rounded-md px-1.5 py-0.5 text-[11px] font-bold", yearTot >= 0 ? "bg-[#cdf138]/15 text-[#cdf138]" : "bg-rose-400/15 text-rose-300")}>{fmtPct(yearTot, 1)}</span>}
                </div>
                <div className="grid flex-1 grid-cols-6 gap-1.5 md:grid-cols-12">
                  {vals.map((v, i) => (
                    <div key={i} title={`${MO[i]} ${y.year}: ${v === null ? "—" : fmtPct(v)}`} className={cx("group rounded-xl border px-1 py-2 text-center transition-transform hover:scale-[1.06]", cellColor(v))}>
                      <div className="text-[9.5px] font-bold tracking-wider opacity-60 uppercase">{MO[i]}</div>
                      <div className="mono-num text-[12.5px] font-black">{v === null ? "·" : `${v >= 0 ? "+" : ""}${v.toFixed(1)}`}</div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
        <div className="mt-4 flex flex-wrap items-center gap-3 text-[11.5px] text-white/40">
          <span className="flex items-center gap-1.5"><CalendarDays size={13} /> 27 green months of 33</span>
          <span className="flex items-center gap-1.5"><Award size={13} /> Best: May ’26 +6.8%</span>
          <span className="flex items-center gap-1.5"><Waves size={13} /> Worst: Apr ’25 −6.4% (tariff shock)</span>
          <span className="ml-auto hidden items-center gap-1.5 md:flex"><span className="h-2.5 w-2.5 rounded bg-[#ff2d55]" /><span className="h-2.5 w-2.5 rounded bg-white/10" /><span className="h-2.5 w-2.5 rounded bg-[#cdf138]" /> −6% → +6%</span>
        </div>
      </Card>

      {/* drawdown + consistency */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card className="p-6">
          <SectionHead kicker="Pain" title="Drawdowns" />
          <div className="mt-4">
            <div className="flex items-end justify-between"><span className="mono-num text-[34px] leading-none font-black text-rose-300">−9.2%</span><span className="text-[11.5px] text-white/40">Apr 4 → May 15 · 41 days</span></div>
            <svg viewBox="0 0 300 90" className="mt-3 w-full" preserveAspectRatio="none" style={{ height: 86 }}>
              <path d="M0,18 C40,22 60,30 90,52 C120,74 150,78 190,60 C230,42 260,30 300,22 L300,90 L0,90 Z" fill="rgba(255,107,122,0.12)" />
              <path d="M0,18 C40,22 60,30 90,52 C120,74 150,78 190,60 C230,42 260,30 300,22" fill="none" stroke="#ff6b7a" strokeWidth={2.4} strokeLinecap="round" />
              <circle cx={118} cy={72} r={4.5} fill="#ff2d55" stroke="#05080f" strokeWidth={2} />
              <text x={118} y={88} textAnchor="middle" fill="rgba(255,255,255,0.4)" fontSize={9}>trough −9.2%</text>
            </svg>
            <div className="mt-2 grid grid-cols-2 gap-2 text-[11.5px]"><span className="rounded-lg bg-white/[0.04] p-2">Recovery <b className="text-white">41 days</b></span><span className="rounded-lg bg-white/[0.04] p-2">Benchmark DD <b className="text-white">−8.1%</b></span></div>
          </div>
        </Card>
        <Card className="p-6">
          <SectionHead kicker="Habits" title="Consistency" />
          <div className="mt-4 flex items-center gap-4">
            <div className="relative h-[110px] w-[110px]">
              <svg viewBox="0 0 100 100" className="h-full w-full -rotate-90"><circle cx={50} cy={50} r={42} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth={10} /><motion.circle cx={50} cy={50} r={42} fill="none" stroke="#cdf138" strokeWidth={10} strokeLinecap="round" strokeDasharray={264} initial={{ strokeDashoffset: 264 }} whileInView={{ strokeDashoffset: 264 * (1 - 0.68) }} viewport={{ once: true }} transition={{ duration: 1.2 }} /></svg>
              <div className="absolute inset-0 grid place-items-center"><div className="text-center"><div className="mono-num text-[22px] font-black">68%</div><div className="text-[10px] text-white/40">up-months</div></div></div>
            </div>
            <div className="space-y-2 text-[12px]">
              {[["Positive quarters", "10 / 12"], ["Beat SPY (rolling 3M)", "71%"], ["Worst 30d streak", "−7.4%"]].map(([k, v]) => <div key={k} className="flex justify-between gap-4 rounded-lg bg-white/[0.04] px-2.5 py-1.5"><span className="text-white/50">{k}</span><b className="mono-num">{v}</b></div>)}
            </div>
          </div>
        </Card>
        <Card className="flex flex-col justify-between border-[#cdf138]/20 bg-gradient-to-b from-[#cdf138]/[0.08] to-transparent p-6">
          <div><SectionHead kicker="Verdict" title="Are you beating the market?" />
            <p className="mt-3 text-[13.5px] leading-relaxed text-white/65"><b className="text-white">Yes — and it's skill-tilted, not luck.</b> 6.2 pts of YTD alpha with 56% daily win rate. Concentration explains the magnitude; stock selection explains the sign.</p></div>
          <div className="mt-4 flex gap-2">
            <span className="inline-flex items-center gap-1.5 rounded-xl bg-[#cdf138] px-3.5 py-2 text-[12.5px] font-bold text-black"><Crosshair size={13} /> Alpha: real</span>
            <span className="inline-flex items-center gap-1.5 rounded-xl border border-white/12 px-3.5 py-2 text-[12.5px] font-semibold text-white/60"><PieChart size={13} /> See mix →</span>
          </div>
        </Card>
      </div>
    </div>
  );
}
