import { motion } from "framer-motion";
import {
  LayoutDashboard, Newspaper, Globe2, Eye, Lightbulb, NotebookPen,
  Search, Bell, Command, ChevronDown, Wallet,
} from "lucide-react";
import { cx } from "../lib/format";
import { FX } from "../lib/format";

export const TABS = [
  { id: "overview", label: "Overview", hint: "Pulse" },
  { id: "holdings", label: "Holdings", hint: "12 assets" },
  { id: "performance", label: "Performance", hint: "+18.6% YTD" },
  { id: "analysis", label: "Analysis", hint: "Risk & mix" },
] as const;
export type TabId = (typeof TABS)[number]["id"];

export function Sidebar({ activeApp }: { activeApp: string }) {
  const apps = [
    { id: "portfolio", icon: Wallet, label: "Portfolio" },
    { id: "markets", icon: Globe2, label: "Markets" },
    { id: "news", icon: Newspaper, label: "News" },
    { id: "watchlist", icon: Eye, label: "Watchlist" },
    { id: "ideas", icon: Lightbulb, label: "Ideas" },
    { id: "journal", icon: NotebookPen, label: "Journal" },
  ];
  return (
    <aside className="hidden lg:flex w-[212px] shrink-0 flex-col border-r border-white/[0.07] bg-[#070b14]/90 px-4 py-6">
      <div className="flex items-center gap-3 px-2">
        <div className="relative grid h-10 w-10 place-items-center rounded-2xl bg-gradient-to-br from-[#cdf138] via-[#7dd3fc] to-[#a78bfa] shadow-[0_0_30px_rgba(205,241,56,0.25)]">
          <svg viewBox="0 0 24 24" className="h-5 w-5 text-black" fill="none" stroke="currentColor" strokeWidth={2.4}>
            <path d="M4 17 L9 11 L13 13 L20 5" strokeLinecap="round" strokeLinejoin="round" />
            <circle cx="20" cy="5" r="1.6" fill="currentColor" stroke="none" />
          </svg>
        </div>
        <div>
          <div className="font-display text-[19px] leading-none font-medium tracking-tight">Meridian</div>
          <div className="mt-1 text-[10px] tracking-[0.22em] text-white/40 uppercase">Private markets</div>
        </div>
      </div>

      <div className="mt-8 space-y-1">
        <div className="px-2 pb-2 text-[10px] font-semibold tracking-[0.2em] text-white/30 uppercase">Workspace</div>
        {apps.map((a) => {
          const on = a.id === activeApp;
          return (
            <button key={a.id} className={cx("group flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-[13.5px] transition-all", on ? "bg-white/[0.07] text-white shadow-inner" : "text-white/50 hover:bg-white/[0.04] hover:text-white/85")}>
              <a.icon size={17} strokeWidth={on ? 2.2 : 1.8} className={on ? "text-[#cdf138]" : "text-white/40 group-hover:text-white/70"} />
              <span className="font-medium">{a.label}</span>
              {on && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-[#cdf138] shadow-[0_0_12px_#cdf138]" />}
              {a.id === "news" && <span className="ml-auto rounded-full bg-[#ff6b7a]/15 px-1.5 py-0.5 text-[10px] font-bold text-[#ff8f9c]">9</span>}
            </button>
          );
        })}
      </div>

      <div className="mt-6 rounded-2xl border border-white/[0.08] bg-gradient-to-b from-white/[0.06] to-transparent p-4">
        <div className="flex items-center gap-2 text-[11px] font-semibold tracking-wider text-white/60 uppercase"><LayoutDashboard size={13} /> Buying power</div>
        <div className="mono-num mt-2 text-[22px] font-semibold">$28,400</div>
        <div className="mt-1 text-[11.5px] text-white/40">4.3% sweep · deploy on −7%</div>
        <button className="mt-3 w-full rounded-xl bg-[#cdf138] py-2 text-[12.5px] font-bold text-black transition hover:brightness-110">Move cash</button>
      </div>

      <div className="mt-auto flex items-center gap-3 rounded-2xl border border-white/[0.07] bg-white/[0.03] p-3">
        <div className="grid h-9 w-9 place-items-center rounded-full bg-gradient-to-br from-violet-400 to-sky-400 text-[13px] font-bold text-black">JK</div>
        <div className="min-w-0">
          <div className="truncate text-[13px] font-semibold">Jonas Keller</div>
          <div className="text-[11px] text-white/40">Pro · Zurich</div>
        </div>
        <ChevronDown size={14} className="ml-auto text-white/30" />
      </div>
    </aside>
  );
}

export function Topbar({ ccy, setCcy, query, setQuery }: { ccy: string; setCcy: (c: string) => void; query: string; setQuery: (q: string) => void }) {
  return (
    <header className="sticky top-0 z-30 border-b border-white/[0.07] bg-[#05080f]/80 backdrop-blur-xl">
      <div className="flex items-center gap-3 px-4 py-3 md:px-8">
        <div className="lg:hidden flex items-center gap-2">
          <div className="grid h-8 w-8 place-items-center rounded-xl bg-gradient-to-br from-[#cdf138] to-[#7dd3fc]"><Wallet size={15} className="text-black" /></div>
          <span className="font-display text-lg">Meridian</span>
        </div>
        <div className="hidden md:flex items-center gap-2 text-[12px] text-white/40">
          <span>Portfolio</span><span className="text-white/20">/</span><span className="text-white/80">Jonas · Growth</span>
          <span className="ml-2 hidden xl:inline-flex items-center gap-1.5 rounded-full border border-emerald-300/20 bg-emerald-300/10 px-2.5 py-1 text-[11px] font-semibold text-emerald-300"><span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-300" /> Market open · 15:42 CET</span>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <div className="hidden sm:flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 text-[13px] text-white/60 focus-within:border-white/25 w-[220px]">
            <Search size={15} />
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search holdings…" className="w-full bg-transparent outline-none placeholder:text-white/30 text-white/85" />
            <kbd className="hidden md:flex items-center gap-1 rounded-md border border-white/10 bg-white/[0.05] px-1.5 py-0.5 text-[10px] text-white/40"><Command size={10} />K</kbd>
          </div>
          <div className="flex items-center rounded-xl border border-white/10 bg-white/[0.04] p-1">
            {Object.keys(FX).map((c) => (
              <button key={c} onClick={() => setCcy(c)} className={cx("rounded-lg px-2.5 py-1.5 text-[11.5px] font-bold transition-all", ccy === c ? "bg-[#cdf138] text-black shadow-[0_0_16px_rgba(205,241,56,0.35)]" : "text-white/45 hover:text-white")}>{c}</button>
            ))}
          </div>
          <button className="relative grid h-9 w-9 place-items-center rounded-xl border border-white/10 bg-white/[0.04] text-white/60 hover:text-white"><Bell size={16} /><span className="absolute top-2 right-2 h-1.5 w-1.5 rounded-full bg-[#ff6b7a]" /></button>
        </div>
      </div>
    </header>
  );
}

export function TabNav({ tab, setTab }: { tab: TabId; setTab: (t: TabId) => void }) {
  return (
    <div className="flex items-center gap-1 overflow-x-auto rounded-2xl border border-white/[0.08] bg-white/[0.03] p-1.5">
      {TABS.map((t) => {
        const on = tab === t.id;
        return (
          <button key={t.id} onClick={() => setTab(t.id)} className={cx("relative flex-1 min-w-[130px] rounded-xl px-4 py-2.5 text-left transition-all", on ? "text-black" : "text-white/55 hover:text-white hover:bg-white/[0.05]")}>
            {on && <motion.span layoutId="tab-pill" className="absolute inset-0 rounded-xl bg-gradient-to-r from-[#cdf138] to-[#e9ff9a] shadow-[0_8px_30px_-8px_rgba(205,241,56,0.6)]" transition={{ type: "spring", bounce: 0.18, duration: 0.55 }} />}
            <span className="relative block text-[13.5px] font-bold leading-none">{t.label}</span>
            <span className={cx("relative mt-1 block text-[11px]", on ? "text-black/60" : "text-white/35")}>{t.hint}</span>
          </button>
        );
      })}
    </div>
  );
}

export function Card({ className, children }: { className?: string; children: React.ReactNode }) {
  return <div className={cx("glass-deep noise relative overflow-hidden rounded-3xl", className)}>{children}</div>;
}

export function SectionHead({ kicker, title, right, sub }: { kicker: string; title: string; sub?: string; right?: React.ReactNode }) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-3">
      <div>
        <div className="text-[10.5px] font-bold tracking-[0.24em] text-[#cdf138]/90 uppercase">{kicker}</div>
        <h3 className="font-display mt-1 text-[22px] leading-tight font-medium tracking-tight">{title}</h3>
        {sub && <p className="mt-1 max-w-[520px] text-[12.5px] leading-relaxed text-white/45">{sub}</p>}
      </div>
      {right}
    </div>
  );
}

export function LogoOrb({ ticker, color, size = 40 }: { ticker: string; color: string; size?: number }) {
  return (
    <div className="relative shrink-0" style={{ width: size, height: size }}>
      <div className="absolute inset-0 rounded-2xl opacity-30 blur-[8px]" style={{ background: color }} />
      <div className="relative grid h-full w-full place-items-center rounded-2xl border border-white/15 bg-[#0e1628]" style={{ width: size, height: size }}>
        <span className="font-mono2 text-[11px] font-bold" style={{ color }}>{ticker.slice(0, 4)}</span>
      </div>
    </div>
  );
}
