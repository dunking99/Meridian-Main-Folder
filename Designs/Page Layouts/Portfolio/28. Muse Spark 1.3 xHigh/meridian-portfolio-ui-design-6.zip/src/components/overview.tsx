import { useMemo, useState, useRef, useEffect } from "react";
import { motion } from "framer-motion";
import { ArrowUpRight, ArrowDownRight, Sparkles, CalendarClock, Plus, Minus, Zap, Trophy, TrendingUp, ShieldCheck, CircleDollarSign } from "lucide-react";
import { ENRICHED, TOTAL, DAY_PL, DAY_PCT, TOTAL_GAIN, HISTORY, EVENTS, TRANSACTIONS, NEWS, SECTORS } from "../data/portfolio";
import { fmtMoney, fmtPct, cx } from "../lib/format";
import { Card, SectionHead, LogoOrb } from "./chrome";

function useCountUp(target: number, dur = 1100) {
  const [v, setV] = useState(target * 0.9);
  useEffect(() => {
    let raf: number;
    const t0 = performance.now();
    const tick = (t: number) => {
      const p = Math.min(1, (t - t0) / dur);
      const e = 1 - Math.pow(1 - p, 3);
      setV(p === 1 ? target : target * (0.9 + 0.1 * e));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, dur]);
  return v;
}

function ValueChart({ ccy, showBench }: { ccy: string; showBench: boolean }) {
  const [range, setRange] = useState("1Y");
  const [hover, setHover] = useState<number | null>(null);
  const ref = useRef<HTMLDivElement>(null);

  const slice = useMemo(() => {
    const n = range === "1M" ? 30 : range === "3M" ? 90 : range === "6M" ? 180 : range === "YTD" ? 267 : 365;
    return HISTORY.slice(-n);
  }, [range]);

  const W = 900, H = 300, PAD = 8;
  const vals = slice.map((d) => d.v);
  const bvals = slice.map((d) => d.b);
  const all = showBench ? [...vals, ...bvals] : vals;
  const min = Math.min(...all), max = Math.max(...all);
  const X = (i: number) => PAD + (i / (slice.length - 1)) * (W - PAD * 2);
  const Y = (v: number) => H - PAD - ((v - min) / (max - min || 1)) * (H - PAD * 2 - 30);

  const line = vals.map((v, i) => `${i === 0 ? "M" : "L"}${X(i).toFixed(1)},${Y(v).toFixed(1)}`).join(" ");
  const bline = bvals.map((v, i) => `${i === 0 ? "M" : "L"}${X(i).toFixed(1)},${Y(v).toFixed(1)}`).join(" ");
  const area = `${line} L${X(vals.length - 1).toFixed(1)},${H} L${X(0).toFixed(1)},${H} Z`;

  const first = slice[0]?.v ?? 1, last = slice[slice.length - 1]?.v ?? 1;
  const chg = ((last - first) / first) * 100;

  const onMove = (e: React.MouseEvent) => {
    const r = ref.current?.getBoundingClientRect(); if (!r) return;
    const px = ((e.clientX - r.left) / r.width) * W;
    const i = Math.round(((px - PAD) / (W - PAD * 2)) * (slice.length - 1));
    setHover(Math.max(0, Math.min(slice.length - 1, i)));
  };

  return (
    <div>
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex rounded-xl border border-white/10 bg-black/30 p-1">
          {["1M", "3M", "6M", "YTD", "1Y"].map((r) => (
            <button key={r} onClick={() => setRange(r)} className={cx("rounded-lg px-3 py-1.5 text-[11.5px] font-bold transition", range === r ? "bg-white text-black" : "text-white/45 hover:text-white")}>{r}</button>
          ))}
        </div>
        <div className={cx("ml-auto mono-num rounded-xl border px-3 py-1.5 text-[12px] font-semibold", chg >= 0 ? "border-[#cdf138]/25 bg-[#cdf138]/10 text-[#cdf138]" : "border-rose-400/25 bg-rose-400/10 text-rose-300")}>
          {fmtPct(chg)} <span className="text-white/40 font-normal">in range</span>
        </div>
      </div>

      <div ref={ref} onMouseMove={onMove} onMouseLeave={() => setHover(null)} className="relative mt-4 cursor-crosshair">
        <svg viewBox={`0 0 ${W} ${H}`} className="w-full" preserveAspectRatio="none" style={{ height: 280 }}>
          <defs>
            <linearGradient id="mg" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#7dd3fc" /><stop offset="45%" stopColor="#a78bfa" /><stop offset="75%" stopColor="#cdf138" /><stop offset="100%" stopColor="#cdf138" />
            </linearGradient>
            <linearGradient id="mgFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#cdf138" stopOpacity="0.32" /><stop offset="55%" stopColor="#a78bfa" stopOpacity="0.10" /><stop offset="100%" stopColor="#05080f" stopOpacity="0" />
            </linearGradient>
          </defs>
          {[0.2, 0.4, 0.6, 0.8].map((f) => (
            <line key={f} x1={0} x2={W} y1={H * f} y2={H * f} stroke="rgba(255,255,255,0.06)" strokeDasharray="3 6" />
          ))}
          {showBench && <path d={bline} fill="none" stroke="rgba(255,255,255,0.35)" strokeWidth={1.4} strokeDasharray="5 5" />}
          <path d={area} fill="url(#mgFill)" />
          <path d={line} fill="none" stroke="url(#mg)" strokeWidth={2.6} strokeLinecap="round" style={{ filter: "drop-shadow(0 0 14px rgba(205,241,56,0.35))" }} />
          {/* April drawdown annotation */}
          <g>
            <ellipse cx={W * 0.58} cy={H * 0.62} rx={52} ry={30} fill="rgba(255,107,122,0.07)" stroke="rgba(255,107,122,0.3)" strokeDasharray="4 4" />
            <text x={W * 0.58} y={H * 0.62 - 34} textAnchor="middle" fill="#ff8f9c" fontSize={11} fontWeight={700}>Liberation-day −9.2%</text>
          </g>
          {hover !== null && (
            <g>
              <line x1={X(hover)} x2={X(hover)} y1={0} y2={H} stroke="rgba(255,255,255,0.35)" strokeWidth={1} />
              <circle cx={X(hover)} cy={Y(vals[hover])} r={5} fill="#cdf138" stroke="#05080f" strokeWidth={2.5} />
            </g>
          )}
          <circle cx={X(vals.length - 1)} cy={Y(vals[vals.length - 1])} r={4.5} fill="#cdf138">
            <animate attributeName="r" values="4.5;7;4.5" dur="2s" repeatCount="indefinite" />
          </circle>
        </svg>
        {hover !== null && (
          <div className="pointer-events-none absolute z-10 -translate-x-1/2 rounded-2xl border border-white/15 bg-[#0b111e]/95 px-4 py-2.5 shadow-2xl backdrop-blur" style={{ left: `${(X(hover) / W) * 100}%`, top: 8 }}>
            <div className="text-[11px] text-white/45">{slice[hover].t}</div>
            <div className="mono-num text-[15px] font-bold">{fmtMoney(slice[hover].v, ccy)}</div>
            {showBench && <div className="mono-num text-[11px] text-white/40">SPY {fmtMoney(slice[hover].b, ccy, { decimals: 0 })}</div>}
          </div>
        )}
      </div>
      <div className="mt-2 flex items-center gap-5 text-[11.5px] text-white/45">
        <span className="flex items-center gap-1.5"><span className="h-[3px] w-6 rounded-full bg-gradient-to-r from-sky-300 via-violet-300 to-[#cdf138]" /> Meridian Growth</span>
        {showBench && <span className="flex items-center gap-1.5"><span className="h-0 w-6 border-t-2 border-dashed border-white/40" /> S&P 500 TR</span>}
        <span className="ml-auto hidden sm:block">{slice[0].t} → {slice[slice.length - 1].t}</span>
      </div>
    </div>
  );
}

export default function Overview({ ccy, onOpen }: { ccy: string; onOpen: (id: string) => void }) {
  const animated = useCountUp(TOTAL);
  const [showBench, setShowBench] = useState(true);
  const top = ENRICHED.slice(0, 4);
  const movers = [...ENRICHED].filter((h) => h.ticker !== "CASH").sort((a, b) => b.dayChg - a.dayChg);
  const gainers = movers.slice(0, 3), losers = movers.slice(-3).reverse();
  const maxW = Math.max(...ENRICHED.map((h) => Math.abs(h.dayChg)));

  return (
    <div className="space-y-4">
      {/* HERO */}
      <Card className="aurora p-0">
        <div className="grid-lines absolute inset-0" />
        <div className="relative grid gap-6 p-6 md:grid-cols-[1.15fr_0.85fr] md:p-8">
          <div>
            <div className="flex items-center gap-2 text-[11px] font-bold tracking-[0.22em] text-white/45 uppercase">
              <span className="grid h-6 w-6 place-items-center rounded-lg bg-[#cdf138]/15 text-[#cdf138]"><Zap size={13} /></span>
              Total net worth · live
            </div>
            <div className="font-display mt-3 text-[52px] leading-[0.95] font-light tracking-tight md:text-[68px]">
              {fmtMoney(animated, ccy)}
            </div>
            <div className="mt-4 flex flex-wrap items-center gap-2.5">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-[#cdf138] px-3.5 py-1.5 text-[13px] font-bold text-black shadow-[0_0_28px_rgba(205,241,56,0.4)]">
                <ArrowUpRight size={15} strokeWidth={2.6} /> {fmtMoney(DAY_PL, ccy, { decimals: 0 })} · {fmtPct(DAY_PCT)} today
              </span>
              <span className="inline-flex items-center gap-1.5 rounded-full border border-white/12 bg-white/[0.05] px-3 py-1.5 text-[12px] text-white/60">After-hours <b className="text-emerald-300">+$312</b></span>
              <span className="inline-flex items-center gap-1.5 rounded-full border border-white/12 bg-white/[0.05] px-3 py-1.5 text-[12px] text-white/60">All-time <b className="text-white">+{fmtMoney(TOTAL_GAIN, ccy, { decimals: 0 })}</b></span>
            </div>
            {/* day range ribbon */}
            <div className="mt-6 max-w-[480px]">
              <div className="flex justify-between text-[11px] text-white/40"><span>Day low {fmtMoney(TOTAL - 6200, ccy, { decimals: 0 })}</span><span className="text-white/70 font-semibold">● now</span><span>Day high {fmtMoney(TOTAL + 2400, ccy, { decimals: 0 })}</span></div>
              <div className="relative mt-2 h-2 rounded-full bg-white/[0.07]">
                <div className="absolute inset-y-0 left-0 rounded-full bg-gradient-to-r from-sky-400 via-violet-400 to-[#cdf138]" style={{ width: "78%" }} />
                <div className="absolute top-1/2 h-4 w-4 -translate-x-1/2 -translate-y-1/2 rounded-full border-[3px] border-[#05080f] bg-[#cdf138] shadow-[0_0_16px_#cdf138]" style={{ left: "78%" }} />
              </div>
              <div className="mt-3 flex gap-2 text-[11.5px]">
                <span className="rounded-lg border border-white/10 bg-white/[0.04] px-2.5 py-1.5 text-white/55">Cost basis <b className="mono-num text-white">{fmtMoney(TOTAL - TOTAL_GAIN, ccy, { decimals: 0 })}</b></span>
                <span className="rounded-lg border border-white/10 bg-white/[0.04] px-2.5 py-1.5 text-white/55">Cash <b className="mono-num text-white">$28.4k</b></span>
                <span className="rounded-lg border border-white/10 bg-white/[0.04] px-2.5 py-1.5 text-white/55">Day's best <b className="text-[#cdf138]">IBIT +5.8%</b></span>
              </div>
            </div>
          </div>

          {/* right: meridian dial */}
          <div className="relative flex flex-col justify-center rounded-2xl border border-white/[0.08] bg-black/30 p-5">
            <div className="flex items-center justify-between">
              <div className="text-[11px] font-bold tracking-[0.2em] text-white/40 uppercase">Meridian pulse</div>
              <span className="inline-flex items-center gap-1 rounded-full bg-violet-400/15 px-2 py-1 text-[11px] font-semibold text-violet-300"><Sparkles size={12} /> AI digest</span>
            </div>
            <div className="mt-3 space-y-2.5 text-[13px] leading-relaxed">
              {[
                ["AI cape cycle is paying you", "NVDA + AVGO + TSM drove 71% of today's gain. Positioning matches spend — stay overweight."],
                ["Watch the single-name load", "NVDA is 11.9%. Trim rule triggers at 13% — you're one green week away."],
                ["Cash has a job", "$28.4k covers two planned buys. Auto-deploy if SPY −7% from highs."],
              ].map(([t, d], i) => (
                <motion.div key={t} initial={{ opacity: 0, x: 14 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.25 + i * 0.15 }} className="flex gap-3 rounded-xl border border-white/[0.07] bg-white/[0.03] p-3">
                  <span className="mono-num mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-lg bg-[#cdf138]/15 text-[11px] font-bold text-[#cdf138]">0{i + 1}</span>
                  <span><b className="text-white/90">{t}.</b> <span className="text-white/50">{d}</span></span>
                </motion.div>
              ))}
            </div>
            <div className="mt-4 flex items-center gap-2">
              <div className="h-2 flex-1 overflow-hidden rounded-full bg-white/[0.07]">
                <motion.div initial={{ width: 0 }} animate={{ width: "82%" }} transition={{ duration: 1.2, delay: 0.4 }} className="h-full rounded-full bg-gradient-to-r from-sky-400 via-violet-400 to-[#cdf138]" />
              </div>
              <span className="mono-num text-[12px] font-bold text-white/70">82 · Robust</span>
            </div>
          </div>
        </div>
      </Card>

      {/* VALUE OVER TIME */}
      <Card className="p-6 md:p-7">
        <SectionHead kicker="Trajectory" title="Value over time" sub="Your compounding curve against the S&P 500 total return. Shaded glow is your edge — currently +8.4 pts of alpha this year."
          right={<label className="flex cursor-pointer items-center gap-2 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 text-[12px] font-semibold text-white/60"><input type="checkbox" checked={showBench} onChange={(e) => setShowBench(e.target.checked)} className="h-3.5 w-3.5 accent-[#cdf138]" /> Benchmark</label>} />
        <div className="mt-5"><ValueChart ccy={ccy} showBench={showBench} /></div>
        <div className="mt-5 grid grid-cols-2 gap-3 md:grid-cols-4">
          {[
            ["1Y growth", "+34.3%", "+$131k", true],
            ["Alpha vs SPY", "+12.1 pts", "top 8% of installs", true],
            ["Best month", "May ’26 +6.8%", "AI re-acceleration", true],
            ["Max drawdown", "−9.2% Apr", "recovered in 41d", false],
          ].map(([k, v, s, good]) => (
            <div key={k as string} className="rounded-2xl border border-white/[0.07] bg-white/[0.025] p-3.5">
              <div className="text-[10.5px] font-bold tracking-[0.16em] text-white/35 uppercase">{k}</div>
              <div className={cx("mono-num mt-1 text-[17px] font-bold", good ? "text-white" : "text-rose-300")}>{v}</div>
              <div className="mt-0.5 text-[11.5px] text-white/40">{s}</div>
            </div>
          ))}
        </div>
      </Card>

      {/* ALLOCATION + TOP + MOVERS */}
      <div className="grid gap-4 xl:grid-cols-3">
        <Card className="p-6">
          <SectionHead kicker="Allocation" title="At a glance" />
          {/* stacked ribbon */}
          <div className="mt-4 flex h-4 overflow-hidden rounded-full">
            {[["#cdf138", 30.4], ["#38bdf8", 16.8], ["#e8edf5", 12.9], ["#34d399", 12.7], ["#60a5fa", 8.1], ["#fb923c", 8.2], ["#f97316", 7.3]].map(([c, w], i) => (
              <motion.div key={i} initial={{ scaleX: 0 }} animate={{ scaleX: 1 }} transition={{ delay: i * 0.08, duration: 0.6 }} className="h-full origin-left" style={{ width: `${w}%`, background: c as string }} />
            ))}
          </div>
          <div className="mt-4 space-y-2.5">
            {SECTORS.slice(0, 6).map((s, i) => (
              <div key={s.name} className="group flex items-center gap-3">
                <span className="h-2.5 w-2.5 rounded-[4px]" style={{ background: s.color }} />
                <span className="w-[130px] truncate text-[12.5px] text-white/70">{s.name}</span>
                <div className="relative h-1.5 flex-1 overflow-hidden rounded-full bg-white/[0.06]">
                  <motion.div initial={{ width: 0 }} whileInView={{ width: `${(s.w / 32) * 100}%` }} viewport={{ once: true }} transition={{ duration: 0.9, delay: i * 0.06 }} className="h-full rounded-full" style={{ background: s.color }} />
                </div>
                <span className="mono-num w-12 text-right text-[12.5px] font-bold">{s.w}%</span>
              </div>
            ))}
          </div>
          <div className="mt-4 grid grid-cols-3 gap-2 text-center">
            {[["Stocks", "76%", "9 names"], ["ETFs", "12.7%", "ballast"], ["Crypto", "7.3%", "convexity"]].map(([k, v, s]) => (
              <div key={k} className="rounded-xl border border-white/[0.07] bg-black/25 p-2.5"><div className="mono-num text-[15px] font-bold">{v}</div><div className="text-[10.5px] text-white/40">{k} · {s}</div></div>
            ))}
          </div>
        </Card>

        <Card className="p-6">
          <SectionHead kicker="Conviction" title="Top holdings" right={<span className="mono-num text-[11px] text-white/35">by market value</span>} />
          <div className="mt-4 space-y-2.5">
            {top.map((h, i) => (
              <button key={h.id} onClick={() => onOpen(h.id)} className="card-hover group flex w-full items-center gap-3 rounded-2xl border border-white/[0.07] bg-white/[0.03] p-3 text-left">
                <span className="font-display text-[22px] text-white/20 italic">0{i + 1}</span>
                <LogoOrb ticker={h.ticker} color={h.color} size={38} />
                <span className="min-w-0 flex-1">
                  <span className="flex items-center gap-2"><b className="text-[13.5px]">{h.ticker}</b><span className={cx("mono-num text-[11px] font-bold", h.dayChg >= 0 ? "text-[#cdf138]" : "text-rose-300")}>{fmtPct(h.dayChg, 1)}</span></span>
                  <span className="mt-1 block h-1 overflow-hidden rounded-full bg-white/[0.07]"><span className="block h-full rounded-full bg-gradient-to-r from-sky-300 to-[#cdf138]" style={{ width: `${(h.weight / 12) * 100}%` }} /></span>
                </span>
                <span className="text-right"><span className="mono-num block text-[13.5px] font-bold">{fmtMoney(h.value, ccy, { decimals: 0 })}</span><span className="mono-num text-[11px] text-white/40">{h.weight.toFixed(1)}% wt</span></span>
              </button>
            ))}
          </div>
          <button onClick={() => onOpen(top[0].id)} className="mt-3 w-full rounded-xl border border-dashed border-white/15 py-2.5 text-[12.5px] font-semibold text-white/50 hover:border-[#cdf138]/50 hover:text-[#cdf138]">Open full holdings →</button>
        </Card>

        <Card className="p-6">
          <SectionHead kicker="Movers" title="What moved" sub="Last session, sized by impact — not just percent." />
          <div className="mt-4">
            <div className="mb-2 flex items-center gap-2 text-[11px] font-bold tracking-wider text-[#cdf138] uppercase"><TrendingUp size={12} /> Drivers</div>
            {gainers.map((h) => (
              <button key={h.id} onClick={() => onOpen(h.id)} className="group mb-1.5 flex w-full items-center gap-2.5">
                <span className="mono-num w-14 text-[11.5px] font-bold">{h.ticker}</span>
                <span className="relative h-[26px] flex-1 overflow-hidden rounded-lg bg-white/[0.04]">
                  <motion.span initial={{ width: 0 }} whileInView={{ width: `${(Math.abs(h.dayChg) / maxW) * 100}%` }} viewport={{ once: true }} className="absolute inset-y-0 left-0 rounded-lg bg-gradient-to-r from-[#cdf138]/25 to-[#cdf138]" />
                  <span className="mono-num absolute inset-0 flex items-center px-2 text-[11px] font-bold text-black mix-blend-screen">{fmtMoney(h.dayPL, ccy, { decimals: 0 })}</span>
                </span>
                <span className="mono-num w-16 text-right text-[12px] font-bold text-[#cdf138]">{fmtPct(h.dayChg, 1)}</span>
              </button>
            ))}
            <div className="mt-3 mb-2 flex items-center gap-2 text-[11px] font-bold tracking-wider text-rose-300 uppercase"><ArrowDownRight size={12} /> Drags</div>
            {losers.map((h) => (
              <button key={h.id} onClick={() => onOpen(h.id)} className="group mb-1.5 flex w-full items-center gap-2.5">
                <span className="mono-num w-14 text-[11.5px] font-bold">{h.ticker}</span>
                <span className="relative h-[26px] flex-1 overflow-hidden rounded-lg bg-white/[0.04]">
                  <motion.span initial={{ width: 0 }} whileInView={{ width: `${(Math.abs(h.dayChg) / maxW) * 100}%` }} viewport={{ once: true }} className="absolute inset-y-0 left-0 rounded-lg bg-gradient-to-r from-rose-500/25 to-rose-400" />
                  <span className="mono-num absolute inset-0 flex items-center px-2 text-[11px] font-bold">{fmtMoney(h.dayPL, ccy, { decimals: 0 })}</span>
                </span>
                <span className="mono-num w-16 text-right text-[12px] font-bold text-rose-300">{fmtPct(h.dayChg, 1)}</span>
              </button>
            ))}
          </div>
        </Card>
      </div>

      {/* ACTIVITY + EVENTS + NEWS */}
      <div className="grid gap-4 xl:grid-cols-3">
        <Card className="p-6">
          <SectionHead kicker="Ledger" title="Recent activity" right={<span className="text-[12px] font-semibold text-white/40">Cash in/out</span>} />
          <div className="mt-4 space-y-2">
            {TRANSACTIONS.slice(0, 5).map((t) => (
              <div key={t.d + t.ticker} className="flex items-center gap-3 rounded-xl border border-white/[0.06] bg-white/[0.02] px-3 py-2.5">
                <span className={cx("grid h-8 w-8 place-items-center rounded-lg", t.type === "BUY" ? "bg-[#cdf138]/15 text-[#cdf138]" : t.type === "SELL" ? "bg-rose-400/15 text-rose-300" : "bg-sky-400/15 text-sky-300")}>
                  {t.type === "BUY" ? <Plus size={15} /> : t.type === "SELL" ? <Minus size={15} /> : <CircleDollarSign size={15} />}
                </span>
                <span className="min-w-0 flex-1"><b className="text-[12.5px]">{t.type} {t.ticker}</b><span className="block truncate text-[11.5px] text-white/40">{t.detail} · {t.d}</span></span>
                <span className="mono-num text-[12.5px] font-bold">{fmtMoney(t.amount, ccy, { decimals: t.amount < 500 ? 2 : 0 })}</span>
              </div>
            ))}
          </div>
        </Card>
        <Card className="p-6">
          <SectionHead kicker="Calendar" title="Catalysts ahead" right={<CalendarClock size={16} className="text-white/30" />} />
          <div className="relative mt-4 space-y-0">
            <div className="absolute top-2 bottom-2 left-[52px] w-px bg-white/10" />
            {EVENTS.map((e, i) => (
              <div key={e.ticker + e.d} className="relative flex items-center gap-3 py-2">
                <span className="mono-num w-11 text-[11.5px] font-bold text-white/50">{e.d}</span>
                <span className={cx("relative z-10 grid h-7 w-7 place-items-center rounded-full border text-[10px] font-bold", i === 0 ? "border-[#cdf138]/60 bg-[#cdf138]/15 text-[#cdf138]" : "border-white/15 bg-[#0b111e] text-white/50")}>{e.ticker.slice(0, 2)}</span>
                <span className="min-w-0 flex-1"><b className="block truncate text-[12.5px]">{e.what}</b><span className="text-[11px] text-white/40">{e.ticker} · <span className="text-violet-300">{e.tag}</span></span></span>
              </div>
            ))}
          </div>
        </Card>
        <Card className="border-violet-300/15 p-6" >
          <SectionHead kicker="Linked news" title="Why it moved" sub="Stories auto-mapped to your holdings — the secondary layer." />
          <div className="mt-4 space-y-2.5">
            {NEWS.map((n) => (
              <div key={n.t} className="card-hover cursor-pointer rounded-xl border border-white/[0.07] bg-white/[0.03] p-3">
                <div className="text-[13px] leading-snug font-semibold">{n.t}</div>
                <div className="mt-1.5 flex items-center gap-2 text-[11px] text-white/40"><span>{n.src} · {n.time} ago</span><span className="ml-auto flex gap-1">{n.tickers.map((t) => <span key={t} className="mono-num rounded-md bg-white/[0.07] px-1.5 py-0.5 font-bold text-white/60">{t}</span>)}</span></div>
              </div>
            ))}
          </div>
          <div className="mt-3 flex items-center gap-2 rounded-xl bg-gradient-to-r from-violet-500/15 to-sky-500/10 border border-violet-300/20 p-3 text-[12px] text-white/60"><ShieldCheck size={15} className="shrink-0 text-violet-300" /> News sentiment on your book: <b className="text-white">68% positive</b> this week.</div>
        </Card>
      </div>

      {/* strip */}
      <div className="flex flex-wrap items-center gap-3 rounded-3xl border border-[#cdf138]/20 bg-gradient-to-r from-[#cdf138]/10 via-transparent to-violet-500/10 px-6 py-4">
        <Trophy size={18} className="text-[#cdf138]" />
        <span className="text-[13.5px]"><b>September so far: +$8,412.</b> <span className="text-white/50">You're beating 92% of Meridian Growth portfolios. Keep the foot on AI infrastructure.</span></span>
        <button className="ml-auto rounded-xl bg-white px-4 py-2 text-[12.5px] font-bold text-black hover:bg-[#cdf138]">Review September →</button>
      </div>
    </div>
  );
}
