import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowUpRight, ArrowDownRight, Search, LayoutGrid, Table2, Trophy, TrendingDown, X as XIcon, Plus, Bell, ArrowLeftRight, Star, Globe2, Building2, Coins } from "lucide-react";
import { ENRICHED, TOTAL, NEWS, TRANSACTIONS } from "../data/portfolio";
import type { Enriched } from "../data/portfolio";
import { fmtMoney, fmtPct, cx, sparkPath } from "../lib/format";
import { Card, SectionHead, LogoOrb } from "./chrome";

function intensity(day: number) {
  if (day > 3) return "from-[#cdf138] to-[#8fb81f] text-black";
  if (day > 1) return "from-[#cdf138]/80 to-[#cdf138]/40 text-black";
  if (day > 0) return "from-white/[0.12] to-white/[0.05] text-white border border-white/15";
  if (day > -1.5) return "from-white/[0.07] to-white/[0.03] text-white border border-white/10";
  return "from-[#ff6b7a] to-[#b33745] text-white";
}

function Treemap({ data, ccy, onOpen }: { data: Enriched[]; ccy: string; onOpen: (id: string) => void }) {
  const rows = data.filter((h) => h.ticker !== "CASH");
  return (
    <div className="flex flex-wrap gap-2">
      {rows.map((h, i) => {
        const w = Math.max(13, (h.weight / 12.5) * 30);
        return (
          <motion.button key={h.id} initial={{ opacity: 0, scale: 0.92 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ delay: i * 0.04 }}
            onClick={() => onOpen(h.id)} className={cx("card-hover group relative overflow-hidden rounded-2xl bg-gradient-to-br p-3.5 text-left", intensity(h.dayChg))}
            style={{ width: `${w}%`, minWidth: 148, flexGrow: 1, minHeight: 118 }}>
            <div className="flex items-center justify-between">
              <span className="mono-num text-[13px] font-black tracking-tight">{h.ticker}</span>
              <span className={cx("mono-num rounded-md px-1.5 py-0.5 text-[11px] font-bold", h.dayChg >= 0 ? "bg-black/25" : "bg-black/25")}>{fmtPct(h.dayChg, 1)}</span>
            </div>
            <div className="mono-num mt-1 text-[19px] font-bold tracking-tight">{fmtMoney(h.value, ccy, { decimals: 0 })}</div>
            <div className="mt-0.5 flex items-center justify-between text-[11px] opacity-80"><span>{h.weight.toFixed(1)}% of book</span><span className="mono-num">{h.qty} sh</span></div>
            <svg viewBox="0 0 100 26" className="mt-2 w-full opacity-70" preserveAspectRatio="none" style={{ height: 26 }}>
              <path d={sparkPath(h.spark, 100, 26)} fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" />
            </svg>
          </motion.button>
        );
      })}
    </div>
  );
}

type SortK = "value" | "dayChg" | "gainPct" | "weight" | "price";

export function HoldingsView({ ccy, query, openId, setOpenId }: { ccy: string; query: string; openId: string | null; setOpenId: (id: string | null) => void }) {
  const [mode, setMode] = useState<"table" | "map">("table");
  const [sort, setSort] = useState<{ k: SortK; dir: 1 | -1 }>({ k: "value", dir: -1 });
  const [focus, setFocus] = useState<"all" | "winners" | "losers">("all");
  const [typeF, setTypeF] = useState<string>("All");

  const rows = useMemo(() => {
    let r = [...ENRICHED];
    if (query) r = r.filter((h) => (h.ticker + h.name).toLowerCase().includes(query.toLowerCase()));
    if (focus === "winners") r = r.filter((h) => h.dayChg > 0);
    if (focus === "losers") r = r.filter((h) => h.dayChg < 0);
    if (typeF !== "All") r = r.filter((h) => h.type === typeF || (typeF === "Equity" && h.type === "Stock"));
    r.sort((a, b) => ((a[sort.k] as number) - (b[sort.k] as number)) * (sort.dir === 1 ? 1 : -1));
    return r;
  }, [query, focus, typeF, sort]);

  const best = [...ENRICHED].sort((a, b) => b.gainPct - a.gainPct)[0];
  const worst = [...ENRICHED].sort((a, b) => a.gainPct - b.gainPct)[0];

  const th = (label: string, k: SortK) => (
    <button onClick={() => setSort({ k, dir: sort.k === k ? (sort.dir === 1 ? -1 : 1) : -1 })} className={cx("text-[10.5px] font-bold tracking-[0.14em] uppercase transition", sort.k === k ? "text-[#cdf138]" : "text-white/35 hover:text-white/70")}>
      {label} {sort.k === k && (sort.dir === -1 ? "↓" : "↑")}
    </button>
  );

  return (
    <div className="space-y-4">
      {/* best / worst strip */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card className="relative overflow-hidden p-5">
          <div className="absolute -top-10 -right-10 h-40 w-40 rounded-full bg-[#cdf138]/20 blur-3xl" />
          <div className="flex items-center gap-3">
            <span className="grid h-10 w-10 place-items-center rounded-2xl bg-[#cdf138] text-black"><Trophy size={18} /></span>
            <div><div className="text-[10.5px] font-bold tracking-[0.2em] text-[#cdf138] uppercase">Best performer · all-time</div>
              <div className="text-[15px] font-bold">{best.ticker} · {best.name} <span className="mono-num text-[#cdf138]">+{best.gainPct.toFixed(1)}%</span></div></div>
            <button onClick={() => setOpenId(best.id)} className="ml-auto rounded-xl border border-[#cdf138]/40 px-3 py-1.5 text-[12px] font-bold text-[#cdf138] hover:bg-[#cdf138] hover:text-black">Open →</button>
          </div>
        </Card>
        <Card className="relative overflow-hidden p-5">
          <div className="absolute -top-10 -right-10 h-40 w-40 rounded-full bg-rose-500/20 blur-3xl" />
          <div className="flex items-center gap-3">
            <span className="grid h-10 w-10 place-items-center rounded-2xl bg-rose-400/20 text-rose-300"><TrendingDown size={18} /></span>
            <div><div className="text-[10.5px] font-bold tracking-[0.2em] text-rose-300 uppercase">Needs attention</div>
              <div className="text-[15px] font-bold">{worst.ticker} · {worst.name} <span className="mono-num text-rose-300">{worst.gainPct.toFixed(1)}%</span></div></div>
            <button onClick={() => setOpenId(worst.id)} className="ml-auto rounded-xl border border-rose-300/40 px-3 py-1.5 text-[12px] font-bold text-rose-200 hover:bg-rose-400 hover:text-black">Review →</button>
          </div>
        </Card>
      </div>

      <Card className="p-6">
        <div className="flex flex-wrap items-center gap-2">
          <SectionHead kicker="The book" title={`${ENRICHED.length} positions`} sub="Size = conviction · colour = momentum. Click any tile or row for the full dossier." />
          <div className="ml-auto flex items-center gap-2">
            <div className="flex rounded-xl border border-white/10 bg-black/30 p-1">
              <button onClick={() => setMode("table")} className={cx("flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-[12px] font-bold", mode === "table" ? "bg-white text-black" : "text-white/50")}><Table2 size={13} /> Table</button>
              <button onClick={() => setMode("map")} className={cx("flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-[12px] font-bold", mode === "map" ? "bg-white text-black" : "text-white/50")}><LayoutGrid size={13} /> Map</button>
            </div>
          </div>
        </div>

        <div className="mt-4 flex flex-wrap items-center gap-2">
          <div className="flex rounded-xl border border-white/10 bg-white/[0.03] p-1">
            {(["all", "winners", "losers"] as const).map((f) => (
              <button key={f} onClick={() => setFocus(f)} className={cx("rounded-lg px-3.5 py-1.5 text-[12px] font-bold capitalize transition", focus === f ? f === "losers" ? "bg-rose-400 text-black" : f === "winners" ? "bg-[#cdf138] text-black" : "bg-white text-black" : "text-white/50 hover:text-white")}>{f}</button>
            ))}
          </div>
          <div className="flex gap-1.5">
            {["All", "Stock", "ETF", "Crypto", "Cash"].map((t) => (
              <button key={t} onClick={() => setTypeF(t)} className={cx("rounded-full border px-3 py-1.5 text-[11.5px] font-semibold transition", typeF === t ? "border-[#cdf138]/60 bg-[#cdf138]/10 text-[#cdf138]" : "border-white/10 text-white/45 hover:text-white")}>{t}</button>
            ))}
          </div>
          {query && <span className="ml-auto flex items-center gap-1.5 text-[12px] text-white/45"><Search size={13} /> “{query}” · {rows.length} match{rows.length !== 1 && "es"}</span>}
        </div>

        {mode === "map" ? (
          <div className="mt-5"><Treemap data={rows} ccy={ccy} onOpen={(id) => setOpenId(id)} /></div>
        ) : (
          <div className="mt-4 overflow-x-auto rounded-2xl border border-white/[0.07]">
            <table className="w-full min-w-[880px] text-left">
              <thead>
                <tr className="border-b border-white/[0.07] bg-black/30 text-left">
                  <th className="px-4 py-3 text-[10.5px] font-bold tracking-[0.14em] text-white/35 uppercase">Holding</th>
                  <th className="px-3 py-3">{th("Price", "price")}</th>
                  <th className="px-3 py-3">{th("Day", "dayChg")}</th>
                  <th className="px-3 py-3 text-[10.5px] font-bold tracking-[0.14em] text-white/35 uppercase">Position</th>
                  <th className="px-3 py-3">{th("Value", "value")}</th>
                  <th className="px-3 py-3">{th("Gain", "gainPct")}</th>
                  <th className="px-3 py-3">{th("Weight", "weight")}</th>
                  <th className="px-4 py-3 text-[10.5px] font-bold tracking-[0.14em] text-white/35 uppercase">Trend</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((h) => (
                  <tr key={h.id} onClick={() => setOpenId(h.id)} className="group cursor-pointer border-b border-white/[0.05] transition hover:bg-[#cdf138]/[0.045]">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <LogoOrb ticker={h.ticker} color={h.color} size={36} />
                        <div><div className="text-[13.5px] font-bold">{h.ticker}</div><div className="max-w-[170px] truncate text-[11.5px] text-white/40">{h.name} · {h.sector}</div></div>
                      </div>
                    </td>
                    <td className="mono-num px-3 py-3 text-[13px] font-semibold">{h.ticker === "CASH" ? "—" : fmtMoney(h.price, "USD")}</td>
                    <td className="px-3 py-3">
                      <span className={cx("mono-num inline-flex items-center gap-1 rounded-lg px-2 py-1 text-[12px] font-bold", h.dayChg >= 0 ? "bg-[#cdf138]/12 text-[#cdf138]" : "bg-rose-400/12 text-rose-300")}>
                        {h.dayChg >= 0 ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}{fmtPct(h.dayChg, 1)}
                      </span>
                    </td>
                    <td className="mono-num px-3 py-3 text-[12px] text-white/55">{h.ticker === "CASH" ? fmtMoney(h.qty, "USD", { decimals: 0 }) : `${h.qty} sh`}</td>
                    <td className="mono-num px-3 py-3 text-[13.5px] font-bold">{fmtMoney(h.value, ccy, { decimals: 0 })}</td>
                    <td className="px-3 py-3">
                      <div className={cx("mono-num text-[12.5px] font-bold", h.gain >= 0 ? "text-emerald-300" : "text-rose-300")}>{h.gain >= 0 ? "+" : ""}{fmtMoney(h.gain, ccy, { decimals: 0 })}</div>
                      <div className={cx("mono-num text-[11px]", h.gainPct >= 0 ? "text-emerald-300/70" : "text-rose-300/70")}>{fmtPct(h.gainPct, 1)}</div>
                    </td>
                    <td className="px-3 py-3">
                      <div className="mono-num text-[12.5px] font-bold">{h.weight.toFixed(1)}%</div>
                      <div className="mt-1 h-1 w-20 overflow-hidden rounded-full bg-white/[0.08]"><div className="h-full rounded-full bg-gradient-to-r from-sky-300 to-[#cdf138]" style={{ width: `${Math.min(100, (h.weight / 12) * 100)}%` }} /></div>
                    </td>
                    <td className="px-4 py-3">
                      <svg viewBox="0 0 96 28" className="w-[96px]" preserveAspectRatio="none" style={{ height: 28 }}>
                        <path d={sparkPath(h.spark, 96, 28)} fill="none" stroke={h.dayChg >= 0 ? "#cdf138" : "#ff6b7a"} strokeWidth={1.8} strokeLinecap="round" />
                      </svg>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <div className="mono-num mt-3 flex flex-wrap gap-4 text-[11.5px] text-white/35">
          <span>Total value <b className="text-white">{fmtMoney(TOTAL, ccy, { decimals: 0 })}</b></span>
          <span>Showing <b className="text-white">{rows.length}</b> of {ENRICHED.length}</span>
          <span className="ml-auto">Tip: press <b className="text-white/60">Map</b> to feel concentration at a glance</span>
        </div>
      </Card>

      <HoldingDetail ccy={ccy} openId={openId} onClose={() => setOpenId(null)} />
    </div>
  );
}

function HoldingDetail({ ccy, openId, onClose }: { ccy: string; openId: string | null; onClose: () => void }) {
  const h = ENRICHED.find((x) => x.id === openId) ?? null;
  const [range, setRange] = useState("6M");
  const [watched, setWatched] = useState(false);

  useEffectScrollLock(!!h);
  if (!h) return null;

  const pos = ((h.price - h.low52) / (h.high52 - h.low52)) * 100;
  const rel = NEWS.filter((n) => n.tickers.includes(h.ticker));
  const txs = TRANSACTIONS.filter((t) => t.ticker === h.ticker);
  const W = 640, H = 190;
  const vals = h.spark;
  const min = Math.min(...vals), max = Math.max(...vals);
  const X = (i: number) => 4 + (i / (vals.length - 1)) * (W - 8);
  const Y = (v: number) => H - 6 - ((v - min) / (max - min || 1)) * (H - 20);
  const line = vals.map((v, i) => `${i === 0 ? "M" : "L"}${X(i).toFixed(1)},${Y(v).toFixed(1)}`).join(" ");
  const area = `${line} L${X(vals.length - 1).toFixed(1)},${H} L${X(0).toFixed(1)},${H} Z`;

  return (
    <AnimatePresence>
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm" />
      <motion.div initial={{ x: "100%" }} animate={{ x: 0 }} exit={{ x: "100%" }} transition={{ type: "spring", damping: 30, stiffness: 260 }}
        className="fixed top-0 right-0 z-50 flex h-full w-full max-w-[640px] flex-col overflow-y-auto border-l border-white/10 bg-[#080d18]">
        <div className="sticky top-0 z-10 border-b border-white/[0.07] bg-[#080d18]/90 p-5 backdrop-blur-xl">
          <div className="flex items-center gap-3">
            <LogoOrb ticker={h.ticker} color={h.color} size={48} />
            <div className="min-w-0">
              <div className="flex items-center gap-2"><h2 className="font-display text-[24px] leading-none font-medium">{h.ticker}</h2>
                <span className="rounded-full border border-white/12 px-2 py-0.5 text-[10.5px] font-semibold text-white/50">{h.type} · {h.sector}</span></div>
              <div className="mt-1 truncate text-[12.5px] text-white/45">{h.name} · {h.country} · <span className="mono-num">{h.ccy}</span></div>
            </div>
            <button onClick={onClose} className="ml-auto grid h-9 w-9 place-items-center rounded-xl border border-white/10 bg-white/[0.04] hover:bg-white/10"><XIcon size={16} /></button>
          </div>
          <div className="mt-4 flex flex-wrap items-end gap-3">
            <div className="mono-num text-[34px] leading-none font-bold tracking-tight">{h.ticker === "CASH" ? fmtMoney(h.qty, ccy, { decimals: 0 }) : fmtMoney(h.price, "USD")}</div>
            <span className={cx("mono-num mb-1 inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[12.5px] font-bold", h.dayChg >= 0 ? "bg-[#cdf138] text-black" : "bg-rose-400 text-black")}>
              {h.dayChg >= 0 ? <ArrowUpRight size={13} /> : <ArrowDownRight size={13} />}{fmtPct(h.dayChg)} today · {fmtMoney(h.dayPL, ccy, { decimals: 0 })}
            </span>
            <div className="mb-1 ml-auto flex gap-2">
              <button className="rounded-xl bg-[#cdf138] px-4 py-2 text-[12.5px] font-bold text-black hover:brightness-110"><Plus size={13} className="mr-1 inline" />Buy</button>
              <button onClick={() => setWatched(!watched)} className={cx("rounded-xl border px-3 py-2 text-[12.5px] font-bold", watched ? "border-amber-300/60 bg-amber-300/10 text-amber-200" : "border-white/12 text-white/60")}><Bell size={13} className="mr-1 inline" />{watched ? "Watching" : "Alert"}</button>
            </div>
          </div>
        </div>

        <div className="space-y-4 p-5">
          <div className="rounded-2xl border border-white/[0.08] bg-black/30 p-4">
            <div className="flex items-center justify-between">
              <div className="flex gap-1 rounded-lg border border-white/10 bg-white/[0.04] p-1">{["1M", "6M", "1Y", "MAX"].map((r) => <button key={r} onClick={() => setRange(r)} className={cx("rounded-md px-2.5 py-1 text-[11px] font-bold", range === r ? "bg-white text-black" : "text-white/45")}>{r}</button>)}</div>
              <span className="mono-num text-[11.5px] text-white/40">{h.weekChg >= 0 ? "+" : ""}{h.weekChg}% this week</span>
            </div>
            <svg viewBox={`0 0 ${W} ${H}`} className="mt-3 w-full" preserveAspectRatio="none" style={{ height: 170 }}>
              <defs><linearGradient id={`hg-${h.id}`} x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={h.color} stopOpacity="0.4" /><stop offset="100%" stopColor={h.color} stopOpacity="0" /></linearGradient></defs>
              <path d={area} fill={`url(#hg-${h.id})`} />
              <path d={line} fill="none" stroke={h.color === "#e8edf5" ? "#fff" : h.color} strokeWidth={2.4} strokeLinecap="round" style={{ filter: `drop-shadow(0 0 10px ${h.color})` }} />
            </svg>
            <div className="mt-3">
              <div className="flex justify-between text-[11px] text-white/40"><span className="mono-num">52w low {fmtMoney(h.low52, "USD")}</span><span className="mono-num">52w high {fmtMoney(h.high52, "USD")}</span></div>
              <div className="relative mt-1.5 h-1.5 rounded-full bg-white/[0.08]"><div className="absolute inset-y-0 left-0 rounded-full" style={{ width: `${pos}%`, background: h.color }} /><div className="absolute top-1/2 h-3.5 w-3.5 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-black" style={{ left: `${pos}%`, background: h.color }} /></div>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2">
            {[
              ["Market value", fmtMoney(h.value, ccy, { decimals: 0 }), `${h.weight.toFixed(1)}% of book`],
              ["Unrealized", `${h.gain >= 0 ? "+" : ""}${fmtMoney(h.gain, ccy, { decimals: 0 })}`, `${fmtPct(h.gainPct, 1)} vs cost`],
              ["Position", h.ticker === "CASH" ? "sweep" : `${h.qty} sh @ ${fmtMoney(h.avgCost, "USD")}`, h.ticker === "CASH" ? "4.30% yield" : "avg cost"],
              ["Beta", h.beta.toFixed(2), h.beta > 1.2 ? "high octane" : h.beta < 0.6 ? "ballast" : "market-like"],
              ["P/E · Div", h.pe ? `${h.pe}×` : "—", h.divYield ? `${h.divYield}% yield` : "no payout"],
              ["Mkt cap", h.mktCap, h.region],
            ].map(([k, v, s]) => (
              <div key={k as string} className="rounded-2xl border border-white/[0.07] bg-white/[0.03] p-3"><div className="text-[10px] font-bold tracking-[0.14em] text-white/35 uppercase">{k}</div><div className="mono-num mt-1 truncate text-[14.5px] font-bold">{v}</div><div className="truncate text-[11px] text-white/40">{s}</div></div>
            ))}
          </div>

          <div className="rounded-2xl border border-[#cdf138]/20 bg-gradient-to-b from-[#cdf138]/[0.07] to-transparent p-4">
            <div className="flex items-center gap-2 text-[11px] font-bold tracking-[0.18em] text-[#cdf138] uppercase"><Star size={13} /> Why you own it</div>
            <p className="mt-2 text-[13.5px] leading-relaxed text-white/75">{h.thesis}</p>
            <div className="mt-3 grid gap-2 sm:grid-cols-2">
              <div className="rounded-xl border border-white/[0.08] bg-black/25 p-3"><div className="text-[11px] font-bold text-emerald-300">▲ Next catalyst</div><div className="mt-1 text-[12.5px] text-white/70">{h.catalyst}</div></div>
              <div className="rounded-xl border border-white/[0.08] bg-black/25 p-3"><div className="text-[11px] font-bold text-rose-300">▼ Key risk</div><div className="mt-1 text-[12.5px] text-white/70">{h.risk}</div></div>
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="rounded-2xl border border-white/[0.07] bg-white/[0.02] p-4">
              <div className="flex items-center gap-2 text-[11px] font-bold tracking-[0.18em] text-white/40 uppercase"><Building2 size={13} /> Linked news</div>
              <div className="mt-2.5 space-y-2">
                {(rel.length ? rel : NEWS.slice(0, 2)).map((n) => <div key={n.t} className="rounded-xl bg-white/[0.04] p-2.5 text-[12.5px] leading-snug font-medium">{n.t}<div className="mt-1 text-[11px] font-normal text-white/40">{n.src} · {n.time} ago</div></div>)}
              </div>
            </div>
            <div className="rounded-2xl border border-white/[0.07] bg-white/[0.02] p-4">
              <div className="flex items-center gap-2 text-[11px] font-bold tracking-[0.18em] text-white/40 uppercase"><ArrowLeftRight size={13} /> Your trades</div>
              <div className="mt-2.5 space-y-2">
                {(txs.length ? txs : [{ d: "—", type: "HOLD", ticker: h.ticker, detail: "No recent trades", amount: 0 }]).map((t: { d: string; type: string; detail: string; amount: number }, i: number) => (
                  <div key={i} className="flex items-center justify-between rounded-xl bg-white/[0.04] px-3 py-2 text-[12px]"><span><b>{t.type}</b> <span className="text-white/45">· {t.detail}</span></span><span className="mono-num text-white/40">{t.d}</span></div>
                ))}
              </div>
              <div className="mt-3 flex items-center gap-2 text-[11.5px] text-white/40"><Globe2 size={13} /> Exposure: {h.region} · {h.ccy} <span className="ml-auto inline-flex items-center gap-1"><Coins size={12} /> Enriches Analysis →</span></div>
            </div>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}

import { useEffect } from "react";
function useEffectScrollLock(on: boolean) {
  useEffect(() => {
    if (on) { document.body.style.overflow = "hidden"; } else { document.body.style.overflow = ""; }
    return () => { document.body.style.overflow = ""; };
  }, [on]);
}
